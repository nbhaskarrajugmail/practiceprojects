-- 
-- *****************************
-- Name :Anusha Bheemunipalli
-- Date : 16-Oct-2020
-- Iteration :  ADFIB5.5.7.3
-- Reference : request_id = IBF-17899
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedProcessClassName',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedProcessClassName'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedProcessClassName';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedPreprocessClassName',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedPreprocessClassName'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedPreprocessClassName';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedPostprocessClassName',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedPostprocessClassName'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedPostprocessClassName';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedPageSize',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedPageSize'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedPageSize';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedNumberOfThreads',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedNumberOfThreads'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedNumberOfThreads';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedCommitPolicy',
       BFKEY = 'ScheduleUpdateBatchprocess.requestedCommitPolicy'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedCommitPolicy';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.requestedBOName',
       BFKEY = 'ScheduleUpdateBatchProcess.requestedBOName'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.requestedBOName';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.maxpool',
       BFKEY = 'ScheduleUpdateBatchProcess.maxpool'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.maxpool';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.corepool',
       BFKEY = 'ScheduleUpdateBatchProcess.corepool'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.corepool';

UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFPROPIDPK = 'ScheduleUpdateBatchProcess.commitpolicy',
       BFKEY = 'ScheduleUpdateBatchProcess.commitpolicy'
WHERE BFPROPIDPK = 'ScheduleUpdateBatch.commitpolicy';

UPDATE BANKFUSION.BFTB_CONTENTIONCONTEXT
   SET BFCONTENTIONCONTEXTIDPK = 'ScheduleUpdateBatchProcess_batch',
       BFCONTEXT = 'ScheduleUpdateBatchProcess_batch'
WHERE BFCONTENTIONCONTEXTIDPK = 'ScheduleUpdateBatch_batch';

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_066.sql,v $', '$LastChangedRevision$', 'BFDATA');