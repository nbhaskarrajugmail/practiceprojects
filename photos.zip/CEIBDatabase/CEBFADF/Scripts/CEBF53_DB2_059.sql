-- 
-- *****************************
-- Name :Bhaskar
-- Date : 30-09-2020
-- Iteration :  ADFIB5.5.7.2
-- Reference : request_id = IBF-18376
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_RATE_INCREATE_NOT_ALLOWED_NORMAL_LOANS',44000331,0,0,' ','E_RATE_INCREATE_NOT_ALLOWED_NORMAL_LOANS','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000331','E_RATE_INCREATE_NOT_ALLOWED_NORMAL_LOANS','en_GB','Rate increase is not allowed in Normal Loan Process','Rate increase is not allowed in Normal Loan Process',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_059.sql,v $', '$LastChangedRevision$', 'BFDATA');