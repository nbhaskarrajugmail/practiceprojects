-- 
-- *****************************
-- Name :Bhaskar
-- Date : 24-08-2020
-- Iteration :  ADFIB5.5.10
-- Reference : request_id = IBF-17660
-- Schema : BF
-- Description : Menu Script for deal hold process 
-- Revision : $Id$
-- *****************************

delete from BANKFUSION.BFTB_CATEGORYRESRCE where BFRESOURCEID = 'CE_IB_HoldDeal_PRC';
INSERT INTO BANKFUSION.BFTB_CATEGORYRESRCE
(
  BFCATEGORYRESOURCEIDPK,
  BFCATEGORYID,
  BFRESOURCEID,
  BFRESOURCENAME,
  BFSORTORDER,
  VERSIONNUM,
  BFAPPLICATIONID,
  BFNONNATIVEFLAG,
  BFNONNATIVEURL
)
VALUES
(
  '01173e6f36987654',
  'IslamicDealOrigination',
  'CE_IB_HoldDeal_PRC',
  'Deal Hold Process',
  152,
  0,
  'ADFIB',
  0,
  NULL
);




INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_038.sql,v $', '$LastChangedRevision$', 'BFDATA');

