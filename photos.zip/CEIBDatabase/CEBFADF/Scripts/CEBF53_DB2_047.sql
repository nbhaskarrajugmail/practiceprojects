-- 
-- *****************************
-- Name :Bhaskar
-- Date : 09-09-2020
-- Iteration :  ADFIB5.5.10
-- Reference : request_id = IBF-17878
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_ASSET_REGISTRY_AMOUNT_LESS',44000292,0,0,' ','E_ASSET_REGISTRY_AMOUNT_LESS','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000292','E_ASSET_REGISTRY_AMOUNT_LESS','en_GB','Selected Total Asset Registries Amount for {0} Should Be Lesser Than {1}','Selected Total Asset Registries Amount for {0} Should Be Lesser Than {1}',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_047.sql,v $', '$LastChangedRevision$', 'BFDATA');