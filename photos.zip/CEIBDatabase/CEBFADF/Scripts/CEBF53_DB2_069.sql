-- 
-- *****************************
-- Name : Amit KD
-- Date : 04-11-2020
-- Iteration : ADFIB 5.5.7.3
-- Reference : request_id = IBF-18405
-- Schema : BF
-- Description : script for eventcode
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE
(
  BFEVENTCODEIDPK,
  BFEVENTCODENUMBER,
  BFHANDLEABLE,
  BFCOLLECTIBLE,
  BFHANDLER,
  BFDESCRIPTION,
  BFSEVERITY,
  BFOVERIDESEVERITY,
  BFISREADONLY,
  BFHOSTMODULEID,
  BFUSERCONFIGURABLE,
  BFFRONTOFFICEID,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  'E_ASSET_CONF_EXIST',
  44000344,
  0,
  0,
  NULL,
  'E_ASSET_CONF_EXIST',
  'E',
  NULL,
  0,
  NULL,
  1,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);

INSERT INTO BFTB_EVENTCODEMSG
(
  BFEVENTCODEMESSAGEIDPK,
  BFEVENTCODEID,
  BFLOCALE,
  BFDESIGNTIMEMESSAGE,
  BFRUNTIMEMESSAGE,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  '44000344',
  'E_ASSET_CONF_EXIST',
  'en_GB',
  'The Configuration for the Selected Asset is already Exist.',
  'The Configuration for the Selected Asset is already Exist.',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);

---------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_069.sql,v $', '$LastChangedRevision$', 'BFDATA');