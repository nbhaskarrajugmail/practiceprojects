-- 
-- *****************************
-- Name :Ramachandra
-- Date : 14-08-2020
-- Iteration :  ADFIB5.5.10
-- Reference : request_id = IBF-18253
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_DEAL_HAS_NO_ACTIVE_INVOICE',44000267,0,0,' ','E_DEAL_HAS_NO_ACTIVE_INVOICE','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000267','E_DEAL_HAS_NO_ACTIVE_INVOICE','en_GB','Selected deal is not having with any active Sadad Invoice.','Selected deal is not having with any active Sadad Invoice.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_035.sql,v $', '$LastChangedRevision$', 'BFDATA');