-- 
-- *****************************
-- Name : Reshma Benny
-- Date : 08-10-2020
-- Iteration : ADFIB 5.5.7
-- Reference : request_id = IBF-18388
-- Schema : BF
-- Description : script for eventcode
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE
(
  BFEVENTCODEIDPK,
  BFEVENTCODENUMBER,
  BFHANDLEABLE,
  BFCOLLECTIBLE,
  BFHANDLER,
  BFDESCRIPTION,
  BFSEVERITY,
  BFOVERIDESEVERITY,
  BFISREADONLY,
  BFHOSTMODULEID,
  BFUSERCONFIGURABLE,
  BFFRONTOFFICEID,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  'E_REQUEST_CANNOT_BE_DELETED',
  44000337,
  0,
  0,
  NULL,
  'E_REQUEST_CANNOT_BE_DELETED',
  'E',
  NULL,
  0,
  NULL,
  1,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);


INSERT INTO BFTB_EVENTCODEMSG
(
  BFEVENTCODEMESSAGEIDPK,
  BFEVENTCODEID,
  BFLOCALE,
  BFDESIGNTIMEMESSAGE,
  BFRUNTIMEMESSAGE,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  '44000337',
  'E_REQUEST_CANNOT_BE_DELETED',
  'en_GB',
  'Collateral is existing for this request, cannot be deleted.',
  'Collateral is existing for this request, cannot be deleted.',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);

---------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_061.sql,v $', '$LastChangedRevision$', 'BFDATA');