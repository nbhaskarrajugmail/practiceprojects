-- 
-- *****************************
-- Name :Bhaskar
-- Date : 15-11-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-17893
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE',44000352,0,0,' ','E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000352','E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE','en_GB','Selected Total Assets Cost {0} should not be more than the Asset Final Cost {1}','Selected Total Assets Cost {0} should not be more than the Asset Final Cost {1}',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_076.sql,v $', '$LastChangedRevision$', 'BFDATA');