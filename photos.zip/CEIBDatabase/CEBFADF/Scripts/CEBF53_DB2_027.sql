-- 
-- *****************************
-- Name :Rama
-- Date : 16-07-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-18038
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_DEAL_NOT_ON_HOLD',44000253,0,0,' ','E_DEAL_NOT_ON_HOLD','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '57cfe2c30001ffff','E_DEAL_NOT_ON_HOLD','en_GB','Selected deal is not on hold.','Selected deal is not on hold.',0);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_027.sql,v $', '$LastChangedRevision$', 'BFDATA');