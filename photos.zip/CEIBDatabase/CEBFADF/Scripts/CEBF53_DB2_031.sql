-- 
-- *****************************
-- Name :Anusha Bheemunipalli
-- Date : 19-07-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-17880
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_PARTY_WITH_SAME_AGENT_SOURCE_CANNOT_BE_ADDED_IB',44000263,0,0,' ','E_PARTY_WITH_SAME_AGENT_SOURCE_CANNOT_BE_ADDED_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000263','E_PARTY_WITH_SAME_AGENT_SOURCE_CANNOT_BE_ADDED_IB','en_GB','Party {0} with same Agent Source {1} is already added.','Party {0} with same Agent Source {1} is already added.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_031.sql,v $', '$LastChangedRevision$', 'BFDATA');