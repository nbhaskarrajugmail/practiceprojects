-- 
-- *****************************
-- Name :Anusha Bheemunipalli
-- Date : 03-09-2020
-- Iteration :  ADFIB5.5.10
-- Reference : request_id = IBF-17872
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_PERCENTAGE_CANNOT_BE_NEG_CEIB',44000282,0,0,' ','E_PERCENTAGE_CANNOT_BE_NEG_CEIB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000282','E_PERCENTAGE_CANNOT_BE_NEG_CEIB','en_GB','Upfront Profit Percentage cannot be less than zero and greather than hundred.','Upfront Profit Percentage cannot be less than zero and greather than hundred.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_044.sql,v $', '$LastChangedRevision$', 'BFDATA');