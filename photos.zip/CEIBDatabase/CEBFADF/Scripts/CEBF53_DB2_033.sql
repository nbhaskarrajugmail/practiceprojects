-- 
-- *****************************
-- Name :Ramachandra
-- Date : 04-08-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-17881
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_CANNOT_DELETE_SADAD_INVOICE',44000265,0,0,' ','E_CANNOT_DELETE_SADAD_INVOICE','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000265','E_CANNOT_DELETE_SADAD_INVOICE','en_GB','The Sadad Invoice for the fee {0} cannot be deleted.','The Sadad Invoice for the fee {0} cannot be deleted.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_033.sql,v $', '$LastChangedRevision$', 'BFDATA');