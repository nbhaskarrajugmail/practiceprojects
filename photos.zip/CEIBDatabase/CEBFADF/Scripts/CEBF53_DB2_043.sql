-- 
-- *****************************
-- Name :Saba Nayyar
-- Date : 01-Sept-2020
-- Iteration :  ADFIB5.5.7.X
-- Reference : request_id = IBF-17895
-- Schema : BF
-- Description : Menu Script for Follow Up Assignment Sheet 
-- Revision : $Id$
-- *****************************

delete from BANKFUSION.BFTB_CATEGORYRESRCE where BFRESOURCEID = 'CE_IB_FollowUpAssignmentConf_PRC';

INSERT INTO BANKFUSION.BFTB_CATEGORYRESRCE
(
  BFCATEGORYRESOURCEIDPK,
  BFCATEGORYID,
  BFRESOURCEID,
  BFRESOURCENAME,
  BFSORTORDER,
  VERSIONNUM,
  BFAPPLICATIONID,
  BFNONNATIVEFLAG,
  BFNONNATIVEURL
)
VALUES
( 
  '02fvs469cg62bj90D',
  'SystemConfiguration',
  'CE_IB_FollowUpAssignmentConf_PRC',
  'Follow Up Assignment Sheet',
  1,
  0,
  'ADFIB',
  0,
  NULL
);



INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_043.sql,v $', '$LastChangedRevision$', 'BFDATA');

