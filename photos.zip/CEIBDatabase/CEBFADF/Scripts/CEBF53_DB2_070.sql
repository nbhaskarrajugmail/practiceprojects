-- ============================================================
-- Menu item for Pricing Engine Configuration
-- ============================================================
DELETE
FROM BFTB_CATEGORYRESRCE
WHERE BFRESOURCEID = 'CE_IB_PricingEngineConfiguration_PRC';

INSERT INTO BFTB_CATEGORYRESRCE
(
  BFCATEGORYRESOURCEIDPK,
  BFCATEGORYID,
  BFRESOURCEID,
  BFRESOURCENAME,
  BFSORTORDER,
  VERSIONNUM,
  BFAPPLICATIONID,
  BFNONNATIVEFLAG,
  BFNONNATIVEURL
)
VALUES
(
  '93a5c50100011c82',
  'BusinessConfiguration',
  'CE_IB_PricingEngineConfiguration_PRC',
  'Pricing Engine Configuration',
  1,
  0,
  'ADFIB',
  0,
  NULL
);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE)
    VALUES ('$RCSfile: CEBF53_DB2_070.sql,v $', '$LastChangedRevision$', 'BFDATA');