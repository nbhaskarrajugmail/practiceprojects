-- 
-- *****************************
-- Name :Anusha
-- Date : 10-10-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17567
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_ATLEAST_ONE_FOLLOWUP_DTL_REQ_IB',44000232,0,0,' ','E_ATLEAST_ONE_FOLLOWUP_DTL_REQ_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( 'a8bdd5f800135778','E_ATLEAST_ONE_FOLLOWUP_DTL_REQ_IB','en_GB','Atleast one followUpDetails object is needed.','Atleast one followUpDetails object is needed.',0);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_020.sql,v $', '$LastChangedRevision$', 'BFDATA');