-- 
-- *****************************
-- Name :Anusha Bheemunipalli
-- Date : 15-07-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-17880
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_ID_ENTERED_IS_NOT_VALID',44000249,0,0,' ','E_ID_ENTERED_IS_NOT_VALID','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '336d18c7000124f2','E_ID_ENTERED_IS_NOT_VALID','en_GB','ID that has been entered is not valid.','ID that has been entered is not valid.',0);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_026.sql,v $', '$LastChangedRevision$', 'BFDATA');