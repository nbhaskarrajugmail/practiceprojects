-- 
-- *****************************
-- Name :Anusha
-- Date : 10-10-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17567
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_ONLY_ONE_FOLLOWUP_IB',44000231,0,0,' ','E_ONLY_ONE_FOLLOWUP_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( 'a8bdd4f800135778','E_ONLY_ONE_FOLLOWUP_IB','en_GB','Only one followup details can be added.','Only one followup details can be added.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_019.sql,v $', '$LastChangedRevision$', 'BFDATA');