-- 
-- *****************************
-- Name :Supriya Kolamala
-- Date : 09-21-2020
-- Iteration :  ADFIB5.5.10
-- Reference : request_id = IBF-18309
-- Schema : BF
-- Description : Validation Event Codes 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_HOST_AMOUNTS_CHANGE_CEIB',44000313,0,0,' ','E_HOST_AMOUNTS_CHANGE_CEIB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '44000313','E_HOST_AMOUNTS_CHANGE_CEIB','en_GB','Cannot proceed with Reschedule as there is change in Outstanding Principal or Profit','Cannot proceed with Reschedule as there is change in Outstanding Principal or Profit',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_053.sql,v $', '$LastChangedRevision$', 'BFDATA');