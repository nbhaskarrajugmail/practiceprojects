-- 
-- *****************************
-- Name : Supriya Kolamala
-- Date : 12-11-2020
-- Iteration : ADFIB 5.5.7
-- Reference : request_id = IBF-18437
-- Schema : BF
-- Description : script for eventcode
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE
(
  BFEVENTCODEIDPK,
  BFEVENTCODENUMBER,
  BFHANDLEABLE,
  BFCOLLECTIBLE,
  BFHANDLER,
  BFDESCRIPTION,
  BFSEVERITY,
  BFOVERIDESEVERITY,
  BFISREADONLY,
  BFHOSTMODULEID,
  BFUSERCONFIGURABLE,
  BFFRONTOFFICEID,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  'E_REFUND_HOST_AMOUNTS_CHANGE_CEIB',
  44000351,
  0,
  0,
  NULL,
  'E_REFUND_HOST_AMOUNTS_CHANGE_CEIB',
  'E',
  NULL,
  0,
  NULL,
  1,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);


INSERT INTO BFTB_EVENTCODEMSG
(
  BFEVENTCODEMESSAGEIDPK,
  BFEVENTCODEID,
  BFLOCALE,
  BFDESIGNTIMEMESSAGE,
  BFRUNTIMEMESSAGE,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  '44000351',
  'E_REFUND_HOST_AMOUNTS_CHANGE_CEIB',
  'en_GB',
  'Cannot proceed with Refund Reschedule Profit as there is change in Outstanding Principal or Profit',
  'Cannot proceed with Refund Reschedule Profit as there is change in Outstanding Principal or Profit',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);
---------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_075.sql,v $', '$LastChangedRevision$', 'BFDATA');