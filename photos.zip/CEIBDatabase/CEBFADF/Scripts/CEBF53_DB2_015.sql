-- 
-- *****************************
-- Name :Anusha
-- Date : 13-09-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17392
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

UPDATE BANKFUSION.BFTB_EVENTCODEMSG
SET BFDESIGNTIMEMESSAGE = 'Deal cannot be recalled, as there is no Negative followup initiated before {0} days.',
    BFRUNTIMEMESSAGE = 'Deal cannot be recalled, as there is no Negative followup initiated before {0} days.'
WHERE BFEVENTCODEID = 'E_DEAL_CANNOT_BE_RECALLED_IB';

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_015.sql,v $', '$LastChangedRevision$', 'BFDATA');
