-- ============================================================
-- Event code description update
-- ============================================================
UPDATE BFTB_EVENTCODEMSG
   SET BFDESIGNTIMEMESSAGE = 'Relationship type وكيل متضامن linking is mandatory for female loan applicant.',
       BFRUNTIMEMESSAGE = 'Relationship type وكيل متضامن linking is mandatory for female loan applicant.'
WHERE BFEVENTCODEMESSAGEIDPK = '44000328';

UPDATE BFTB_EVENTCODEMSG
   SET BFDESIGNTIMEMESSAGE = 'The customer is linked with Split document title deed.',
       BFRUNTIMEMESSAGE = 'The customer is linked with Split document title deed.'
WHERE BFEVENTCODEMESSAGEIDPK = '44000327';


-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE)
    VALUES ('$RCSfile: CEBF53_DB2_071.sql,v $', '$LastChangedRevision$', 'BFDATA');