UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFVALUE = 'com.ce.bankfusion.ib.fatom.CEDealInitiationPanelInfoProvider'
WHERE BFPROPIDPK = 'DealInitiationPanelProvider';
