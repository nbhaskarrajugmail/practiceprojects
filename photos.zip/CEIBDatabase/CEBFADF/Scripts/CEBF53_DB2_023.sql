-- 
-- *****************************
-- Name :Rama
-- Date : 09-07-2020
-- Iteration :  ADFIB5.5.7
-- Reference : request_id = IBF-18038
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_DEAL_ON_HOLD_IB',44000242,0,0,' ','E_DEAL_ON_HOLD_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( '336d18c7000124e0','E_DEAL_ON_HOLD_IB','en_GB','Cannot proceed as the deal is on hold due to {0}.','Cannot proceed as the deal is on hold due to {0}.',0);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_023.sql,v $', '$LastChangedRevision$', 'BFDATA');