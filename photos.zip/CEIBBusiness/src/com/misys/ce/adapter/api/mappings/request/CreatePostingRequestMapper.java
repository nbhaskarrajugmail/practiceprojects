package com.misys.ce.adapter.api.mappings.request;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.adapter.api.mappings.common.IRequestMapper;
import com.misys.ib.adapter.common.AdaptorUtil;
import com.misys.ib.adapter.common.MapperConstants;
import com.misys.ib.adapter.commons.PropertyUtils;

import bf.com.misys.financialposting.types.AccountPseudonym;
import bf.com.misys.financialposting.types.Amount;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRq;
import bf.com.misys.financialposting.types.ChargeKeyDtls;
import bf.com.misys.financialposting.types.EventChargeCalculationDetail;
import bf.com.misys.financialposting.types.EventChargeDetail;
import bf.com.misys.financialposting.types.EventChargeTaxDetail;
import bf.com.misys.financialposting.types.FxInfo;
import bf.com.misys.financialposting.types.PostingLeg;
import bf.com.misys.financialposting.types.TxnDetails;
import bf.com.misys.ib.spi.types.AccountEntries;
import bf.com.misys.ib.spi.types.messages.PostAccountEntriesRq;

public class CreatePostingRequestMapper implements IRequestMapper {

    @Override
    public Object convert(Object data) {
        PostAccountEntriesRq accountingEntires = (PostAccountEntriesRq) data;
        BackOfficeAccountPostingRq accountPostingRq = new BackOfficeAccountPostingRq();
        accountPostingRq.setBackOfficePostingLegs(getBackOfficePostingLegs(accountingEntires.getAccountingEntries(),(String)accountingEntires.getExtensionDetails().getUserExtension()));
        accountPostingRq.setEventCharges(getEventCharges(accountingEntires.getAccountingEntries()));
        accountPostingRq.setSrvVersion(CommonConstants.EMPTY_STRING);
        accountPostingRq.setTxnDetails(getTxnDetails(accountingEntires.getAccountingEntries()));

        return accountPostingRq;

    }

    private EventChargeDetail[] getEventCharges(AccountEntries accountEntries) {

        EventChargeDetail[] chargeDetails = new EventChargeDetail[accountEntries.getAccountEntriesCount()];
        for (int i = 0; i < accountEntries.getAccountEntriesCount(); i++) {
            chargeDetails[i] = (EventChargeDetail) AdaptorUtil.intializeDefaultvalues(new EventChargeDetail());
            EventChargeTaxDetail[] chgTaxAmtDetails = new EventChargeTaxDetail[1];
            EventChargeCalculationDetail chgAmtCalcDetails = (EventChargeCalculationDetail) AdaptorUtil
                    .intializeDefaultvalues(new EventChargeCalculationDetail());
            Amount totalChgAmt = (Amount) AdaptorUtil.intializeDefaultvalues(new Amount());
            chgAmtCalcDetails.setChargeAmount(totalChgAmt);
            chgAmtCalcDetails.setChgAmtAcctCur(totalChgAmt);
            chgAmtCalcDetails.setChgAmtFundAcctCur(totalChgAmt);
            chgAmtCalcDetails.setChgAmtTxnCur(totalChgAmt);
            FxInfo chgExchRateDetails = (FxInfo) AdaptorUtil.intializeDefaultvalues(new FxInfo());
            chgAmtCalcDetails.setChgExchRateDetails(chgExchRateDetails);
            ChargeKeyDtls onlineChgKeyDtls = (ChargeKeyDtls) AdaptorUtil.intializeDefaultvalues(new ChargeKeyDtls());

            chgAmtCalcDetails.setOnlineChgKeyDtls(onlineChgKeyDtls);
            for (int j = 0; j < 1; j++) {
                chgTaxAmtDetails[j] = (EventChargeTaxDetail) AdaptorUtil.intializeDefaultvalues(new EventChargeTaxDetail());

                chgTaxAmtDetails[j].setChgAmtCalcDetails(chgAmtCalcDetails);
                chgTaxAmtDetails[j].setOriginalChgAmtCalcDetails(chgAmtCalcDetails);
                chgTaxAmtDetails[j].setOriginalTaxAmtCalcDetails(chgAmtCalcDetails);
                chgTaxAmtDetails[j].setTaxAmtCalcDetails(chgAmtCalcDetails);
            }

            chargeDetails[i].setChgTaxAmtDetails(chgTaxAmtDetails);
            // chargeDetails[i].setFundingAccount(fundingAccount);

            chargeDetails[i].setTotalChgAmt(totalChgAmt);
            Amount totalChgTaxAmt = (Amount) AdaptorUtil.intializeDefaultvalues(new Amount());
            chargeDetails[i].setTotalChgTaxAmt(totalChgTaxAmt);
            Amount totalTaxAmt = (Amount) AdaptorUtil.intializeDefaultvalues(new Amount());
            chargeDetails[i].setTotalTaxAmt(totalTaxAmt);
        }

        return chargeDetails;
    }

    private TxnDetails getTxnDetails(AccountEntries accountEntries) {
        TxnDetails details = (TxnDetails) AdaptorUtil.intializeDefaultvalues(new TxnDetails());
        details.setTransactionId(accountEntries.getAccountEntries(0).getTxnID()); // TODO doubt of
                                                                                  // ORIGIN in map
                                                                                  // doc
        details.setTransactionReference(accountEntries.getAccountEntries(0).getTxnReference());
        details.setValueDate(accountEntries.getAccountEntries(0).getValueDate());
        details.setBranchSortCode(accountEntries.getAccountEntries(0).getMainBranchCode());
        details.setForcePost(accountEntries.getAccountEntries(0).getIsForcePostTxn());
        details.setChannelId(BankFusionThreadLocal.getSourceId());

        return details;
    }

    private PostingLeg[] getBackOfficePostingLegs(AccountEntries accountEntries,String dealID) {
        PostingLeg[] postingLegs = new PostingLeg[accountEntries.getAccountEntriesCount()];
        String loanAccountID = IBCommonUtils.getDealDetails(dealID).getF_DealAccountId();
        if(loanAccountID.equals(CommonConstants.EMPTY_STRING))
        	loanAccountID = dealID;
        
        for (int i = 0; i < accountEntries.getAccountEntriesCount(); i++) {
            postingLegs[i] = (PostingLeg) AdaptorUtil.intializeDefaultvalues(new PostingLeg());
            if (accountEntries.getAccountEntries(i).getAccountFormatType().equals(MapperConstants.ACCOUNT_FORMAT_TYPE)) {
                postingLegs[i].setAccountId(accountEntries.getAccountEntries(i).getAccount());
            }
            else if (accountEntries.getAccountEntries(i).getAccountFormatType().equals(MapperConstants.PSEUDONYM_FORMAT_TYPE)) {

                postingLegs[i].setAccountId((String) AdaptorUtil.getPsedonymInternalAcc(accountEntries.getAccountEntries(i)
                        .getAccount(), PropertyUtils.getContextForPseudonym(), accountEntries.getAccountEntries(i)
                        .getMainBranchCode(), accountEntries.getAccountEntries(i).getTxnCurrencyCode()));
            }

            // postingLegs[i].setAccountId(accountEntries.getAccountEntries(i).getAccount());
            AccountPseudonym accountPseudonym = (AccountPseudonym) AdaptorUtil.intializeDefaultvalues(new AccountPseudonym());

            /*
             * accountPseudonym.setPseudonym(accountEntries.getAccountEntries(i).getAccount());
             * accountPseudonym.setContext(PropertyUtils.getContextForPseudonym());
             * accountPseudonym.setContextValue("99999999");
             */

            postingLegs[i].setAccountPseudonym(accountPseudonym);

            postingLegs[i].setTransactionCurrency(accountEntries.getAccountEntries(i).getTxnCurrencyCode());
            postingLegs[i].setAmount(accountEntries.getAccountEntries(i).getTxnAmount().getAmountEdited());

            postingLegs[i].setCreditDebitIndicator(accountEntries.getAccountEntries(i).getPostingAction());
            if ("C".equals(postingLegs[i].getCreditDebitIndicator())) {
                postingLegs[i].setTransactionCode(PropertyUtils.getDefaultCreditTransactionCode());

            }
            else {
                postingLegs[i].setTransactionCode(PropertyUtils.getDefaultDebitTransactionCode());

            }
            // String narratives=
            // (accountEntries.getAccountEntries(i).getNarrativeDetails().getNarrativeLine1()).concat(accountEntries.getAccountEntries(i).getNarrativeDetails().getNarrativeLine2()).concat(accountEntries.getAccountEntries(i).getNarrativeDetails().getNarrativeLine3()).concat(accountEntries.getAccountEntries(i).getNarrativeDetails().getNarrativeLine4());
            postingLegs[i].setNarrative(loanAccountID+"$"+accountEntries.getAccountEntries(i).getDescription());
            FxInfo amountToBaseEquivalentFxDetail = (FxInfo) AdaptorUtil.intializeDefaultvalues(new FxInfo());
            amountToBaseEquivalentFxDetail.setExchangeRateType(accountEntries.getAccountEntries(i).getExchangeRateType());
            amountToBaseEquivalentFxDetail.setMultiplyDivide(accountEntries.getAccountEntries(i).getRoundingMethod());
            postingLegs[i].setAmountToBaseEquivalentFxDetail(amountToBaseEquivalentFxDetail);
            postingLegs[i].setBaseEquivalentAmount(accountEntries.getAccountEntries(i).getBaseEquivalent().getAmountEdited());

        }

        return postingLegs;
    }

}