package com.ce.ib.processManagement;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.fatom.IssuePOFatom;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class IssuePaymentOrderProcess extends AbstractIslamicProcessManager {
	private static final Integer E_ISSUE_PO_NOT_ALLOWED_NO_LOAN_ACC_IB = 44000403;
	private static final String STATUS_NEW = "New";
	private static final String STATUS_APPROVED = "Approved";
	private static String GET_PO_BY_DEAL_QUERY = " WHERE " + IBOCE_IB_IssuePODetail.IBDEALID + " = ? AND ("
			+ IBOCE_IB_IssuePODetail.IBSTATUS + " = ? OR "+ IBOCE_IB_IssuePODetail.IBSTATUS + " = ?)";
	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		if (status.equals(IBConstants.DECISION_REJECTED) || status.equals(IBConstants.DECISION_CANCELLED)) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(islamicBankingObject.getDealID());
			params.add(STATUS_NEW);
			params.add(STATUS_APPROVED);
			List<IBOCE_IB_IssuePODetail> issuePoList = factory
					.findByQuery(IBOCE_IB_IssuePODetail.BONAME, GET_PO_BY_DEAL_QUERY, params, null, true);
			if (issuePoList != null && !issuePoList.isEmpty()) {
				String purchaseOrderID = issuePoList.get(0).getF_IBPURCHASEORDERID();
				IssuePOFatom.deleteIssuePO(purchaseOrderID);
				IssuePOFatom.deleteIssuePOAssetDetails(purchaseOrderID);
				IssuePOFatom.deleteIssuePOLiabilityDetails(purchaseOrderID);
				IssuePOFatom.deleteIssuePOPaymentDetails(purchaseOrderID);
			}
		}

		return true;
	}

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}
	@Override
    public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		if(dealDetails!=null && dealDetails.getF_DealAccountId().equals(CommonConstants.EMPTY_STRING)) {
			IBCommonUtils.raiseUnparameterizedEvent(E_ISSUE_PO_NOT_ALLOWED_NO_LOAN_ACC_IB);
		}
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(islamicBankingObject.getDealID());
		params.add(STATUS_NEW);
		params.add(STATUS_APPROVED);
		List<IBOCE_IB_IssuePODetail> issuePOList = factory
				.findByQuery(IBOCE_IB_IssuePODetail.BONAME, GET_PO_BY_DEAL_QUERY, params, null, true);
		if (issuePOList != null && !issuePOList.isEmpty()) {
			IBCommonUtils.raiseUnparameterizedEvent(44000400);
		}
    	
    }
}
