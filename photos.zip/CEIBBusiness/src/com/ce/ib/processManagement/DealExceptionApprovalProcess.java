package com.ce.ib.processManagement;

import org.apache.commons.lang.StringUtils;

import com.misys.bankfusion.common.GUIDGen;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;

public class DealExceptionApprovalProcess extends AbstractIslamicProcessManager{

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return StringUtils.isBlank(transactionID) ? GUIDGen.getNewGUID() : transactionID;
	}

}
