package com.ce.ib.processManagement;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;

public class DealRescheduleProcess extends AbstractIslamicProcessManager {

	private static final Log LOGGER = LogFactory.getLog(DealRescheduleProcess.class.getName());

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {

		IBOCE_IB_DealReschedule reschObj = (IBOCE_IB_DealReschedule) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, islamicBankingObject.getTransactionID(), true);

		if (reschObj != null) {
			IBOIB_CFG_StepDetails stepDetailsObj = IBCommonUtils.getStepDetails(islamicBankingObject.getStepID(),
					islamicBankingObject.getProcessConfigID());
			if (stepDetailsObj == null) {
				stepDetailsObj = IBCommonUtils.getStepDetails(islamicBankingObject.getStepID());
			}
			if (!reschObj.getF_IBRESCHEDULESTATUS().equals(RescheduleConstants.STATUS_COMPLETED)
					&& !IBCommonUtils.isNullOrEmpty(status)) {
				reschObj.setF_IBRESCHEDULESTATUS(status);
				reschObj.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
				reschObj.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
			}
			if (stepDetailsObj != null && stepDetailsObj.getF_STEPTYPE().equals(IBConstants.STEP_TYPE_APPROVAL)
					&& status.equals(IBConstants.DECISION_APPROVED)) {
				reschObj.setF_IBRECAPPROVEDBY(IBCommonUtils.getUserId());
				reschObj.setF_IBRECAPPROVEDDATE(IBCommonUtils.getBFBusinessDateTime());
			}
			return true;

		}
		return false;
	}

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return IBCommonUtils.generateCBSID("IB_DEAL_RESCHL_ID");
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		IBOCE_IB_REFUNDRESCHDTLS RefundReschProfitActiveReq = RescheduleUtils
				.getRefundReschProfitActiveReq(islamicBankingObject.getDealID());
		if (null != RefundReschProfitActiveReq
				&& !RefundReschProfitActiveReq.getBoID().equals(islamicBankingObject.getTransactionID())) {
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_REFUND_RESCH_REQ_EXISTS_CEIB);
		}
		RescheduleUtils.validateMultipleRequests(islamicBankingObject.getDealID());

		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getLoanBasicDetails()
				.getTotalDisbursementAmount().compareTo(BigDecimal.ZERO) == 0) {
			 IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCHEDULE_DISBURSE_AMOUNT_ZERO_CEIB);
		}
		//commenting to allow partial disbursed reschedule
		/*if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getLoanBasicDetails()
				.getTotalDisbursementAmount().compareTo(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt()) != 0) {
			 IBCommonUtils.raiseUnparameterizedEvent(35100467);
		}*/
	}
}
