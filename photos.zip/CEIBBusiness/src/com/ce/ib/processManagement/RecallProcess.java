/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import java.sql.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.servercommon.expression.builder.functions.SubtractDateFromDate;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;

public class RecallProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(RecallProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		return false;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of RecallProcess" + islamicBankingObject.getDealID());
		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());
		EarlyAssetPayoffUtils.validateRecallMultipleRequests(islamicBankingObject.getDealID());
		EarlyAssetPayoffUtils.validateArrearDeal(readLoanDetailsRs);
		
		IBOCE_IB_DealFollowUpDtls dealFollowUpDtls = DealFollowUpUtils
				.getPreviousFollowUpDtls(islamicBankingObject.getDealID());
		String[] msgArgs = { String.valueOf(DealFollowUpUtils.getFollowUpPeriodConfigured()) };
		if (dealFollowUpDtls != null) {
			if (dealFollowUpDtls.getF_IBFOLLOWUPSTATUS().equals(CeConstants.FOLLOWUP_STATUS_NEGATIVE)) {
				Date followUpdate = new Date(dealFollowUpDtls.getF_IBFOLLOWUPDATE().getTime());
				int diffInDays = SubtractDateFromDate.run(IBCommonUtils.getBFBusinessDate(), followUpdate);
				if (diffInDays <= DealFollowUpUtils.getFollowUpPeriodConfigured()) {
					IBCommonUtils.raiseParametrizedEvent(CeConstants.E_DEAL_CANNOT_BE_RECALLED_IB, msgArgs);
				} else {
					//validating if there is any asset exists for Recall
					EarlyAssetPayoffUtils.validateNoOfAssetsForRecall(islamicBankingObject.getDealID());
				}
			} else {
				IBCommonUtils.raiseParametrizedEvent(CeConstants.E_DEAL_CANNOT_BE_RECALLED_IB, msgArgs);
			}
		} else {
			IBCommonUtils.raiseParametrizedEvent(CeConstants.E_DEAL_CANNOT_BE_RECALLED_IB, msgArgs);
		}
		logger.info("Exiting validateProcessDetails of RecallProcess" + islamicBankingObject.getDealID());
	}
}
