/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;

public class DealFollowUpProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(DealFollowUpProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		return false;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of DealFollowUpProcess" + islamicBankingObject.getDealID());
		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());

		// Follow up cannot be initiated if deal is fully satisfied or closed
		DealFollowUpUtils.validateIfDealIsFullySatsfied(readLoanDetailsRs);

		// Follow up cannot be initiated if deal has any left over disbursements to be
		// done
		DealFollowUpUtils.validateIfDealIsNotCompletelyDisbursed(islamicBankingObject.getDealID(), readLoanDetailsRs);
		
		//validate if technical analysis is done for this deal
		DealFollowUpUtils.validateIfTechAnalysisIsDone(islamicBankingObject.getDealID());

		// Follow up cannot be initiated if deal has any follow up negative already
		// exists and which is before the configured period
		DealFollowUpUtils.isFollowUpInProgressExist(islamicBankingObject.getDealID());

		// Follow up cannot be initiated, if followup is assigned to different user
		DealFollowUpUtils.validateUserAssignedToDealFollowup(islamicBankingObject.getDealID());

		// Once all above conditions satisfies, change the current followup status to In
		// Progress in follow up configuration
		DealFollowUpUtils.updateFollowUpStatus(islamicBankingObject.getDealID());

		logger.info("Exiting validateProcessDetails of DealFollowUpProcess" + islamicBankingObject.getDealID());
	}
}
