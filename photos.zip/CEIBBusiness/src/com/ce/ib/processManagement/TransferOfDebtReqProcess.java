/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class TransferOfDebtReqProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(TransferOfDebtReqProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of TransferOfDebtReqProcess" + islamicBankingObject.getDealID());
		String s1 ="";
//		TODO:Chethan BN Get the Error message details from Amr and update here
//		if (!com.ce.bankfusion.ib.util.TransferOfDebtReqUtils.isDealActive(islamicBankingObject.getDealID())) {
//			String[] msgArgs = { islamicBankingObject.getDealID() };
//			com.misys.bankfusion.util.IBCommonUtils.raiseUnparameterizedEvent(40310433);
//		}
		if (!com.ce.bankfusion.ib.util.TransferOfDebtReqUtils.isArrearDeal(islamicBankingObject.getDealID())) {
			com.misys.bankfusion.util.IBCommonUtils.raiseUnparameterizedEvent(44000407);
		}
		logger.info("Exiting validateProcessDetails of TransferOfDebtReqProcess" + islamicBankingObject.getDealID());
	}
}
