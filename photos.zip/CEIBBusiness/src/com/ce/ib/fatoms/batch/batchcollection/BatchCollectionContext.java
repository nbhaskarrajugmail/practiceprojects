package com.ce.ib.fatoms.batch.batchcollection;

import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

public class BatchCollectionContext extends AbstractPersistableFatomContext {

	private static String batchProcessName = "ADFBatchCollection";
    private Object[] additionalProcessParams;
    private Map inputTagDataMap;
	private static final String PROCESS_CLASSNAME = loadProcessClassName("ADFBatchCollection", "");

    public BatchCollectionContext() {
    }

    public BatchCollectionContext(String batchProcessName) {
        this.batchProcessName = batchProcessName;
        this.additionalProcessParams = new Object[3];
    }

    /**
     * Returns the full name of the processing class that workers will load.
     * 
     * @return PROCESS_CLASSNAME.
     * @see com.trapedza.bankfusion.batch.fatom.AbstractFatomContext#getProcessClassName()
     */
    public String getProcessClassName() {
        return loadProcessClassName(getBatchProcessName(), PROCESS_CLASSNAME);
    }

    @Override
    public boolean isMultiNodeSupported() {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public Object[] getAdditionalProcessParams() {
        return additionalProcessParams;
    }

    @Override
    public String getBatchProcessName() {
        // TODO Auto-generated method stub
        return batchProcessName;
    }

    @Override
    public Map getInputTagDataMap() {
    	return inputTagDataMap;
    }

    @Override
    public Map getOutputTagDataMap() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setAdditionalProcessParams(Object[] arg0) {
        additionalProcessParams = arg0;

    }

    @Override
    public void setBatchProcessName(String arg0) {
        batchProcessName = arg0;
    }

    @Override
    public void setInputTagDataMap(Map inDataMap) {
    	this.inputTagDataMap = inDataMap;

    }

    @Override
    public void setOutputTagDataMap(Map arg0) {
        // TODO Auto-generated method stub

    }

}
