package com.ce.ib.fatoms.batch.batchcollection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchCollTag;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_BatchCollectionBatch;
import com.ce.financialgateway.BatchCollectionConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.batch.mbean.impl.BatchServiceUtil;
import com.misys.cbs.common.util.log.CBSLogger;
import com.misys.cbs.config.ModuleConfiguration;
import com.misys.ub.fatoms.batch.BatchUtil;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.postingengine.gateway.interfaces.IPostingMessage;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.utils.GUIDGen;

public class BatchCollectionFatom extends AbstractCE_ADF_BatchCollectionBatch {

    private static final String BATCH_PROCESS_NAME = "ADFBatchCollection";

    private BankFusionEnvironment environment;
    private BatchCollectionContext batchCollectionContext;
    private IPersistenceObjectsFactory factory;

    private static final String CLASS_NAME = BatchCollectionFatom.class.getName();
    private static final transient CBSLogger LOGGER = new CBSLogger(CLASS_NAME);

    public BatchCollectionFatom(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    protected AbstractFatomContext getFatomContext() {
        return new BatchCollectionContext(BATCH_PROCESS_NAME);
    }

    @Override
    protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {
		LOGGER.info("ADFBatchCollectionFatom:process - Start");
		batchCollectionContext = (BatchCollectionContext) context;
		Map dataMap = getInDataMap();
		IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, getF_IN_batchReference(), true);
		String txnType = getF_IN_txnType();
		String debitAccountNumber = CommonConstants.EMPTY_STRING;
		if (txnType.equals(BatchCollectionConstants.TXN_TYPE_BANK)) {
			debitAccountNumber = getDebitAccountNumber(fileDtls.getF_BANKID());
		} else {
			debitAccountNumber = getF_IN_debitAccForGovt();
		}
		String creditAccountNumber = fileDtls.getF_INTERNALACC();
		String transactionID = GUIDGen.getNewGUID();

		String debitTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.debitTxnCode");
		String creditTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.creditTxnCode");
		dataMap.put("debitAccountNumber", debitAccountNumber);
		dataMap.put("creditAccountNumber", creditAccountNumber);
		dataMap.put("txnType", txnType);
		dataMap.put("transactionID", transactionID);
		dataMap.put("runningBalRecID", getF_IN_runningBalRecID());
		batchCollectionContext.setInputTagDataMap(dataMap);
		String runtimeBPID = env.getRuntimeMicroflowID();
		batchCollectionContext.setRuntimeBPID(runtimeBPID);
		batchCollectionContext.setBatchProcessName(context.getBatchProcessName());
		batchCollectionContext.setBatchSubmissionContext(context.getBPID());
        
        this.environment = env;
        Boolean status = null;

        if (!BatchServiceUtil.isBatchSubmitted(context)) {
        	this.factory = BankFusionThreadLocal.getPersistanceFactory();
        	factory.beginTransaction();
    		this.factory.bulkDeleteAll(IBOCE_ADF_BatchCollTag.BONAME);
    		this.factory.commitTransaction();
    		this.factory.beginTransaction();
    		String INSERT_SQL_QUERRY = CommonConstants.EMPTY_STRING;
            if(txnType.equals(BatchCollectionConstants.TXN_TYPE_BANK)) {
            	INSERT_SQL_QUERRY = "INSERT INTO CUSTOMEXTN.CETB_BATCHCOLLTAG(CEID,CEROWSEQPK,VERSIONNUM)"
                        + " SELECT CEIDPK,ROW_NUMBER() OVER(ORDER BY CEIDPK) CEROWSEQPK,0 VERSIONNUM FROM CUSTOMEXTN.CETB_BATCHTXNDETAIL "
                        + "  WHERE CEBATCHREF=?";
            }else {
             INSERT_SQL_QUERRY = "INSERT INTO CUSTOMEXTN.CETB_BATCHCOLLTAG(CEID,CEROWSEQPK,VERSIONNUM)"
                    + " SELECT CEIDPK,ROW_NUMBER() OVER(ORDER BY CEIDPK) CEROWSEQPK,0 VERSIONNUM FROM CUSTOMEXTN.CETB_BATCHTXNDETAIL "
                    + "  WHERE CEBATCHREF=? AND CESTATUS<>'PROCESSED' AND CEPROCESSING='Y'";
            }
            Connection connection = factory.getJDBCConnection();
            PreparedStatement preparedStatement = null;
            try {
                preparedStatement = connection.prepareStatement(INSERT_SQL_QUERRY);
                preparedStatement.setString(1, getF_IN_batchReference());
                preparedStatement.execute();
            }
            catch (SQLException sqlException) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error("processBatch()", sqlException.getLocalizedMessage());
                }
            }
            finally {
                try {
                    if (null != preparedStatement)
                        preparedStatement.close();
                }
                catch (SQLException e) {
                    LOGGER.error("processBatch()", "Error while closing prepared statement.", e);
                }
            }
            factory.commitTransaction();
            factory.beginTransaction();
        }
        if(txnType.equals(BatchCollectionConstants.TXN_TYPE_BANK)){

			
			List<IBOCE_ADF_BatchCollTag> batchCollectionList = factory.findAll(IBOCE_ADF_BatchCollTag.BONAME, null,
					true);
			ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
			IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(debitAccountNumber);
			IPostingMessage debitPostingMessage = BatchCollectionProcess.getFinPostingMessage(debitAccountDetails, debitAccountNumber, fileDtls.getF_AMNTTOPROCESS(),
					debitTxnCode, "-", transactionID, "", debitAccountNumber,getF_IN_batchReference(),SystemInformationManager.getInstance().getBFBusinessDate());
			postingMessageList.add(debitPostingMessage);
			for (IBOCE_ADF_BatchCollTag iboce_ADF_BatchCollTag : batchCollectionList) {
				IBOCE_BATCHTXNDETAIL batchTxnDetails = (IBOCE_BATCHTXNDETAIL) factory
						.findByPrimaryKey(IBOCE_BATCHTXNDETAIL.BONAME, iboce_ADF_BatchCollTag.getF_ID(), true);
				BigDecimal amount = batchTxnDetails.getF_AMOUNT();
				batchTxnDetails.setF_BATCHGWREF(creditAccountNumber);
				IBOAttributeCollectionFeature creditAccountDetails = FinderMethods.getAccountBO(creditAccountNumber);
				IPostingMessage creditPostingMessage = BatchCollectionProcess.getFinPostingMessage(creditAccountDetails, creditAccountNumber,
						amount, creditTxnCode, "+", transactionID, batchTxnDetails.getF_NARRATIVE(),
						creditAccountNumber,getF_IN_batchReference(),SystemInformationManager.getInstance().getBFBusinessDate());

				postingMessageList.add(creditPostingMessage);

			}
			try {
				BatchCollectionProcess.postTransaction(postingMessageList);
				factory.beginTransaction();
	    		this.factory.bulkDeleteAll(IBOCE_ADF_BatchCollTag.BONAME);
	    		this.factory.commitTransaction();
			} catch (Exception exception) {
				BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
				BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
				LOGGER.error("process()", "Error occured while processing the account : Error Message : " + BatchUtil.getExceptionAsString(exception));

				//updateFailedRecordProcessState(creditAccountNumber, exception);
			}
		
        }
        BatchService service = (BatchService) ServiceManager.getService(ServiceManager.BATCH_SERVICE);
        if (service.runBatch(environment, batchCollectionContext)) {
            status = Boolean.TRUE;
        }
        else {
            status = Boolean.FALSE;
        }
        setF_OUT_BATCH_STATUS(status);
        LOGGER.info("ADFBatchCollectionFatom:process - End");
    }

    @Override
    protected void setOutputTags(AbstractFatomContext arg0) {

    }
    private String getDebitAccountNumber(String bankID) {
		
		
		/*if (StringUtils.isEmpty(fileDtls.getF_INTERNALACC())) {
			return getSettlementAccount(fileDtls.getF_BANKID());
		} else {
			return fileDtls.getF_INTERNALACC();
		}*/
		return getSettlementAccount(bankID);
	}
    private String getSettlementAccount(String bankId) {
		String GET_SETTLEMENT_QUERY = "SELECT SETTLEMENTACCOUNT FROM "
				+ BankFusionPropertySupport.getProperty("System.DefaultSchema", "WASADMIN") + " .BANKS WHERE NSC = '"
				+ bankId + "'";
		ResultSet rs = null;
		try (PreparedStatement pstmt = BankFusionThreadLocal.getPersistanceFactory().getJDBCConnection()
				.prepareStatement(GET_SETTLEMENT_QUERY)) {
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			LOGGER.error("Error getting settlement account for other bank");
			throw new BankFusionException(e);
		} 
		return "";
	}
}
