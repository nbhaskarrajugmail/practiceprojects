package com.ce.ib.fatoms.batch.batchcollection;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class BatchCollectionAccumulator extends AbstractProcessAccumulator {

    /**
     * 
     */
    private static final long serialVersionUID = 7644648213176165111L;

    public BatchCollectionAccumulator(Object[] accumulatorArgs) {
        super(accumulatorArgs);
    }

    @Override
    public void addAccumulatorForMerging(AbstractProcessAccumulator arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void acceptChanges() {
        // TODO Auto-generated method stub

    }

    @Override
    public void accumulateTotals(Object[] arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public Object[] getMergedTotals() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Object[] getProcessWorkerTotals() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void mergeAccumulatedTotals(Object[] arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void restoreState() {
        // TODO Auto-generated method stub

    }

    @Override
    public void storeState() {
        // TODO Auto-generated method stub

    }
}
