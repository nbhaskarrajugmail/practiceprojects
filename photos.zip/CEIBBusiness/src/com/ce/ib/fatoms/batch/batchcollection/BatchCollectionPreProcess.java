package com.ce.ib.fatoms.batch.batchcollection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class BatchCollectionPreProcess implements IBatchPreProcess {

	private static final Log logger = LogFactory.getLog(BatchCollectionPreProcess.class);

	@Override
	public void init(BankFusionEnvironment arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void process(AbstractFatomContext ctx) {
		logger.debug("in pre-process");
		String debitTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.debitTxnCode");
		String creditTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.creditTxnCode");

		Object[] additionalParams = new Object[3];

		String suspenseAccount = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"suspenseAccount");
		additionalParams[0] = debitTxnCode;
		additionalParams[1] = creditTxnCode;
		additionalParams[2] = suspenseAccount;

		ctx.setAdditionalProcessParams(additionalParams);

	}
}
