package com.ce.ib.fatoms.batch.scheduleUpdateProcess;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * @author Anusha Bheemunipalli
 * 
 */
public class ScheduleUpdateBatchPostProcess implements IBatchPostProcess {

	IBatchStatus batchStatus = null;

	@SuppressWarnings("deprecation")
	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext context, IBatchStatus batchStatus) {
		this.batchStatus = batchStatus;
		env.getFactory().commitTransaction();
		env.getFactory().beginTransaction();
	}

	@Override
	public IBatchStatus process(AbstractProcessAccumulator arg0) {
		batchStatus.setStatus(true);
		return batchStatus;
	}
}
