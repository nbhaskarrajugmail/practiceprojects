package com.ce.ib.fatoms.batch.dealholdprocess;

import java.util.HashMap;
import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

/**
 * 
 * @author Bhaskar N
 * 
 */
public class DealHoldBatchFatomContext extends AbstractPersistableFatomContext {

    private static final long serialVersionUID = 1L;
    private String batchProcessName;

    private static final String PROCESS_CLASSNAME = loadProcessClassName("DealHoldBatchProcess",
            "com.ce.ib.fatoms.batch.dealholdprocess.DealHoldBatchProcess");

    private Map inputDataMap;

    public DealHoldBatchFatomContext(String batchProcessName) {
        this.batchProcessName = batchProcessName;
        super.setStatus(true);
    }

    public DealHoldBatchFatomContext() {

    }

    @Override
    public boolean isMultiNodeSupported() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Object[] getAdditionalProcessParams() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getBatchProcessName() {
        // TODO Auto-generated method stub
        return this.batchProcessName;
    }

    @Override
    public Map getInputTagDataMap() {
        // TODO Auto-generated method stub
        return inputDataMap;
    }

    @Override
    public Map getOutputTagDataMap() {
        // TODO Auto-generated method stub
        return new HashMap();
    }

    @Override
    public void setAdditionalProcessParams(Object[] arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void setBatchProcessName(String batchProcessName) {
        this.batchProcessName = batchProcessName;
    }

    @Override
    public void setInputTagDataMap(Map inputDataMap) {
        this.inputDataMap = inputDataMap;
    }

    @Override
    public void setOutputTagDataMap(Map arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public String getProcessClassName() {
        return PROCESS_CLASSNAME;
    }

}
