package com.ce.ib.fatoms.batch.scheduleUpdateProcess;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ScheduleBreakupUpdateTag;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ScheduleUpdateBatch;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * @author Anusha Bheemunipalli
 */
public class ScheduleUpdateBatchFatom extends AbstractCE_IB_ScheduleUpdateBatch {

	private static final long serialVersionUID = 1L;

	private transient final static Log logger = LogFactory.getLog(ScheduleUpdateBatchFatom.class.getName());

	private static final String BATCH_PROCESS_NAME = "ScheduleUpdateBatchProcess";

	private static final String loanRepayments_whereClause = "WHERE " + IBOLoanRepayments.PAIDDATE + " =? ";
	private static final String breakupDtls_whereClause = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public ScheduleUpdateBatchFatom(BankFusionEnvironment env) {
		super(env);
	}

	public ScheduleUpdateBatchFatom(String batchProcessName) {

	}

	@SuppressWarnings("deprecation")
	protected void processBatch(BankFusionEnvironment environment, AbstractFatomContext context) {
		if (logger.isInfoEnabled())
			logger.info("Schedule Update Batch Process Started.....");
		ScheduleUpdateBatchFatomContext scheduleUpdateContext = null;
		boolean batchStatus = true;
		try {
			deleteScheduleUpdateTagData();
			insertScheduleUpdateTagData();
			factory.commitTransaction();
			factory.beginTransaction();
			scheduleUpdateContext = (ScheduleUpdateBatchFatomContext) context;
			scheduleUpdateContext.setInputTagDataMap(getInDataMap());
			BatchService service = (BatchService) ServiceManager.getService(ServiceManager.BATCH_SERVICE);
			batchStatus = service.runBatch(environment, scheduleUpdateContext);
			setF_OUT_BATCH_STATUS(batchStatus);

		} catch (Exception e) {
			if (logger.isErrorEnabled())
				logger.error("ScheduleUpdateBatchFatom - processBatch() : Exception : " + e.getMessage());
			factory.rollbackTransaction();
			factory.beginTransaction();
		}
		if (logger.isInfoEnabled())
			logger.info("Schedule Update Batch Process Initiated");

		factory.rollbackTransaction();
		factory.beginTransaction();
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new ScheduleUpdateBatchFatomContext(BATCH_PROCESS_NAME);
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {

	}

	private void deleteScheduleUpdateTagData() {
		factory.bulkDeleteAll(IBOCE_IB_ScheduleBreakupUpdateTag.BONAME);
		factory.commitTransaction();
		factory.beginTransaction();
		if (logger.isInfoEnabled())
			logger.info("Deleted all ScheduleBreakupUpdateTag records ");
	}

	private void insertScheduleUpdateTagData() {
		ArrayList<Object> params = new ArrayList<>();
		params.add(IBCommonUtils.getBFBusinessDate());
		List<IBOLoanRepayments> loanRepaymentDtls = (List<IBOLoanRepayments>) factory
				.findByQuery(IBOLoanRepayments.BONAME, loanRepayments_whereClause, params, null, true);
		int insertedRecordCount = 0;
		if (loanRepaymentDtls != null && !loanRepaymentDtls.isEmpty()) {
			logger.info("No of repayments found paid/partailly paid in Loan Repayment table with business date: "
					+ IBCommonUtils.getBFBusinessDate() + " is :" + loanRepaymentDtls.size());
			for (IBOLoanRepayments loanRepaymentDtl : loanRepaymentDtls) {
				params.clear();
				params.add(loanRepaymentDtl.getF_ACCOUNTID());
				IBOLendingFeature loanDtls = (IBOLendingFeature) factory.findByPrimaryKey(IBOLendingFeature.BONAME,
						loanRepaymentDtl.getF_ACCOUNTID(), true);
				if (loanDtls != null) {
					params.clear();
					params.add(loanDtls.getF_LOANREFERENCE());
					params.add(loanRepaymentDtl.getF_DUEDATE());
					List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
							.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, breakupDtls_whereClause, params, null,
									true);
					if (ibPaymentSchResult != null && !ibPaymentSchResult.isEmpty()) {
						// inserting data into tag table for batch processing only if the data is
						// present in Breakup customized table
						IBOCE_IB_ScheduleBreakupUpdateTag scheduleUpdateTag = (IBOCE_IB_ScheduleBreakupUpdateTag) factory
								.getStatelessNewInstance(IBOCE_IB_ScheduleBreakupUpdateTag.BONAME);
						scheduleUpdateTag.setBoID(loanRepaymentDtl.getBoID());
						scheduleUpdateTag.setF_IBACCOUNTID(loanRepaymentDtl.getF_ACCOUNTID());
						scheduleUpdateTag.setF_IBDUEDATE(loanRepaymentDtl.getF_DUEDATE());
						scheduleUpdateTag.setF_IBINTERESTPAID(loanRepaymentDtl.getF_INTERESTPAID());
						scheduleUpdateTag.setF_IBPRINCIPALPAID(loanRepaymentDtl.getF_PRINCIPALPAID());
						scheduleUpdateTag.setF_IBLOANREFERENCE(loanDtls.getF_LOANREFERENCE());
						scheduleUpdateTag.setF_IBROWSEQ(++insertedRecordCount);
						if(loanRepaymentDtl.getF_REPAYMENTUNPAID().compareTo(BigDecimal.ZERO) == 0) 
							scheduleUpdateTag.setF_IBISFULLYPAID(true);
						else 					
							scheduleUpdateTag.setF_IBISFULLYPAID(false);
						factory.create(IBOCE_IB_ScheduleBreakupUpdateTag.BONAME, scheduleUpdateTag);
						if (insertedRecordCount % 10 == 0) {
							factory.commitTransaction();
							factory.beginTransaction();
						}
					}
				}
			}
			if (logger.isInfoEnabled())
				logger.info("Schedule Breakup update tag records inserted " + insertedRecordCount);
		} else {
			logger.info("No IB loan accounts found to be updated");
		}
	}

}
