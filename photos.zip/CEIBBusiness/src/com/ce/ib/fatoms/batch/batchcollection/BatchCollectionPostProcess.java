package com.ce.ib.fatoms.batch.batchcollection;

import java.util.ArrayList;
import java.util.List;

import com.ce.financialgateway.BatchCollectionConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.common.util.log.CBSLogger;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class BatchCollectionPostProcess implements IBatchPostProcess {
	private static final String CLASS_NAME = BatchCollectionPostProcess.class.getName();
	private static final transient CBSLogger LOGGER = new CBSLogger(CLASS_NAME);
	private static final String FIND_BATCH_TXNS = " WHERE " + IBOCE_BATCHTXNDETAIL.BATCHREF + " =? AND "
			+ IBOCE_BATCHTXNDETAIL.STATUS + " <> 'PROCESSED'";
	private IBatchStatus batchStatus;

	@SuppressWarnings("unused")
	private AbstractFatomContext batchCollectionContext;

	@SuppressWarnings("unused")
	private BankFusionEnvironment env;

	/**
	 * @param environment
	 *            Used to get a handle on the BankFusion environment
	 * @param context
	 *            A set of data passed to the PreProcess, Process and PostProcess
	 *            classes
	 * @see com.trapedza.bankfusion.batch.process.IBatchPostProcess#
	 *      init(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment,
	 *      com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	public void init(BankFusionEnvironment environment, AbstractFatomContext abstractContext,
			IBatchStatus batchStatus) {
		env = environment;
		this.batchStatus = batchStatus;
		this.batchCollectionContext = abstractContext;
	}

	/**
	 * Executes any post processing logic after the IDE tax collection has run
	 * 
	 * @param accumulator
	 *            The accumulator @ * Thrown if a BankFusionFusionException,
	 *            ServiceException or ErrorOnCommitException is caught
	 * @see com.trapedza.bankfusion.batch.process.IBatchPostProcess#
	 *      process(com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator)
	 */
	@Override
	public IBatchStatus process(AbstractProcessAccumulator arg0) {
		String txnType = (String) batchCollectionContext.getInputTagDataMap().get("txnType");
		LOGGER.info("BatchCollectionPostProcess Post Process - Start");
		String batchReference = (String) batchCollectionContext.getInputTagDataMap().get("batchReference");
		IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, batchReference, true);
		if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
			fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PROCESSED);
			ArrayList param = new ArrayList();
			param.add(batchReference);
			List<IBOCE_BATCHTXNDETAIL> listofUnProcessedRecs = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, FIND_BATCH_TXNS, param, null, true);
			for (IBOCE_BATCHTXNDETAIL dtlRec : listofUnProcessedRecs) {
				if (dtlRec.getF_PROCESSING().equals(CommonConstants.N)
						|| dtlRec.getF_PROCESSING().equals(CommonConstants.EMPTY_STRING)) {
					fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PARTPROCESSED);
					// dtlRec.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_UNPROCESSED);
				} else {
					// dtlRec.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PROCESSED);
					dtlRec.setF_PROCESSING(CommonConstants.EMPTY_STRING);
				}
			}
		}else {
			fileDtls.setF_ISLOADED(true);
		}
		batchStatus.setStatus(true);
		LOGGER.info("BatchCollectionPostProcess Post Process - End");
		return batchStatus;
	}

}
