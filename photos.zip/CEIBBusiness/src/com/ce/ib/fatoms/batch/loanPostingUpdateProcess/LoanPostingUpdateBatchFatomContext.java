package com.ce.ib.fatoms.batch.loanPostingUpdateProcess;

import java.util.HashMap;
import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

public class LoanPostingUpdateBatchFatomContext extends AbstractPersistableFatomContext {
	
	private static final long serialVersionUID = 1L;
	private String batchProcessName;

	private static final String PROCESS_CLASSNAME = loadProcessClassName("LoanPostingUpdateBatchProcess",
			"com.ce.ib.fatoms.batch.loanPostingUpdateProcess.LoanPostingUpdateBatchProcess");

	private Map inputDataMap;

	public LoanPostingUpdateBatchFatomContext(String batchProcessName) {
		this.batchProcessName = batchProcessName;
		super.setStatus(true);
	}

	public LoanPostingUpdateBatchFatomContext() {

	}

	@Override
	public boolean isMultiNodeSupported() {
		return false;
	}

	@Override
	public Object[] getAdditionalProcessParams() {
		return null;
	}

	@Override
	public String getBatchProcessName() {
		return this.batchProcessName;
	}

	@Override
	public Map getInputTagDataMap() {
		return inputDataMap;
	}

	@Override
	public Map getOutputTagDataMap() {
		return new HashMap();
	}

	@Override
	public void setAdditionalProcessParams(Object[] arg0) {

	}

	@Override
	public void setBatchProcessName(String batchProcessName) {
		this.batchProcessName = batchProcessName;
	}

	@Override
	public void setInputTagDataMap(Map inputDataMap) {
		this.inputDataMap = inputDataMap;
	}

	@Override
	public void setOutputTagDataMap(Map arg0) {

	}

	@Override
	public String getProcessClassName() {
		return PROCESS_CLASSNAME;
	}

}



