package com.ce.ib.fatoms.batch.scheduleUpdateProcess;

import java.util.HashMap;
import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

/**
 * 
 * @author Anusha Bheemunipalli
 * 
 */
public class ScheduleUpdateBatchFatomContext extends AbstractPersistableFatomContext {

	private static final long serialVersionUID = 1L;
	private String batchProcessName;

	private static final String PROCESS_CLASSNAME = loadProcessClassName("ScheduleUpdateBatchProcess",
			"com.ce.ib.fatoms.batch.scheduleUpdateProcess.ScheduleUpdateBatchProcess");

	private Map inputDataMap;

	public ScheduleUpdateBatchFatomContext(String batchProcessName) {
		this.batchProcessName = batchProcessName;
		super.setStatus(true);
	}

	public ScheduleUpdateBatchFatomContext() {

	}

	@Override
	public boolean isMultiNodeSupported() {
		return false;
	}

	@Override
	public Object[] getAdditionalProcessParams() {
		return null;
	}

	@Override
	public String getBatchProcessName() {
		return this.batchProcessName;
	}

	@Override
	public Map getInputTagDataMap() {
		return inputDataMap;
	}

	@Override
	public Map getOutputTagDataMap() {
		return new HashMap();
	}

	@Override
	public void setAdditionalProcessParams(Object[] arg0) {

	}

	@Override
	public void setBatchProcessName(String batchProcessName) {
		this.batchProcessName = batchProcessName;
	}

	@Override
	public void setInputTagDataMap(Map inputDataMap) {
		this.inputDataMap = inputDataMap;
	}

	@Override
	public void setOutputTagDataMap(Map arg0) {

	}

	@Override
	public String getProcessClassName() {
		return PROCESS_CLASSNAME;
	}

}
