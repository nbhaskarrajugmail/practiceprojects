package com.ce.ib.buildingblock;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;

public class RefundRescheduleFeeBuildingBlock extends AbstractIslamicBuildingBlock {
	
	public RefundRescheduleFeeBuildingBlock() {
    }

    @Override
    public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
        String mode = "";
        if (buildingBlockConfig != null) {
            mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
        }
        if (isDealEnquiry)
            mode = "VIEW";
        Boolean viewOnly = false;
        if (mode.equals("VIEW")) {
            viewOnly = true;
        }
        return viewOnly;
    }


}
