package com.ce.ib.buildingblock;

import com.ce.bankfusion.ib.fatom.ReadDealValidationExceptions;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.DealValidationList;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ValidationConfList;

public class DealValidationExcepInfoBB extends AbstractIslamicBuildingBlock{

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig arg0, boolean arg1) {
		return null;
	}
	
	@Override
	public boolean isBuildingBlockSuppresed(IslamicBankingObject ibObj)
	{
		boolean isBBSuppressed = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME,
				ibObj.getDealID(), true);
		if(null == dealDetails)
		{
			return true;
		}
		ValidationConfList configuredValidations = ValidationsUtil.getValidationListForProcessAndStep(
				ibObj.getProcessConfigID(), ibObj.getStepID());
		if(configuredValidations.getValidationConfCount() == 0)
		{
			isBBSuppressed = true;
		}
		else
		{
			ReadDealValidationExceptions readExcps = new ReadDealValidationExceptions();
			readExcps.setF_IN_context("PREPARE");;
			readExcps.setF_IN_islmaicBankingObj(ibObj);
			readExcps.process(BankFusionThreadLocal.getBankFusionEnvironment());
			DealValidationList dealValExcps = readExcps.getF_OUT_dealValidationExceptions();
			if(dealValExcps.getDealValidationsCount() == 0)
			{
				isBBSuppressed = true;
			}
		}
		return isBBSuppressed;
	}

}
