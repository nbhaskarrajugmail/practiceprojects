package com.ce.ib.buildingblock;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;

public class DealValidationExcepApprvlBB extends AbstractIslamicBuildingBlock{

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig arg0, boolean arg1) {
		// TODO Auto-generated method stub
		return null;
	}

}
