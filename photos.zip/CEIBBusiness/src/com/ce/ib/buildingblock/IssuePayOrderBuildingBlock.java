package com.ce.ib.buildingblock;

import java.util.HashMap;

import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AdditionalFieldsEditableTags;
import bf.com.misys.ib.types.IslamicBankingObject;

public class IssuePayOrderBuildingBlock extends AbstractIslamicBuildingBlock {

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {

		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry)
			mode = BuildingBlockConstants.MODE_VIEW;
		AdditionalFieldsEditableTags readOnlyTags = new AdditionalFieldsEditableTags();
		if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			readOnlyTags.setAllTags(true);

		} else if (editMode.equals(BuildingBlockConstants.FULL_EDIT_MODE)) {
			readOnlyTags.setAllTags(false);
		} else {
			readOnlyTags.setAllTags(false);
		}

		return readOnlyTags;
	
	}
	@Override
	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_ACTION);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF("CE_IB_IssuePayOrder_PRC", BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}

	@Override
	public boolean executeReverseAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_REVERSAL);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF("CE_IB_IssuePayOrder_PRC", BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}

}
