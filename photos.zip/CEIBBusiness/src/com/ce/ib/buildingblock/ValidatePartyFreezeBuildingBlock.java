package com.ce.ib.buildingblock;

import java.util.HashMap;

import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ValidatePartyFreezeBuildingBlock extends AbstractIslamicBuildingBlock {

    @Override
    public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
        return null;
    }

    @Override
    public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
        HashMap<String, IslamicBankingObject> inputs = new HashMap<String, IslamicBankingObject>();
        islamicBankingObject.setMode(IBConstants.BB_MODE_ACTION);
        inputs.put("taskInputPayload", islamicBankingObject);
        MFExecuter.executeMF(CeConstants.VALIDATEPARTYFREEZE_PRC, BankFusionThreadLocal.getBankFusionEnvironment(), inputs);
        return true;
    }

    @Override
    public boolean executeReverseAction(IslamicBankingObject islamicBankingObject) {
        return true;
    }

}
