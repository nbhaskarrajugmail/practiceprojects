package com.ce.ib.buildingblock;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;

import bf.com.misys.ib.types.AdditionalFieldsEditableTags;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.TransferToBankEditMode;

public class TransferToBankBuildingBlock extends AbstractIslamicBuildingBlock {

	public static final String buildingBlockId = "TRANSFERBANK";

	@Override
	public boolean isBuildingBlockSuppresed(IslamicBankingObject ibObj) {
		boolean isBBSuppressed = false;
		return isBBSuppressed;
	}

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
		TransferToBankEditMode readOnlyTags = new TransferToBankEditMode();
		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry) {
			mode = BuildingBlockConstants.MODE_VIEW;
			readOnlyTags.setIsDealInquiry(true);
			readOnlyTags.setIsFullMode(false);
			readOnlyTags.setIsGenerateMode(false);
		}
		if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			readOnlyTags.setIsDealInquiry(true);

		} else if (editMode.equals(BuildingBlockConstants.FULL_EDIT_MODE)) {
			readOnlyTags.setIsFullMode(true);
			readOnlyTags.setIsGenerateMode(false);
		} else {
			readOnlyTags.setIsFullMode(true);
			readOnlyTags.setIsGenerateMode(true);
		}

		return readOnlyTags;

	}

}
