package com.ce.ib.buildingblock;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;

import bf.com.misys.ib.types.AdditionalFieldsEditableTags;

public class CreateCollateralHBuildingBlock extends AbstractIslamicBuildingBlock {
	
	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {

		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry)
			mode = BuildingBlockConstants.MODE_VIEW;
		AdditionalFieldsEditableTags readOnlyTags = new AdditionalFieldsEditableTags();
		if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			readOnlyTags.setAllTags(true);

		} else if (editMode.equals(BuildingBlockConstants.FULL_EDIT_MODE)) {
			readOnlyTags.setAllTags(false);
		} else {
			readOnlyTags.setAllTags(false);
		}

		return readOnlyTags;
	
	}

}
