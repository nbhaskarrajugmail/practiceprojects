package com.ce.ib.buildingblock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ce.api.dto.AssetCategory;
import bf.com.misys.ce.api.dto.TechnicaFarmDtls;
import bf.com.misys.ce.api.dto.TechnicalAnalysisDTO;
import bf.com.misys.ce.api.dto.TechnicalAreaAndCoordinateDtls;
import bf.com.misys.ce.api.dto.TechnicalAreaDtls;
import bf.com.misys.ce.api.dto.TechnicalAssetDtls;
import bf.com.misys.ce.api.dto.TechnicalCropDtls;
import bf.com.misys.ce.api.dto.TechnicalWellDtls;
import bf.com.misys.ce.ib.types.TechnicalAnalysisEditableTags;
import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.api.bb.dto.AdditionalFieldInfo;
import bf.com.misys.ib.api.bb.dto.AssetAttributeInfo;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;
import edu.emory.mathcs.backport.java.util.Arrays;

public class TechnicalAnalysisBuildingBlock extends AbstractIslamicBuildingBlock {

	public TechnicalAnalysisBuildingBlock() {
	}

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
		String mode = "";
		String editMode = "";
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry)
			mode = "VIEW";
		TechnicalAnalysisEditableTags readOnlyTags = new TechnicalAnalysisEditableTags();
		if (mode.equals("VIEW")) {
			readOnlyTags.setAreaAssgined(Boolean.valueOf(true));
			readOnlyTags.setAreaCanBeUsed(Boolean.valueOf(true));
			readOnlyTags.setAreaEastCoordinate(Boolean.valueOf(true));
			readOnlyTags.setAreaEastCoordinateO(Boolean.valueOf(true));
			readOnlyTags.setAreaNorthCoordinate(Boolean.valueOf(true));
			readOnlyTags.setAreaNorthCoordinateO(Boolean.valueOf(true));
			readOnlyTags.setAreaUsed(Boolean.valueOf(true));
			readOnlyTags.setAssetDetails(Boolean.valueOf(true));
			readOnlyTags.setAssetName(Boolean.valueOf(true));
			readOnlyTags.setCropArea(Boolean.valueOf(true));
			readOnlyTags.setDate(Boolean.valueOf(true));
			readOnlyTags.setDescription(Boolean.valueOf(true));
			readOnlyTags.setEastCoordinate(Boolean.valueOf(true));
			readOnlyTags.setEastCoordinateO(Boolean.valueOf(true));
			readOnlyTags.setElectricitySrcAvailable(Boolean.valueOf(true));
			readOnlyTags.setFarmType(Boolean.valueOf(true));
			readOnlyTags.setForPalm(Boolean.valueOf(true));
			readOnlyTags.setInspector(Boolean.valueOf(true));
			readOnlyTags.setInsuredByFarmer(Boolean.valueOf(true));
			readOnlyTags.setLength(Boolean.valueOf(true));
			readOnlyTags.setMainActivity(Boolean.valueOf(true));
			readOnlyTags.setNew(Boolean.valueOf(true));
			readOnlyTags.setNorthCoordinate(Boolean.valueOf(true));
			readOnlyTags.setNorthCoordinateO(Boolean.valueOf(true));
			readOnlyTags.setNotes(Boolean.valueOf(true));
			readOnlyTags.setNumberOfReceipt(Boolean.valueOf(true));
			readOnlyTags.setNumberOfSeedlings(Boolean.valueOf(true));
			readOnlyTags.setOtherFindings(Boolean.valueOf(true));
			readOnlyTags.setPurpose(Boolean.valueOf(true));
			readOnlyTags.setRemove(Boolean.valueOf(true));
			readOnlyTags.setSave(Boolean.valueOf(true));
			readOnlyTags.setSeedlingType(Boolean.valueOf(true));
			readOnlyTags.setSelectCategory(Boolean.valueOf(true));
			readOnlyTags.setSignExist(Boolean.valueOf(true));
			readOnlyTags.setSoilType(Boolean.valueOf(true));
			readOnlyTags.setStatus(Boolean.valueOf(true));
			readOnlyTags.setTitleDeedId(Boolean.valueOf(true));
			readOnlyTags.setTotalArea(Boolean.valueOf(true));
			readOnlyTags.setWaterAvailability(Boolean.valueOf(true));
			readOnlyTags.setWateringMethod(Boolean.valueOf(true));
		} else if (editMode.equals("F")) {
			readOnlyTags.setAreaAssgined(Boolean.valueOf(false));
			readOnlyTags.setAreaCanBeUsed(Boolean.valueOf(false));
			readOnlyTags.setAreaEastCoordinate(Boolean.valueOf(false));
			readOnlyTags.setAreaEastCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setAreaNorthCoordinate(Boolean.valueOf(false));
			readOnlyTags.setAreaNorthCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setAreaUsed(Boolean.valueOf(false));
			readOnlyTags.setAssetDetails(Boolean.valueOf(false));
			readOnlyTags.setAssetName(Boolean.valueOf(false));
			readOnlyTags.setCropArea(Boolean.valueOf(false));
			readOnlyTags.setDate(Boolean.valueOf(false));
			readOnlyTags.setDescription(Boolean.valueOf(false));
			readOnlyTags.setEastCoordinate(Boolean.valueOf(false));
			readOnlyTags.setEastCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setElectricitySrcAvailable(Boolean.valueOf(false));
			readOnlyTags.setFarmType(Boolean.valueOf(false));
			readOnlyTags.setForPalm(Boolean.valueOf(false));
			readOnlyTags.setInspector(Boolean.valueOf(false));
			readOnlyTags.setInsuredByFarmer(Boolean.valueOf(false));
			readOnlyTags.setLength(Boolean.valueOf(false));
			readOnlyTags.setMainActivity(Boolean.valueOf(false));
			readOnlyTags.setNew(Boolean.valueOf(false));
			readOnlyTags.setNorthCoordinate(Boolean.valueOf(false));
			readOnlyTags.setNorthCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setNotes(Boolean.valueOf(false));
			readOnlyTags.setNumberOfReceipt(Boolean.valueOf(false));
			readOnlyTags.setNumberOfSeedlings(Boolean.valueOf(false));
			readOnlyTags.setOtherFindings(Boolean.valueOf(false));
			readOnlyTags.setPurpose(Boolean.valueOf(false));
			readOnlyTags.setRemove(Boolean.valueOf(false));
			readOnlyTags.setSave(Boolean.valueOf(false));
			readOnlyTags.setSeedlingType(Boolean.valueOf(false));
			readOnlyTags.setSelectCategory(Boolean.valueOf(false));
			readOnlyTags.setSignExist(Boolean.valueOf(false));
			readOnlyTags.setSoilType(Boolean.valueOf(false));
			readOnlyTags.setStatus(Boolean.valueOf(false));
			readOnlyTags.setTitleDeedId(Boolean.valueOf(false));
			readOnlyTags.setTotalArea(Boolean.valueOf(false));
			readOnlyTags.setWaterAvailability(Boolean.valueOf(false));
			readOnlyTags.setWateringMethod(Boolean.valueOf(false));
		} else {
			readOnlyTags.setAreaAssgined(Boolean.valueOf(false));
			readOnlyTags.setAreaCanBeUsed(Boolean.valueOf(false));
			readOnlyTags.setAreaEastCoordinate(Boolean.valueOf(false));
			readOnlyTags.setAreaEastCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setAreaNorthCoordinate(Boolean.valueOf(false));
			readOnlyTags.setAreaNorthCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setAreaUsed(Boolean.valueOf(false));
			readOnlyTags.setAssetDetails(Boolean.valueOf(false));
			readOnlyTags.setAssetName(Boolean.valueOf(false));
			readOnlyTags.setCropArea(Boolean.valueOf(false));
			readOnlyTags.setDate(Boolean.valueOf(false));
			readOnlyTags.setDescription(Boolean.valueOf(false));
			readOnlyTags.setEastCoordinate(Boolean.valueOf(false));
			readOnlyTags.setEastCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setElectricitySrcAvailable(Boolean.valueOf(false));
			readOnlyTags.setFarmType(Boolean.valueOf(false));
			readOnlyTags.setForPalm(Boolean.valueOf(false));
			readOnlyTags.setInspector(Boolean.valueOf(false));
			readOnlyTags.setInsuredByFarmer(Boolean.valueOf(false));
			readOnlyTags.setLength(Boolean.valueOf(false));
			readOnlyTags.setMainActivity(Boolean.valueOf(false));
			readOnlyTags.setNew(Boolean.valueOf(false));
			readOnlyTags.setNorthCoordinate(Boolean.valueOf(false));
			readOnlyTags.setNorthCoordinateO(Boolean.valueOf(false));
			readOnlyTags.setNotes(Boolean.valueOf(false));
			readOnlyTags.setNumberOfReceipt(Boolean.valueOf(false));
			readOnlyTags.setNumberOfSeedlings(Boolean.valueOf(false));
			readOnlyTags.setOtherFindings(Boolean.valueOf(false));
			readOnlyTags.setPurpose(Boolean.valueOf(false));
			readOnlyTags.setRemove(Boolean.valueOf(false));
			readOnlyTags.setSave(Boolean.valueOf(false));
			readOnlyTags.setSeedlingType(Boolean.valueOf(false));
			readOnlyTags.setSelectCategory(Boolean.valueOf(false));
			readOnlyTags.setSignExist(Boolean.valueOf(false));
			readOnlyTags.setSoilType(Boolean.valueOf(false));
			readOnlyTags.setStatus(Boolean.valueOf(false));
			readOnlyTags.setTitleDeedId(Boolean.valueOf(false));
			readOnlyTags.setTotalArea(Boolean.valueOf(false));
			readOnlyTags.setWaterAvailability(Boolean.valueOf(false));
			readOnlyTags.setWateringMethod(Boolean.valueOf(false));
		}
		return readOnlyTags;
	}

	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		HashMap inputs = new HashMap();
		islamicBankingObject.setMode("ACTION");
		inputs.put("taskInputPayload", islamicBankingObject);
		MFExecuter.executeMF("CE_IB_TechnicalAnalysis_PRC", BankFusionThreadLocal.getBankFusionEnvironment(), inputs);
		return true;
	}

	@Override
	public AbstractBuildingBlock getBuildingBlockDetails(IslamicBankingObject islamicBankingObject) {
		TechnicalAnalysisDTO technicalAnalysisDTO = null;
		technicalAnalysisDTO = callReadTechncialAnalysisService(islamicBankingObject);
		return technicalAnalysisDTO;
	}

	private TechnicalAnalysisDTO callReadTechncialAnalysisService(IslamicBankingObject islamicBankingObject) {
		TechnicalAnalysisDTO analysisDTO = new TechnicalAnalysisDTO();
		TechnicalAnalysisDtls technicalAnalysisDtls = new TechnicalAnalysisDtls();
		HashMap inputParams = new HashMap();
		inputParams.put("islamicBankingObject", islamicBankingObject);
		HashMap outputParams = MFExecuter.executeMF("CE_IB_ReadTechnicalAnalysisDtls_SRV",
				IBCommonUtils.getBankFusionEnvironment(), inputParams);
		TechnicalAnalysisDtls technicalAnalysisDtlsOp = (TechnicalAnalysisDtls) outputParams
				.get("technicalAnalysisDtls");
		List<TechnicalAssetDtls> technicalAssetDtls = new ArrayList<>();
		List<TechnicalAreaAndCoordinateDtls> techCoordinateDtls = Arrays
				.asList(technicalAnalysisDtlsOp.getTechnicalAreaCoordinatesList().getTechnicalAreaCoordinateDtlList());
		List<TechnicalAreaDtls> technicalAreaDtls = Arrays
				.asList(technicalAnalysisDtlsOp.getTechnicalAreaDtlsList().getTechnicalAreaDtlList());
		/*
		 * List<TechnicalAssetDtls> technicalAssetDtls = Arrays
		 * .asList(technicalAnalysisDtlsOp.getTechnicalAssetDtlsList().
		 * getTechincalAssetDtlsList());
		 */
		List<TechnicalCropDtls> technicalCropDetails = Arrays
				.asList(technicalAnalysisDtlsOp.getTechnicalCropDtlsList().getTechnicalCropDtlList());
		List<TechnicaFarmDtls> technicalFarmDtls = Arrays
				.asList(technicalAnalysisDtlsOp.getTechnicalFarmDtlsList().getTechnicalFarmDtlList());
		List<TechnicalWellDtls> technicalWellDtls = Arrays
				.asList(technicalAnalysisDtlsOp.getTechnicalWellDtlsList().getTechnicalWellDtlList());
		// List<TechnicalAnalysisAssetUDFs>
		// technicalAssetUDFs=Arrays.asList(technicalAnalysisDtlsOp.getTechnicalAssetUDFs().getAssetUDFs());

		if (technicalAnalysisDtlsOp != null
				&& technicalAnalysisDtlsOp.getTechnicalAssetDtlsList().getTechincalAssetDtlsList().length > 0) {
			for (TechnicalAssetDtl assetDetails : technicalAnalysisDtlsOp.getTechnicalAssetDtlsList()
					.getTechincalAssetDtlsList()) {
				TechnicalAssetDtls technicalAssetDtlDTO = new TechnicalAssetDtls();
				AssetCategory assetCat = new AssetCategory();
				assetCat.setCategorization(assetDetails.getAssetCategory().getCategorization());
				assetCat.setCategory(assetDetails.getAssetCategory().getCategory());
				assetCat.setSubCategory(assetDetails.getAssetCategory().getSubCategory());
				technicalAssetDtlDTO.setAssetCategory(assetCat);
				technicalAssetDtlDTO.setAssetId(assetDetails.getAssetId());
				technicalAssetDtlDTO.setAssetName(assetDetails.getAssetName());
				bf.com.misys.ce.api.dto.ExtensionDetails extDtls = new bf.com.misys.ce.api.dto.ExtensionDetails();
				/*
				 * extDtls.setHostExtension(assetDetails.getExtensionDetails().getHostExtension(
				 * ));
				 * extDtls.setUserExtension(assetDetails.getExtensionDetails().getUserExtension(
				 * ));
				 **/
				technicalAssetDtlDTO.setExtensionDetails(extDtls);
				technicalAssetDtlDTO.setReferenceNumber(assetDetails.getReferenceNumber());

				technicalAssetDtls.add(technicalAssetDtlDTO);
			}
			analysisDTO.setTechnicalAssetDtls(technicalAssetDtls);

			for (TechnicalAssetDtls assetDetails : technicalAssetDtls) {
				HashMap<String, Object> assetUDFMap = CeUtils.getAssetUDFForAPI(
						assetDetails.getAssetCategory().getCategory(), islamicBankingObject.getDealID(),
						technicalAnalysisDtlsOp.getTechnicalAssetUDFs().getAssetUDFs());
				if (assetUDFMap != null && !assetUDFMap.isEmpty()) {
					assetDetails
							.setAdditionalInfo((List<AdditionalFieldInfo>) assetUDFMap.get("additionalFieldInfoList"));
					assetDetails
							.setAssetAttributeInfo((List<AssetAttributeInfo>) assetUDFMap.get("assetAttributeList"));
				}
			}
		}

		analysisDTO.setTechnicalAreaAndCoordinateDtls(techCoordinateDtls);

		analysisDTO.setTechnicalAreaDtls(technicalAreaDtls);

		analysisDTO.setTechnicalAssetDtls(technicalAssetDtls);

		analysisDTO.setTechnicalCropDetails(technicalCropDetails);

		analysisDTO.setTechnicalFarmDtls(technicalFarmDtls);

		analysisDTO.setTechnicalWellDtls(technicalWellDtls);

		// analysisDTO.setTechnicalAssetUDFs(technicalAssetUDFs);
		return analysisDTO;
	}

	@Override
	public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		callTechnicalAnalysisBBProcess(islamicBankingObject, abstractBuildingBlock);
		return IBCommonUtils.getNextBuildingBlockDtls(islamicBankingObject.getProcessConfigID(),
				islamicBankingObject.getStepID(), islamicBankingObject.getPhaseID());
	}

	private void callTechnicalAnalysisBBProcess(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {

		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(0);
		pagingRequest.setRequestedPage(0);
		pagingRequest.setTotalPages(0);
		pagedQuery.setPagingRequest(pagingRequest);
		HashMap inputParams = new HashMap();
		inputParams.put(IBConstants.BB_TASK_ID_TAG_NAME, islamicBankingObject.getTaskType());
		islamicBankingObject.setTaskType(IBConstants.EMPTY_STRING);
		islamicBankingObject.setMode(IBConstants.EMPTY_STRING);
		TechnicalAnalysisDTO technicalAnalysisDtlFromAPI = (TechnicalAnalysisDTO) abstractBuildingBlock;
		/*
		 * if (!IBCommonUtils.isEmpty(technicalAnalysisDtlFromAPI.getWhatIfId())) {
		 * islamicBankingObject.setTransactionName(IBConstants.WHATIF_ACTION); }
		 */
		inputParams.put(IBConstants.BB_TASK_INPUT_PAYLOAD_TAG_NAME, islamicBankingObject);

		TechnicalAnalysisDtls technicalAnalysisDtls = new TechnicalAnalysisDtls();
		TechnicalAreaCoordinateDtlList technicalAreaCoordinatesList = new TechnicalAreaCoordinateDtlList();
		TechnicalFarmDtlList technicalFarmDtlsList = new TechnicalFarmDtlList();
		TechnicalCropDtlList technicalCropDtlsList = new TechnicalCropDtlList();
		TechnicalAreaDtlList technicalAreaDtlsList = new TechnicalAreaDtlList();
		TechincalAssetDtlsList technicalAssetDtlsList = new TechincalAssetDtlsList();
		TechnicalWellDtlsList technicalWellDtlsList = new TechnicalWellDtlsList();

		List<TechnicalAreaAndCoordinateDtls> techCoordinateFromAPI = technicalAnalysisDtlFromAPI
				.getTechnicalAreaAndCoordinateDtls();
		technicalAreaCoordinatesList.setTechnicalAreaCoordinateDtlList(getTechCoordinate(techCoordinateFromAPI));

		List<TechnicaFarmDtls> techFarmFromAPI = technicalAnalysisDtlFromAPI.getTechnicalFarmDtls();
		technicalFarmDtlsList.setTechnicalFarmDtlList((getTechFarm(techFarmFromAPI)));

		List<TechnicalCropDtls> techCropFromAPI = technicalAnalysisDtlFromAPI.getTechnicalCropDetails();
		technicalCropDtlsList.setTechnicalCropDtlList(getTechCrop(techCropFromAPI));

		List<TechnicalAreaDtls> techAreaFromAPI = technicalAnalysisDtlFromAPI.getTechnicalAreaDtls();
		technicalAreaDtlsList.setTechnicalAreaDtlList(getTechArea(techAreaFromAPI));

		List<TechnicalAssetDtls> techAssetFromAPI = technicalAnalysisDtlFromAPI.getTechnicalAssetDtls();
		technicalAssetDtlsList.setTechincalAssetDtlsList(getTechAsset(techAssetFromAPI));

		List<TechnicalWellDtls> techWellFromAPI = technicalAnalysisDtlFromAPI.getTechnicalWellDtls();
		technicalWellDtlsList.setTechnicalWellDtlList(getTechWell(techWellFromAPI));

		technicalFarmDtlsList.setPagedQuery(pagedQuery);
		technicalAreaDtlsList.setPagedQuery(pagedQuery);
		technicalAreaCoordinatesList.setPagedQuery(pagedQuery);
		technicalCropDtlsList.setPagedQuery(pagedQuery);
		technicalAssetDtlsList.setPagedQuery(pagedQuery);
		technicalAnalysisDtls.setTechnicalAreaCoordinatesList(technicalAreaCoordinatesList);
		technicalAnalysisDtls.setTechnicalAreaDtlsList(technicalAreaDtlsList);
		technicalAnalysisDtls.setTechnicalAssetDtlsList(technicalAssetDtlsList);
		technicalAnalysisDtls.setTechnicalCropDtlsList(technicalCropDtlsList);
		technicalAnalysisDtls.setTechnicalFarmDtlsList(technicalFarmDtlsList);
		technicalAnalysisDtls.setTechnicalAssetUDFs(getAssetUDFs(techAssetFromAPI));
		technicalAnalysisDtls.setTechnicalWellDtlsList(technicalWellDtlsList);

		inputParams.put("taskInputPayload", islamicBankingObject);
		inputParams.put("technicalAnalysisAPI", technicalAnalysisDtls);
		MFExecuter.executeMF("CE_IB_TechnicalAnalysis_PRC", inputParams,
				BankFusionThreadLocal.getUserLocator().getStringRepresentation());
	}

	private TechnicalWellDtl[] getTechWell(List<TechnicalWellDtls> techWellFromAPI) {
		List<TechnicalWellDtl> technicalWellDtlsLists = new ArrayList<TechnicalWellDtl>();
		if (techWellFromAPI != null) {
			for (TechnicalWellDtls technicalWellDtls : techWellFromAPI) {
				TechnicalWellDtl eachTechWellDetails = new TechnicalWellDtl();
				eachTechWellDetails.setEastCoordinate(technicalWellDtls.getEastCoordinate());
				eachTechWellDetails.setEastCoordinateO(technicalWellDtls.getEastCoordinateO());
				eachTechWellDetails.setIsWellUsed(technicalWellDtls.getIsWellUsed());
				eachTechWellDetails.setLicenseDate(technicalWellDtls.getLicenseDate());
				eachTechWellDetails.setLicenseDateHijri(technicalWellDtls.getLicenseDateHijri());
				eachTechWellDetails.setLicenseNumber(technicalWellDtls.getLicenseNumber());
				eachTechWellDetails.setNorthCoordinate(technicalWellDtls.getNorthCoordinate());
				eachTechWellDetails.setNorthCoordinateO(technicalWellDtls.getNorthCoordinateO());
				eachTechWellDetails.setOldBranchCode(technicalWellDtls.getOldBranchCode());
				eachTechWellDetails.setOldContractID(technicalWellDtls.getOldContractID());
				eachTechWellDetails.setReferenceNumber(technicalWellDtls.getReferenceNumber());
				eachTechWellDetails.setSerialNumber(technicalWellDtls.getSerialNumber());
				eachTechWellDetails.setTitleDeedId(technicalWellDtls.getTitleDeedId());
				eachTechWellDetails.setTitleDescription(technicalWellDtls.getTitleDescription());
				eachTechWellDetails.setWellAir(technicalWellDtls.getWellAir());
				eachTechWellDetails.setWellArch(technicalWellDtls.getWellArch());
				eachTechWellDetails.setWellDepth(technicalWellDtls.getWellDepth());
				eachTechWellDetails.setWellStatus(technicalWellDtls.getWellStatus());
				eachTechWellDetails.setWellType(technicalWellDtls.getWellType());
				technicalWellDtlsLists.add(eachTechWellDetails);

			}
		}
		TechnicalWellDtl[] technicalWellDtlsRes = technicalWellDtlsLists
				.toArray(new TechnicalWellDtl[technicalWellDtlsLists.size()]);
		return technicalWellDtlsRes;
	}

	private TechnicalAreaCoordinateDtl[] getTechCoordinate(List<TechnicalAreaAndCoordinateDtls> techCoordinateFromAPI) {
		List<TechnicalAreaCoordinateDtl> settechnicalCoordinateDtls = new ArrayList();
		if (techCoordinateFromAPI != null) {
			for (TechnicalAreaAndCoordinateDtls technicalCoordinateDtlDTO : techCoordinateFromAPI)// dto
			{
				TechnicalAreaCoordinateDtl eachTechUI = new TechnicalAreaCoordinateDtl();
				eachTechUI.setEastCoordinate(technicalCoordinateDtlDTO.getEastCoordinate());
				eachTechUI.setEastCoordinateO(technicalCoordinateDtlDTO.getEastCoordinateO());
				eachTechUI.setNorthCoordinate(technicalCoordinateDtlDTO.getNorthCoordinate());
				eachTechUI.setNorthCoordinateO(technicalCoordinateDtlDTO.getNorthCoordinateO());
				eachTechUI.setReferenceNumber(technicalCoordinateDtlDTO.getReferenceNumber());
				eachTechUI.setSerail(technicalCoordinateDtlDTO.getSerail());
				eachTechUI.setTitleDeedId(technicalCoordinateDtlDTO.getTitleDeedId());
				eachTechUI.setDefaultCoordinates(technicalCoordinateDtlDTO.isDefaultCoordinates());
				settechnicalCoordinateDtls.add(eachTechUI);

			}
		}
		TechnicalAreaCoordinateDtl[] technicalCoordinateDtls = settechnicalCoordinateDtls
				.toArray(new TechnicalAreaCoordinateDtl[settechnicalCoordinateDtls.size()]);
		return technicalCoordinateDtls;
	}

	private AssetUDFsCollection getAssetUDFs(List<TechnicalAssetDtls> techAssetFromAPI) {
		AssetUDFsCollection assetUDFsCollection = new AssetUDFsCollection();
		if (techAssetFromAPI != null && !techAssetFromAPI.isEmpty()) {
			// loop for additional fields
			for (TechnicalAssetDtls eachTechAssetDetails : techAssetFromAPI) {
				if (eachTechAssetDetails.getAdditionalInfo() != null
						&& !eachTechAssetDetails.getAdditionalInfo().isEmpty()) {
					for (AdditionalFieldInfo additionalFieldInfo : eachTechAssetDetails.getAdditionalInfo()) {
						AssetUDF assetUDF = new AssetUDF();
						assetUDF.setAssetid(eachTechAssetDetails.getAssetId());
						assetUDF.setFieldId(additionalFieldInfo.getAdditionalFieldDetails().getKey());
						assetUDF.setFieldValue(
								String.valueOf(additionalFieldInfo.getAdditionalFieldDetails().getValue()));
						assetUDFsCollection.addAssetUDFs(assetUDF);
					}
				}
			}
			// asset attributes
			for (TechnicalAssetDtls eachTechAssetDetails : techAssetFromAPI) {
				if (eachTechAssetDetails.getAssetAttributeInfo() != null
						&& !eachTechAssetDetails.getAssetAttributeInfo().isEmpty()) {
					for (AssetAttributeInfo assetAttribueInfo : eachTechAssetDetails.getAssetAttributeInfo()) {
						AssetUDF assetUDF = new AssetUDF();
						assetUDF.setAssetid(eachTechAssetDetails.getAssetId());
						assetUDF.setFieldId(assetAttribueInfo.getAssetAttributeDetails().getKey());
						assetUDF.setFieldValue(String.valueOf(assetAttribueInfo.getAssetAttributeDetails().getValue()));
						assetUDFsCollection.addAssetUDFs(assetUDF);
					}
				}
			}
		}
		// dealFollowUpDetails.setFollowUpAssetUDFs(assetUDFsCollection);

		return assetUDFsCollection;
	}

	private TechnicalAssetDtl[] getTechAsset(List<TechnicalAssetDtls> techAssetFromAPI) {
		List<TechnicalAssetDtl> settechnicalAssetDtls = new ArrayList();
		if (techAssetFromAPI != null) {
			for (TechnicalAssetDtls technicalAssetDtlDTO : techAssetFromAPI)// dto
			{
				TechnicalAssetDtl eachTechUI = new TechnicalAssetDtl();
				AsstCategory assetCat = new AsstCategory();
				assetCat.setCategorization(technicalAssetDtlDTO.getAssetCategory().getCategorization());
				assetCat.setCategory(technicalAssetDtlDTO.getAssetCategory().getCategory());
				assetCat.setSubCategory(technicalAssetDtlDTO.getAssetCategory().getSubCategory());
				eachTechUI.setAssetCategory(assetCat);
				eachTechUI.setAssetId(technicalAssetDtlDTO.getAssetId());
				eachTechUI.setAssetName(technicalAssetDtlDTO.getAssetName());
				ExtensionDetails extDtls = new ExtensionDetails();
				extDtls.setHostExtension(technicalAssetDtlDTO.getExtensionDetails().getHostExtension());
				extDtls.setUserExtension(technicalAssetDtlDTO.getExtensionDetails().getUserExtension());
				eachTechUI.setExtensionDetails(extDtls);
				eachTechUI.setReferenceNumber(technicalAssetDtlDTO.getReferenceNumber());
				settechnicalAssetDtls.add(eachTechUI);

			}
		}
		TechnicalAssetDtl[] technicalAssetDtls = settechnicalAssetDtls
				.toArray(new TechnicalAssetDtl[settechnicalAssetDtls.size()]);
		return technicalAssetDtls;
	}

	private TechnicalAreaDtl[] getTechArea(List<TechnicalAreaDtls> techAreaFromAPI) {
		List<TechnicalAreaDtl> settechnicalAreaDtls = new ArrayList();
		if (techAreaFromAPI != null) {
			for (TechnicalAreaDtls technicalAreaDtlDTO : techAreaFromAPI)// dto
			{
				TechnicalAreaDtl eachTechUI = new TechnicalAreaDtl();
				eachTechUI.setAreaAssigned(technicalAreaDtlDTO.getAreaAssigned());
				eachTechUI.setAreaCanBeUsed(technicalAreaDtlDTO.getAreaCanBeUsed());
				eachTechUI.setAreaCanBeUsedForAllDeeds(technicalAreaDtlDTO.getAreaCanBeUsedForAllDeeds());
				eachTechUI.setAreaUsed(technicalAreaDtlDTO.getAreaUsed());
				eachTechUI.setAreaUsedForAllDeeds(technicalAreaDtlDTO.getAreaUsedForAllDeeds());
				eachTechUI.setReferenceNumber(technicalAreaDtlDTO.getReferenceNumber());
				eachTechUI.setTitleDeedId(technicalAreaDtlDTO.getTitleDeedId());
				eachTechUI.setTitleDescription(technicalAreaDtlDTO.getTitleDescription());
				eachTechUI.setTotalArea(technicalAreaDtlDTO.getTotalArea());
				eachTechUI.setTotalAreaForAllDeeds(technicalAreaDtlDTO.getTotalAreaForAllDeeds());
				eachTechUI.setTitleDeedSource(technicalAreaDtlDTO.getTitleDeedSource());
				eachTechUI.setTitleDeedType(technicalAreaDtlDTO.getTitleDeedType());
				eachTechUI.setLandPlanNumber(technicalAreaDtlDTO.getLandPlanNumber());
				eachTechUI.setLandPlotNumber(technicalAreaDtlDTO.getLandPlotNumber());
				eachTechUI.setTitleDeedYear(technicalAreaDtlDTO.getTitleDeedYear());
				settechnicalAreaDtls.add(eachTechUI);

			}
		}
		TechnicalAreaDtl[] technicalAreaDtls = settechnicalAreaDtls
				.toArray(new TechnicalAreaDtl[settechnicalAreaDtls.size()]);
		return technicalAreaDtls;
	}

	private TechnicalCropDtl[] getTechCrop(List<TechnicalCropDtls> techCropFromAPI) {
		List<TechnicalCropDtl> settechnicalCropDtls = new ArrayList();
		if (techCropFromAPI != null) {
			for (TechnicalCropDtls technicalCropDtlDTO : techCropFromAPI)// dto
			{
				TechnicalCropDtl eachTechUI = new TechnicalCropDtl();
				eachTechUI.setArea(technicalCropDtlDTO.getArea());

				eachTechUI.setCropType(technicalCropDtlDTO.getCropType());
				eachTechUI.setForPalm((technicalCropDtlDTO.getForPalm()));
				eachTechUI.setForPalmRef(technicalCropDtlDTO.getForPalmRef());
				eachTechUI.setInsuredByFarmer(technicalCropDtlDTO.getInsuredByFarmer());
				eachTechUI.setLengthOfWateringMethod(technicalCropDtlDTO.getLengthOfWateringMethod());
				eachTechUI.setMainActivity(technicalCropDtlDTO.getMainActivity());
				eachTechUI.setMainActivityRef(technicalCropDtlDTO.getMainActivityRef());
				eachTechUI.setNoOfSeedling(technicalCropDtlDTO.getNoOfSeedling());
				eachTechUI.setReferenceNumber(technicalCropDtlDTO.getReferenceNumber());
				eachTechUI.setSeedlingType(technicalCropDtlDTO.getSeedlingType());
				eachTechUI.setSeedlingTypeRef(technicalCropDtlDTO.getSeedlingTypeRef());
				eachTechUI.setStatus(technicalCropDtlDTO.getStatus());
				eachTechUI.setStatusRef(technicalCropDtlDTO.getStatusRef());
				eachTechUI.setTotalAreaForAlCrop(technicalCropDtlDTO.getTotalAreaForAlCrop());
				eachTechUI.setWateringMethod(technicalCropDtlDTO.getWateringMethod());
				eachTechUI.setWateringMethodRef(technicalCropDtlDTO.getWateringMethodRef());

				settechnicalCropDtls.add(eachTechUI);

			}
		}
		TechnicalCropDtl[] technicalCropDtls = settechnicalCropDtls
				.toArray(new TechnicalCropDtl[settechnicalCropDtls.size()]);
		return technicalCropDtls;
	}

	private TechnicalFarmDtl[] getTechFarm(List<TechnicaFarmDtls> techFarmFromAPI) {
		List<TechnicalFarmDtl> settechnicalFarmDtls = new ArrayList();

		for (TechnicaFarmDtls technicalFarmDtlDTO : techFarmFromAPI)// dto
		{
			TechnicalFarmDtl eachTechUI = new TechnicalFarmDtl();
			eachTechUI.setDate(technicalFarmDtlDTO.getDate());
			eachTechUI.setDealId(technicalFarmDtlDTO.getDealId());
			eachTechUI.setEastCoordinate(technicalFarmDtlDTO.getEastCoordinate());
			eachTechUI.setEastCoordinateO(technicalFarmDtlDTO.getEastCoordinateO());
			eachTechUI.setElectricitySrcAvailable(technicalFarmDtlDTO.getElectricitySrcAvailable());
			eachTechUI.setFarmType(technicalFarmDtlDTO.getFarmType());
			eachTechUI.setFarmTypeRef(technicalFarmDtlDTO.getFarmTypeRef());
			eachTechUI.setInspectorName(technicalFarmDtlDTO.getInspectorName());
			eachTechUI.setNorthCoordinate(technicalFarmDtlDTO.getNorthCoordinate());
			eachTechUI.setNorthCoordinateO(technicalFarmDtlDTO.getNorthCoordinateO());
			eachTechUI.setNotesAndConditions(technicalFarmDtlDTO.getNotesAndConditions());
			eachTechUI.setNumberOfReceipt(technicalFarmDtlDTO.getNumberOfReceipt());
			eachTechUI.setOtherFindings(technicalFarmDtlDTO.getOtherFindings());
			eachTechUI.setPurpose(technicalFarmDtlDTO.getPurpose());
			eachTechUI.setPurposeRef(technicalFarmDtlDTO.getPurposeRef());
			eachTechUI.setReferenceNumber(technicalFarmDtlDTO.getReferenceNumber());
			eachTechUI.setSignExist(technicalFarmDtlDTO.getSignExist());
			eachTechUI.setSoilType(technicalFarmDtlDTO.getSoilType());
			eachTechUI.setSoilTypeRef(technicalFarmDtlDTO.getSoilTypeRef());
			eachTechUI.setWaterAvailabilty(technicalFarmDtlDTO.getWaterAvailabilty());
			eachTechUI.setWaterAvailabiltyRef(technicalFarmDtlDTO.getWaterAvailabiltyRef());

			eachTechUI.setAreaAssignedForSpclPrj(technicalFarmDtlDTO.getAreaAssignedForSpclPrj());
			eachTechUI.setFishEastCoordinate(technicalFarmDtlDTO.getFishEastCoordinate());
			eachTechUI.setFishEastCoordinateO(technicalFarmDtlDTO.getFishEastCoordinateO());
			eachTechUI.setFishLicenseDate(technicalFarmDtlDTO.getFishLicenseDate());
			eachTechUI.setFishLicenseDateHijri(technicalFarmDtlDTO.getFishLicenseDateHijri());
			eachTechUI.setFishNorthCoordinate(technicalFarmDtlDTO.getFishNorthCoordinate());
			eachTechUI.setFishNorthCoordinateO(technicalFarmDtlDTO.getFishNorthCoordinateO());
			eachTechUI.setFishPort(technicalFarmDtlDTO.getFishPort());
			eachTechUI.setLetterDate(technicalFarmDtlDTO.getLetterDate());
			eachTechUI.setLetterDateHijri(technicalFarmDtlDTO.getLetterDateHijri());
			eachTechUI.setLetterNumber(technicalFarmDtlDTO.getLetterNumber());
			eachTechUI.setLetterSource(technicalFarmDtlDTO.getLetterSource());
			eachTechUI.setWealthLetterDate(technicalFarmDtlDTO.getWealthLetterDate());
			eachTechUI.setWealthLetterDateHijri(technicalFarmDtlDTO.getWealthLetterDateHijri());
			eachTechUI.setWealthLetterNumber(technicalFarmDtlDTO.getWealthLetterNumber());
			eachTechUI.setWealthLetterSource(technicalFarmDtlDTO.getWealthLetterSource());
			eachTechUI.setNoOfBoats(technicalFarmDtlDTO.getNoOfBoats());
			eachTechUI.setLicenseNumber(technicalFarmDtlDTO.getLicenseNumber());
			eachTechUI.setLicenseSource(technicalFarmDtlDTO.getLicenseSource());
			eachTechUI.setLicenseType(technicalFarmDtlDTO.getLicenseType());

			settechnicalFarmDtls.add(eachTechUI);

		}
		TechnicalFarmDtl[] technicalFarmDtls = settechnicalFarmDtls
				.toArray(new TechnicalFarmDtl[settechnicalFarmDtls.size()]);
		return technicalFarmDtls;
	}

}
