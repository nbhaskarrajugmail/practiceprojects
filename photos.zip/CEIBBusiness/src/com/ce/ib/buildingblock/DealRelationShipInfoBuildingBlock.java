package com.ce.ib.buildingblock;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;

public class DealRelationShipInfoBuildingBlock extends AbstractIslamicBuildingBlock {

    public DealRelationShipInfoBuildingBlock() {
    }

    @Override
    public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
        String mode = "";
        if (buildingBlockConfig != null) {
            mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
        }
        if (isDealEnquiry)
            mode = "VIEW";
        Boolean viewOnly = false;
        if (mode.equals("VIEW")) {
            viewOnly = true;
        }
        return viewOnly;
    }

}
