package com.ce.ib.buildingblock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;

import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.types.AssetThirdPartyAttributePanelVisibility;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetAndStudyInfoBuildingBlock extends AbstractIslamicBuildingBlock {
	private transient final static Log LOGGER = LogFactory
			.getLog(AssetAndStudyInfoBuildingBlock.class.getName());
	

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		String stepId = CommonConstants.EMPTY_STRING;
		System.err.println();
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();  //edit/view
			editMode = buildingBlockConfig.getF_EDITMODES(); // four fields
			stepId=buildingBlockConfig.getF_STEPID();
		}
		if (isDealEnquiry)
			mode = BuildingBlockConstants.MODE_VIEW;
		AssetThirdPartyAttributePanelVisibility assetThirdPartyAttributePanelVisibility = new AssetThirdPartyAttributePanelVisibility();
		 if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			assetThirdPartyAttributePanelVisibility.setInitalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setGrantApprovalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setFinalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setViewMode(true);
      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(false);
        if(!isDealEnquiry && editMode.equals(CeConstants.ASSET_REPLACEMENT_MODE)) {
          assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(true);
          assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(false);
          assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(true);
          assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(false);
          assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(true);
       }
		} 
		if (editMode.equals(CeConstants.ASSET_ONLY_MODE)) {
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(false);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(false);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(false);
      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(false);
    } 
		else if(editMode.equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE)) {
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityMachineType(true);
			assetThirdPartyAttributePanelVisibility.setInitalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(false);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(false);
			assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(true);
      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(false);
			
		/*	IBOIB_CFG_ProcessConfig processConfig = IBCommonUtils.getProcessConfigByPrimaryKey(buildingBlockConfig.getF_PROCESSCONFIGID());
			if(processConfig.getF_TEMPLATEID().equalsIgnoreCase(CeConstants.SPECIAL_LOANS) || processConfig.getF_TEMPLATEID().equalsIgnoreCase(CeConstants.WORKING_CAPITAL_LOANS)) {
				assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(false);
			}*/
			
		}else if(editMode.equals(CeConstants.STUDY_AND_GRANTAPPROVAL_ONLY_MODE)) {
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityMachineType(false);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(true);
			assetThirdPartyAttributePanelVisibility.setInitalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(false);
			assetThirdPartyAttributePanelVisibility.setGrantApprovalCostReadOnly(true);
      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(false);

		}else if(editMode.equals(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE)) {
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityMachineType(false);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(true);
			assetThirdPartyAttributePanelVisibility.setInitalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setGrantApprovalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(true);
			assetThirdPartyAttributePanelVisibility.setFinalCostReadOnly(true);
			assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(false);

		}
		else if(editMode.equals(CeConstants.ASSET_REPLACEMENT_MODE)) {
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityMachineType(true);
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityInitalCost(false);
	      assetThirdPartyAttributePanelVisibility.setInitalCostReadOnly(true);
	      assetThirdPartyAttributePanelVisibility.setAssetStudyCostReadOnly(true);
	      assetThirdPartyAttributePanelVisibility.setGrantApprovalCostReadOnly(true);
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetStudyCost(true);
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityGrantApprovalCost(false);
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityFinalCost(true);
	      assetThirdPartyAttributePanelVisibility.setFinalCostReadOnly(false);
	      assetThirdPartyAttributePanelVisibility.setPanelVisibilityAssetRemainingCost(true);
	    }
		return assetThirdPartyAttributePanelVisibility;
	}
	@Override
	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		return true;
	}

	@Override
	public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		return "";
	}
}
