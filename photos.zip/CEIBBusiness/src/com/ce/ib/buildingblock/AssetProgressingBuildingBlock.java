package com.ce.ib.buildingblock;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;

import bf.com.misys.ce.api.dto.AssetProgressDTO;
import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressingBuildingBlock extends AbstractIslamicBuildingBlock {
	private transient final static Log LOGGER = LogFactory
			.getLog(AssetProgressingBuildingBlock.class.getName());
	

	@Override
	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		return true;
	}

	@Override
	public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		AssetProgressDTO assetProgressDTO = (AssetProgressDTO) abstractBuildingBlock;
		AssetProgressingFatom assetProgressFatom = new AssetProgressingFatom(IBCommonUtils.getBankFusionEnvironment());
		assetProgressFatom.setF_IN_mode(AssetProgressingFatom.SAVE);
		assetProgressFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetProgressFatom.setF_IN_allAssetProgressPricingList(assetProgressDTO.getAssetProgressPricingList());
		assetProgressFatom.setF_IN_assetProgressReportDetails(assetProgressDTO.getAssetProgressReportDetails());
		assetProgressFatom.process(IBCommonUtils.getBankFusionEnvironment());
		return IBCommonUtils.getNextBuildingBlockDtls(islamicBankingObject.getProcessConfigID(),
				islamicBankingObject.getStepID(), islamicBankingObject.getPhaseID());
	}
	
	@Override
	 public AbstractBuildingBlock getBuildingBlockDetails(IslamicBankingObject islamicBankingObject) {
		AssetProgressDTO assetProgressDTO = new AssetProgressDTO();
		AssetProgressingFatom assetProgressFatom = new AssetProgressingFatom(IBCommonUtils.getBankFusionEnvironment());
		assetProgressFatom.setF_IN_mode(AssetProgressingFatom.RETRIEVE);
		assetProgressFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetProgressFatom.process(IBCommonUtils.getBankFusionEnvironment());
		assetProgressDTO.setAssetProgressPricingList(assetProgressFatom.getF_OUT_allAssetProgressPricingList());
		assetProgressDTO.setAssetProgressReportDetails(assetProgressFatom.getF_OUT_assetProgressReportDetails());
		return assetProgressDTO;
	 }

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig arg0, boolean arg1) {
		return null;
	}


}
