package com.ce.ib.buildingblock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.APIUtils;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ce.api.dto.AssetCategory;
import bf.com.misys.ce.api.dto.FollowUpAssetDetails;
import bf.com.misys.ce.api.dto.FollowUpCropDetails;
import bf.com.misys.ce.api.dto.FollowUpDetails;
import bf.com.misys.ce.api.dto.FollowUpDetailsDTO;
import bf.com.misys.dealfollowup.dtls.ib.types.DealFollowUpDetails;
import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.api.bb.dto.AdditionalFieldInfo;
import bf.com.misys.ib.api.bb.dto.AssetAttributeInfo;
import bf.com.misys.ib.types.AdditionalFieldsEditableTags;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.ib.types.IslamicBankingObject;
import edu.emory.mathcs.backport.java.util.Arrays;

public class DealFollowUpProcessBuildingBlock extends AbstractIslamicBuildingBlock {

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
		String mode = CommonConstants.EMPTY_STRING;
		if (isDealEnquiry)
			mode = BuildingBlockConstants.MODE_VIEW;
		AdditionalFieldsEditableTags readOnlyTags = new AdditionalFieldsEditableTags();
		readOnlyTags.setAllTags(true);
		if (mode.equals(BuildingBlockConstants.MODE_VIEW))
			readOnlyTags.setAllTags(false);

		return readOnlyTags;
	}

	@Override
	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_ACTION);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF(CeConstants.DEALFOLLOWUPPROCESS_PRC, BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}

	@Override
	public boolean executeReverseAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_REVERSAL);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF(CeConstants.DEALFOLLOWUPPROCESS_PRC, BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}

	@Override
	public boolean isBuildingBlockSuppresed(IslamicBankingObject islamicBankingObject) {
		List<IBOCE_IB_DealFollowUpDtls> dealFollowUpDtls = DealFollowUpUtils
				.getFollowUpDtlsFromDB(islamicBankingObject.getDealID());
		return dealFollowUpDtls != null && !dealFollowUpDtls.isEmpty();
	}

	@Override
	public AbstractBuildingBlock getBuildingBlockDetails(IslamicBankingObject islamicBankingObject) {
		FollowUpDetailsDTO followUpDetailDTO = null;
		followUpDetailDTO = callReadFollowUpDetailsService(islamicBankingObject);
		return followUpDetailDTO;
	}

	private FollowUpDetailsDTO callReadFollowUpDetailsService(IslamicBankingObject islamicBankingObject) {
		FollowUpDetailsDTO followUpDetailDTO = new FollowUpDetailsDTO();
		HashMap inputParams = new HashMap();
		inputParams.put("islamicBankingObject", islamicBankingObject);
		inputParams.put("mode", "ON_LOAD");
		HashMap outputParams = MFExecuter.executeMF("CE_IB_GetDealFollowUpDtls_SRV",
				IBCommonUtils.getBankFusionEnvironment(), inputParams);
		DealFollowUpDetails dealFollowUpDetails = (DealFollowUpDetails) outputParams.get("dealFollowUpDetails");
		List<FollowUpAssetDetails> followUpAssetDetails = new ArrayList<>();
		List<FollowUpCropDetails> followUpCropDetails = Arrays.asList(dealFollowUpDetails.getFollowUpCropDetails());
		List<FollowUpDetails> followUpDetails = Arrays.asList(dealFollowUpDetails.getFollowUpDetails());

		followUpDetailDTO.setFollowUpDetails(followUpDetails);
		followUpDetailDTO.setFollowUpCropDetails(followUpCropDetails);

		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpAssetDetails().length > 0) {
			for(bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails assetDetails : dealFollowUpDetails.getFollowUpAssetDetails()) {
				FollowUpAssetDetails assetDetailsDTO = new FollowUpAssetDetails();
				AssetCategory assetCategory = new AssetCategory();
				assetCategory.setCategorization(assetDetails.getAssetCategory().getCategorization());
				assetCategory.setCategory(assetDetails.getAssetCategory().getCategory());
				assetCategory.setSubCategory(assetDetails.getAssetCategory().getSubCategory());
				assetDetailsDTO.setAssetCategory(assetCategory);
				assetDetailsDTO.setAssetExist(assetDetails.getAssetExist());
				assetDetailsDTO.setAssetId(assetDetails.getAssetId());
				assetDetailsDTO.setAssetName(assetDetails.getAssetName());
				assetDetailsDTO.setFollowUpId(assetDetails.getFollowUpId());
				assetDetailsDTO.setStudyCost(APIUtils.getAPICurrencyAmount(assetDetails.getStudyCost()));
				assetDetailsDTO.setFinalCost(APIUtils.getAPICurrencyAmount(assetDetails.getFinalCost()));
				assetDetailsDTO.setMachineNumber(assetDetails.getMachineNumber());
				assetDetailsDTO.setNotes(assetDetails.getNotes());
				assetDetailsDTO.setSpecificationsOnSite(assetDetails.getSpecificationsOnSite());
				assetDetailsDTO.setStatus(assetDetails.getStatus());
				followUpAssetDetails.add(assetDetailsDTO);
			}
			followUpDetailDTO.setFollowUpAssetDetails(followUpAssetDetails);
			
			for (FollowUpAssetDetails assetDetails : followUpDetailDTO.getFollowUpAssetDetails()) {
				HashMap<String, Object> assetUDFMap = CeUtils.getAssetUDFForAPI(assetDetails.getAssetCategory().getCategory(),
						islamicBankingObject.getDealID(), dealFollowUpDetails.getFollowUpAssetUDFs().getAssetUDFs());
				if (assetUDFMap != null && !assetUDFMap.isEmpty()) {
					assetDetails
							.setAdditionalInfo((List<AdditionalFieldInfo>) assetUDFMap.get("additionalFieldInfoList"));
					assetDetails
							.setAssetAttributeInfo((List<AssetAttributeInfo>) assetUDFMap.get("assetAttributeList"));
				}
			}
		}

		return followUpDetailDTO;
	}

	@Override
	public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		callFollowUpExecuteProcess(islamicBankingObject, abstractBuildingBlock);
		return IBCommonUtils.getNextBuildingBlockDtls(islamicBankingObject.getProcessConfigID(),
				islamicBankingObject.getStepID(), islamicBankingObject.getPhaseID());
	}

	private void callFollowUpExecuteProcess(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {

		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(0);
		pagingRequest.setRequestedPage(0);
		pagingRequest.setTotalPages(0);
		pagedQuery.setPagingRequest(pagingRequest);
		HashMap inputParams = new HashMap();
		inputParams.put(IBConstants.BB_TASK_ID_TAG_NAME, islamicBankingObject.getTaskType());
		islamicBankingObject.setTaskType(IBConstants.EMPTY_STRING);
		islamicBankingObject.setMode(IBConstants.EMPTY_STRING);

		FollowUpDetailsDTO followUpDtlFromAPI = (FollowUpDetailsDTO) abstractBuildingBlock;
		DealFollowUpDetails dealFollowUpDetails = new DealFollowUpDetails();
		setFollowUpDetail(dealFollowUpDetails, followUpDtlFromAPI);
		setFollowUpAssetDetails(islamicBankingObject, dealFollowUpDetails, followUpDtlFromAPI);
		setFollowUpCropDetails(dealFollowUpDetails, followUpDtlFromAPI);
		setAssetUDF(dealFollowUpDetails, followUpDtlFromAPI);

		inputParams.put(IBConstants.BB_TASK_INPUT_PAYLOAD_TAG_NAME, islamicBankingObject);
		inputParams.put("dealFollowupDtlsAPI", dealFollowUpDetails);
		MFExecuter.executeMF("CE_IB_DealFollowUp_PRC", inputParams,
				BankFusionThreadLocal.getUserLocator().getStringRepresentation());
	}

	private void setAssetUDF(DealFollowUpDetails dealFollowUpDetails, FollowUpDetailsDTO followUpDtlFromAPI) {
		AssetUDFsCollection assetUDFsCollection = new AssetUDFsCollection();
		if (followUpDtlFromAPI != null && !followUpDtlFromAPI.getFollowUpAssetDetails().isEmpty()) {
			// loop for additional fields
			for (FollowUpAssetDetails followUpAssetDetails : followUpDtlFromAPI.getFollowUpAssetDetails()) {
				if (followUpAssetDetails.getAdditionalInfo() != null
						&& !followUpAssetDetails.getAdditionalInfo().isEmpty()) {
					for (AdditionalFieldInfo additionalFieldInfo : followUpAssetDetails.getAdditionalInfo()) {
						AssetUDF assetUDF = new AssetUDF();
						assetUDF.setAssetid(followUpAssetDetails.getAssetId());
						assetUDF.setFieldId(additionalFieldInfo.getAdditionalFieldDetails().getKey());
						assetUDF.setFieldValue(String.valueOf(additionalFieldInfo.getAdditionalFieldDetails().getValue()));
						assetUDFsCollection.addAssetUDFs(assetUDF);
					}
				}
			}
			// asset attributes
			for (FollowUpAssetDetails followUpAssetDetails : followUpDtlFromAPI.getFollowUpAssetDetails()) {
				if (followUpAssetDetails.getAssetAttributeInfo() != null
						&& !followUpAssetDetails.getAssetAttributeInfo().isEmpty()) {
					for (AssetAttributeInfo assetAttribueInfo : followUpAssetDetails.getAssetAttributeInfo()) {
						AssetUDF assetUDF = new AssetUDF();
						assetUDF.setAssetid(followUpAssetDetails.getAssetId());
						assetUDF.setFieldId(assetAttribueInfo.getAssetAttributeDetails().getKey());
						assetUDF.setFieldValue(String.valueOf(assetAttribueInfo.getAssetAttributeDetails().getValue()));
						assetUDFsCollection.addAssetUDFs(assetUDF);
					}
				}
			}
		}
		dealFollowUpDetails.setFollowUpAssetUDFs(assetUDFsCollection);
	}

	private void setFollowUpDetail(DealFollowUpDetails dealFollowUpDetails, FollowUpDetailsDTO followUpDtlFromAPI) {
		if (followUpDtlFromAPI != null && !followUpDtlFromAPI.getFollowUpDetails().isEmpty()) {
			for (FollowUpDetails followUpDetails : followUpDtlFromAPI.getFollowUpDetails()) {
				IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(followUpDetails.getDealId());
				bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails followUpDtl = DealFollowUpUtils
						.initializeFollowUpDetail(dealDetails);
				followUpDtl.setCustomerStatus(followUpDetails.getCustomerStatus());
				followUpDtl.setFarmStatus(followUpDetails.getFarmStatus());
				followUpDtl.setFollowUpStatus(followUpDetails.getFollowUpStatus());
				dealFollowUpDetails.addFollowUpDetails(followUpDtl);
			}
		}
	}

	private void setFollowUpCropDetails(DealFollowUpDetails dealFollowUpDetails,
			FollowUpDetailsDTO followUpDtlFromAPI) {
		bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails followUpDetails = dealFollowUpDetails
				.getFollowUpDetails(0);
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(followUpDetails.getDealId());
		if (followUpDtlFromAPI != null && !followUpDtlFromAPI.getFollowUpCropDetails().isEmpty()) {
			for (FollowUpCropDetails followUpCropDetails : followUpDtlFromAPI.getFollowUpCropDetails()) {
				bf.com.misys.dealfollowup.dtls.ib.types.FollowUpCropDetails cropDetails = new bf.com.misys.dealfollowup.dtls.ib.types.FollowUpCropDetails();
				cropDetails.setCropId(followUpCropDetails.getCropId());
				cropDetails.setFollowUpId(followUpDetails.getFollowUpId());
				cropDetails.setUsedAreaInFollowUpReport(followUpCropDetails.getUsedAreaInFollowUpReport());
				cropDetails.setExpectedRevenue(
						IBCommonUtils.getBFCurrencyAmount(followUpCropDetails.getExpectedRevenue().getAmount(),
								followUpCropDetails.getExpectedRevenue().getCurrency()));			
				cropDetails.setCropType(followUpCropDetails.getCropType());

				dealFollowUpDetails.addFollowUpCropDetails(cropDetails);
			}
		} else {
			DealFollowUpUtils.initializeFollowUpCropDtls(dealFollowUpDetails, followUpDetails.getFollowUpId(),
					followUpDetails.getDealId(), dealDetails.getF_IsoCurrencyCode());
		}
	}

	private void setFollowUpAssetDetails(IslamicBankingObject islamicBankingObject, DealFollowUpDetails dealFollowUpDetails,
			FollowUpDetailsDTO followUpDtlFromAPI) {
		bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails followUpDetails = dealFollowUpDetails
				.getFollowUpDetails(0);
		if (followUpDtlFromAPI != null && !followUpDtlFromAPI.getFollowUpAssetDetails().isEmpty()) {
			for (FollowUpAssetDetails followUpAssetDetails : followUpDtlFromAPI.getFollowUpAssetDetails()) {
				bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails assetDetails = new bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails();
				assetDetails.setAssetId(followUpAssetDetails.getAssetId());
				assetDetails.setAssetExist(followUpAssetDetails.getAssetExist());
				assetDetails.setMachineNumber(followUpAssetDetails.getMachineNumber());
				assetDetails.setSpecificationsOnSite(followUpAssetDetails.getSpecificationsOnSite());
				assetDetails.setNotes(followUpAssetDetails.getNotes());
				assetDetails.setFollowUpId(followUpDetails.getFollowUpId());

				dealFollowUpDetails.addFollowUpAssetDetails(assetDetails);
			}
		} else {
			DealFollowUpUtils.initializeFollowupAssetDtls(islamicBankingObject, dealFollowUpDetails, followUpDetails.getFollowUpId(),
					followUpDetails.getDealId());
		}
	}

	@Override
	public boolean validateBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		FollowUpDetailsDTO followUpDetails = (FollowUpDetailsDTO) abstractBuildingBlock;
		validateAtleastOneFollowUpDtl(followUpDetails);
		validateMultipleFollowUpDtls(followUpDetails);
		validateMandatoryInputs(followUpDetails);
		validateFollowUpStatus(followUpDetails);
		validateFarmStatus(followUpDetails);
		return true;
	}

	private void validateAtleastOneFollowUpDtl(FollowUpDetailsDTO followUpDetails) {
		if (followUpDetails == null || (followUpDetails != null && followUpDetails.getFollowUpDetails().isEmpty()))
			IBCommonUtils.raiseUnparameterizedEvent(44000232);

	}

	private void validateFarmStatus(FollowUpDetailsDTO followUpDetails) {
		ListGenericCodeRs followUpStatusCodes = IBCommonUtils.getGCList("CEFARMSTATUS");
		if (followUpDetails != null && !followUpDetails.getFollowUpDetails().isEmpty()) {
			boolean isValidSector = false;
			for (GcCodeDetail followUpStatus : followUpStatusCodes.getGcCodeDetails()) {
				if (followUpStatus.getCodeValue()
						.equalsIgnoreCase(followUpDetails.getFollowUpDetails().get(0).getFarmStatus())) {
					isValidSector = true;
				}
			}
			if (!isValidSector) {
				String[] msgArgs = { "Farm Status", followUpDetails.getFollowUpDetails().get(0).getFarmStatus() };
				IBCommonUtils.raiseParametrizedEvent(IBConstants.E_INPUT_TAG_INVALID, msgArgs);

			}
		}

	}

	private void validateMandatoryInputs(FollowUpDetailsDTO followUpDetails) {
		IBCommonUtils.isValidateMandatoryField(followUpDetails.getFollowUpDetails().get(0).getFollowUpStatus(),
				"Follow Up Status");
		IBCommonUtils.isValidateMandatoryField(followUpDetails.getFollowUpDetails().get(0).getFarmStatus(),
				"Farm Status");
		IBCommonUtils.isValidateMandatoryField(followUpDetails.getFollowUpDetails().get(0).getCustomerStatus(),
				"Customer Status");
		IBCommonUtils.isValidateMandatoryField(followUpDetails.getFollowUpDetails().get(0).getDealId(), "Deal Id");
	}

	private void validateFollowUpStatus(FollowUpDetailsDTO followUpDetails) {
		ListGenericCodeRs followUpStatusCodes = IBCommonUtils.getGCList("CEFOLLOWUPSTATUS");
		if (followUpDetails != null && !followUpDetails.getFollowUpDetails().isEmpty()) {
			boolean isValidSector = false;
			for (GcCodeDetail followUpStatus : followUpStatusCodes.getGcCodeDetails()) {
				if (followUpStatus.getCodeValue()
						.equalsIgnoreCase(followUpDetails.getFollowUpDetails().get(0).getFollowUpStatus())) {
					isValidSector = true;
				}
			}
			if (!isValidSector) {
				String[] msgArgs = { "Follow Up Status",
						followUpDetails.getFollowUpDetails().get(0).getFollowUpStatus() };
				IBCommonUtils.raiseParametrizedEvent(IBConstants.E_INPUT_TAG_INVALID, msgArgs);
			}
		}
	}

	private void validateMultipleFollowUpDtls(FollowUpDetailsDTO followUpDetails) {
		if (followUpDetails != null && followUpDetails.getFollowUpDetails().size() > 1)
			IBCommonUtils.raiseUnparameterizedEvent(44000231);

	}
}
