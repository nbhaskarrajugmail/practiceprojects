/**
 * 
 */
package com.ce.ib.cfg.dto;

import bf.com.misys.ib.types.PricingList;

/**
 * @author chethabn
 *
 */
public class PriceListDto {
	private PricingList pricingList;

	/**
	 * @return the pricingList
	 */
	public PricingList getPricingList() {
		return pricingList;
	}

	/**
	 * @param pricingList
	 *            the pricingList to set
	 */
	public void setPricingList(PricingList pricingList) {
		this.pricingList = pricingList;
	}

}
