package com.ce.ib.cfg.bo;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListCfg;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.cfg.dto.PriceListDto;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListAssetCfg;
import bf.com.misys.ib.types.PricingListCfg;

public class PriceList {
	public static final String LIKE = "  like ?";
	/**
	 * "WHERE " + IBOCE_IB_PricingListAssetCfg.IBPRICINGLISTID + " =?";
	 */
	private static String PRICINGLISTASST_WHERECLAUSE = "WHERE " + IBOCE_IB_PricingListAssetCfg.IBPRICINGLISTID + " =?";
	private static String PRICINGLIST_WHERECLAUSE = "WHERE " + IBOCE_IB_PricingListCfg.IBPRICINGLISTID + " =?";

	/**
	 * 
	 * @param referenceNo
	 * @param year
	 * @param asstCategory
	 * @return
	 */
	public PriceListDto getPriceList(String referenceNo, Integer year, AsstCategory asstCategory) {
		String asstCat = asstCategory.getCategory();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		PriceListDto dto = new PriceListDto();
		StringBuilder registyDtlsWhereClause1 = new StringBuilder("WHERE ");
		ArrayList params = new ArrayList();
		String and = " AND ";
		if (StringUtils.isNotEmpty(referenceNo)) {
			params.add(referenceNo);
			registyDtlsWhereClause1.append(IBOCE_IB_PricingListCfg.IBREFERENCENUMBER + LIKE);
		}
		if (year > 0 && year != 1979) {
			if (registyDtlsWhereClause1.length() > 6) {
				registyDtlsWhereClause1.append(and);
			}
			params.add(year);
			registyDtlsWhereClause1.append(IBOCE_IB_PricingListCfg.IBPRICELISTYEAR + " = ?");
		}

		List<IBOCE_IB_PricingListCfg> pricingList;
		if (registyDtlsWhereClause1.toString().equals("WHERE ")) {
			pricingList = factory.findAll(IBOCE_IB_PricingListCfg.BONAME, null, true);
		} else {
			pricingList = factory.findByQuery(IBOCE_IB_PricingListCfg.BONAME, registyDtlsWhereClause1.toString(),
					params, null, true);
		}
		String[] pricingId = new String[pricingList.size()];
		List<String> price = new ArrayList<>();
		for (int i = 0; i < pricingList.size(); i++) {
			price.add(pricingList.get(i).getBoID());
			pricingId[i] = pricingList.get(i).getBoID();
		}
		List<IBOCE_IB_PricingListAssetCfg> priceAssetList = getPriceListAssetbyAsstCategory(asstCat, pricingId);
		if (null != priceAssetList && !priceAssetList.isEmpty() && StringUtils.isNotEmpty(asstCat) ) {
			StringBuilder whereClause1 = new StringBuilder(" Where " + IBOCE_IB_PricingListCfg.IBPRICINGLISTID);
			ArrayList params1 = new ArrayList();
			new StringBuilder(whereClause1.append(" IN ("));
			for (int i = 0; i < priceAssetList.size(); i++) {
				whereClause1.append("?,");
				params1.add(priceAssetList.get(i).getF_IBPRICINGLISTID());
			}
			whereClause1 = new StringBuilder(whereClause1.substring(0, whereClause1.lastIndexOf(","))).append(")");
			pricingList = factory.findByQuery(IBOCE_IB_PricingListCfg.BONAME, whereClause1.toString(), params1, null,
					true);
		}
		if (!pricingList.isEmpty()) {
			preparePricingList(dto, pricingList);
			preparePricingListAssets(dto, priceAssetList);
		}
		return dto;
	}

	private void preparePricingList(PriceListDto dto, List<IBOCE_IB_PricingListCfg> pricingList) {
		List<PricingListCfg> pricingLists = new ArrayList<>();

		for (IBOCE_IB_PricingListCfg priceList : pricingList) {
			PricingListCfg priceListcfg = new PricingListCfg();
			priceListcfg.setPricingListId(priceList.getBoID());
			priceListcfg.setDocumentDate(priceList.getF_IBDOCUMENTDATE());
			priceListcfg.setDocumentNumber(priceList.getF_IBDOCUMENTNUMBER());
			priceListcfg.setPriceListYear(priceList.getF_IBPRICELISTYEAR());
			priceListcfg.setPricingListDate(priceList.getF_IBPRICINGLISTDATE());
			priceListcfg.setReferenceNumber(priceList.getF_IBREFERENCENUMBER());
			priceListcfg.setVendorId(priceList.getF_IBVENDORID());
			priceListcfg.setVendorName(priceList.getF_IBVENDORNAME());
			priceListcfg.setVendorType(priceList.getF_IBVENDORTYPE());
			pricingLists.add(priceListcfg);
		}
		PricingListCfg[] priceListArray = pricingLists.toArray(new PricingListCfg[pricingLists.size()]);
		bf.com.misys.ib.types.PricingList pricLst = new bf.com.misys.ib.types.PricingList();
		pricLst.setPricingListDtls(priceListArray);
		dto.setPricingList(pricLst);
	}

	private void preparePricingListAssets(PriceListDto priceList, List<IBOCE_IB_PricingListAssetCfg> priceAssetList) {
		List<PricingListAssetCfg> priceListAsstCfg = new ArrayList<>();
		for (IBOCE_IB_PricingListAssetCfg priceAsset : priceAssetList) {
			PricingListAssetCfg asstCfg = new PricingListAssetCfg();
			asstCfg.setAssetSerial(priceAsset.getBoID());
			asstCfg.setAssetCategory(CeUtils.getAssetCategory(priceAsset.getF_IBASSETCATEGORY()));
			asstCfg.setHorsePower(priceAsset.getF_IBHORSEPOWER());
			asstCfg.setMachineNumber(priceAsset.getF_IBMACHINENUMBER());
			asstCfg.setModel(priceAsset.getF_IBMODEL());
			BFCurrencyAmount currency = new BFCurrencyAmount();
			currency.setCurrencyAmount(priceAsset.getF_IBPRICE());
			currency.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
			asstCfg.setPrice(currency);
			asstCfg.setPricingListId(priceAsset.getF_IBPRICINGLISTID());
			asstCfg.setExtensionIndicator(priceAsset.isF_IBEXTENSIONINDICATOR());
			asstCfg.setStatus((Boolean.compare(priceAsset.isF_IBSTATUS(), Boolean.TRUE) == 0) ? "ACTIVE" : "INACTIVE");
			asstCfg.setAttribute1(priceAsset.getF_IBATTRIBUTE1());
			asstCfg.setAttribute2(priceAsset.getF_IBATTRIBUTE2());
			asstCfg.setAttribute3(priceAsset.getF_IBATTRIBUTE3());
			asstCfg.setMachineType(priceAsset.getF_IBMACHINETYPE());
			asstCfg.setRegistryId(priceAsset.getF_IBREGISTRYID());
			asstCfg.setNewPricingListNum1(priceAsset.getF_NEWPRICELISTNUM1());
			asstCfg.setNewPricingListNum2(priceAsset.getF_NEWPRICELISTNUM2());
			asstCfg.setNewPLDate1(priceAsset.getF_NEWPLDATE1());
			asstCfg.setNewPLDate2(priceAsset.getF_NEWPLDATE2());
			asstCfg.setNewPLYear1(priceAsset.getF_NEWPLYEAR1());
			asstCfg.setNewPLYear2(priceAsset.getF_NEWPLYEAR2());
			priceListAsstCfg.add(asstCfg);
		}

		PricingListAssetCfg[] priceListAssets = priceListAsstCfg
				.toArray(new PricingListAssetCfg[priceListAsstCfg.size()]);
		priceList.getPricingList().setPricingListAssetDtls(priceListAssets);
	}

	/**
	 * 
	 * @param assetCat
	 * @param pricingId
	 * @return
	 */
	public List<IBOCE_IB_PricingListAssetCfg> getPriceListAssetbyAsstCategory(String assetCat, String[] pricingId) {

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		StringBuilder whereClause = new StringBuilder(" Where " + IBOCE_IB_PricingListAssetCfg.IBPRICINGLISTID);
		ArrayList params = new ArrayList();
		String and = " AND ";
		if (pricingId.length > 0) {
			new StringBuilder(whereClause.append(" IN ("));
			for (int i = 0; i < pricingId.length; i++) {
				whereClause.append("?,");
				params.add(pricingId[i]);
			}
			whereClause = new StringBuilder(whereClause.substring(0, whereClause.lastIndexOf(","))).append(")");
		}
		if (StringUtils.isNotEmpty(assetCat)) {
			whereClause.append(and);
			params.add(assetCat);
			whereClause.append(IBOCE_IB_PricingListAssetCfg.IBASSETCATEGORY + " = ?");
		}

		List<IBOCE_IB_PricingListAssetCfg> priceAsstList = new ArrayList<>();
		if (whereClause.toString().equals("WHERE ")) {
			priceAsstList = factory.findAll(IBOCE_IB_PricingListAssetCfg.BONAME, null, true);
		} else {
			priceAsstList = factory.findByQuery(IBOCE_IB_PricingListAssetCfg.BONAME, whereClause.toString(), params,
					null, true);
		}
		return priceAsstList;
	}

	public void savePricingList(PricingList pricingList) {
		PricingListAssetCfg[] pricingListAssetCfgs = pricingList.getPricingListAssetDtls();
		PricingListCfg[] pricingListCfgs = pricingList.getPricingListDtls();
		for (PricingListCfg pricingListCfg : pricingListCfgs) {
			savePricingList(pricingListCfg);
		}
		savePricingAssetList(StringUtils.EMPTY, pricingListAssetCfgs);
	}

	/**
	 * 
	 * @param pricingListCfg
	 */
	public void savePricingList(PricingListCfg pricingListCfg) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_PricingListCfg priceLsitCfg = (IBOCE_IB_PricingListCfg) factory
				.findByPrimaryKey(IBOCE_IB_PricingListCfg.BONAME, pricingListCfg.getPricingListId(), true);
		if (null == priceLsitCfg) {// && StringUtils.isEmpty(priceLsitCfg.getBoID())) {
			createPricingList(pricingListCfg, factory);
		} else {
			deletePricingListById(priceLsitCfg.getBoID(), factory);
			createPricingList(pricingListCfg, factory);
		}
	}

	private int deletePricingListById(String priceLsitCfgId, IPersistenceObjectsFactory factory) {
		ArrayList<String> params = new ArrayList<>();
		params.add(priceLsitCfgId);
		int res = factory.bulkDelete(IBOCE_IB_PricingListCfg.BONAME, PRICINGLIST_WHERECLAUSE, params);
		factory.commitTransaction();
		factory.beginTransaction();
		return res;

	}

	private void createPricingList(PricingListCfg pricingListCfg, IPersistenceObjectsFactory factory) {
		IBOCE_IB_PricingListCfg priceListCfg = (IBOCE_IB_PricingListCfg) factory
				.getStatelessNewInstance(IBOCE_IB_PricingListCfg.BONAME);
		priceListCfg.setBoID(pricingListCfg.getPricingListId());
		priceListCfg.setF_IBDOCUMENTNUMBER(pricingListCfg.getDocumentNumber());
		priceListCfg.setF_IBDOCUMENTDATE(pricingListCfg.getDocumentDate());
		priceListCfg.setF_IBPRICELISTYEAR(pricingListCfg.getPriceListYear());
		priceListCfg.setF_IBPRICINGLISTDATE(pricingListCfg.getPricingListDate());
		priceListCfg.setF_IBVENDORID(pricingListCfg.getVendorId());
		priceListCfg.setF_IBVENDORNAME(pricingListCfg.getVendorName());
		priceListCfg.setF_IBVENDORTYPE(pricingListCfg.getVendorType());
		priceListCfg.setF_IBREFERENCENUMBER(pricingListCfg.getReferenceNumber());
		factory.create(IBOCE_IB_PricingListCfg.BONAME, priceListCfg);
	}

	public PriceListDto getPriceListAssetbyPriceListId(String pricingListID) {
		PriceListDto priceListDto = CeUtils.getPriceListDto();
		List<IBOCE_IB_PricingListAssetCfg> priceListAssets = getPriceListAssetbyAsstCategory(StringUtils.EMPTY,
				new String[] { pricingListID });
		preparePricingListAssets(priceListDto, priceListAssets);
		return priceListDto;
	}

	/**
	 * 
	 * @param priceListID
	 * @param pricingListAssetCfg
	 */
	public void savePricingAssetList(String priceListID, PricingListAssetCfg[] pricingListAssetCfg) {
		deletePricingAssetListByPricingListId(priceListID);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_PricingListAssetCfg priceListAsstCfg = (IBOCE_IB_PricingListAssetCfg) factory
				.getStatelessNewInstance(IBOCE_IB_PricingListAssetCfg.BONAME);
		for (PricingListAssetCfg pricingListAssets : pricingListAssetCfg) {
			priceListAsstCfg.setBoID(pricingListAssets.getAssetSerial());
			priceListAsstCfg.setF_IBASSETCATEGORY(pricingListAssets.getAssetCategory().getCategory());
			priceListAsstCfg.setF_IBEXTENSIONINDICATOR(pricingListAssets.getExtensionIndicator());
			priceListAsstCfg.setF_IBHORSEPOWER(pricingListAssets.getHorsePower());
			priceListAsstCfg.setF_IBMACHINENUMBER(pricingListAssets.getMachineNumber());
			priceListAsstCfg.setF_IBMODEL(pricingListAssets.getModel());
			priceListAsstCfg.setF_IBPRICE(pricingListAssets.getPrice().getCurrencyAmount());
			priceListAsstCfg.setF_IBPRICINGLISTID(
					StringUtils.isNotEmpty(pricingListAssets.getPricingListId()) ? pricingListAssets.getPricingListId()
							: priceListID);
			priceListAsstCfg.setF_IBSTATUS((pricingListAssets.getStatus()).equalsIgnoreCase("Active") ? true : false);
			priceListAsstCfg.setF_IBATTRIBUTE1(pricingListAssets.getAttribute1());
			priceListAsstCfg.setF_IBATTRIBUTE2(pricingListAssets.getAttribute2());
			priceListAsstCfg.setF_IBATTRIBUTE3(pricingListAssets.getAttribute3());
			priceListAsstCfg.setF_IBMACHINETYPE(pricingListAssets.getMachineType());
			priceListAsstCfg.setF_IBREGISTRYID(pricingListAssets.getRegistryId());
			priceListAsstCfg.setF_NEWPRICELISTNUM1(pricingListAssets.getNewPricingListNum1());
			priceListAsstCfg.setF_NEWPRICELISTNUM2(pricingListAssets.getNewPricingListNum2());
			priceListAsstCfg.setF_NEWPLDATE1(pricingListAssets.getNewPLDate1());
			priceListAsstCfg.setF_NEWPLDATE2(pricingListAssets.getNewPLDate2());
			priceListAsstCfg.setF_NEWPLYEAR1(pricingListAssets.getNewPLYear1());
			priceListAsstCfg.setF_NEWPLYEAR2(pricingListAssets.getNewPLYear2());
			factory.beginTransaction();
			factory.create(IBOCE_IB_PricingListAssetCfg.BONAME, priceListAsstCfg);
			factory.commitTransaction();
		}
	}

	/**
	 * 
	 * @param pricingListId
	 * @return
	 */
	public int deletePricingAssetListByPricingListId(String pricingListId) {
		int res = 0;
		if (StringUtils.isNotEmpty(pricingListId)) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(pricingListId);
			res = factory.bulkDelete(IBOCE_IB_PricingListAssetCfg.BONAME, PRICINGLISTASST_WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}

}
