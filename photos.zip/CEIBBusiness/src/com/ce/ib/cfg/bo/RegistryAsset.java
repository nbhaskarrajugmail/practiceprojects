package com.ce.ib.cfg.bo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.RegistryAssetListCfg;

public class RegistryAsset {
	private static final Log logger = LogFactory.getLog(RegistryAsset.class);

	public void createRegistryAssetDtls(RegistryAssetListCfg[] regAsset, String regId) {
		try {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			deleteRegistryAssetListByRegistryId(regId, factory);

			for (RegistryAssetListCfg registryAssetListCfg : regAsset) {
				regId = (StringUtils.isNotEmpty(registryAssetListCfg.getRegistryId()) ? registryAssetListCfg.getRegistryId()
						: regId);
					IBOCE_IB_RegistryAssetCfg assetCfg = (IBOCE_IB_RegistryAssetCfg) factory
							.getStatelessNewInstance(IBOCE_IB_RegistryAssetCfg.BONAME);
					assetCfg.setF_IBASSETCATEGORY(registryAssetListCfg.getAssetCategory().getCategory());
					assetCfg.setBoID(registryAssetListCfg.getAssetSerial());
					assetCfg.setF_IBREGISTRYID(regId);
					assetCfg.setF_IBHORSEPOWER(new BigDecimal(0));
					assetCfg.setF_IBMODEL(registryAssetListCfg.getModel());
					assetCfg.setF_IBVENDORID(registryAssetListCfg.getVendorId());
					assetCfg.setF_IBVENDORNAME(registryAssetListCfg.getVendorName());
					assetCfg.setF_IBPRICE(registryAssetListCfg.getPrice().getCurrencyAmount());
					assetCfg.setF_IBATTRIBUTE1(registryAssetListCfg.getAttribute1());
					assetCfg.setF_IBATTRIBUTE2(registryAssetListCfg.getAttribute2());
					assetCfg.setF_IBATTRIBUTE3(registryAssetListCfg.getAttribute3());
					assetCfg.setF_IBMACHINETYPE(registryAssetListCfg.getMachineType());
					factory.beginTransaction();
					factory.create(IBOCE_IB_RegistryAssetCfg.BONAME, assetCfg);
					factory.commitTransaction();
			}
		} catch (Exception e) {
			logger.error("Data insertion failed for RegistryAssetCfg" + e.getMessage());
			throw e;
		}

	}

	/**
	 * 
	 * @param pricingListId
	 * @return
	 */
	public int deleteRegistryAssetListByRegistryId(String registryListId, IPersistenceObjectsFactory factory) {
		int res = 0;
		String REGISTRYLISTASST_WHERECLAUSE = "WHERE " + IBOCE_IB_RegistryAssetCfg.IBREGISTRYID + " =?";
		if (StringUtils.isNotEmpty(registryListId)) {
			ArrayList<String> params = new ArrayList<>();
			params.add(registryListId);
			res = factory.bulkDelete(IBOCE_IB_RegistryAssetCfg.BONAME, REGISTRYLISTASST_WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}

	public RegistryAssetListCfg readRegistryAssetDtls() {

		return new RegistryAssetListCfg();
	}

	private List<IBOCE_IB_RegistryAssetCfg> getRegAsstDtlsByRegIds(String[] regIds) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		StringBuilder whereClause = new StringBuilder(" Where " + IBOCE_IB_RegistryAssetCfg.IBREGISTRYID + " IN (");
		ArrayList params = new ArrayList();
		for (int i = 0; i < regIds.length; i++) {
			whereClause.append("?,");
			params.add(regIds[i]);
		}
		whereClause = new StringBuilder(whereClause.substring(0, whereClause.lastIndexOf(","))).append(")");
		return factory.findByQuery(IBOCE_IB_RegistryAssetCfg.BONAME, whereClause.toString(), params, null, true);
	}

	public RegistryAssetListCfg[] getRegistryAsstByRegId(String[] regID) {
		String ass=null;
		List<IBOCE_IB_RegistryAssetCfg> registryAsstCfg = getRegAsstDtlsByRegIds(regID);
		RegistryAssetListCfg[] registryCfg = new RegistryAssetListCfg[registryAsstCfg.size()];
		for (int i = 0; i < registryAsstCfg.size(); i++) {
			RegistryAssetListCfg registryAsstList = new RegistryAssetListCfg();
			registryAsstList.setAssetCategory(CeUtils.getAssetCategory(registryAsstCfg.get(i).getF_IBASSETCATEGORY()));
			registryAsstList.setAssetSerial(registryAsstCfg.get(i).getBoID());
			registryAsstList.setHorsePower(registryAsstCfg.get(i).getF_IBHORSEPOWER());
			registryAsstList.setModel(registryAsstCfg.get(i).getF_IBMODEL());
			
			BFCurrencyAmount amount = new BFCurrencyAmount();
			amount.setCurrencyAmount(registryAsstCfg.get(i).getF_IBPRICE());
			amount.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
			registryAsstList.setPrice(amount);
			registryAsstList.setRegistryId(registryAsstCfg.get(i).getF_IBREGISTRYID());
			registryAsstList.setVendorId(registryAsstCfg.get(i).getF_IBVENDORID());
			registryAsstList.setVendorName(registryAsstCfg.get(i).getF_IBVENDORNAME());
			registryAsstList.setAttribute1(registryAsstCfg.get(i).getF_IBATTRIBUTE1());
			registryAsstList.setAttribute2(registryAsstCfg.get(i).getF_IBATTRIBUTE2());
			registryAsstList.setAttribute3(registryAsstCfg.get(i).getF_IBATTRIBUTE3());
			registryAsstList.setMachineType(registryAsstCfg.get(i).getF_IBMACHINETYPE());

			registryCfg[i] = registryAsstList;
		}
		return registryCfg;
	}

	public RegistryAssetListCfg[] getRegistryAsstByRegId(String registryId, RegistryAssetListCfg[] regAssList) {

		for (int i = 0; i < regAssList.length; i++) {
			if (!regAssList[i].getRegistryId().equals(registryId)) {
				regAssList[i] = regAssList[i + 1];
			}

		}
		return regAssList;
	}

}
