package com.ce.ib.cfg.bo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryListCfg;
import com.ce.ib.cfg.dto.RegistryDto;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.ib.types.RegistryAssetListCfg;
import bf.com.misys.ib.types.RegistryList;
import bf.com.misys.ib.types.RegistryListCfg;

/**
 * 
 * @author chethabn
 *
 */
public class Registry {
	public static final String LIKE = "  like ?";
	private static final Log LOGGER = LogFactory.getLog(Registry.class.getName());

	public RegistryDto getRegistryDtls(String referenceNo, Date docDate, String docNo, Date regDate) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		RegistryDto dto = new RegistryDto();
		StringBuilder registyDtlsWhereClause1 = new StringBuilder("WHERE ");
		ArrayList params = new ArrayList();
		String and = " AND ";
		if (StringUtils.isNotEmpty(referenceNo)) {
			params.add(referenceNo);
			registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBREFERENCENUMBER + LIKE);
		}
		if (StringUtils.isNotEmpty(docNo)) {
			if (registyDtlsWhereClause1.length() > 6) {
				registyDtlsWhereClause1.append(and);
			}
			params.add(docNo);
			registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBDOCUMENTNUMBER + LIKE);
		}
		if (null != docDate) {
			if (registyDtlsWhereClause1.length() > 6) {
				registyDtlsWhereClause1.append(and);
			}
			registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBDOCUMENTDATE + " =?");
			params.add(docDate);
		}
		if (null != regDate) {
			if (registyDtlsWhereClause1.length() > 6) {
				registyDtlsWhereClause1.append(and);
			}
			registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBREGISTRYDATE + " =?");

			params.add(regDate);
		}
		List<IBOCE_IB_RegistryListCfg> registryList = new ArrayList<>();
		if (registyDtlsWhereClause1.toString().equals("WHERE ")) {
			registryList = factory.findAll(IBOCE_IB_RegistryListCfg.BONAME, null, true);
		} else {
			registryList = factory.findByQuery(IBOCE_IB_RegistryListCfg.BONAME, registyDtlsWhereClause1.toString(),
					params, null, true);
		}
		RegistryList registryListDtls = new RegistryList();
		RegistryListCfg[] regListCfg = new RegistryListCfg[registryList.size()];
		String[] regID = new String[registryList.size()];
		for (int i = 0; i < registryList.size(); i++) {

			RegistryListCfg registryListCfg = new RegistryListCfg();
			registryListCfg.setDocumentDate(registryList.get(i).getF_IBDOCUMENTDATE());
			registryListCfg.setDocumentNumber(registryList.get(i).getF_IBDOCUMENTNUMBER());
			registryListCfg.setReferenceNumber(registryList.get(i).getF_IBREFERENCENUMBER());
			registryListCfg.setRegistryDate(registryList.get(i).getF_IBREGISTRYDATE());
			registryListCfg.setRegistryId(registryList.get(i).getBoID());
			regID[i] = registryList.get(i).getBoID();
			registryListCfg.setRegistryStatus(
					(Boolean.compare(registryList.get(i).isF_IBREGISTRYSTATUS(), Boolean.TRUE) == 0) ? "ACTIVE"
							: "INACTIVE");
			regListCfg[i] = registryListCfg;
		}
		registryListDtls.setRegistryListDtls(regListCfg);
		dto.setRegistryList(registryListDtls);
		return dto;
	}

	public String saveRegistry(RegistryList registryList) {
		LOGGER.info("Following details of Registry are stored to DB " + registryList);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		RegistryListCfg[] regList = registryList.getRegistryListDtls();
		for (RegistryListCfg cfg : regList) {
			saveRegistryList(cfg);
		}
		RegistryAssetListCfg[] assetListCfgs = registryList.getRegistryAssetListDtls();
		RegistryAsset registryAsset = new RegistryAsset();
		registryAsset.createRegistryAssetDtls(assetListCfgs, StringUtils.EMPTY);

		return "Success";
	}

	private void createRegistryList(IPersistenceObjectsFactory factory, RegistryListCfg cfg) {
		String regId;
		IBOCE_IB_RegistryListCfg regListCfg = (IBOCE_IB_RegistryListCfg) factory
				.getStatelessNewInstance(IBOCE_IB_RegistryListCfg.BONAME);
		regId = cfg.getRegistryId();
		regListCfg.setBoID(regId);
		regListCfg.setF_IBDOCUMENTDATE(cfg.getDocumentDate());
		regListCfg.setF_IBDOCUMENTNUMBER(cfg.getDocumentNumber());
		regListCfg.setF_IBREGISTRYDATE(cfg.getRegistryDate());
		regListCfg.setF_IBREGISTRYSTATUS((cfg.getRegistryStatus().equalsIgnoreCase("Active")) ? true : false);
		regListCfg.setF_IBREFERENCENUMBER(cfg.getReferenceNumber());
		factory.create(IBOCE_IB_RegistryListCfg.BONAME, regListCfg);
	}

	public void saveRegistryList(RegistryListCfg registryListCfg) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_RegistryListCfg newRegistryListCfg = (IBOCE_IB_RegistryListCfg) factory
				.findByPrimaryKey(IBOCE_IB_RegistryListCfg.BONAME, registryListCfg.getRegistryId(), true);
		if (null == newRegistryListCfg) {
			createRegistryList(factory, registryListCfg);
		} else {
			deleteRegistryListById(registryListCfg.getRegistryId(), factory);
			createRegistryList(factory, registryListCfg);
		}
	}

	private int deleteRegistryListById(String registryId, IPersistenceObjectsFactory factory) {
		final String REG_LIST_WHERECLAUSE = "WHERE " + IBOCE_IB_RegistryListCfg.IBREGISTRYID + " =?";
		ArrayList<String> params = new ArrayList<>();
		params.add(registryId);
		int res = factory.bulkDelete(IBOCE_IB_RegistryListCfg.BONAME, REG_LIST_WHERECLAUSE, params);
		factory.commitTransaction();
		factory.beginTransaction();
		return res;

	}
}
