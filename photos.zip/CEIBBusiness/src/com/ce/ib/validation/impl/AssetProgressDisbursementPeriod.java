package com.ce.ib.validation.impl;

import java.sql.Date;

import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressDisbursementPeriod implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		ReadAssetData readAssetData = CeUtils.readAssetData(bankingObject);
		Date dealEffectiveDate = (Date) CeUtils.getUDFValueByNameFromAdditionalDtls(bankingObject.getDealID(),
				"Deal_Effective_Date");
		Date scheduleStartDate = CeUtils.getScheduleStartDate(dealEffectiveDate, "YEARLY",
				CeUtils.getMinDisbursementPeriod(readAssetData));
		if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), scheduleStartDate)) {
			isException = true;
		}
		return isException;
	}

}
