package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class MainActivityTechnicalAnalysis implements IValidation{

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String selectQueryFarm = "WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ? ";
        ArrayList<String> param = new ArrayList<>();
        param.add(bankingObject.getDealID());
        List<IBOCE_IB_TechnicalFarm> farmDetail = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
            selectQueryFarm, param, null, false);
        String cropID = farmDetail.get(0).getBoID();
        
        String selectQueryCrop = "WHERE " + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " = ? ";
        ArrayList<String> params = new ArrayList<>();
        params.add(cropID);
        List<IBOCE_IB_TechnicalCrop> cropDetail = factory.findByQuery(IBOCE_IB_TechnicalCrop.BONAME,
            selectQueryCrop, params, null, false);
        if(cropDetail != null) {
            for(IBOCE_IB_TechnicalCrop mainActivity : cropDetail) {
                if(mainActivity.getF_IBMAINACTIVITY().equals("1")) {
                    return true;
                }
            }
        }
        return false;
        
       
    }

}
