package com.ce.ib.validation.impl;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_DealRescheduleDetails;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DealFrequencyChangeValidation implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {

        /*
         * if frequency is changed from deal frequency in Reschedule then it should go for approval
         */
        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(bankingObject.getDealID());
        IBOCE_IB_DealReschedule rescheduleDetails = (IBOCE_IB_DealReschedule) IBCommonUtils.getPersistanceFactory()
            .findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, bankingObject.getTransactionID(), true);
        if (dealDetails != null && rescheduleDetails != null) {
            if (!IBCommonUtils.isNullOrEmpty(rescheduleDetails.getF_IBRESCHEDULEFREQ())
                && !rescheduleDetails.getF_IBRESCHEDULEFREQ().equalsIgnoreCase(dealDetails.getF_RepayFreqcode())) {
                return true;
            }
        }
        return false;
    }
}
