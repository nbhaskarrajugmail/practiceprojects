package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.fatom.GetAssetAttributeNames;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class GroupCDToolNoFarmStatusTotalArea implements IValidation{

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String whereCondition = "WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ? ";
        ArrayList<String> param = new ArrayList<>();
        param.add(bankingObject.getDealID());
        List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
            whereCondition, param, null, false);
        
        for(IBOIB_DLI_DealAssetDtls dealAsset : dealAssetDtls) {
            String asetDtlID = dealAsset.getF_ASSETDETAILSID();
           
            IBOIB_AST_AssetDetails asset = (IBOIB_AST_AssetDetails) factory.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, asetDtlID);
            String CategoryID = asset.getF_CATEGORY();
            
            GetAssetAttributeNames assetAttributeNames = new GetAssetAttributeNames(
                BankFusionThreadLocal.getBankFusionEnvironment());
            assetAttributeNames.setF_IN_categoryID(CategoryID);
            assetAttributeNames.setF_IN_onlyAttributeMode(false);
            assetAttributeNames.setF_IN_dealID("Dummy");
            assetAttributeNames.process(BankFusionThreadLocal.getBankFusionEnvironment());
            Integer groupcd = assetAttributeNames.getF_OUT_GROUPCD();
            Integer toolNo = assetAttributeNames.getF_OUT_TOOLNO();
            
            
            String farmCondition = "WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ? ";
            ArrayList<String> params = new ArrayList<>();
            params.add(bankingObject.getDealID());
            List<IBOCE_IB_TechnicalFarm> farmDtlsList = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
                farmCondition, param, null, false);
            
            for (IBOCE_IB_TechnicalFarm farmDtl : farmDtlsList) {
                String refNum = farmDtl.getBoID();
                
                String cropCondition = "WHERE " + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " = ? ";
                ArrayList<String> par = new ArrayList<>();
                par.add(refNum);
                List<IBOCE_IB_TechnicalCrop> cropList = factory.findByQuery(IBOCE_IB_TechnicalCrop.BONAME,
                    cropCondition, par, null, false);
                
                for(IBOCE_IB_TechnicalCrop crop : cropList) {
                    if((((toolNo == 4 || toolNo == 5) && groupcd == 10) || (toolNo == 6 && groupcd == 12)) && ( Integer.valueOf(crop.getF_IBSTATUS()) == 1 || Integer.valueOf(crop.getF_IBSTATUS()) == 3) && ( Integer.valueOf(crop.getF_IBAREA()) < 50 )) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}
