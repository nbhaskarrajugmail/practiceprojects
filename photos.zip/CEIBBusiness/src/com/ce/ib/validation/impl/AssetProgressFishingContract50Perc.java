package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressFishingContract50Perc implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		String boatToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.BOAT_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);

		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode("RETRIEVE");
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
		boolean normalFishingContract = false;
		BigDecimal boatProgress = BigDecimal.ZERO;
		BigDecimal boatDisbursedAmount = BigDecimal.ZERO;
		String currentReportID = CommonConstants.EMPTY_STRING;
		if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 1) {
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals("New")) {
					currentReportID = assetProgressReport.getReportID();
				}
			}
			for (AssetProgressDetails assetProgressDetails : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressDetailsList()) {
				if (assetProgressDetails.getToolNO().toString().equals(boatToolID)) {
					normalFishingContract = true;
					boatProgress = assetProgressDetails.getInvoiceCompletionPercentage();
					boatDisbursedAmount = assetProgressDetails.getAllowedFinalCost().getCurrencyAmount();
				}
			}
			if (normalFishingContract) {
				if (boatProgress.compareTo(new BigDecimal(100)) == CommonConstants.INTEGER_ZERO) {
					if (boatDisbursedAmount.compareTo(BigDecimal.ZERO) == CommonConstants.INTEGER_ZERO) {
						for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
								.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
							if ((!assetProgressDetails.getToolNO().toString().equals(boatToolID))
									&& currentReportID.equals(assetProgressDetails.getReportID())
									&& assetProgressDetails.getAllowedFinalCost().getCurrencyAmount().compareTo(
											assetProgressDetails.getActualFinalCost().getCurrencyAmount()) > 0) {
								return true;
							}
						}
					} 
				}
			}

			
		}
		return isException;
	}
}
