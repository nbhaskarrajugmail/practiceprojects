package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.GetDealRescheduleDetails;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.dealreschedule.dtls.ib.types.CeDistributePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CePostPonePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.DealRescheduleDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class RescheduleFeesChangeValidation implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        int rescheduleFeePercentage = Integer.parseInt(IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeePercentage").getValue());
        boolean isFeesChanged = false;
        BigDecimal totalAmountProcessed = BigDecimal.ZERO;
        GetDealRescheduleDetails dealRescheduleDetails = new GetDealRescheduleDetails();
        dealRescheduleDetails.setF_IN_islamicBankingObject(bankingObject);
        dealRescheduleDetails.process(BankFusionThreadLocal.getBankFusionEnvironment());
        DealRescheduleDetails rescheduleDetails = dealRescheduleDetails.getF_OUT_dealRescheduleDetails();
        BigDecimal currentRescheduleProft = rescheduleDetails.getRescheduleRequestDetails().getCurrentRescheduleProfit()
                .getCurrencyAmount();
        BigDecimal expectedRescheduleProfit = BigDecimal.ZERO;
        BigDecimal rescheduleFeeAmtCap = new BigDecimal((IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeeAmtCap").getValue()));
        BigDecimal outstandingPrincipal = rescheduleDetails.getRescheduleRequestDetails().getOutstandinPrincipal().getCurrencyAmount();
        if (outstandingPrincipal.compareTo(rescheduleFeeAmtCap) >= CommonConstants.INTEGER_ZERO) {
            if (rescheduleDetails.getRescheduleRequestDetails().getIsGenerate()) {
                totalAmountProcessed = rescheduleDetails.getRescheduleRequestDetails().getOutstandinPrincipal().getCurrencyAmount();
            }
            else if (rescheduleDetails.getRescheduleRequestDetails().getIsDistribute() != null
                    && rescheduleDetails.getRescheduleRequestDetails().getIsDistribute()) {
                for (CeDistributePaymentSchedule ceDistributePaymentSchedule : rescheduleDetails.getDistributePaymentSchedule()) {
                    if (ceDistributePaymentSchedule.isIsSkipRepayment()) {
                        totalAmountProcessed = totalAmountProcessed
                                .add(ceDistributePaymentSchedule.getTotalRepaymentAmount().getCurrencyAmount());
                    }
                }
            }
            else {
                for (CePostPonePaymentSchedule cePostPonePaymentSchedule : rescheduleDetails.getPostPonePaymentSchedule()) {
                    if (cePostPonePaymentSchedule.getRepaymentNewDate() != null) {
                        totalAmountProcessed = totalAmountProcessed
                                .add(cePostPonePaymentSchedule.getTotalRepaymentAmount().getCurrencyAmount());
                    }
                }
            }
            if (totalAmountProcessed.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
                expectedRescheduleProfit = totalAmountProcessed.multiply(new BigDecimal(rescheduleFeePercentage))
                        .divide(new BigDecimal(100));
            }
            BigDecimal deltaAmount = expectedRescheduleProfit.subtract(currentRescheduleProft);
            System.out.println("Expected Amount: " + expectedRescheduleProfit);
            System.out.println("Current Amount: " + currentRescheduleProft);
            if (deltaAmount.compareTo(BigDecimal.ONE) < CommonConstants.INTEGER_ZERO)
                return isFeesChanged;

            if (expectedRescheduleProfit.compareTo(currentRescheduleProft) != CommonConstants.INTEGER_ZERO)
                isFeesChanged = true;
        }
        return isFeesChanged;
    }

}
