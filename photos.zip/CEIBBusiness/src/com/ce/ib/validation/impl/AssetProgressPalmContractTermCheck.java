package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressPalmContractTermCheck implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		String palmIrrigationNetwrk = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.PALM_IRRIG_NET_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		String palmFluits = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.PALM_FLUITS_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);

		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode(CeConstants.MODE_RETRIEVE);
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());

		if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 2) {
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals(CeConstants.STATUS_NEW)) {
					for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
							.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
						if (assetProgressDetails.getReportID().equals(assetProgressReport.getReportID())) {
							BigDecimal actualAmount = assetProgressDetails.getActualFinalCost().getCurrencyAmount();
							BigDecimal allowedAmount = assetProgressDetails.getAllowedFinalCost().getCurrencyAmount();
							if ((palmIrrigationNetwrk.equals(assetProgressDetails.getToolNO().toString())
									|| palmFluits.equals(assetProgressDetails.getToolNO().toString()))
									&& actualAmount.compareTo(allowedAmount) < 0)
								return true;
						}
					}
				}
			}
		}
		return isException;
	}
}
