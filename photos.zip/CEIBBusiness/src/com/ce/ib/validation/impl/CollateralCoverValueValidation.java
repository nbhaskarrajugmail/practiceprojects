package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCollateral;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.ib.types.IslamicBankingObject;

public class CollateralCoverValueValidation implements IValidation {

    /*
     * If total collateral value(cover value) is less than deal/ principal amount then it should go for approval to group 1
     */
    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        BigDecimal totalCollateralValue = BigDecimal.ZERO;

        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

        String whereClause = " WHERE " + IBOIB_IDI_DealCollateral.DEALNO + " = ?";

        ArrayList params = new ArrayList<>();
        params.add(bankingObject.getDealID());
        List<IBOIB_IDI_DealCollateral> dealCollaterals =
            factory.findByQuery(IBOIB_IDI_DealCollateral.BONAME, whereClause, params, null, false);

        for (IBOIB_IDI_DealCollateral dealCollateral : dealCollaterals) {
            totalCollateralValue = totalCollateralValue.add(dealCollateral.getF_AMOUNT());
        }

        IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(bankingObject.getDealID());

        String validateON = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.COLLATERAL_CUSTOM_CONF_FILE,
            CeConstants.VALIDATE_ON, "", CeConstants.ADFIBCONFIGLOCATION);

        if ((validateON.equalsIgnoreCase("DA") && totalCollateralValue.compareTo(dealDtls.getF_DealAmt()) < 0)
            || (validateON.equalsIgnoreCase("PA") && totalCollateralValue.compareTo(dealDtls.getF_PrincipleAmt()) < 0))
            return true;

        return false;
    }

}
