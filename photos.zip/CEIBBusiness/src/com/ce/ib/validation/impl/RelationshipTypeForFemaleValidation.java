package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.CustomerDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class RelationshipTypeForFemaleValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If Loan Applicant is female then relationship type 23 is mandatory if not then it should go for approval to group 99
		 */
		boolean isFemaleApplicantNotLikedWithRelType23 = false;
		String primaryPartyID = IBCommonUtils.getDealPrimaryPartyID(bankingObject.getDealID());
		if(StringUtils.isNotBlank(primaryPartyID))
		{
			CustomerDetails customerDetails = IBCommonUtils.getPartyDetailsFromPartyID(primaryPartyID,BankFusionThreadLocal.getBankFusionEnvironment());
			if(null != customerDetails && null != customerDetails.getPersonalDetails() &&
					"F".equalsIgnoreCase(customerDetails.getPersonalDetails().getGenderCode()))
			{
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
				String whereClause = "WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? AND "
						+ IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE + " = ?";
				ArrayList<String> params = new ArrayList<>();
				params.add(bankingObject.getDealID());
				params.add("23");
				List<IBOCE_IB_DealRelationshipDetails> dealRelationshipDetails = factory.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME,
						whereClause, params, null, false);
				if(dealRelationshipDetails.isEmpty())
				{
					isFemaleApplicantNotLikedWithRelType23 = true;
				}
			}
		}
		return isFemaleApplicantNotLikedWithRelType23;
	}

}
