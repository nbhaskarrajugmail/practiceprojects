package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetStudyApprovalValidation implements IValidation {
	private static final Log LOGGER = LogFactory.getLog(AssetStudyApprovalValidation.class);

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		
		/*	V_DEALNO    :   DEAL NUMBER 
			V_MSG_NUM  : ERROR MESSAGE NUMBER , IF NULL   NO ERRORS 
			V_MSG              : ERROR MESSAGE TEXT  , IF NULL   NO ERRORS 
			V_APPROVE_IND  :  IN CASE OF ERROR ONLY , IF 1 THIS ERROR MESSAGE CAN BE PASSED BY APPROVAL , IF 0 THIS ERROR CAN NOT BE PASSED 
		 */
		System.err.println();
		boolean isAnyError = false;
		String msg_num = CommonConstants.EMPTY_STRING;
		String msg = CommonConstants.EMPTY_STRING;
		String approve_ind = CommonConstants.EMPTY_STRING;
		String validationResponse = CommonConstants.EMPTY_STRING;
		try {
			validationResponse = ADFTechGrantAssetUtils.validateStudyPackage(bankingObject.getDealID());
		} catch (Exception e) {
			LOGGER.error("error ocuured in validating assets from package" + e.getLocalizedMessage());
		}
		List<String> valResponseList = new ArrayList<>();
		if (validationResponse != null && !validationResponse.isEmpty()) {
			valResponseList = IBCommonUtils.isNotEmpty(validationResponse)? Arrays.asList(validationResponse.split("\\$"))
					: new ArrayList<String>();
		}
		if (!valResponseList.isEmpty()) {
			msg_num = valResponseList.get(0);
			msg = valResponseList.get(1);
			approve_ind = valResponseList.get(2);
		}
		if(!msg_num.equals("null") && !msg.equals("null") && approve_ind.equals("1")) {
			return true;
		}
		return isAnyError;
	}

}
