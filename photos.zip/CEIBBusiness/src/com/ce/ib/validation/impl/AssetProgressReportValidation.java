package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressReportValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isLastDisbursed = false;
		int disbursementNo = 1;

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String assetProgressReportDtlsWhereClause = "WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + " = ?"
				+ " ORDER BY " + IBOCE_IB_AssetProgressReport.IBVISITDATEG + ","
				+ IBOCE_IB_AssetProgressReport.IBDISBURSEMENTNO + " ASC ";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_AssetProgressReport> assetProgressReportDtlList = factory.findByQuery(
				IBOCE_IB_AssetProgressReport.BONAME, assetProgressReportDtlsWhereClause, params, null, false);

		for (IBOCE_IB_AssetProgressReport eachAssetProgressReportDtl : assetProgressReportDtlList) {
			disbursementNo = eachAssetProgressReportDtl.getF_IBDISBURSEMENTNO();
		}

		for (IBOCE_IB_AssetProgressReport eachAssetProgressReportDtl : assetProgressReportDtlList) {
			if (eachAssetProgressReportDtl.getF_IBDISBURSEMENTNO().equals(disbursementNo - 1)
					&& eachAssetProgressReportDtl.isF_IBISLASTDISBURSED()) {

				isLastDisbursed = true;

			}

		}

		return isLastDisbursed;
	}

}
