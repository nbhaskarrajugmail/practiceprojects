package com.ce.ib.validation.impl;

import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class Gcd6Tln37MandatoryAssetValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - if GroupCD 6 and Tool No 37 Is Added and GroupCD 2 and Tool No 98 Is not added 
		 * as Existing asset or New asset List  it should go for Approval to group 99
		 */
		boolean isGcd6Tln37Attached = false;
		boolean isGcd2Tln98Attached = false;
		AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		assetInfoAndStudyFatom.setF_IN_islamicBankingObject(bankingObject);
		assetInfoAndStudyFatom.setF_IN_mode(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE);
		assetInfoAndStudyFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		AssetThirdPartyDetailsList assetList = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList();
		for(AssetThirdPartyDetails eachAssetDtl : assetList.getAssetThirdPartyDetails())
		{
			if(eachAssetDtl.getGroupCD() == 6 && eachAssetDtl.getToolNO() == 37)
			{
				isGcd6Tln37Attached = true;
			}
			if(eachAssetDtl.getGroupCD() == 2 && eachAssetDtl.getToolNO() == 98)
			{
				isGcd2Tln98Attached = true;
			}
		}
		if(isGcd6Tln37Attached && !isGcd2Tln98Attached)
		{
			return true;
		}
		return false;
	}

}
