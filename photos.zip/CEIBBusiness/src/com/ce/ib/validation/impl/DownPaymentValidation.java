package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DownPaymentValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isThereNoDownPayment = false;
		IBOIB_DLI_DealAditionalDtls dealAddDtls = IBCommonUtils.getDealAdditionalDetails(bankingObject.getDealID());
		if(null == dealAddDtls || null == dealAddDtls.getF_DownPaymentAmt() || BigDecimal.ZERO.compareTo(dealAddDtls.getF_DownPaymentAmt()) >= 0)
		{
			isThereNoDownPayment = true;
		}
		return isThereNoDownPayment;
	}

}
