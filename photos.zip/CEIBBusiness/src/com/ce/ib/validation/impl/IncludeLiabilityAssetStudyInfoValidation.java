package com.ce.ib.validation.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.util.IBConstants;

import bf.com.misys.ib.types.IslamicBankingObject;

public class IncludeLiabilityAssetStudyInfoValidation implements IValidation {
	private transient final static Log LOGGER = LogFactory
			.getLog(IncludeLiabilityAssetStudyInfoValidation.class.getName());

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If Liability amount is excluded i.e Include Liability is false/unchecked then it should go for Approval
		 */
		boolean excludeLiability = false;
		String liabilityUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.INCLUDELIABILITY, "", CeConstants.ADFIBCONFIGLOCATION);
		String liability = (String)AssetStudyAndInfoUtil.getUDFValue(liabilityUdfName, bankingObject.getDealID());
		LOGGER.info("Total liability configured for the deal: "+bankingObject.getDealID()+" is :"+liability);
		if(liability != null && liability.equalsIgnoreCase(IBConstants.NO)) {
			excludeLiability = true;
		}
		return excludeLiability;
	}

}
