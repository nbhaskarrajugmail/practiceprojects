package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class RelationshipTypeAndAssetCategoryValidation implements IValidation{
	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - In relationship BB, User will add a person with a specific type(type 14) and if the user wants to the same person again in the same deal but
	 	As a guarantor (different relationship type) And the list of assets in the deal includes specific asset category
 		Then system should raise this case for approval
		 */
		boolean isRelationshipTypeDifferent= false;
		boolean isAssetCondition= false;
		String dealID= bankingObject.getDealID();
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();


		String whereClause = "WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? AND "
				+ IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE + " = ?";		
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		params.add("14");
		List<IBOCE_IB_DealRelationshipDetails> dealRelationshipDetails = factory.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME,
				whereClause, params, null, false);
		if(!dealRelationshipDetails.isEmpty()) {
			for(IBOCE_IB_DealRelationshipDetails dealRelationshipDtls: dealRelationshipDetails) {
			
				String dealrelationshipWhereClause = "WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? AND "
					+ IBOCE_IB_DealRelationshipDetails.IBPARTYID + " = ? AND " + IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE + " != ?";
				params.clear();
				params.add(dealID);
				params.add(dealRelationshipDtls.getF_IBPARTYID());
				params.add("14");
				List<IBOCE_IB_DealRelationshipDetails> dealRelationshipList = factory.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME,
					dealrelationshipWhereClause, params, null, false);
			
				if(!dealRelationshipList.isEmpty()) {
					isRelationshipTypeDifferent=true;
				}
			}
		}
	
		String dealAssetDtlsWhereClause = "WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ?";
		params.clear();
		params.add(bankingObject.getDealID());
		List<IBOIB_DLI_DealAssetDtls> dealAssetDtlList = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
				dealAssetDtlsWhereClause, params, null, false);
		for (IBOIB_DLI_DealAssetDtls eachdealAsset : dealAssetDtlList) {
			String assetDtlsWhereClause = "WHERE " + IBOIB_AST_AssetDetails.ASSETDETAILSID + " = ?";
			params.clear();
			params.add(eachdealAsset.getF_ASSETDETAILSID());
			List<IBOIB_AST_AssetDetails> assetDtlList = factory.findByQuery(IBOIB_AST_AssetDetails.BONAME,
					assetDtlsWhereClause, params, null, false);			
			for (IBOIB_AST_AssetDetails eachAssetDtl : assetDtlList) {
				String assetCategoryWhereClause = "WHERE " + IBOIB_AST_AssetCategory.CATEGORYID + " = ?";
				params.clear();
				params.add(eachAssetDtl.getF_CATEGORY());
				List<IBOIB_AST_AssetCategory> assetCategoryDtlList = factory.findByQuery(IBOIB_AST_AssetCategory.BONAME,
						assetCategoryWhereClause, params, null, false);
				for(IBOIB_AST_AssetCategory assetCategoryDtls : assetCategoryDtlList) {
					String assetCategoryID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(ValidationExceptionConstants.PROPERTIES_FILE,
				            ValidationExceptionConstants.ASSET_CATEGORY_ID, "", CeConstants.ADFIBCONFIGLOCATION);
					if (assetCategoryDtls.getF_PARENTCATEGORY().equals(assetCategoryID)) {
						isAssetCondition= true;
					}
				}				
			}
		}
		if(isRelationshipTypeDifferent==true && isAssetCondition==true) {
			return true;
		}
		else {
			return false;
		}
	}

}
