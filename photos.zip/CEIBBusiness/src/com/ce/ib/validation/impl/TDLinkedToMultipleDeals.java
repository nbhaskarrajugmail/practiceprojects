package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class TDLinkedToMultipleDeals implements IValidation {

	private transient final static Log LOGGER = LogFactory.getLog(TDLinkedToMultipleDeals.class.getName());
	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If the Title deed is linked to another deal for which disbursement is not done fully 
		 * and Disbursement period is not completed it should go for approval to 99
		 */
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealTDWhereClause = "WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> tdsLinkedToDeal = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, dealTDWhereClause, params, null, false);
		for(IBOCE_IB_DealTitleDeedDtls tdLinkedToDeal : tdsLinkedToDeal)
		{
			String dealsLinkedToTDWhereClause = "WHERE " + IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID + " = ? AND "
					+ IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDVERSIONNUM + " = ? AND "
					+ IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " != ?";
			params.clear();
			params.add(tdLinkedToDeal.getF_IBTITLEDEEDID());
			params.add(tdLinkedToDeal.getF_IBTITLEDEEDVERSIONNUM());
			params.add(bankingObject.getDealID());
			List<IBOCE_IB_DealTitleDeedDtls> dealsLinkedToTD = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, dealsLinkedToTDWhereClause, params, null, false);
			for(IBOCE_IB_DealTitleDeedDtls dealLinkedToTD : dealsLinkedToTD)
			{
				String dealID = dealLinkedToTD.getF_IBDEALNUMBER();
				IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealID);
				if(StringUtils.isNotBlank(dealDtls.getF_DealAccountId()))
				{
					boolean isDisbursementPeriodOver = isDisbursementPeriodOver(dealID, bankingObject);
					boolean isDisbursementCompleted = isDisbursementCompleted(dealID);
					if(!isDisbursementPeriodOver && !isDisbursementCompleted)
					{
						LOGGER.info("The current TD is attached to the active deal : " +dealID);
						return true;
					}
				}
			}
		}
		return false;
	}

		private boolean isDisbursementCompleted(String dealID) {
			boolean isDisbursementCompleted = false;
			ReadLoanDetailsRs loanDetails = IBCommonUtils.getLoanDetails(dealID);
			BigDecimal totalDisbursedAmt = loanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount();
			BigDecimal totalPrincipalAmt = loanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt();
			if(totalPrincipalAmt.compareTo(totalDisbursedAmt) == 0)
			{
				isDisbursementCompleted = true;
			}
			return isDisbursementCompleted;
		}

	private boolean isDisbursementPeriodOver(String dealID, IslamicBankingObject islamicBankingObject) {
		boolean isDisbursementPeriodOver = true;
		int maxDisbPeriodnYears = CommonConstants.INTEGER_ZERO;
		AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		String originalDealId = islamicBankingObject.getDealID();
		islamicBankingObject.setDealID(dealID);
		assetInfoAndStudyFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetInfoAndStudyFatom.setF_IN_mode(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE);
		assetInfoAndStudyFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		AssetThirdPartyDetailsList assetList = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList();
		for(AssetThirdPartyDetails eachAssetDtl : assetList.getAssetThirdPartyDetails())
		{
			Integer disPeriodInYears = eachAssetDtl.getDisbursementPeriod();
			if(null != disPeriodInYears && disPeriodInYears > maxDisbPeriodnYears)
			{
				maxDisbPeriodnYears = disPeriodInYears;
			}
		}
		islamicBankingObject.setDealID(originalDealId);
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealID);
		Date disPeriodEnd = new Date(IBCommonUtils.getNextPaymentDate(dealDtls.getF_DealStartDate(), DealInitiationConstants.FREQ_ANNUALLY, 
				1, maxDisbPeriodnYears, 0, false, 0).getTime());
		if(disPeriodEnd.after(SystemInformationManager.getInstance().getBFBusinessDate()))
		{
			isDisbursementPeriodOver =  false;
		}
		return isDisbursementPeriodOver;
	}

}
