package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.fatom.CheckCurrentDealIsSpecialProject;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgress1PercentValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isException = false;

		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode("RETRIEVE");
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());

		boolean ignoreSecReportExc = false;
		CheckCurrentDealIsSpecialProject specialProject = new CheckCurrentDealIsSpecialProject(
				IBCommonUtils.getBankFusionEnvironment());
		specialProject.setF_IN_subProductID(bankingObject.getSubProductID());
		if (specialProject.isF_OUT_isSpecialProject()) {
			BigDecimal specialLoanMinCompletion = BigDecimal.ZERO;
			if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 1) {
				specialLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
						CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.SPECIAL_LOAN_MIN_PROG_PERC1, "",
						CeConstants.ADFIBCONFIGLOCATION));
			}
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals("New")) {
					if (assetProgressReport.getTotalProgressPercentage()
							.compareTo(specialLoanMinCompletion) < CommonConstants.INTEGER_ZERO) {
						return true;
					}
				}
			}

		} else {
			BigDecimal normalLoanMinCompletion = BigDecimal.ZERO;
			if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 1) {
				normalLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
						CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_LOAN_MIN_PROG_PERC1, "",
						CeConstants.ADFIBCONFIGLOCATION));
			}
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals("New")) {
					if (!ignoreSecReportExc && assetProgressReport.getTotalProgressPercentage()
							.compareTo(normalLoanMinCompletion) < CommonConstants.INTEGER_ZERO) {
						return true;
					}
				}
			}
		}

		return isException;
	}

}
