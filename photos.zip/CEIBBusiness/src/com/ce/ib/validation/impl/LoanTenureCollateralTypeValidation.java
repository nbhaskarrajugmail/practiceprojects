package com.ce.ib.validation.impl;

import java.time.Period;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;

public class LoanTenureCollateralTypeValidation implements IValidation {

	private static final int TENUREPERIODINYEARS = 5;

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isLoanTenureMoreThan5Years = isLoanTenureMoreThan5Years(bankingObject);
		boolean isCollateralTypePersonal = isCollateralTypePersonal(bankingObject);
		if (isLoanTenureMoreThan5Years && isCollateralTypePersonal) {
			return true;
		}
		return false;
	}

	public boolean isLoanTenureMoreThan5Years(IslamicBankingObject bankingObject) {
		boolean isLoanTenureMoreThan5Years = false;

		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(bankingObject.getDealID());

		if (IBCommonUtils.isNotEmpty(dealDtls.getF_DealAccountId())) {
			ReadLoanDetailsRs loanDetails = IBCommonUtils.getLoanDetails(bankingObject.getDealID());
			Date loanStartDate = loanDetails.getDealDetails().getLoanBasicDetails().getLoanStartDate();
			Date loanEndDate = loanDetails.getDealDetails().getLoanBasicDetails().getLoanMaturityDate();
			Period loanTenure = Period.between(loanStartDate.toLocalDate(), loanEndDate.toLocalDate());
			if (loanTenure.getYears() > TENUREPERIODINYEARS) {
				isLoanTenureMoreThan5Years = true;
			}
		} else {
			Date dealStartDate = dealDtls.getF_DealStartDate();
			Date dealLastRepaymentDate = dealDtls.getF_LastRepaymentDate();
			Period dealTenure = Period.between(dealStartDate.toLocalDate(), dealLastRepaymentDate.toLocalDate());
			if (dealTenure.getYears() > TENUREPERIODINYEARS) {
				isLoanTenureMoreThan5Years = true;
			}
		}
		return isLoanTenureMoreThan5Years;

	}

	public boolean isCollateralTypePersonal(IslamicBankingObject bankingObject) {
		boolean isCollateralTypePersonal = false;
		int collateralPersonalTypeCount = 0;

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealCollateralDtlsWhereClause = "WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_DealCollateralDtls> dealCollateralDtlsList = factory
				.findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, dealCollateralDtlsWhereClause, params, null, false);
		for (IBOCE_IB_DealCollateralDtls eachDealCollateralDtls : dealCollateralDtlsList) {
			if (eachDealCollateralDtls.getF_IBREQUESTTYPE().equalsIgnoreCase("Personal")) {
				collateralPersonalTypeCount++;
			}

		}
		if (collateralPersonalTypeCount == 1) {
			isCollateralTypePersonal = true;
		}

		return isCollateralTypePersonal;

	}

}
