package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CreditRatingValidation implements IValidation {
	
	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - New Additional field needs to be added on Request Activation for credit rating, if its less than 70% it should go to approval to Group 13
		 */
		BigDecimal creditRatingValue=CommonConstants.BIGDECIMAL_ZERO;
		boolean isCreditRatingLessThan70 = false;
		String dealID= bankingObject.getDealID();	
		BigDecimal allowedCreditRating=new BigDecimal(70);
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

        String whereClause = " WHERE IBDEALNOPK = ?";
           
        ArrayList<String> queryParams = new ArrayList<String>();
        queryParams.add(dealID);

         List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD = factory
                    .findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClause, queryParams, null, true);
         String creditRating = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
                    CeConstants.UDFPROPERTY, CeConstants.CREDIT_RATING, "", CeConstants.ADFIBCONFIGLOCATION);

         for (IBOUDFEXTIB_DLI_DealDetails eachDealDetailsUD : dealDetailsUD) {
              UserDefinedFields userDefinedFields = eachDealDetailsUD.getUserDefinedFields();
              if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
                  for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {

                	  if (userDefinedFld.getFieldName().equals(creditRating)) {
                            creditRatingValue = new BigDecimal(userDefinedFld.getFieldValue().toString());                           
                            break;
                      }
                  }
              }
          }
          if(creditRatingValue.compareTo(allowedCreditRating)==-1) {
			isCreditRatingLessThan70 = true;
         }
        return isCreditRatingLessThan70;
	}
}
			
