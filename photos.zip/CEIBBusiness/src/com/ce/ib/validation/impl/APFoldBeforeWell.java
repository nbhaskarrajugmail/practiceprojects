package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class APFoldBeforeWell implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		String wellToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.WELL_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		String foldToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.FOLD_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		BigDecimal wellProgressPercentage = BigDecimal.ZERO;
		BigDecimal foldProgressPercentage = BigDecimal.ZERO;
		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode(CeConstants.MODE_RETRIEVE);
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
		if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 1) {
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals(CeConstants.STATUS_NEW)) {
					for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
							.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
						if (assetProgressDetails.getReportID().equals(assetProgressReport.getReportID())) {
							if (assetProgressDetails.getToolNO().toString().equals(foldToolID)) {
								foldProgressPercentage = assetProgressDetails.getInvoiceCompletionPercentage();
							}
							if (assetProgressDetails.getToolNO().toString().equals(wellToolID)) {
								wellProgressPercentage = assetProgressDetails.getInvoiceCompletionPercentage();
							}
						}
					}
				}
			}
			if ((wellProgressPercentage.compareTo(new BigDecimal(100)) != CommonConstants.INTEGER_ZERO)
					&& (foldProgressPercentage.compareTo(new BigDecimal(0)) > CommonConstants.INTEGER_ZERO)) {
				return true;
			}
		}
		return isException;
	}

}
