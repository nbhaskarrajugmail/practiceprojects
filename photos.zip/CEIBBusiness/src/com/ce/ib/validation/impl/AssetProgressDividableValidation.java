package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressDividableValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isDividable = false;
		boolean isSpecialLoan = false;
		List<String> specialLoanProcessesList = new ArrayList<>();
		String specialLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.SPECIAL_LOAN_SUBPRODUCTS, "",
				CeConstants.ADFIBCONFIGLOCATION);

		if (specialLoanProcesses != null && !specialLoanProcesses.isEmpty()) {
			specialLoanProcessesList = IBCommonUtils.isNotEmpty(specialLoanProcesses)
					? Arrays.asList(specialLoanProcesses.split(","))
					: new ArrayList<String>();
		}
		if (specialLoanProcessesList.contains(bankingObject.getSubProductID())) {
			isSpecialLoan = true;
		}
		if (!isSpecialLoan) {
			List<String> normalLoanToolIDs = new ArrayList<>();
			String normalLoanTools = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_LOAN_TOOLIDS_NO_EXCEPTION, "",
					CeConstants.ADFIBCONFIGLOCATION);

			if (normalLoanTools != null && !normalLoanTools.isEmpty()) {
				normalLoanToolIDs = IBCommonUtils.isNotEmpty(normalLoanTools)
						? Arrays.asList(normalLoanTools.split(","))
						: new ArrayList<String>();
			}

			AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
					IBCommonUtils.getBankFusionEnvironment());
			assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
			assetProgressingFatom.setF_IN_mode("RETRIEVE");
			assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals("New")) {
					for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
							.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
						if (assetProgressDetails.getReportID().equals(assetProgressReport.getReportID())) {
							Map<String, BigDecimal> costMap = AssetProgressUtil
									.getPreviousReportsCosts(assetProgressingFatom.getF_OUT_assetProgressReportDetails()
											.getAssetProgressReportList(), assetProgressDetails.getAssetID());

							BigDecimal calcCost = costMap.get("CALCULATEDCOST");
							if (!normalLoanToolIDs.contains(assetProgressDetails.getToolNO().toString())
									&& calcCost.compareTo(BigDecimal.ZERO) > 0)
								return true;
						}
					}
				}
			}
		}

		return isDividable;
	}

}
