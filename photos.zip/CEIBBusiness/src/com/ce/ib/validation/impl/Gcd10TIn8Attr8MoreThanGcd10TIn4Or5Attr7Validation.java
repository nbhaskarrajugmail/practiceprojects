package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.ib.validation.IValidation;

import bf.com.misys.ib.types.IslamicBankingObject;

public class Gcd10TIn8Attr8MoreThanGcd10TIn4Or5Attr7Validation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isAttr8MoreThanAttr7 = false;
		BigDecimal attr8Gcd10TNo95 = DealValidationUtil.getAttributeValue(8, 10, 95, bankingObject);
		BigDecimal attr7Gcd10TNo4 = DealValidationUtil.getAttributeValue(7, 10, 4, bankingObject);
		BigDecimal attr7Gcd10TNo5 = DealValidationUtil.getAttributeValue(7, 10, 5, bankingObject);
		BigDecimal percentageValue70 = new BigDecimal(70).divide(new BigDecimal(100));
		if (null != attr7Gcd10TNo4 && null != attr8Gcd10TNo95) {
			BigDecimal percentageValueAttr7Gcd10TNo4 = attr7Gcd10TNo4.multiply(percentageValue70);
			if (attr8Gcd10TNo95.compareTo(percentageValueAttr7Gcd10TNo4) > 0) {
				isAttr8MoreThanAttr7 = true;
			}
		}
		if (null != attr7Gcd10TNo5 && null != attr8Gcd10TNo95) {
			BigDecimal percentageValueAttr7Gcd10TNo5 = attr7Gcd10TNo5.multiply(percentageValue70);
			if (attr8Gcd10TNo95.compareTo(percentageValueAttr7Gcd10TNo5) > 0) {
				isAttr8MoreThanAttr7 = true;
			}
		}
		return isAttr8MoreThanAttr7;
	}

}
