package com.ce.ib.validation;

import bf.com.misys.ib.types.IslamicBankingObject;

public interface IValidation {
	
	boolean validate(IslamicBankingObject bankingObject);

}
