package com.ce.bankfusion.ib.sysobject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetUdfDetails;
import com.misys.cbs.objectloader.AbstractGenericExecutor;
import com.misys.cbs.objectloader.DbStep;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.DealCostDetails;

public class DealCostDetailsLoader extends AbstractGenericExecutor{

	private static final String AssetFinalCost_UDF_FIELD_ID = "AssetFinalCost";
	private static final String AssetGrantApprovalCost_UDF_FIELD_ID = "AssetGrantApprovalCost";
	private static final String AssetOriginalCost_UDF_FIELD_ID = "AssetOriginalCost";
	private static final String AssetStudyCost_UDF_FIELD_ID = "AssetStudyCost";
	
	@Override
	public void initialize(DbStep arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List executeAndPopulate(Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		Object dealId = paramMap.get("dealId");
        if (dealId != null)
            return doTheStuff(dealId.toString(), paramMap);
        return null;
	}
	
	private List<Object> doTheStuff(String dealId, Map<String, Object> paramMap) {

        List<Object> returns = new ArrayList<Object>();

        DealCostDetails dealCostDetails = new DealCostDetails();
        BigDecimal expectedGrantAppPerc = BigDecimal.ZERO;
        BigDecimal totalAssetFinalCost = BigDecimal.ZERO;
        BigDecimal totalAssetGrantApprovalCost = BigDecimal.ZERO;
        BigDecimal totalAssetOriginalCost = BigDecimal.ZERO;
        BigDecimal totalAssetStudyCost = BigDecimal.ZERO;
        System.err.println();

        try {
        	
        	String whereCluase = "WHERE " + IBOIB_AST_AssetUdfDetails.DEALID + " = ?";
        	ArrayList<String> params = new ArrayList<>();
        	params.add(dealId);
        	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        	List<IBOIB_AST_AssetUdfDetails> dealAssetUDFDtls = factory.findByQuery(IBOIB_AST_AssetUdfDetails.BONAME,whereCluase,params, null, false);
        	
        	if(null != dealAssetUDFDtls && !dealAssetUDFDtls.isEmpty())
        	{
        		for(IBOIB_AST_AssetUdfDetails udfDtl : dealAssetUDFDtls)
        		{
        			if(StringUtils.isNotBlank(udfDtl.getF_FIELDID()))
        			{
        				switch(udfDtl.getF_FIELDID())
        				{
        				case AssetFinalCost_UDF_FIELD_ID:
        					if(null != udfDtl.getF_FIELDVALUE())
        					{
        						totalAssetFinalCost = totalAssetFinalCost.add(new BigDecimal(udfDtl.getF_FIELDVALUE()));
        					}
        					break;
        				case AssetGrantApprovalCost_UDF_FIELD_ID:
        					if(null != udfDtl.getF_FIELDVALUE())
        					{
        						totalAssetGrantApprovalCost = totalAssetGrantApprovalCost.add(new BigDecimal(udfDtl.getF_FIELDVALUE()));
        					}
        					break;
        				case AssetOriginalCost_UDF_FIELD_ID:
        					if(null != udfDtl.getF_FIELDVALUE())
        					{
        						totalAssetOriginalCost = totalAssetOriginalCost.add(new BigDecimal(udfDtl.getF_FIELDVALUE()));
        					}
        					break;
        				case AssetStudyCost_UDF_FIELD_ID:
        					if(null != udfDtl.getF_FIELDVALUE())
        					{
        						totalAssetStudyCost = totalAssetStudyCost.add(new BigDecimal(udfDtl.getF_FIELDVALUE()));
        					}
        					break;
        				default:
        					break;
        				}
        			}
        		}
        	}

        	dealCostDetails.setTotalAssetFinalCost(totalAssetFinalCost);
            dealCostDetails.setTotalAssetGrantApprovalCost(totalAssetGrantApprovalCost);
            dealCostDetails.setTotalAssetOriginalCost(totalAssetOriginalCost);
            dealCostDetails.setTotalAssetStudyCost(totalAssetStudyCost);
            dealCostDetails.setLiabilityAmount(CommonConstants.BIGDECIMAL_ZERO);
            dealCostDetails.setTotalGrantApprBeforeStudyCost(CommonConstants.BIGDECIMAL_ZERO);
            dealCostDetails.setExpectedGrantAppPercentage(CommonConstants.BIGDECIMAL_ZERO);
            BigDecimal liabilityAmount = ADFTechGrantAssetUtils.getCustomerLiabilty(dealId);
			if (totalAssetGrantApprovalCost.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
				dealCostDetails.setTotalGrantApprBeforeStudyCost(totalAssetGrantApprovalCost);
			} else {
				dealCostDetails.setTotalGrantApprBeforeStudyCost(
						AssetStudyAndInfoUtil.calculateGrantApprovalBeforeStudyCost(dealId, totalAssetOriginalCost,liabilityAmount));
			}
			dealCostDetails.setLiabilityAmount(liabilityAmount);
			try {
				expectedGrantAppPerc = dealCostDetails.getTotalGrantApprBeforeStudyCost()
						.divide(dealCostDetails.getTotalAssetOriginalCost(),6,RoundingMode.FLOOR).multiply(new BigDecimal(100));
			} catch (ArithmeticException arithmeticException) {
				expectedGrantAppPerc = new BigDecimal(100);
			}
			dealCostDetails.setExpectedGrantAppPercentage(expectedGrantAppPerc);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        returns.add(dealCostDetails);

        return returns;
    }

}
