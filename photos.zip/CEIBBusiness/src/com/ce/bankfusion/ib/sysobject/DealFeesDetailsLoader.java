package com.ce.bankfusion.ib.sysobject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FEECONFIG;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.objectloader.AbstractGenericExecutor;
import com.misys.cbs.objectloader.DbStep;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.ib.types.DealCostDetails;
import bf.com.misys.ib.types.DealFeesDetails;
import bf.com.misys.ib.types.RuleInputData;
import bf.com.misys.ib.types.RuleInputRq;
import bf.com.misys.ib.types.SystemObjectOutputDetail;
import bf.com.misys.ib.types.SystemParam;

public class DealFeesDetailsLoader extends AbstractGenericExecutor{
	
	@Override
	public void initialize(DbStep arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List executeAndPopulate(Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		Object dealId = paramMap.get("dealId");
        if (dealId != null)
            return doTheStuff(dealId.toString(), paramMap);
        return null;
	}
	
	private List<Object> doTheStuff(String dealId, Map<String, Object> paramMap) {

        List<Object> returns = new ArrayList<Object>();

        DealFeesDetails dealFeesDetails = new DealFeesDetails();
        
        BigDecimal initialFee=BigDecimal.ZERO;
        BigDecimal studyAdjustmentFee=BigDecimal.ZERO;
        
        System.err.println();

        try {
        	
        	ArrayList<String> params = new ArrayList<>();
        	
        	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        	       	
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
			
			String getFeeConfig = "WHERE " + IBOCE_IB_FEECONFIG.IBTYPE + " = ?";
			
			params.clear();
			params.add("INITIALFEE");
			
			List<IBOCE_IB_FEECONFIG> feeConfig = factory.findByQuery(IBOCE_IB_FEECONFIG.BONAME,getFeeConfig,params, null, false);
			
			BigDecimal percentage = BigDecimal.ZERO;
			String ruleId = IBConstants.EMPTY_STRING;
			BigDecimal ruleAmount = BigDecimal.ZERO;
			BigDecimal TotalOriginalCost = BigDecimal.ZERO;
			
			
			DealCostDetailsLoader dealCostDetails = new DealCostDetailsLoader();
			List<DealCostDetails> dealCosts = dealCostDetails.executeAndPopulate(paramMap);
			
			for(DealCostDetails dealCost: dealCosts) {
				TotalOriginalCost = dealCost.getTotalAssetOriginalCost();
			}
			
			for(IBOCE_IB_FEECONFIG feesconfig:feeConfig){
				
				if(feesconfig.getF_IBRANGEFROM().compareTo(TotalOriginalCost) < 0 && feesconfig.getF_IBRANGETO().compareTo(TotalOriginalCost) >= 0) {
				percentage = feesconfig.getF_IBPERCENTAGE().divide(new BigDecimal(100)); 
				ruleId = feesconfig.getF_IBRULEID();
				
				if(ruleId!=null && !ruleId.isEmpty()) {
					
				      SystemObjectOutputDetail sysObjectDetail = new SystemObjectOutputDetail();
				      sysObjectDetail.setSystemObjectName(IBOIB_DLI_DealDetails.BONAME);

				      List<Object> feeDetailsObjList = new ArrayList<>();
				      feeDetailsObjList.add(IBCommonUtils.getDealDetails(dealId));
				      sysObjectDetail.setSystemObjectList(feeDetailsObjList);
				      
		               RuleInputRq ruleInputRq = new RuleInputRq();
		               RuleInputData ruleData = new RuleInputData();
		               SystemParam systemParam = new SystemParam();
		               systemParam.setParamName(IBConstants.DEALID_SYSTEMOBJECT_CONSTANTS);
		               systemParam.setParamValue(dealId);
		               ruleData.addInputParam(systemParam);
		               ruleData.setRuleId(ruleId);
		               ruleData.addInputData(sysObjectDetail);
		               ruleData.setXmlContext("Default");
		               ruleInputRq.setRuleInputList(ruleData);

		               RuleExecRsData response = IBCommonUtils.executeRule(ruleInputRq);
		               
		               if (response.getRuleType().equals(IBConstants.RULE_TYPE_FORMULA_CONSTANTS) && response.getRuleData() != null) {
		                   List<String> responseList = (List<String>) response.getRuleData();
		                   if (responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
		                	   ruleAmount = new BigDecimal(responseList.get(CommonConstants.INTEGER_ZERO));
		                   }
		               }
		               initialFee = percentage.multiply(ruleAmount).setScale(0,BigDecimal.ROUND_UP);
				}
			}
			}
			
			
			params.clear();
			params.add("STUDYFEE");
			
			feeConfig = factory.findByQuery(IBOCE_IB_FEECONFIG.BONAME,getFeeConfig,params, null, false);
			
			percentage = BigDecimal.ZERO;
			ruleId = IBConstants.EMPTY_STRING;
			ruleAmount = BigDecimal.ZERO;
			
			
			for(IBOCE_IB_FEECONFIG feesconfig:feeConfig){
				
				if(feesconfig.getF_IBRANGEFROM().compareTo(dealDetails.getF_PrincipleAmt()) < 0 && feesconfig.getF_IBRANGETO().compareTo(dealDetails.getF_PrincipleAmt()) >= 0) {
				percentage = feeConfig.get(0).getF_IBPERCENTAGE().divide(new BigDecimal(100));
				ruleId = feesconfig.getF_IBRULEID();
				
				if(ruleId!=null && !ruleId.isEmpty()) {
					
				      SystemObjectOutputDetail sysObjectDetail = new SystemObjectOutputDetail();
				      sysObjectDetail.setSystemObjectName(IBOIB_DLI_DealDetails.BONAME);

				      List<Object> feeDetailsObjList = new ArrayList<>();
				      feeDetailsObjList.add(IBCommonUtils.getDealDetails(dealId));
				      sysObjectDetail.setSystemObjectList(feeDetailsObjList);
				      
		               RuleInputRq ruleInputRq = new RuleInputRq();
		               RuleInputData ruleData = new RuleInputData();
		               SystemParam systemParam = new SystemParam();
		               systemParam.setParamName(IBConstants.DEALID_SYSTEMOBJECT_CONSTANTS);
		               systemParam.setParamValue(dealId);
		               ruleData.addInputParam(systemParam);
		               ruleData.setRuleId(ruleId);
		               ruleData.addInputData(sysObjectDetail);
		               ruleData.setXmlContext("Default");
		               ruleInputRq.setRuleInputList(ruleData);

		               RuleExecRsData response = IBCommonUtils.executeRule(ruleInputRq);
		               
		               if (response.getRuleType().equals(IBConstants.RULE_TYPE_FORMULA_CONSTANTS) && response.getRuleData() != null) {
		                   List<String> responseList = (List<String>) response.getRuleData();
		                   if (responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
		                	   ruleAmount = new BigDecimal(responseList.get(CommonConstants.INTEGER_ZERO));
		                   }
		               }
		               studyAdjustmentFee = percentage.multiply(ruleAmount).setScale(0,BigDecimal.ROUND_UP);
		               studyAdjustmentFee = studyAdjustmentFee.subtract(initialFee);
				}
				}
				}
			
			dealFeesDetails.setInitialFee(initialFee);
			dealFeesDetails.setStudyAdjustmentFee(studyAdjustmentFee);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        returns.add(dealFeesDetails);

        return returns;
    }

}
