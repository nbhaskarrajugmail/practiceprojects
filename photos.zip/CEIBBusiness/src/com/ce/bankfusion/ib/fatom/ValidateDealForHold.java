package com.ce.bankfusion.ib.fatom;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateDealForHold;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class ValidateDealForHold extends AbstractCE_IB_ValidateDealForHold{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4432856043797506168L;

	public ValidateDealForHold()
	{
		super();
	}
	public ValidateDealForHold(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		String dealId = getF_IN_dealID();
		String reason = DealHoldUtil.isDealOnHold(dealId);
		//if the reason is null or empty, then the deal is not on hold. 
		if(StringUtils.isNotEmpty(reason))
		{
			IBCommonUtils.raiseParametrizedEvent(CeConstants.E_DEAL_ON_HOLD, new String[] {reason});
		}
		
	}
}
