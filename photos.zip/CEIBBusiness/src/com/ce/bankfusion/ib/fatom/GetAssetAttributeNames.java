package com.ce.bankfusion.ib.fatom;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetMigrationData;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetAssetAttributeNames;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtimeworkbench.util.udf.UserDefinedFieldsUtil;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_ProductAssetConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_AssetCatAttrbts;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UDFDataCollection;
import bf.com.misys.bankfusion.attributes.UDFInformation;
import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.ib.types.AssetCategoryAttributeInfo;
import bf.com.misys.ib.types.AssetCategoryBasicInfo;
import bf.com.misys.ib.types.AssetCategoryDtls;
import bf.com.misys.ib.types.AssetThirdPartyAttributePanelVisibility;

public class GetAssetAttributeNames extends AbstractCE_IB_GetAssetAttributeNames {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Properties confProperties = new Properties();
	private static final Log LOGGER = LogFactory.getLog(GetAssetAttributeNames.class);
	private static String GET_ALL_ATTRIBUTES_OF_CATEGORY_QUERY = " where ";
	private static final String MACHINE_TYPE_ASSET_QUERY = " where "+IBOIB_IBF_ProductAssetConfig.ASSETCATEGORYID+" = ? and "+IBOIB_IBF_ProductAssetConfig.PRODUCTID+" = ?";

	private static final String PICKLIST = "PickList";
	private static String migragtedDataQuery =
            " WHERE " + IBOCE_IB_AssetMigrationData.IBDEALNO + "= ? AND "+IBOCE_IB_AssetMigrationData.IBASSETSERIAL+" = ? AND "+IBOCE_IB_AssetMigrationData.IBPROCESSED+" =? ";
	
	public GetAssetAttributeNames(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {

		checkIsMigratedAsset();
		String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
		String filePath = confPath.concat(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE);
		loadProperties(filePath);

		AssetCategoryDtls assetCatDtls = new AssetCategoryDtls();
		List<String> categoryNamesList = new ArrayList<>();
		if (getF_IN_categoryID() != null && StringUtils.isNoneEmpty(getF_IN_categoryID())) {
			List<AssetCategoryBasicInfo> categoriesList = AssetCategoryUtil.getAllParentCategoryBasicInfo(
					getF_IN_categoryID(),
					(com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory) BankFusionThreadLocal
							.getPersistanceFactory());
			List<String> categoryIds = new ArrayList<>();
			for (AssetCategoryBasicInfo basicInfo : categoriesList) {
				categoryNamesList.add(basicInfo.getName());
				categoryIds.add(basicInfo.getAssetCategoryid());
			}
			if (categoryIds.size() > CommonConstants.INTEGER_ZERO)
				getAssetAttributesByCategory(assetCatDtls, categoryIds);

			List<UDFInformation> tempList = new ArrayList<>();
			getAssetCategoryAttributes(assetCatDtls, tempList);
		}
		if (BankFusionThreadLocal.getUserLocale().toString().equals("en_GB")) {
			setF_OUT_assetName("New Asset");
		} else {
			setF_OUT_assetName(confProperties.getProperty("AssetName"));
		}
		IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, getF_IN_categoryID(), true);
		if (assetCategory != null) {
			String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
			IBOIB_AST_AssetCategory parentCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal
					.getPersistanceFactory().findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, parentCategoryID, true);
			setF_OUT_assetName(parentCategory.getF_CATEGORYNAME());
		}
	}

	private  Map<String, String> getAssetCategoryAttributes(AssetCategoryDtls assetCatDtls,
			List<UDFInformation> tempList) {
		Map<String, String> UDFDealAssetMap = new HashMap<>();
		Map<String, String> UDFDealAssetAttrMap = new HashMap<>();
		List<UDFInformation> newList = null;
		if (assetCatDtls.getCategoryAttributeInfoCount() > 0) {
			ArrayList<String> udfIdList = new ArrayList<String>();
			for (int j = 0; j < assetCatDtls.getCategoryAttributeInfoCount(); j++) {
				udfIdList.add(assetCatDtls.getCategoryAttributeInfo(j).getAttributeID());
				UDFDealAssetAttrMap.put(assetCatDtls.getCategoryAttributeInfo(j).getAttributeID(), assetCatDtls.getCategoryAttributeInfo(j).getAttributeName());
			}
			UDFDataCollection udfcollection = UserDefinedFieldsUtil.getSpecifiedUDFFieldsForBO(IBOIB_AST_AssetDetails.BONAME,
					udfIdList);
			newList = new ArrayList<UDFInformation>(Arrays.asList(udfcollection.getUDFDataGroup()));
		}
		if (newList != null && newList.size() > 0) {
			tempList.addAll(newList);
		}
		AssetThirdPartyAttributePanelVisibility attributePanelVisibility=new AssetThirdPartyAttributePanelVisibility();
		for (UDFInformation udfInfo : tempList) {
			UDFDealAssetMap.put(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()), udfInfo.getUDFFIELDDETAILS().getLABELNAME());
			
			if((confProperties.getProperty("Attribute-1")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute1(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID1(udfInfo.getUDFNAME());
				setF_OUT_attribute1Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				setF_OUT_attribute1LabelVisibility(true);
				attributePanelVisibility.setPanelVisibilityAttribute1(true);
			}
			if((confProperties.getProperty("Attribute-2")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute2(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID2(udfInfo.getUDFNAME());
				setF_OUT_attribute2Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				setF_OUT_attribute2LabelVisibility(true);
				attributePanelVisibility.setPanelVisibilityAttribute2(true);
			}
			if((confProperties.getProperty("Attribute-3")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute3(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID3(udfInfo.getUDFNAME());
				setF_OUT_attribute3Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				setF_OUT_attribute3LabelVisibility(true);
				attributePanelVisibility.setPanelVisibilityAttribute3(true);
			}
			if((confProperties.getProperty("Attribute-4")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute4(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID4(udfInfo.getUDFNAME());
				setF_OUT_attribute4Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute4(true);
			}
			if((confProperties.getProperty("Attribute-5")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute5(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID5(udfInfo.getUDFNAME());
				setF_OUT_attribute5Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute5(true);
			}
			if((confProperties.getProperty("Attribute-6")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute6(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID6(udfInfo.getUDFNAME());
				setF_OUT_attribute6Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute6(true);
			}
			if((confProperties.getProperty("Attribute-7")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute7(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID7(udfInfo.getUDFNAME());
				setF_OUT_attribute7Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute7(true);
			}
			if((confProperties.getProperty("Attribute-8")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute8(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID8(udfInfo.getUDFNAME());
				setF_OUT_attribute8Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute8(true);
			}
			if((confProperties.getProperty("Attribute-9")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
				getF_OUT_assetAttributeSearchVisibility().setSearchAttribute9(udfInfo.getUDFFIELDDETAILS().getDISPLAYTYPE().equals(PICKLIST));
				getF_OUT_assetAttributeSearchVisibility().setAttributeID9(udfInfo.getUDFNAME());
				setF_OUT_attribute9Label(udfInfo.getUDFFIELDDETAILS().getLABELNAME());
				attributePanelVisibility.setPanelVisibilityAttribute9(true);
			}
			if(!isF_IN_onlyAttributeMode()) {  //Not loading the rule related attributes when populating the grid
				if((confProperties.getProperty("GRP_CD")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_GROUPCD(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("TOOLNO")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_TOOLNO(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("AssetType")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_assetType(String.valueOf(execRule(getF_IN_dealID(), udfInfo.getUDFNAME())));
				}
				if((confProperties.getProperty("Dividable")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_isDividable((String.valueOf(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()))).equals("0")?true:false);
				}
				if((confProperties.getProperty("Priced")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_isPriced((String.valueOf(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()))).equals("0")?true:false);;
				}
				if ((confProperties.getProperty("DisbursmentPeriodInYears")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_disbursmentPeriod(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("Asset_Tenor_in_years")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_noOfInstallmentValue(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("MaxAssetAllowedPerdeal")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_maxAssetAllowed(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("MaxRateChangeAllowed")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_maxrateChangeAllowed(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()));
				}
				if((confProperties.getProperty("SubsidyPercentage")).equals(UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()))) {
					setF_OUT_subsidyPercentage(new BigDecimal(String.valueOf(execRule(getF_IN_dealID(), udfInfo.getUDFNAME()))));
				}
			}
		}
		if (!getF_OUT_assetType().equals("1")) {
			String udfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
					"DisbursmentPeriodInYears", "", CeConstants.ADFIBCONFIGLOCATION);
			setF_OUT_disbursmentPeriod((Integer)AssetStudyAndInfoUtil.getUDFValue(udfName, getF_IN_dealID()));
			String udfName1 = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
					"numberOfinstallment", "", CeConstants.ADFIBCONFIGLOCATION);
			setF_OUT_noOfInstallmentValue((Integer)AssetStudyAndInfoUtil.getUDFValue(udfName1, getF_IN_dealID()));
		}
		if (getF_IN_editMode() != null && (getF_IN_editMode().equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE) || getF_IN_editMode().equals(CeConstants.ASSET_REPLACEMENT_MODE))) {
			 ArrayList<String> queryParams = new ArrayList<String>();
			IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, getF_IN_categoryID(),
							true);
			String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
			queryParams.add(parentCategoryID);
			queryParams.add(CeConstants.MACHINE_TYPE_ASSET_PRODUCTID);
			List<IBOIB_IBF_ProductAssetConfig> productAssetConfigList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOIB_IBF_ProductAssetConfig.BONAME, MACHINE_TYPE_ASSET_QUERY, queryParams, null,
							true);
			if (productAssetConfigList != null && !productAssetConfigList.isEmpty()) {
				attributePanelVisibility.setPanelVisibilityMachineType(true);
				if (isF_IN_forAssetProgress()) {
					attributePanelVisibility.setPanelVisibilityAttribute7(false);
					attributePanelVisibility.setPanelVisibilityAttribute8(false);
					attributePanelVisibility.setPanelVisibilityAttribute9(false);
				}
			} else {
				attributePanelVisibility.setPanelVisibilityMachineType(false);
				if (isF_IN_forAssetProgress()&& isF_IN_isSpecialLoan()) {
					attributePanelVisibility.setPanelVisibilityAttribute7(false);
					attributePanelVisibility.setPanelVisibilityAttribute8(false);
					attributePanelVisibility.setPanelVisibilityAttribute9(false);
				}
			}
		}
		setF_OUT_assetThirdPartyAttributePanelVisibility(attributePanelVisibility);

		return UDFDealAssetMap;
	}
	

	private  void getAssetAttributesByCategory(AssetCategoryDtls assetCatDtls, List<String> categoryIds) {
		StringBuffer queryAttr = new StringBuffer(GET_ALL_ATTRIBUTES_OF_CATEGORY_QUERY);
		queryAttr.append("(");
		for (int i = 0; i < categoryIds.size(); i++) {
			queryAttr.append(IBOIB_IDI_AssetCatAttrbts.CATEGORYID + " = ? ");
			if ((i + 1) == categoryIds.size()) {
				queryAttr.append(") AND " + IBOIB_IDI_AssetCatAttrbts.ISDELETE + "='N'  AND "
						+ IBOIB_IDI_AssetCatAttrbts.ISACTIVE + " =  'Y'");
			} else {
				queryAttr.append(" OR ");
			}
		}
		queryAttr.append(" ORDER BY boID ASC");
		List<IBOIB_IDI_AssetCatAttrbts> attrResultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOIB_IDI_AssetCatAttrbts.BONAME, queryAttr.toString(), (ArrayList) categoryIds, null, true);
		List<String> parentAttrIds = new ArrayList<String>();
		if (null != attrResultSet) {
			for (int i = (attrResultSet.size() - 1); i > -1; i--) {
				IBOIB_IDI_AssetCatAttrbts attribute = attrResultSet.get(i);
				AssetCategoryAttributeInfo attributeDetails = new AssetCategoryAttributeInfo();
				if (null != attribute.getF_PARENTATTRID() && attribute.getF_PARENTATTRID().length() > 0) {

					parentAttrIds.add(attribute.getF_PARENTATTRID());
				}
				if (!parentAttrIds.contains(attribute.getBoID())) {
					attributeDetails.setAttributeID(attribute.getBoID());
					attributeDetails.setAttributeName(attribute.getF_ATTRID());
					assetCatDtls.addCategoryAttributeInfo(attributeDetails);
				}
			}
		}
	}

	private int execRule(String dealId, String udfName) {
		IBOIB_IDI_AssetCatAttrbts assetCatAttrbts = (IBOIB_IDI_AssetCatAttrbts) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOIB_IDI_AssetCatAttrbts.BONAME, udfName, true);
		if (null != assetCatAttrbts && IBCommonUtils.isNotEmpty(assetCatAttrbts.getF_DEFAULTRULEID())) {
			if (dealId != null && !dealId.equals(CommonConstants.EMPTY_STRING)) {
				String ruleOutput = "";
				RuleExecRsData ruleResponse = IBCommonUtils.getRuleAndExecute(assetCatAttrbts.getF_DEFAULTRULEID(), dealId);
				if (null != ruleResponse && null != ruleResponse.getRuleData()) {
					List<String> responseList = (List<String>) ruleResponse.getRuleData();
					if (ruleResponse.getRuleType().equals(IBConstants.RULE_TYPE_FORMULA_CONSTANTS)
							&& ruleResponse.getRuleData() != null && responseList.size() > CommonConstants.INTEGER_ZERO
							&& responseList.get(CommonConstants.INTEGER_ZERO) != null) {
						ruleOutput = String.valueOf(responseList.get(CommonConstants.INTEGER_ZERO));
						if (ruleOutput != null)
							return Integer.parseInt(ruleOutput);
					}
				}
			}
			
		}
		return 0;
	}
	private void loadProperties(String absoluteFilePath) {
		try {
			FileReader reader=new FileReader(absoluteFilePath);
			if (reader != null) {
				confProperties.load(reader);
			} else {
				LOGGER.error("Attributes conf file of AssetStudyAndInfoBB(conf/business/assetStudyAndInfoConf.properties) not found");
				throw new FileNotFoundException("property file '" + absoluteFilePath + "' not found in the classpath");
			}
		}catch (Exception e) {
			LOGGER.error("Error occured in reading the attributes conf file for AssetStudyAndInfoBB : "+e);
		} 
	}
	private void checkIsMigratedAsset() {
	    IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock("ASSETANDSTUDYINFO",
          getF_IN_islamicBankingObject().getProductID(), getF_IN_islamicBankingObject().getSubProductID(),
          getF_IN_islamicBankingObject().getStepID(), getF_IN_islamicBankingObject().getProcessConfigID());
        if (getF_IN_assetSerial() != null && !getF_IN_assetSerial().isEmpty()) {
            ArrayList<String> paramValues = new ArrayList<>();
            paramValues.add(getF_IN_dealID());
            paramValues.add(getF_IN_assetSerial());
            paramValues.add("Y");
            List<IBOCE_IB_AssetMigrationData> migratedDataList = BankFusionThreadLocal.getPersistanceFactory()
                .findByQuery(IBOCE_IB_AssetMigrationData.BONAME, migragtedDataQuery, paramValues, null, true);
            if (migratedDataList != null && !migratedDataList.isEmpty()) {
                setF_OUT_migrated(true);
            }
            else {
                if (bbConfig.getF_BUILDINGBLOCKMODE().equals(IBConstants.VIEWMODE))
                    setF_OUT_migrated(true);
               }
        } else {
            setF_OUT_migrated(false);
        }
	}
}