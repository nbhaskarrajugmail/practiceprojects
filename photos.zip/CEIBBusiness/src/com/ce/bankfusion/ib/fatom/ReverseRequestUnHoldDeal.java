package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReverseRequestUnHoldDeal;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class ReverseRequestUnHoldDeal extends AbstractCE_IB_ReverseRequestUnHoldDeal{
    public ReverseRequestUnHoldDeal() {
        super();
    }
    @SuppressWarnings("deprecation")
    public ReverseRequestUnHoldDeal(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        DealHoldUtil.reverseRequestUnHoldDeal(getF_IN_islamicBankingObject().getDealID());
    }

}
