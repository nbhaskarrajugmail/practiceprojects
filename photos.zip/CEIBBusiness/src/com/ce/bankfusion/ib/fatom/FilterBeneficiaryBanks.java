package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PartyFinancialDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FilterBeneficiaryBanks;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class FilterBeneficiaryBanks extends AbstractCE_IB_FilterBeneficiaryBanks {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String WHERE_CLAUSE = "WHERE " + IBOCE_IB_PartyFinancialDetails.IBPARTYID + " = ? AND "
			+ IBOCE_IB_PartyFinancialDetails.IBSTATUS + " = ?";

	public FilterBeneficiaryBanks() {
		super();
	}

	@SuppressWarnings("deprecation")
	public FilterBeneficiaryBanks(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		getF_OUT_beneficiaryBanksGC().removeAllGcCodeDetails();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList<>();
		params.add(getF_IN_partyID());
		System.err.println();
		params.add("ACTIVE");
		List<IBOCE_IB_PartyFinancialDetails> financialDetails = factory
				.findByQuery(IBOCE_IB_PartyFinancialDetails.BONAME, WHERE_CLAUSE, params, null, true);
		ListGenericCodeRs genericCodeRs = IBCommonUtils.getGCList("OTHERBANKNAME");
		for (IBOCE_IB_PartyFinancialDetails iboce_IB_PartyFinancialDetails : financialDetails) {
			for (GcCodeDetail gcCodeDtls : genericCodeRs.getGcCodeDetails()) {
				if (gcCodeDtls.getCodeReference().equals(iboce_IB_PartyFinancialDetails.getF_IBBANKNAME())) {
					getF_OUT_beneficiaryBanksGC().addGcCodeDetails(gcCodeDtls);
					setF_OUT_bankName(gcCodeDtls.getCodeDescription());
				}
			}
		}
	}
}
