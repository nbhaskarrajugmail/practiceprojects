package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateMaxAssetAllowed;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class ValidateMaxAssetAllowed extends AbstractCE_IB_ValidateMaxAssetAllowed{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(ValidateMaxAssetAllowed.class.getName());
	private static Integer E_MAX_ASSET_ALLOWED = 44000326;
	
	@SuppressWarnings("deprecation")
    public ValidateMaxAssetAllowed(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	
    	AssetThirdPartyDetailsList assetTPList = getF_IN_assetThirdPartyDetailsList();
    	AssetThirdPartyDetails selectedAsset = getF_IN_selectedAssetThirdPartyDetails();
    	//IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, ibObj.getProductID(), ibObj.getSubProductID(), ibObj.getStepID(), ibObj.getProcessConfigID());
		if (getF_IN_editMode().equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE)) {

			if (selectedAsset.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) <= 0) {
				IBCommonUtils.raiseUnparameterizedEvent(44000414);
			}
			if(isF_IN_inputFieldvalueChanged()) {
				IBCommonUtils.raiseUnparameterizedEvent(44000420);
			}

		}
		if(getF_IN_islamicBankingObject().getProcessConfigID()!=null && !getF_IN_islamicBankingObject().getProcessConfigID().isEmpty()) {
    	AssetStudyAndInfoUtil.validateMaxRateChange(getF_IN_islamicBankingObject().getProcessConfigID(), getF_IN_selectedAssetThirdPartyDetails(), getF_IN_attribute7Calculated(), getF_IN_attribute8Calculated(), getF_IN_attribute9Calculated(),
				getF_IN_attribute7Label(), getF_IN_attribute8Label(), getF_IN_attribute9Label());
    	}
    	if(assetTPList.getAssetThirdPartyDetails().length == 0) {
    		return;
    	}
    	int count = 0;
    	
    	LOGGER.info("Max Asset Allowed Config : "+selectedAsset.getMaxAssetAllowed());
    	for(AssetThirdPartyDetails asset : assetTPList.getAssetThirdPartyDetails()) {
    		if(!asset.isSelect()) {
    			if(selectedAsset.getAssetCategory().getCategory()!=null && asset.getAssetCategory().getCategory().equals(selectedAsset.getAssetCategory().getCategory())) {
    				count++;
;    			}
    		}
    	}
    	LOGGER.info("Already added times :"+count);
    	if(selectedAsset.getMaxAssetAllowed() <= count) {
    		String[] parms = new String[1];
    		parms[0] = String.valueOf(count);
    		IBCommonUtils.raiseParametrizedEvent(E_MAX_ASSET_ALLOWED, parms);
    	}
    }

}
