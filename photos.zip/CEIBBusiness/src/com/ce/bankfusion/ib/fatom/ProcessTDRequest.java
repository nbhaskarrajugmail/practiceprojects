package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ProcessTDRequest;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.TransferOfDebtsUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.DebtTrnsfrDeal;
import bf.com.misys.ib.types.DebtTrnsfrDealsList;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.TrnsfDbtsElgDeal;
import bf.com.misys.ib.types.TrnsfDbtsElgDealsList;
import bf.com.misys.ib.types.TrnsfDbtsRequest;

public class ProcessTDRequest extends AbstractCE_IB_ProcessTDRequest{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1064936371596953860L;

	public ProcessTDRequest()
	{
		super();
	}
	
	public ProcessTDRequest(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		DebtTrnsfrDealsList debtTrnsfrdDealsList = new DebtTrnsfrDealsList();
		
		TrnsfDbtsRequest transferOfDebtsRq = getF_IN_trnsfDbtsRequest();
		TrnsfDbtsElgDealsList dealsForTD = getF_IN_dealsSelectedForTD();
		if(null == dealsForTD || dealsForTD.getTrnsfDbtsElgDealsCount() == 0)
		{
			IBCommonUtils.raiseUnparameterizedEvent(44000383);
		}
		
		//new customer validation
		TDNewCustValidation newCustValidation = new TDNewCustValidation();
		newCustValidation.setF_IN_partyID(transferOfDebtsRq.getPartyID());
		newCustValidation.setF_IN_selectedDealsForTD(getF_IN_dealsSelectedForTD());
		newCustValidation.process(env);
		
		for(TrnsfDbtsElgDeal selectedDeal : dealsForTD.getTrnsfDbtsElgDeals())
		{
			//getting old deal's loan details
			ReadLoanDetailsRs loadDetails = IBCommonUtils.getLoanDetails(selectedDeal.getDealID());
			
			//this check placed here to check if loan settled [from UB side and IB is unaware of that]
			if(loadDetails.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().compareTo(CommonConstants.BIGDECIMAL_ZERO) == 0)
			{
				IBCommonUtils.raiseParametrizedEvent(44000384, new String[] {selectedDeal.getDealID()});
			}
			
			DebtTrnsfrDeal debtTrnsfrdDeal = new DebtTrnsfrDeal();
			
			//setting amount details
			BFCurrencyAmount newDealAmount = new BFCurrencyAmount();
			newDealAmount.setCurrencyAmount(loadDetails.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt());
			newDealAmount.setCurrencyCode(loadDetails.getDealDetails().getLoanBasicDetails().getLoanCurrency());
			debtTrnsfrdDeal.setNewDealAmt(newDealAmount );
			BFCurrencyAmount newPrincipalAmt = new BFCurrencyAmount();
			newPrincipalAmt.setCurrencyAmount(loadDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt());
			newPrincipalAmt.setCurrencyCode(loadDetails.getDealDetails().getLoanBasicDetails().getLoanCurrency());
			debtTrnsfrdDeal.setNewPrincipalAmt(newPrincipalAmt);
			BFCurrencyAmount newProfitAmt = new BFCurrencyAmount();
			newProfitAmt.setCurrencyAmount(loadDetails.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().
					subtract(loadDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt()));
			newProfitAmt.setCurrencyCode(loadDetails.getDealDetails().getLoanBasicDetails().getLoanCurrency());
			debtTrnsfrdDeal.setNewProfitAmt(newProfitAmt);
			
			//setting other details
			debtTrnsfrdDeal.setCustID(selectedDeal.getPartyID());
			debtTrnsfrdDeal.setDealID(selectedDeal.getDealID());
			debtTrnsfrdDeal.setNewCustID(transferOfDebtsRq.getPartyID());
			
			debtTrnsfrdDealsList.addDebtTrnsfrDeals(debtTrnsfrdDeal);
		}
		
		//Asking for supervisor approval
		IBCommonUtils.raiseUnparameterizedEvent(44000382);
		
		String userToken = TransferOfDebtsUtil.getTechnicalUserToken();
		for(DebtTrnsfrDeal debtTrnsfrDeal : debtTrnsfrdDealsList.getDebtTrnsfrDeals())
		{
			//initiating new Transfer of Debts process
			IslamicBankingObject newDealIBObj = TransferOfDebtsUtil.initiateNewDealForTransfer(debtTrnsfrDeal.getDealID(), userToken);
			debtTrnsfrDeal.setNewDealID(newDealIBObj.getDealID());
			
			//setting basic info and customer info for the newly created deal
			TransferOfDebtsUtil.setBasicDtlsForNewDeal(debtTrnsfrDeal.getDealID(), newDealIBObj);
			TransferOfDebtsUtil.setCustInfoForNewDeal(newDealIBObj, transferOfDebtsRq.getPartyID());
			
			IBOIB_DLI_DealDetails origDealDetails = IBCommonUtils.getDealDetails(debtTrnsfrDeal.getDealID());
			boolean isTroubleProjectRequested = CeConstants.DEAL_STATUS_TROUBLED_PROJECT_REQ.equals(origDealDetails.getF_Status())?true:false;
			//persisting the TD request in DB
			TransferOfDebtsUtil.saveTDDtls(debtTrnsfrDeal, transferOfDebtsRq, isTroubleProjectRequested);
			
			//updating the original deal system status as TRANSFEROFDEBT
			origDealDetails.setF_SYSTEMSTATUS(CeConstants.DEAL_STATUS_TD_INITIATED);
		}
		if(null != userToken)
		{
			TransferOfDebtsUtil.logoutTechnicalUser(userToken);
		}
		setF_OUT_dbtTransferredDealsList(debtTrnsfrdDealsList);
	}
}
