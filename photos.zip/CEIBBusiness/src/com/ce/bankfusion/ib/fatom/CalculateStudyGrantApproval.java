package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_GrandApproval;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateStudyGrantApproval;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CalculateStudyGrantApproval extends AbstractCE_IB_CalculateStudyGrantApproval {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(CalculateStudyGrantApproval.class);
	
	private static String PROJECT_LATEST_TECHNOLOGIES = "ProjectNewTechnologies";
	private static String LATEST_TECHNOLOGY_PERCENTAGE = "LatestTechnologiesProjectPercentage";
	private static String SHARING_PROJECT = "SharingProject";
	private static String SHARING_PROJECT_PERCENTAGE = "SharingProjectPercentage";
	
	
	public CalculateStudyGrantApproval(BankFusionEnvironment env) {
		super(env);
	}

	public CalculateStudyGrantApproval() {
		super();
	}

	public void process(BankFusionEnvironment env) {
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
		IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock("ASSETANDSTUDYINFO",
				ibObj.getProductID(), ibObj.getSubProductID(), ibObj.getStepID(), ibObj.getProcessConfigID());

		if (bbConfig.getF_BUILDINGBLOCKMODE().equals(IBConstants.EDITMODE)) {
			if (getF_IN_editMode().equalsIgnoreCase(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE)) {
				processFinalCost();
			} else {
				processGrantApprovalCost();
			}
		}else {
			setF_OUT_assetThirdPartyDetailsList(getF_IN_assetThirdPartyDetailsList());
		}
	}

	private void processFinalCost() {
		String totalFinalCostUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.TOTAL_FINAL_COST_UDFNAME, "", CeConstants.ADFIBCONFIGLOCATION);
		BigDecimal totalFinalCost = (BigDecimal)AssetStudyAndInfoUtil.getUDFValue(totalFinalCostUdfName, getF_IN_islamicBankingObject().getDealID());
		LOGGER.info("Total final cost for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+totalFinalCost.doubleValue());
		if(totalFinalCost == null || totalFinalCost.compareTo(BigDecimal.ZERO)==0) {
			setF_OUT_assetThirdPartyDetailsList(getF_IN_assetThirdPartyDetailsList());
			return;
		}
		BigDecimal totalAssetsApprovedCost = BigDecimal.ZERO;
		for(AssetThirdPartyDetails assetTPDtl : getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()) {
			totalAssetsApprovedCost = totalAssetsApprovedCost.add(assetTPDtl.getGrantApprovalCost().getCurrencyAmount());
		}
		LOGGER.info("Total Assets final cost for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+totalAssetsApprovedCost.doubleValue());
		BigDecimal increasedPercentage = totalFinalCost.multiply(new BigDecimal(100.0)).divide(totalAssetsApprovedCost, 10, RoundingMode.HALF_DOWN);
		LOGGER.info("Increased percentage is:"+increasedPercentage.doubleValue());
		
		BigDecimal totalAssetCostAfterGiven = BigDecimal.ZERO;
		AssetThirdPartyDetails[] assetThirdParties = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
		for (AssetThirdPartyDetails assetThirdPartyDetails : assetThirdParties) {
			BigDecimal assetApprovedCostBackup = assetThirdPartyDetails.getGrantApprovalCost().getCurrencyAmount();
			BigDecimal assetApprovedCost = assetThirdPartyDetails.getGrantApprovalCost().getCurrencyAmount();
			BigDecimal finalAmendedCost = assetApprovedCost.multiply(increasedPercentage).divide(new BigDecimal(100.0), 2, RoundingMode.HALF_DOWN);
			assetThirdPartyDetails.getFinalCost().setCurrencyAmount(finalAmendedCost);
			assetThirdPartyDetails.setDisplayCost(assetThirdPartyDetails.getFinalCost());
			assetThirdPartyDetails.getGrantApprovalCost().setCurrencyAmount(assetApprovedCostBackup);
			totalAssetCostAfterGiven = totalAssetCostAfterGiven.add(finalAmendedCost);
		}
		LOGGER.info("Total totalAssetCostAfterGiven for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+totalAssetCostAfterGiven.doubleValue());
		if(totalAssetCostAfterGiven.compareTo(totalFinalCost)<0) {
			BigDecimal adjustedBal = totalFinalCost.subtract(totalAssetCostAfterGiven);
			LOGGER.info("Left over total balance for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+adjustedBal.doubleValue()+" . So adding to first asset.");
			BigDecimal assetApprovedCostBackup = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().getCurrencyAmount();
			BigDecimal updateBal = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost().getCurrencyAmount().add(adjustedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost().setCurrencyAmount(updateBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].setDisplayCost((getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost()));
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().setCurrencyAmount(assetApprovedCostBackup);
		}else if(totalAssetCostAfterGiven.compareTo(totalFinalCost)>0) {
			BigDecimal adjustedBal = totalAssetCostAfterGiven.subtract(totalFinalCost);
			LOGGER.info("Left over total balance for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+adjustedBal.doubleValue()+" . So adding to first asset.");
			BigDecimal assetApprovedCostBackup = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().getCurrencyAmount();
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].setGrantApprovalCost(getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost());
			BigDecimal updatedBal = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost().getCurrencyAmount().subtract(adjustedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost().setCurrencyAmount(updatedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].setDisplayCost((getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getFinalCost()));
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().setCurrencyAmount(assetApprovedCostBackup);
		}
		setF_OUT_assetThirdPartyDetailsList(getF_IN_assetThirdPartyDetailsList());
	}

    private void processGrantApprovalCost() {
        IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
        IBOIB_CFG_ProcessConfig processConfig = (IBOIB_CFG_ProcessConfig) BankFusionThreadLocal.getPersistanceFactory()
                .findByPrimaryKey(IBOIB_CFG_ProcessConfig.BONAME, islamicBankingObject.getProcessConfigID(), true);
        String method = processConfig.getF_TEMPLATEID();
        BigDecimal loanRequestedAmount = calculateLoanRequestedAmount();
        BigDecimal liabilityAmount = CommonConstants.BIGDECIMAL_ZERO;
        try {
            String liabilityUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                    CeConstants.INCLUDELIABILITY, "", CeConstants.ADFIBCONFIGLOCATION);
            String liability = (String) AssetStudyAndInfoUtil.getUDFValue(liabilityUdfName, islamicBankingObject.getDealID());
            if (liability != null && liability.equalsIgnoreCase(IBConstants.YES)) {
                liabilityAmount = ADFTechGrantAssetUtils.getCustomerLiabilty(islamicBankingObject.getDealID());
                LOGGER.info("Liablity of the customer is :" + liabilityAmount);
            }
        }
        catch (Exception e) {
            LOGGER.error(e.getLocalizedMessage());
        }
        BigDecimal loanApprovedAmount = new BigDecimal(0);
        String latestTechUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                PROJECT_LATEST_TECHNOLOGIES, "", CeConstants.ADFIBCONFIGLOCATION);
        String latestTechnologies = (String) AssetStudyAndInfoUtil.getUDFValue(latestTechUdfName, islamicBankingObject.getDealID());

        String sharedProjUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                SHARING_PROJECT, "", CeConstants.ADFIBCONFIGLOCATION);
        String sharedProjectValue = (String) AssetStudyAndInfoUtil.getUDFValue(sharedProjUdfName, islamicBankingObject.getDealID());
        BigDecimal expectedGrantAppPercentage = AssetStudyAndInfoUtil.getExpectedGrantAppPercentage(islamicBankingObject.getDealID());
        BigDecimal enteredGrantAppPercentage = AssetStudyAndInfoUtil.getEnteredGrantAppPercentage(islamicBankingObject.getDealID());
        if (expectedGrantAppPercentage.compareTo(enteredGrantAppPercentage) == CommonConstants.INTEGER_ZERO) {
            if (sharedProjectValue != null && sharedProjectValue.equalsIgnoreCase(IBConstants.YES)) {
                Double percentage = Double.valueOf(
                        BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE,
                                SHARING_PROJECT_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION));
                LOGGER.info("Configured percentage for Shared project is :" + percentage);
                percentage = percentage / 100;
                loanApprovedAmount = loanRequestedAmount.multiply(new BigDecimal(percentage));
            }
            else if (latestTechnologies != null && latestTechnologies.equalsIgnoreCase(IBConstants.YES)) {
                Double percentage = Double.valueOf(
                        BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE,
                                LATEST_TECHNOLOGY_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION));
                LOGGER.info("Configured percentage for latest technologies is :" + percentage);
                percentage = percentage / 100;
                loanApprovedAmount = loanRequestedAmount.multiply(new BigDecimal(percentage));
            }
            else {
                List<String> normalLoanProcessesList = new ArrayList<>();
                String normalLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE, CeConstants.NORMAL_LOAN_PROCESSES, "",
                        CeConstants.ADFIBCONFIGLOCATION);

                if (normalLoanProcesses != null && !normalLoanProcesses.isEmpty()) {
                    normalLoanProcessesList = IBCommonUtils.isNotEmpty(normalLoanProcesses)? Arrays.asList(normalLoanProcesses.split(",")) : new ArrayList<String>();
                }
                List<String> specialLoanProcessesList = new ArrayList<>();
                String specialLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE, CeConstants.SPECIAL_LOAN_PROCESSES, "",
                        CeConstants.ADFIBCONFIGLOCATION);

                if (specialLoanProcesses != null && !specialLoanProcesses.isEmpty()) {
                    specialLoanProcessesList = IBCommonUtils.isNotEmpty(specialLoanProcesses) ? Arrays.asList(specialLoanProcesses.split(","))  : new ArrayList<String>();
                }
                if (normalLoanProcessesList.contains(method))
                    loanApprovedAmount = calculateNormalLoan(loanRequestedAmount, liabilityAmount);
                if (specialLoanProcessesList.contains(method)) {
                    loanApprovedAmount = calculateSpecialLoan(loanRequestedAmount, liabilityAmount);
                }
            }
        }
        else {
            LOGGER.info("Entered Grant Approval Percentage is considered for calculation :" + enteredGrantAppPercentage);
            loanApprovedAmount = loanRequestedAmount.multiply(enteredGrantAppPercentage).divide(new BigDecimal(100));
        }
        BigDecimal totalLoanApprovedAmount = loanApprovedAmount;
        updateAllAssets(calculateParticipationPercentage(loanRequestedAmount, loanApprovedAmount), totalLoanApprovedAmount);
    }

	private void updateAllAssets(BigDecimal participationPercentage, BigDecimal loanApprovedAmount) {
		AssetThirdPartyDetails[] assetThirdParties = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
		BigDecimal totalAssetApprovedCost = BigDecimal.ZERO;
		for (AssetThirdPartyDetails assetThirdPartyDetails : assetThirdParties) {
			BigDecimal grantApprovalCost = assetThirdPartyDetails.getAssetStudyCost().getCurrencyAmount()
					.multiply(participationPercentage).divide(new BigDecimal(100), 10, RoundingMode.HALF_UP);
			BFCurrencyAmount amount = new BFCurrencyAmount();
			amount.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
			assetThirdPartyDetails.setGrantApprovalCost(amount);
			assetThirdPartyDetails.setDisplayCost(amount);
			assetThirdPartyDetails.getGrantApprovalCost().setCurrencyAmount(grantApprovalCost);
			assetThirdPartyDetails.getDisplayCost().setCurrencyAmount(grantApprovalCost);
			totalAssetApprovedCost = totalAssetApprovedCost.add(grantApprovalCost);
		}
		if(totalAssetApprovedCost.compareTo(loanApprovedAmount)<0) {
			BigDecimal adjustedBal = loanApprovedAmount.subtract(totalAssetApprovedCost);
			LOGGER.info("Left over total balance for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+adjustedBal.doubleValue()+" . So adding to first asset.");
			BigDecimal updatedBal = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().getCurrencyAmount().add(adjustedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().setCurrencyAmount(updatedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getDisplayCost().setCurrencyAmount(updatedBal);
		}else if(totalAssetApprovedCost.compareTo(loanApprovedAmount)>0) {
			BigDecimal adjustedBal = totalAssetApprovedCost.subtract(loanApprovedAmount);
			LOGGER.info("Left over total balance for the Deal :"+getF_IN_islamicBankingObject().getDealID()+" is:"+adjustedBal.doubleValue()+" . So adding to first asset.");
			BigDecimal updatedBal = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().getCurrencyAmount().subtract(adjustedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getGrantApprovalCost().setCurrencyAmount(updatedBal);
			getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails()[0].getDisplayCost().setCurrencyAmount(updatedBal);
		}
		
		setF_OUT_assetThirdPartyDetailsList(getF_IN_assetThirdPartyDetailsList());

	}

	public static BigDecimal calculateParticipationPercentage(BigDecimal loanRequestedAmount, BigDecimal loanApprovedAmount) {
		BigDecimal participationPercentage = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal OnePercent = loanRequestedAmount.divide(new BigDecimal(100), 10, RoundingMode.HALF_EVEN);
		if(OnePercent.compareTo(BigDecimal.ZERO)==0) {
			participationPercentage = new BigDecimal(1);
		}else {
			participationPercentage = loanApprovedAmount.divide(OnePercent, 10, RoundingMode.HALF_EVEN);
		}
		return participationPercentage;

	}

	private BigDecimal calculateLoanRequestedAmount() {
		AssetThirdPartyDetails[] assetThirdParties = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
		BigDecimal totalLoanReqAmount = CommonConstants.BIGDECIMAL_ZERO;
		for (AssetThirdPartyDetails assetThirdPartyDetails : assetThirdParties) {
			totalLoanReqAmount = totalLoanReqAmount.add(assetThirdPartyDetails.getAssetStudyCost().getCurrencyAmount());
		}
		return totalLoanReqAmount;
	}

	public static BigDecimal calculateNormalLoan(BigDecimal loanRequestedAmount, BigDecimal liabilityAmount) {
		BigDecimal approvalAmount = new BigDecimal(0);
		// BigDecimal liabilityAmount =
		// ADFTechGrantAssetUtils.getCustomerLiabilty(DealNumber);

		BigDecimal x = new BigDecimal(0);
		BigDecimal z = new BigDecimal(0);
		BigDecimal h = new BigDecimal(0);
		BigDecimal s = new BigDecimal(0);
		BigDecimal w = new BigDecimal(0);
		BigDecimal remain = new BigDecimal(0);
		BigDecimal cePercentage2 = new BigDecimal(50);
		BigDecimal cePercentage3 = new BigDecimal(0);
		String SELECT_GRANT_APPROVAL = "WHERE " + IBOCE_IB_GrandApproval.IBTYPE + " = ?  ORDER BY "
				+ IBOCE_IB_GrandApproval.IBORDER + " DESC";
		ArrayList params = new ArrayList<>();
		params.add("N");

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOCE_IB_GrandApproval> grandApprovals = factory.findByQuery(IBOCE_IB_GrandApproval.BONAME,
				SELECT_GRANT_APPROVAL, params, null, true);

		for (IBOCE_IB_GrandApproval grandApproval : grandApprovals) {
			if (grandApproval.getF_IBORDER() == 3) {
				cePercentage3 = grandApproval.getF_IBPERCENTAGE();
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					approvalAmount = loanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
							.divide(new BigDecimal(100));
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == 2) {
				remain = grandApproval.getF_IBRANGETO().subtract(grandApproval.getF_IBRANGEFROM());
				cePercentage2 = grandApproval.getF_IBPERCENTAGE();
				if ((liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0)
						&& liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);

					if (loanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = loanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						// get next row to fetch the next percentage
						// _Result.next();
						approvalAmount = ((loanRequestedAmount.subtract(x)).multiply(new BigDecimal(50))
								.divide(new BigDecimal(100))).add(z);
					}
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == CommonConstants.INTEGER_ONE) {
				// check if Liability Amount <= first record
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);
					if (loanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = loanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						h = loanRequestedAmount.subtract(x);
						if (h.compareTo(remain) <= 0) {
							s = h.multiply(cePercentage2).divide(new BigDecimal(100));
						} else {
							s = remain.multiply(cePercentage2).divide(new BigDecimal(100));
							w = (loanRequestedAmount.subtract((x.add(remain)))).multiply(cePercentage3)
									.divide(new BigDecimal(100));
						}
						approvalAmount = z.add(s).add(w);
					}
					break;
				}
			}
		}
		return approvalAmount;
	}

	public static BigDecimal calculateSpecialLoan(BigDecimal loanRequestedAmount, BigDecimal liabilityAmount) {
		BigDecimal approvalAmount = new BigDecimal(0);
		// BigDecimal liabilityAmount =
		// ADFTechGrantAssetUtils.getCustomerLiabilty(DealNumber);

		BigDecimal x = new BigDecimal(0);
		BigDecimal z = new BigDecimal(0);
		BigDecimal h = new BigDecimal(0);
		BigDecimal s = new BigDecimal(0);
		BigDecimal cePercentage2 = new BigDecimal(50);
		String SELECT_GRANT_APPROVAL = "WHERE " + IBOCE_IB_GrandApproval.IBTYPE + " = ?";
		ArrayList params = new ArrayList<>();
		params.add("S");

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOCE_IB_GrandApproval> grandApprovals = factory.findByQuery(IBOCE_IB_GrandApproval.BONAME,
				SELECT_GRANT_APPROVAL, params, null, true);
		for (IBOCE_IB_GrandApproval grandApproval : grandApprovals) {
			if (grandApproval.getF_IBORDER() == 2) {
				cePercentage2 = grandApproval.getF_IBPERCENTAGE();

				// check if Liability amount > last range
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					approvalAmount = loanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
							.divide(new BigDecimal(100));
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == CommonConstants.INTEGER_ONE) {
				// check if Liability Amount <= first record
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);
					if (loanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = loanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						h = loanRequestedAmount.subtract(x);
						s = h.multiply(cePercentage2).divide(new BigDecimal(100));
						approvalAmount = z.add(s);
					}
					break;
				}
			}
		}
		return approvalAmount;
	}

}