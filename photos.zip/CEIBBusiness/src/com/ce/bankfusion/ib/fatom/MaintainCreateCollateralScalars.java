package com.ce.bankfusion.ib.fatom;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_MaintainCreateCollateralScalars;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_MaintainCreateCollateralScalars;
import com.ce.bankfusion.ib.util.CollateralUtil;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.fatoms.CustomAutoNumFatom;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.ModuleConfigDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CreateCollateralRqDetails;

public class MaintainCreateCollateralScalars extends AbstractCE_IB_MaintainCreateCollateralScalars
        implements ICE_IB_MaintainCreateCollateralScalars {

    private static final transient Log LOGGER = LogFactory.getLog(MaintainCreateCollateralScalars.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public MaintainCreateCollateralScalars() {
        // TODO Auto-generated constructor stub
    }

    public MaintainCreateCollateralScalars(BankFusionEnvironment env) {
        super(env);

    }

    public static enum SCALARACTION {
        SCALAR_NEW, SCALAR_REMOVE, SCALAR_SAVE, SCALAR_AMEND, SCALAR_REQUEST_CHANGE
    };

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method-->" + getF_IN_ibObject().getDealID() + "\n mode-->" + getF_IN_mode());
        getF_OUT_collateralRequestDetailsList().removeAllCollateralRequestDetailsList();
        getF_OUT_createCollateralRqDetailsList().removeAllCreateCollateralRqDetailsList();
        getF_OUT_createCollateralRqDetails().setCoverValue(null);
        getF_OUT_createCollateralRqDetails().setExpiryDate(null);
        SCALARACTION action = SCALARACTION.valueOf(getF_IN_mode());
        switch (action) {

            case SCALAR_NEW:
                addRow();
                break;

            case SCALAR_SAVE:
                saveRow();
                break;
            case SCALAR_AMEND:
                selectRow(env);
                break;
            case SCALAR_REMOVE:
                removeRow();
                break;
            case SCALAR_REQUEST_CHANGE:
                onRequestChange();
                break;
        }
        if (isF_IN_isViewOnly()) {
            setF_OUT_isCreateColScalalarsDisabled(true);
            setF_OUT_isNewButtonDisabled(true);
            setF_OUT_isRemoveButtonDisabled(true);
            setF_OUT_isSaveButtonDisabled(true);
        }
        LOGGER.info("Exiting from process method-->" + getF_IN_ibObject().getDealID() + "\n mode-->" + getF_IN_mode());
    }

    private void setRequestBasedValues() {
        for (CollateralRequestDetails collateralRequestDetails : getF_IN_collateralRequestDetailsList()
                .getCollateralRequestDetailsList()) {
            if (collateralRequestDetails.isSelect()) {
                getF_OUT_createCollateralRqDetails().setCoverValue(collateralRequestDetails.getCoverValue());
                getF_OUT_createCollateralRqDetails().setRequestType(collateralRequestDetails.getRequestType());
                getF_OUT_createCollateralRqDetails().setRequestID(collateralRequestDetails.getRequestID());
                getF_OUT_createCollateralRqDetails().setDescription(collateralRequestDetails.getDescription());
                break;
            }
        }
    }

    private Boolean isNewCollateralRq() {
        Boolean isNew = true;
        if(getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsListCount()>0)
        {
            for(CreateCollateralRqDetails createCollateralRqDetails: getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsList())
            {
                if(createCollateralRqDetails.isSelect() && IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID()))
                {
                    isNew =  false;
                }
            }
        }
        return isNew;
    }

    private void onRequestChange() {
        LOGGER.info("Entering into onRequestChange method");
        Boolean isNew = isNewCollateralRq();
        if (isNew && IBCommonUtils.isNotEmpty(getF_IN_createCollateralDetails().getCollateralID()))
        {
            setExpiryDate();
            setRequestBasedValues();
        }
        else if(!isNew)
        {
            if (getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsListCount() > 0) {
                {
                    for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralrqDetailsList()
                            .getCreateCollateralRqDetailsList()) {
                        if(createCollateralRqDetails.isSelect() && IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID()))
                        { 
                            CreateCollateralRqDetails  vcreateCollateralRqDetails = CalendarUtil.isDateNullOrDefaultDate(getF_IN_createCollateralDetails().getExpiryDate()) ?createCollateralRqDetails:getF_IN_createCollateralDetails();
                            setF_OUT_createCollateralRqDetails(vcreateCollateralRqDetails);
                            break;
                        }
                    }
                }
            }
            
        }
        LOGGER.info("Exiting from onRequestChange method");
    }

    private void selectRow(BankFusionEnvironment env) {
        LOGGER.info("Entering into selectRow method");
        if (getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsListCount() > 0) {
            for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralrqDetailsList()
                    .getCreateCollateralRqDetailsList()) {
                if (createCollateralRqDetails.isSelect() && IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID())) {
                    setExistingValues(createCollateralRqDetails);
                    if (CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED.equals(createCollateralRqDetails.getSystemStatus())) {
                        setF_OUT_isCreateColScalalarsDisabled(true);
                        setF_OUT_isNewButtonDisabled(false);
                        setF_OUT_isRemoveButtonDisabled(true);
                        setF_OUT_isSaveButtonDisabled(true);
                    }
                    break;
                }
                else if(createCollateralRqDetails.isSelect() && IBCommonUtils.isEmpty(createCollateralRqDetails.getCollateralID()))
                {
                    setDefaultValues(env);
                }
            }
        }
        LOGGER.info("Exiting from selectRow method");
    }

    private void setDefaultValues(BankFusionEnvironment env) {
        LOGGER.info("Entering into setDefaultValues method");
        CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom();
        customAutoNumFatom.setF_IN_BONAME("CustomerCollateral");
        customAutoNumFatom.setF_IN_IsRightPad(false);
        customAutoNumFatom.setF_IN_Prefix("CUSTCOL");
        customAutoNumFatom.setF_IN_Suffix("");
        customAutoNumFatom.setF_IN_TotalLength(0);
        customAutoNumFatom.process(env);
        String collateralDtlId = customAutoNumFatom.getF_OUT_PrimKey();
        getF_OUT_createCollateralRqDetails().setCollateralID(collateralDtlId);
        getF_OUT_createCollateralRqDetails().setDocDate(IBCommonUtils.getBFBusinessDate());
        setExpiryDate();
        setRequestBasedValues();
        setF_OUT_isCreateColScalalarsDisabled(false);
        setF_OUT_isNewButtonDisabled(true);
        setF_OUT_isRemoveButtonDisabled(false);
        setF_OUT_isSaveButtonDisabled(false);
        LOGGER.info("Exiting from setDefaultValues method");
    }

    private void setExistingValues(CreateCollateralRqDetails createCollateralRqDetails) {
        LOGGER.info("Entering into setExistingValues method");
        setF_OUT_createCollateralRqDetails(createCollateralRqDetails);
        setF_OUT_isCreateColScalalarsDisabled(false);
        setF_OUT_isNewButtonDisabled(false);
        setF_OUT_isRemoveButtonDisabled(false);
        setF_OUT_isSaveButtonDisabled(false);
        LOGGER.info("Exiting from setExistingValues method");
    }

    private void removeRow() {
        LOGGER.info("Entering into removeRow method");
        setF_OUT_isCreateColScalalarsDisabled(true);
        setF_OUT_isNewButtonDisabled(false);
        setF_OUT_isRemoveButtonDisabled(true);
        setF_OUT_isSaveButtonDisabled(true);
        getF_OUT_collateralRequestDetailsList()
                .setCollateralRequestDetailsList(getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsList());
        getF_OUT_createCollateralRqDetails().setDocDate(null);
        if (getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsListCount() > 0) {
            for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralrqDetailsList()
                    .getCreateCollateralRqDetailsList()) {
                if (createCollateralRqDetails.isSelect()) {
                    if(getF_IN_ibObject().getTransactionName().equals("DEAL")){
                        updateCollateralRequestDetails(createCollateralRqDetails);
                    }else {
                        createCollateralRqDetails.setSystemStatus("DELETED");
                        getF_OUT_createCollateralRqDetailsList().addCreateCollateralRqDetailsList(createCollateralRqDetails);
                    }
                    
                }
                else {
                    getF_OUT_createCollateralRqDetailsList().addCreateCollateralRqDetailsList(createCollateralRqDetails);
                }
            }
        }
        LOGGER.info("Exiting from removeRow method");
    }

    private void updateCollateralRequestDetails(CreateCollateralRqDetails createCollateralRqDetails) {
        LOGGER.info("Entering into updateCollateralRequestDetails method");
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + "= ? and "
                + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTID + "=?");
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_ibObject().getDealID());
        params.add(createCollateralRqDetails.getRequestID());
        List<IBOCE_IB_CollateralRevaluationDetails> createRequestCollateralDetails = (ArrayList<IBOCE_IB_CollateralRevaluationDetails>) factory
                .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, queryCondition.toString(), params, null, true);
        if (null != createRequestCollateralDetails && !createRequestCollateralDetails.isEmpty()) {
            for (IBOCE_IB_CollateralRevaluationDetails reqCollateralDtls : createRequestCollateralDetails) {
                CollateralRequestDetails collateralRequestDetails = new CollateralRequestDetails();
                collateralRequestDetails.setRequestID(reqCollateralDtls.getBoID());
                BFCurrencyAmount availableAmt = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBAVAILABLEBALANCE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setAvailableBalance(availableAmt);
                collateralRequestDetails.setCategoryType(reqCollateralDtls.getF_IBCATEGORYTYPE());
                // collateralRequestDetails.setCollateralID(reqCollateralDtls.getF_COLLATERALID());
                BFCurrencyAmount coverValue = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBCOVERVALUE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setCoverValue(coverValue);
                collateralRequestDetails.setDescription(reqCollateralDtls.getF_IBDESCRIPTION());
                collateralRequestDetails.setRequestType(reqCollateralDtls.getF_IBREQUESTTYPE());
                collateralRequestDetails.setTitleDeedIDPK(reqCollateralDtls.getF_IBTITLEDEEDIDPK());
                collateralRequestDetails.setTitleDeedNum(reqCollateralDtls.getF_IBTITLEDEEDNUM());
				ListGenericCodeRs lsGenericCodesReq = IBCommonUtils.getGCList("REQ_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesReq.getGcCodeDetails()) {
					if (reqCollateralDtls.getF_IBREQUESTTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setRequestTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}
				ListGenericCodeRs lsGenericCodesCat = IBCommonUtils.getGCList("CATEGORY_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesCat.getGcCodeDetails()) {
					if (reqCollateralDtls.getF_IBCATEGORYTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setCategoryTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}

                getF_OUT_collateralRequestDetailsList().addCollateralRequestDetailsList(collateralRequestDetails);
            }
        }
        LOGGER.info("Exiting from updateCollateralRequestDetails method");
    }

    private void saveRow() {
        LOGGER.info("Entering into saveRow method");
        setF_OUT_isCreateColScalalarsDisabled(false);
        setF_OUT_isNewButtonDisabled(false);
        setF_OUT_isRemoveButtonDisabled(false);
        setF_OUT_isSaveButtonDisabled(false);
        validateSaveRowDetails();
        updateRequestDetailsOnSave();
        if (getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsListCount() > 0) {
            for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralrqDetailsList()
                    .getCreateCollateralRqDetailsList()) {
                if (createCollateralRqDetails.isSelect()) {
                    createCollateralRqDetails.setCollateralID(getF_IN_createCollateralDetails().getCollateralID() );
                    createCollateralRqDetails.setCollateralType(getF_IN_createCollateralDetails().getCollateralType());
                    createCollateralRqDetails.setExpiryDate(getF_IN_createCollateralDetails().getExpiryDate());
                    createCollateralRqDetails.setDocDate(getF_IN_createCollateralDetails().getDocDate());
                    createCollateralRqDetails.setIsDocUploaded(getF_IN_createCollateralDetails().isIsDocUploaded());
                    createCollateralRqDetails.setDocnum(getF_IN_createCollateralDetails().getDocnum());
                    createCollateralRqDetails.setDocSourceDesc(getF_IN_createCollateralDetails().getDocSourceDesc());
                    createCollateralRqDetails.setDocSourceId(getF_IN_createCollateralDetails().getDocSourceId());
                    createCollateralRqDetails.setCoverValue(getF_IN_createCollateralDetails().getCoverValue());
                    createCollateralRqDetails.setRequestType(getF_IN_createCollateralDetails().getRequestType());
                    createCollateralRqDetails.setRequestID(getF_IN_createCollateralDetails().getRequestID());
                    createCollateralRqDetails.setDescription(getF_IN_createCollateralDetails().getDescription());
                    for (GcCodeDetail gcCodedtl : getF_IN_allCollateralTypes().getGcCodeDetails()) {
                        if (getF_IN_createCollateralDetails().getCollateralType().equals(gcCodedtl.getCodeReference())) {
                            createCollateralRqDetails.setCollateralTypeDesc(gcCodedtl.getCodeDescription());
                            break;
                        }
                    }
                      
                }
                getF_OUT_createCollateralRqDetailsList().addCreateCollateralRqDetailsList(createCollateralRqDetails);
            }
        }
        LOGGER.info("Exiting from saveRow method");
    }

    private void validateSaveRowDetails() {
        if(getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsListCount() == 0 && isNewCollateralRq())
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_REQUEST_MANDATORY_CEIB);
        if(IBCommonUtils.isEmpty(getF_IN_createCollateralDetails().getCollateralType()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_TYPE_MANDATORY_CEIB);
        if(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(getF_IN_createCollateralDetails().getDocDate()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_DOC_DATE_MANDATORY_CEIB);
        if(IBCommonUtils.isEmpty(getF_IN_createCollateralDetails().getDocnum()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_DOC_NUMBER_MANDATORY_CEIB);
        if(IBCommonUtils.isEmpty(getF_IN_createCollateralDetails().getDocSourceId()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_DOC_SOURCE_MANDATORY_CEIB);
        if(CalendarUtil.isDateNullOrDefaultDate(getF_IN_createCollateralDetails().getExpiryDate()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_EXPIRY_DATE_MANDATORY_CEIB);
        if(!getF_IN_createCollateralDetails().getExpiryDate().after(IBCommonUtils.getBFBusinessDate()))
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_EXPIRY_DATE_RANGE_CEIB);
    }

    private void updateRequestDetailsOnSave() {
        LOGGER.info("Entering into updateRequestDetailsOnSave method");
        if(getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsListCount()>0)
        {
            boolean isNew = isNewCollateralRq();
            for(CollateralRequestDetails collateralRequestDetails : getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsList())
            {
                if(!collateralRequestDetails.isSelect() || (collateralRequestDetails.isSelect() && !isNew))
                    getF_OUT_collateralRequestDetailsList().addCollateralRequestDetailsList(collateralRequestDetails);
            }
            int x=0;
            for(CollateralRequestDetails collateralRequestDetails : getF_OUT_collateralRequestDetailsList().getCollateralRequestDetailsList())
            {
                if (x == 0)
                    collateralRequestDetails.setSelect(true);
                else collateralRequestDetails.setSelect(false);
                x++;
            }
        }
        LOGGER.info("Exiting from updateRequestDetailsOnSave method");
    }

    private void addRow() {
        LOGGER.info("Entering into addRow method");
        getF_OUT_createCollateralRqDetailsList()
        .setCreateCollateralRqDetailsList(getF_IN_createCollateralrqDetailsList().getCreateCollateralRqDetailsList());
        if (getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsListCount() == 0) {
            IBCommonUtils.raiseUnparameterizedEvent(CollateralUtil.E_COLLATERAL_REQUEST_PROMPT_CEIB);
        }
        setF_OUT_isCreateColScalalarsDisabled(false);
        setF_OUT_isNewButtonDisabled(true);
        setF_OUT_isRemoveButtonDisabled(false);
        setF_OUT_isSaveButtonDisabled(false);
        for (CreateCollateralRqDetails createCollateralRqDtls : getF_OUT_createCollateralRqDetailsList()
                .getCreateCollateralRqDetailsList()) {
            createCollateralRqDtls.setSelect(false);
        }
        CreateCollateralRqDetails newCreateCollateralRqDetails = new CreateCollateralRqDetails();
        newCreateCollateralRqDetails.setSelect(true);
        getF_OUT_createCollateralRqDetailsList().addCreateCollateralRqDetailsList(
                getF_OUT_createCollateralRqDetailsList().getCreateCollateralRqDetailsListCount(), newCreateCollateralRqDetails);
        LOGGER.info("Exiting from addRow method");
    }

    private void setExpiryDate() {
        LOGGER.info("Entering into setExpiryDate method");
        if (getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsListCount() > 0
                && (IBCommonUtils.isNotEmpty(getF_IN_createCollateralDetails().getCollateralID())
                        || SCALARACTION.SCALAR_AMEND.toString().equals(getF_IN_mode()))) {
            for (CollateralRequestDetails collateralRequestDetails : getF_IN_collateralRequestDetailsList()
                    .getCollateralRequestDetailsList()) {
                if (collateralRequestDetails.isSelect()) {
                    //getF_OUT_createCollateralRqDetails().setCoverValue(collateralRequestDetails.getCoverValue());
                    try {
                        setExpiryDateDefaultValue(collateralRequestDetails);
                    }
                    catch (ParseException e) {
                        LOGGER.error("Exception in setExpiryDate" + e.getLocalizedMessage());
                        e.printStackTrace();
                    }
                    break;
                }

            }

        }
        else {
            getF_OUT_createCollateralRqDetails().setExpiryDate(null);
        }
        LOGGER.info("Exiting from setExpiryDate method");
    }

    private void setExpiryDateDefaultValue(CollateralRequestDetails collateralRequestDetails) throws ParseException {
        LOGGER.info("Entering into setExpiryDateDefaultValue method");
        ModuleConfigDetails moduleConfigDetails = null;
        if (CollateralUtil.REQUSEST_TYPE_NONPERSONAL.equals(collateralRequestDetails.getRequestType())) {
            moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue(CollateralUtil.NONPERSONALEXPIRYDATE);
        }
        else if (CollateralUtil.REQUSEST_TYPE_PERSONAL.equals(collateralRequestDetails.getRequestType())) {
            moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue(CollateralUtil.PERSONALEXPIRYDATE);
        }
        else if (CollateralUtil.REQUSEST_TYPE_NOEVALUATION.equals(collateralRequestDetails.getRequestType())) {
            moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue(CollateralUtil.NOELALUATIONEXPIRYDATE);
        }
        if (null != moduleConfigDetails) {
            try {
                DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date expiryDate = (java.util.Date) format.parse(moduleConfigDetails.getValue());
                getF_OUT_createCollateralRqDetails().setExpiryDate(new Date(expiryDate.getTime()));
            }
            catch (ParseException e) {
                LOGGER.error("Exception in setExpiryDateDefaultValue" + e.getLocalizedMessage());
                e.printStackTrace();
            }
            catch (Exception e) {
                LOGGER.error("Exception in setExpiryDateDefaultValue" + e.getLocalizedMessage());
                e.printStackTrace();
            }
        }
        LOGGER.info("Exiting from setExpiryDateDefaultValue method");
    }
}
