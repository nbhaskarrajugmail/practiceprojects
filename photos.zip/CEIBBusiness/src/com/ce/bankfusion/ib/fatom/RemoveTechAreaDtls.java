package com.ce.bankfusion.ib.fatom;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RemoveTechAreaDtls;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;

public class RemoveTechAreaDtls extends AbstractCE_IB_RemoveTechAreaDtls {

	private static final long serialVersionUID = 1L;
	private static final transient Log LOG = LogFactory.getLog(RemoveTechAreaDtls.class.getName());

	public RemoveTechAreaDtls() {
		super();

	}

	public RemoveTechAreaDtls(BankFusionEnvironment env) {
		super(env);

	}

	@Override
	public void process(BankFusionEnvironment env) {

		String removeMode = getF_IN_removeArea();
		String removeModeCoordinate = getF_IN_removeCoordinate();
		if (!StringUtils.isEmpty(removeMode) && removeMode.equals("RMVAREA")) {
			TechnicalAreaDtlList hiddenTechAreaDtlList = getF_IN_hiddenTechnicalAreaDtlList();
			TechnicalAreaCoordinateDtlList hiddenTechAreaCoordinateDtlList = getF_IN_hiddenTechnicalAreaCoordinateDtlList();
			TechnicalAreaDtlList technicalAreaDtlList = getF_IN_technicalAreaDtlList();

			for (TechnicalAreaDtl areaDtl : technicalAreaDtlList.getTechnicalAreaDtlList()) {
				for (TechnicalAreaDtl hiddenAreaDtl : hiddenTechAreaDtlList.getTechnicalAreaDtlList()) {
					if (areaDtl.getSelect() && StringUtils.isEmpty(areaDtl.getReferenceNumber())
							&& areaDtl.getReferenceNumber().equals(hiddenAreaDtl.getReferenceNumber())) {
						hiddenTechAreaDtlList.removeTechnicalAreaDtlList(hiddenAreaDtl);
					} else if (areaDtl.getSelect() && areaDtl.getTitleDeedId().equals(hiddenAreaDtl.getTitleDeedId())
							&& areaDtl.getReferenceNumber().equals(hiddenAreaDtl.getReferenceNumber())) {
						hiddenTechAreaDtlList.removeTechnicalAreaDtlList(hiddenAreaDtl);
					}
				}

				for (TechnicalAreaCoordinateDtl areaCoordinateDtl : hiddenTechAreaCoordinateDtlList
						.getTechnicalAreaCoordinateDtlList()) {
					if (areaDtl.getSelect()
							&& areaDtl.getReferenceNumber().equals(areaCoordinateDtl.getReferenceNumber())
							&& (areaDtl.getTitleDeedId().equals(areaCoordinateDtl.getTitleDeedId())))

					{
						hiddenTechAreaCoordinateDtlList.removeTechnicalAreaCoordinateDtlList(areaCoordinateDtl);
					} 

				}
			}
			setF_OUT_hiddenTechnicalAreaCoordinateDtlList(hiddenTechAreaCoordinateDtlList);
			setF_OUT_hiddenTechAreaDtlList(hiddenTechAreaDtlList);
			getF_OUT_technicalAreaCoordinateDtls().removeAllTechnicalAreaCoordinateDtlList();;
		} else if (!StringUtils.isEmpty(removeModeCoordinate) && removeModeCoordinate.equals("RMVCOORDINATE")) {

			TechnicalAreaCoordinateDtlList areaCoordinateDtlList = getF_IN_technicalCoordinateDtls();
			TechnicalAreaCoordinateDtl eachCoordinate = getF_IN_eachTechnicalAreaCoordinateDtl();
			for (int i = 0; i < areaCoordinateDtlList.getTechnicalAreaCoordinateDtlListCount(); i++) {
				if (eachCoordinate.getSerail()
						.equals(areaCoordinateDtlList.getTechnicalAreaCoordinateDtlList(i).getSerail())) {
					areaCoordinateDtlList.removeTechnicalAreaCoordinateDtlListAt(i);
				}
			}
			for (int i = 0; i < areaCoordinateDtlList.getTechnicalAreaCoordinateDtlListCount(); i++) {
				areaCoordinateDtlList.getTechnicalAreaCoordinateDtlList(i).setSerail(i + 1);
			}

			TechnicalAreaCoordinateDtlList hiddenTechCoordinateDtls = getF_IN_hiddenTechnicalAreaCoordinateDtlList();
			for (TechnicalAreaCoordinateDtl eachHidden : hiddenTechCoordinateDtls.getTechnicalAreaCoordinateDtlList()) {
				if (!StringUtils.isEmpty(eachCoordinate.getTitleDeedId())
						&& (eachCoordinate.getTitleDeedId().equals(eachHidden.getTitleDeedId()))
						&& eachCoordinate.getSerail().equals(eachHidden.getSerail())) {
					hiddenTechCoordinateDtls.removeTechnicalAreaCoordinateDtlList(eachHidden);
				}

			}
			setF_OUT_hiddenTechnicalAreaCoordinateDtlList(hiddenTechCoordinateDtls);
			setF_OUT_technicalAreaCoordinateDtls(areaCoordinateDtlList);

		}
	}
}
