package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealPaymentSchedule;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_DLI_FetchDealInstallments;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ib.schedule.payments.PaymentSchedule;
import bf.com.misys.ib.schedule.payments.service.GenerateIslamicPaymentScheduleRs;
import bf.com.misys.ib.spi.types.LoanBasicDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.DealInquiryIDs;
import bf.com.misys.ib.types.DealInstallmentDetails;
import bf.com.misys.ib.types.DealInstallmentHistoryDetails;
import bf.com.misys.ib.types.DealInstallmentsCollection;
import bf.com.misys.ib.types.ProductConfiguration;

public class CEFetchDealInstallments extends AbstractIB_DLI_FetchDealInstallments {

	private static final String ALL = "ALL";

	private static final String UNPAID_STATUS = "Unpaid";

	private static String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? ";

	public CEFetchDealInstallments(BankFusionEnvironment env) {
		super(env);
	}

	public CEFetchDealInstallments() {
		super();
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		DealInstallmentHistoryDetails dealInstallmentHistoryDetails = new DealInstallmentHistoryDetails();
		DealInstallmentsCollection dealInstallmentsCollection = new DealInstallmentsCollection();
		// Currency currency;
		String installmentsFilterByStatus = getF_IN_installmentFetchFlag();
		DealInquiryIDs dealInquiryIDs = getF_IN_dealInquiryIDs();
		if (installmentsFilterByStatus != null && installmentsFilterByStatus.equalsIgnoreCase("EXTERNAL")) {
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealInquiryIDs.getDealId());
			String accountId = dealDetails.getF_DealAccountId();
			if (accountId != null && !CommonConstants.EMPTY_STRING.equals(accountId)) {
				fetchInstallmentsFromHost(dealInquiryIDs.getDealId(), dealInstallmentHistoryDetails,
						dealInstallmentsCollection);
			} else {
				fetchInstallmentsFromDB(dealDetails, dealInstallmentHistoryDetails, dealInstallmentsCollection);

			}
			setF_OUT_dealInstallmentHistoryDetails(dealInstallmentHistoryDetails);

		} else {
			DealInstallmentsCollection dealInstallments = getF_IN_dealInstallments();
			for (DealInstallmentDetails installment : dealInstallments.getDealInstallment()) {
				if (installment.getInstallmentStatus() != null
						&& installment.getInstallmentStatus().equalsIgnoreCase(installmentsFilterByStatus)) {
					dealInstallmentsCollection.addDealInstallment(installment);
				} else if (ALL.equalsIgnoreCase(installmentsFilterByStatus)) {
					dealInstallmentsCollection.addDealInstallment(installment);
				}
			}
		}
		setF_OUT_dealInstallments(dealInstallmentsCollection);

	}

	private void fetchInstallmentsFromHost(String dealID, DealInstallmentHistoryDetails dealInstallmentHistoryDetails,
			DealInstallmentsCollection dealInstallmentsCollection) {
		DealInstallmentDetails installmentDetails = null;
		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealID);
		LoanBasicDetails loanBasicDetails = readLoanDetailsRs.getDealDetails().getLoanBasicDetails();
		LoanPayments loanPayments[] = readLoanDetailsRs.getDealDetails().getPaymentSchedule();
		int index = 1;
		ProductConfiguration prodConfig = IBCommonUtils.loadProductConfiguration(dealID);
		int paidInstallments = 0;
		ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("IBINSTALLMENTSTATUS");

		String loanCurrency = loanBasicDetails.getLoanCurrency();
		BFCurrencyAmount paidPrinciple = new BFCurrencyAmount();
		paidPrinciple.setCurrencyAmount(BigDecimal.ZERO);
		paidPrinciple.setCurrencyCode(loanCurrency);

		BFCurrencyAmount paidFees = new BFCurrencyAmount();
		paidFees.setCurrencyAmount(BigDecimal.ZERO);
		paidFees.setCurrencyCode(loanCurrency);

		BFCurrencyAmount paidProfit = new BFCurrencyAmount();
		paidProfit.setCurrencyAmount(BigDecimal.ZERO);
		paidProfit.setCurrencyCode(loanCurrency);

		// Payment Schedule
		for (LoanPayments loanPayment : loanPayments) {
			installmentDetails = new DealInstallmentDetails();
			if (loanPayment.getRepaymentNo() == null || loanPayment.getRepaymentNo() == 0) {
				installmentDetails.setInstallmentNo(index);
			} else {
				installmentDetails.setInstallmentNo(loanPayment.getRepaymentNo());
			}
			String currencyCode = loanPayment.getIsoCurrencyCode();
			if (currencyCode == null) {
				currencyCode = loanBasicDetails.getLoanCurrency();
			}
			if (RescheduleConstants.FULLY_PAID.equalsIgnoreCase(loanPayment.getRepaymentStatus())
					|| RescheduleConstants.PARTIALLY_PAID.equalsIgnoreCase(loanPayment.getRepaymentStatus())) {
				++paidInstallments;
			}

			installmentDetails.setDueDate(loanPayment.getRepaymentDate());
			installmentDetails.setTotalInstallmentAmount(getCurrency(currencyCode, loanPayment.getRepaymentAmt()));
			installmentDetails.setPrincipleAmount(getCurrency(currencyCode, loanPayment.getPrincipleAmt()));
			// installmentDetails.setProfitAmount(getCurrency(currencyCode,
			// loanPayment.getProfitAmt()));
			// installmentDetails.setFeeAmount(getCurrency(currencyCode,
			// loanPayment.getFeeAmt()));
			installmentDetails.setPaidAmount(getCurrency(currencyCode, loanPayment.getRepaymentAmtPaid()));
			installmentDetails
					.setOutstandingAmount(getCurrency(currencyCode, loanPayment.getOutstandingPrincipalAmt()));
			installmentDetails.setInstallmentStatus(loanPayment.getRepaymentStatus());

			String statusDesc = IBConstants.EMPTY_STRING;
			for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
				if (gcCode.getCodeReference().equals(loanPayment.getRepaymentStatus())) {
					statusDesc = gcCode.getCodeDescription();
					break;
				}
			}
			installmentDetails.setInstallmentStatusDesc(statusDesc);

			// this will loop through breakup table and fetch profit and fee amounts
			getInstallmentProfitAndFeeAmount(installmentDetails, currencyCode);

			dealInstallmentHistoryDetails.addInstallmentDetails(installmentDetails);
			dealInstallmentsCollection.addDealInstallment(installmentDetails);
			index++;
			paidPrinciple.setCurrencyAmount(paidPrinciple.getCurrencyAmount().add(loanPayment.getPrincipalAmtPaid()));
			paidFees.setCurrencyAmount(paidFees.getCurrencyAmount().add(loanPayment.getFeeAmtPaid()));
			paidProfit.setCurrencyAmount(paidProfit.getCurrencyAmount().add(loanPayment.getProfitAmtPaid()));
		}
		// Deal Basic details
		dealInstallmentHistoryDetails.setPaymentCurrency(loanCurrency);
		dealInstallmentHistoryDetails
				.setOriginalDealAmount(getCurrency(loanCurrency, loanBasicDetails.getOriginalDealAmount()));

		BFCurrencyAmount paidAmount = new BFCurrencyAmount();// loan amount minus oustanding loan amount
		paidAmount.setCurrencyAmount(paidPrinciple.getCurrencyAmount()
				.add(paidProfit.getCurrencyAmount().add(paidFees.getCurrencyAmount())));
		if (paidAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) < 0) {
			paidAmount.setCurrencyAmount(BigDecimal.ZERO);
		}
		paidAmount.setCurrencyCode(loanCurrency);

		dealInstallmentHistoryDetails.setTotalPaidAmount(paidAmount);
		dealInstallmentHistoryDetails
				.setOutstandingDealAmt(getCurrency(loanCurrency, loanBasicDetails.getOutstandingDealAmt()));
		dealInstallmentHistoryDetails.setTotalNoOfPayments(loanBasicDetails.getTotalNoOfPayments());
		dealInstallmentHistoryDetails.setTotalNoOfPaidPayments(paidInstallments);
		dealInstallmentHistoryDetails.setRemainingNoOfPayments(loanBasicDetails.getRemainingNoOfPayments());

		dealInstallmentHistoryDetails
				.setArrearDealAmount(getCurrency(loanCurrency, loanBasicDetails.getArrearDealAmount()));
		if (readLoanDetailsRs.getDealDetails().getPaymentSchedule() != null) {
			for (LoanPayments loanPayment : loanPayments) {
				if ("UNPAID".equalsIgnoreCase(loanPayment.getRepaymentStatus())) {
					dealInstallmentHistoryDetails.setNextPaymentDate(loanPayment.getRepaymentDate());
					dealInstallmentHistoryDetails
							.setNextRepaymentAmount(getCurrency(loanCurrency, loanPayment.getRepaymentAmt()));
					break;
				}
			}
		}
		dealInstallmentHistoryDetails.setNoOfPastDueDays(loanBasicDetails.getNoOfPastDueDays());
		dealInstallmentHistoryDetails.setEffectiveRate(RescheduleUtils.getCurrentRate(dealID,
				prodConfig.getIsHostScheduleGenerator(), loanBasicDetails.getEffectiveRate()));
	}

	private void fetchInstallmentsFromDB(IBOIB_DLI_DealDetails dealDetails,
			DealInstallmentHistoryDetails dealInstallmentHistoryDetails,
			DealInstallmentsCollection dealInstallmentsCollection) {
		DealInstallmentDetails installmentDetails = null;
		IPersistenceObjectsFactory persistenceObject = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList queryParams = new ArrayList();
		queryParams.add(dealDetails.getBoID());
		List paymentSchedules = persistenceObject.findByQuery(IBOIB_DLI_DealPaymentSchedule.BONAME, getQuery(),
				queryParams, null, true);
		int index = 0;
		if (paymentSchedules != null && !paymentSchedules.isEmpty()) {
			HashMap responseMap = ScheduleUtils.generateScheduleInfo(dealDetails.getBoID(),
					IBCommonUtils.getBankFusionEnvironment());
			GenerateIslamicPaymentScheduleRs generateIslamicPaymentScheduleRs = (GenerateIslamicPaymentScheduleRs) responseMap
					.get("generateIslamicPaymentScheduleRs");
			// Payment Schedule
			for (PaymentSchedule schedule : generateIslamicPaymentScheduleRs.getPaymentSchedule()) {
				installmentDetails = new DealInstallmentDetails();
				if (schedule.getRepaymentNo() == 0) {
					installmentDetails.setInstallmentNo(index);
				} else {
					installmentDetails.setInstallmentNo(schedule.getRepaymentNo());
				}
				String currencyCode = dealDetails.getF_IsoCurrencyCode();

				if (schedule.getRepaymentNo() == 1) {
					dealInstallmentHistoryDetails.setNextRepaymentAmount(
							getCurrency(currencyCode, schedule.getRepaymentAmt().getCurrencyAmount()));
				}
				installmentDetails.setDueDate(schedule.getRepaymentDate());
				installmentDetails.setTotalInstallmentAmount(
						getCurrency(currencyCode, schedule.getRepaymentAmt().getCurrencyAmount()));
				installmentDetails
						.setPrincipleAmount(getCurrency(currencyCode, schedule.getPrincipleAmt().getCurrencyAmount()));
				installmentDetails
						.setProfitAmount(getCurrency(currencyCode, schedule.getProfitAmt().getCurrencyAmount()));
				installmentDetails.setFeeAmount(getCurrency(currencyCode, schedule.getFeeAmt().getCurrencyAmount()));
				installmentDetails.setPaidAmount(getCurrency(currencyCode, BigDecimal.ZERO));
				installmentDetails.setOutstandingAmount(
						getCurrency(currencyCode, schedule.getOutstandingPrincipalAmt().getCurrencyAmount()));
				installmentDetails.setInstallmentStatus(UNPAID_STATUS.toUpperCase());
				installmentDetails.setInstallmentStatusDesc(UNPAID_STATUS);
				dealInstallmentHistoryDetails.addInstallmentDetails(installmentDetails);
				dealInstallmentsCollection.addDealInstallment(installmentDetails);
				index++;
			}
		}
		// Deal Basic details
		String loanCurrency = dealDetails.getF_IsoCurrencyCode();

		dealInstallmentHistoryDetails.setPaymentCurrency(loanCurrency);
		dealInstallmentHistoryDetails.setOriginalDealAmount(getCurrency(loanCurrency, dealDetails.getF_DealAmt()));
		dealInstallmentHistoryDetails.setTotalPaidAmount(getCurrency(loanCurrency, BigDecimal.ZERO));
		dealInstallmentHistoryDetails.setOutstandingDealAmt(getCurrency(loanCurrency, dealDetails.getF_DealAmt()));
		dealInstallmentHistoryDetails.setTotalNoOfPaidPayments(0);
		if (paymentSchedules != null) {
			dealInstallmentHistoryDetails.setTotalNoOfPayments(paymentSchedules.size());
			dealInstallmentHistoryDetails.setRemainingNoOfPayments(paymentSchedules.size());
		}

		dealInstallmentHistoryDetails.setArrearDealAmount(getCurrency(loanCurrency, BigDecimal.ZERO));
		dealInstallmentHistoryDetails.setNextPaymentDate(dealDetails.getF_FirstRepaymentDate());

		dealInstallmentHistoryDetails.setNoOfPastDueDays(0);
		dealInstallmentHistoryDetails.setEffectiveRate(dealDetails.getF_ProfitRate());

	}

	private BFCurrencyAmount getCurrency(String currencyCode, BigDecimal amount) {
		BFCurrencyAmount currency = new BFCurrencyAmount();
		currency.setCurrencyCode(currencyCode);
		currency.setCurrencyAmount(amount.setScale(2));
		return currency;
	}

	private String getQuery() {
		StringBuilder hql = new StringBuilder("WHERE ").append(IBOIB_DLI_DealPaymentSchedule.DEALNO).append("=?");
		return hql.toString();
	}

	private void getInstallmentProfitAndFeeAmount(DealInstallmentDetails installmentDetails, String currencyCode) {
		BigDecimal profitAmount = BigDecimal.ZERO;
		BigDecimal feeAmount = BigDecimal.ZERO;
		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_dealInquiryIDs().getDealId());
		params.add(installmentDetails.getDueDate());

		// ReadLoan gives fees amount also as profit amount, hence looping through
		// breakup table and fetching amounts
		List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);

		if (!breakupDtls.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : breakupDtls) {
				profitAmount = profitAmount.add(paymentSchBreakup.getF_IBPROFITAMT());
				feeAmount = feeAmount.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
			}
		}

		installmentDetails.setProfitAmount(getCurrency(currencyCode, profitAmount));
		installmentDetails.setFeeAmount(getCurrency(currencyCode, feeAmount));
	}

}
