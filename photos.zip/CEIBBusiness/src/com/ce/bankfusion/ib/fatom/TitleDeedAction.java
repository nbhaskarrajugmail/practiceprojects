package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedAction;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class TitleDeedAction extends AbstractCE_IB_TitleDeedAction{
    
    @SuppressWarnings("deprecation")
    public TitleDeedAction(BankFusionEnvironment env) {
        super(env);
    }
    

    public void process(BankFusionEnvironment env) {
       
        if(!getF_IN_bbMode().equalsIgnoreCase("VIEW")) {
      //  if(!getF_IN_bbModeRq().equalsIgnoreCase("VIEW")) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        //Checking if data exists in DB
        String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ? ";
        ArrayList<String> params = new ArrayList<>();
        params.add(getF_IN_islamicBankingObject().getDealID());
        List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetails = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params,null,false);
        
        for(IBOCE_IB_DealTitleDeedDtls e : titleDeedDetails) {
            e.setF_IBSTATUS("APPROVED");
        }
    //}
    }
    }
}
