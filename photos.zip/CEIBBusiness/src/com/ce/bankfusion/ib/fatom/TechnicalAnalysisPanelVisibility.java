package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TechnicalAnalysisPanelVisibility;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.technical.dtls.ib.types.FishLicenseSource;
import bf.com.misys.technical.dtls.ib.types.FishLicenseType;
import bf.com.misys.technical.dtls.ib.types.FishPort;
import bf.com.misys.technical.dtls.ib.types.LetterGuardSource;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDropDowns;
import bf.com.misys.technical.dtls.ib.types.TitleDeedSource;
import bf.com.misys.technical.dtls.ib.types.WealthLetterSource;
import bf.com.misys.technical.dtls.ib.types.WellCondition;
import bf.com.misys.technical.dtls.ib.types.WellStatus;
import bf.com.misys.technical.dtls.ib.types.WellType;

public class TechnicalAnalysisPanelVisibility extends AbstractCE_IB_TechnicalAnalysisPanelVisibility {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7448862190871356905L;
	/**
	 * 
	 */
	private static final String TECHPRODUCTPROPERTY = "conf/business/techAnaysisProductMap.properties";
	private static final String TITLEDEED = "titleDeedVisibility";
	private static final String FISHERMAN = "fishermanVisibility";
	private static final String CROPS = "cropsVisibility";
	private static final String EXISTINGASSETS = "existingAssetsVisibility";
	private static final String WELL = "wellVisibility";
	private static final String AREA_ASSIGNED_FOR_SPECIAL_PROJECTS = "areaAssignedForSpclPrjVisibility";
	private static final String NO = "NO";

	public TechnicalAnalysisPanelVisibility(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		System.err.println();
		IslamicBankingObject bankingObject = getF_IN_islamicBankingObject();
		String subProductID = bankingObject.getSubProductID();
		String titleDeedVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + TITLEDEED, "", CeConstants.ADFIBCONFIGLOCATION);
		String cropsVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + CROPS, "", CeConstants.ADFIBCONFIGLOCATION);
		String existingAssetsVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + EXISTINGASSETS, "", CeConstants.ADFIBCONFIGLOCATION);
		String wellVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + WELL, "", CeConstants.ADFIBCONFIGLOCATION);
		String fishermanVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + FISHERMAN, "", CeConstants.ADFIBCONFIGLOCATION);
		String areaAssignedForSpclPrjVisibility = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + AREA_ASSIGNED_FOR_SPECIAL_PROJECTS, "", CeConstants.ADFIBCONFIGLOCATION);
		setF_OUT_titileDeedVisibility(true);
		setF_OUT_cropsVisibility(true);
		setF_OUT_existingAssetsVisibility(true);
		setF_OUT_wellVisibility(true);
		setF_OUT_fishermanVisibility(true);
		setF_OUT_areaAssignedForSpclPrj(true);

		if (titleDeedVisibility != null && titleDeedVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_titileDeedVisibility(false);
		}
		if (cropsVisibility != null && cropsVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_cropsVisibility(false);
		}
		if (existingAssetsVisibility != null && existingAssetsVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_existingAssetsVisibility(false);
		}
		if (wellVisibility != null && wellVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_wellVisibility(false);
		}
		if (fishermanVisibility != null && fishermanVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_fishermanVisibility(false);
		}
		if (areaAssignedForSpclPrjVisibility != null && areaAssignedForSpclPrjVisibility.equalsIgnoreCase(NO)) {
			setF_OUT_areaAssignedForSpclPrj(false);
		}
		TechnicalAnalysisDropDowns dropDownValues = getF_OUT_technicalAnalysisDropDowns();
		String whereClause = "WHERE "+IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER +"=?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> dealTitleDeeds=BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params, null);
		dropDownValues.removeAllTitleDeedSource();
		for (IBOCE_IB_DealTitleDeedDtls dealTitleDeedDtls : dealTitleDeeds) {
			TitleDeedSource vTitleDeedSource = new TitleDeedSource();
			CE_TITLEDEEDDETAILSID titleDeedID  =new CE_TITLEDEEDDETAILSID();
			titleDeedID.setF_TITLEDEEDID(dealTitleDeedDtls.getF_IBTITLEDEEDID());
			titleDeedID.setF_TITLEDEEDVERSION(Integer.parseInt(dealTitleDeedDtls.getF_IBTITLEDEEDVERSIONNUM()));
			IBOCE_TITLEDEEDDETAILS titledeeddetails= (IBOCE_TITLEDEEDDETAILS) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,titleDeedID , true);
			vTitleDeedSource.setCodeDescription(titledeeddetails.getF_TITLEDEEDNUMBER());
			vTitleDeedSource.setCodeReference(dealTitleDeedDtls.getF_IBTITLEDEEDID());
			dropDownValues.addTitleDeedSource(vTitleDeedSource);
		}
		
		ListGenericCodeRs wellTypeList = IBCommonUtils.getGCList("CEWELLTYPE");
		GcCodeDetail[] welTypeGcCodes = wellTypeList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : welTypeGcCodes) {
			WellType vTitleDeedSource = new WellType();
			vTitleDeedSource.setCodeDescription(gcCodeDetail.getCodeDescription());
			vTitleDeedSource.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addWellType(vTitleDeedSource);
		}
		ListGenericCodeRs wellStatusList = IBCommonUtils.getGCList("CEWELLSTATUS");
		GcCodeDetail[] wellStatusGcCodes = wellStatusList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : wellStatusGcCodes) {
			WellStatus vTitleDeedSource = new WellStatus();
			vTitleDeedSource.setCodeDescription(gcCodeDetail.getCodeDescription());
			vTitleDeedSource.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addWellStatus(vTitleDeedSource);
		}
		
		ListGenericCodeRs wellConditionList = IBCommonUtils.getGCList("CEWELLCONDITION");
		GcCodeDetail[] wellConditionGcCodes = wellConditionList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : wellConditionGcCodes) {
			WellCondition wellCondition = new WellCondition();
			wellCondition.setCodeDescription(gcCodeDetail.getCodeDescription());
			wellCondition.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addWellCondition(wellCondition);
		}
		
		
		ListGenericCodeRs fishLicenseTypeList = IBCommonUtils.getGCList("CEFISHLICENSETYPE");
		GcCodeDetail[] fishLicenseTypeCodes = fishLicenseTypeList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : fishLicenseTypeCodes) {
			FishLicenseType vFishLicenseType = new FishLicenseType();
			vFishLicenseType.setCodeDescription(gcCodeDetail.getCodeDescription());
			vFishLicenseType.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addFishLicenseType(vFishLicenseType);
		}
		
		ListGenericCodeRs fishLicenseSourceList = IBCommonUtils.getGCList("CEFISHLICENSESOURCE");
		GcCodeDetail[] fishLicenseSourceCodes = fishLicenseSourceList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : fishLicenseSourceCodes) {
			FishLicenseSource vFishLicenseSource = new FishLicenseSource();
			vFishLicenseSource.setCodeDescription(gcCodeDetail.getCodeDescription());
			vFishLicenseSource.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addFishLicenseSource(vFishLicenseSource);
		}
		
		ListGenericCodeRs fishPortList = IBCommonUtils.getGCList("CEFISHPORT");
		GcCodeDetail[] fishPortCodes = fishPortList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : fishPortCodes) {
			FishPort vFishPort = new FishPort();
			vFishPort.setCodeDescription(gcCodeDetail.getCodeDescription());
			vFishPort.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addFishPort(vFishPort);
		}
		
		ListGenericCodeRs letterGuardSourceList = IBCommonUtils.getGCList("CELETTERGUARDSOURCE");
		GcCodeDetail[] letterGuardSourceCodes = letterGuardSourceList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : letterGuardSourceCodes) {
			LetterGuardSource letterGuardSource = new LetterGuardSource();
			letterGuardSource.setCodeDescription(gcCodeDetail.getCodeDescription());
			letterGuardSource.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addLetterGuardSource(letterGuardSource);
		}
		
		ListGenericCodeRs wealthLetterSourceList = IBCommonUtils.getGCList("CEWEALTHLETTERSOURCE");
		GcCodeDetail[] wealthLetterSourceCodes = wealthLetterSourceList.getGcCodeDetails();
		for (GcCodeDetail gcCodeDetail : wealthLetterSourceCodes) {
			WealthLetterSource wealthLetterSource = new WealthLetterSource();
			wealthLetterSource.setCodeDescription(gcCodeDetail.getCodeDescription());
			wealthLetterSource.setCodeReference(gcCodeDetail.getCodeReference());
			dropDownValues.addWealthLetterSource(wealthLetterSource);
		}

	}
}