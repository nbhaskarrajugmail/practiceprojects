/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BuyerDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerDocumentDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_MaintainBuyerSellerDetails;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.BuyerDetails;
import bf.com.misys.ib.types.BuyerSellerAgreement;
import bf.com.misys.ib.types.SellerDetails;
import bf.com.misys.ib.types.SellerDocumentDetails;
import bf.com.misys.ib.types.SellerTitleDeedDetails;

/**
 * @author Aklesh
 *
 */
public class MaintainBuyerSellerDetails extends AbstractCE_ADF_MaintainBuyerSellerDetails {

	private static final long serialVersionUID = 7137308733675905581L;

	public MaintainBuyerSellerDetails(BankFusionEnvironment env) {
		super(env);

	}

	public MaintainBuyerSellerDetails() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		BuyerSellerAgreement buyerSellerAgreement = getF_IN_buyerSellerAgreement();
		SellerDetails sellerDetails = buyerSellerAgreement.getSellerDetails();
		BuyerDetails[] buyerDetails = buyerSellerAgreement.getBuyerDetailsList();
		SellerDocumentDetails[] documentDetails = buyerSellerAgreement.getSellerDocumentDetailsList();
		SellerTitleDeedDetails[] titleDeedDetails = buyerSellerAgreement.getSellerTitleDeedDetailsList();
		validateBuyerSeller(buyerSellerAgreement);
		String documentID = GUIDGen.getNewGUID();
		for (SellerDocumentDetails documentDetail : documentDetails) {
			if (documentDetail.isIsExisting()==null ||!documentDetail.isIsExisting()) {
				IBOCE_ADF_SellerDocumentDtls sellerDocumentDtls = (IBOCE_ADF_SellerDocumentDtls) factory
						.getStatelessNewInstance(IBOCE_ADF_SellerDocumentDtls.BONAME);
				sellerDocumentDtls.setF_APPROVALLETTERNUMBER(documentDetail.getApprovalLetterNumber());
				sellerDocumentDtls.setF_DOCUMENTDATE(documentDetail.getDocumentDate());
				sellerDocumentDtls.setF_DOCUMENTDATEHIJRI(documentDetail.getDocumentDateHijri());
				sellerDocumentDtls.setF_DOCUMENTNUMBER(documentDetail.getDocumentNumber());
				sellerDocumentDtls.setF_DUEAMOUNT(sellerDetails.getPastDueAmount().getCurrencyAmount());
				sellerDocumentDtls.setF_DOCUMENTRECIEVER(documentDetail.getDocumentReciever());
				sellerDocumentDtls.setF_EMPLOYEENAME(documentDetail.getEmployeeName());
				sellerDocumentDtls.setF_EMPLOYEENATIONALID(documentDetail.getEmployeeNationalID());
				sellerDocumentDtls.setF_EMPLOYEENUMBER(documentDetail.getEmployeeNumber());
				sellerDocumentDtls.setF_ISSUINGAUTHORITY(documentDetail.getIssuingAuthority());
				sellerDocumentDtls.setF_ISSUINGDATE(documentDetail.getIssuingDate());
				sellerDocumentDtls.setF_ISSUINGSOURCE(documentDetail.getIssuingSource());
				sellerDocumentDtls.setF_LETTERTYPE(documentDetail.getLetterType());
				sellerDocumentDtls.setF_MORTGAGETYPE(documentDetail.getMortgageType());
				sellerDocumentDtls.setF_PARTYID(sellerDetails.getSellerPartyID());
				sellerDocumentDtls.setF_REMAININGAMOUNT(sellerDetails.getRemainingAmount().getCurrencyAmount());
				sellerDocumentDtls.setF_SEQUENCENUMBER(documentDetail.getSequenceNumber());
				sellerDocumentDtls.setF_SHAREHOLDER(documentDetail.getShareholder());
				sellerDocumentDtls.setF_SHOWEMPLOYEEINREP(documentDetail.getShowEmployeeInRep());
				sellerDocumentDtls.setBoID(documentID);
				factory.create(IBOCE_ADF_SellerDocumentDtls.BONAME, sellerDocumentDtls);
			}
		}
		for (BuyerDetails buyerDetail : buyerDetails) {
			if (buyerDetail.isIsExisting()==null || !buyerDetail.isIsExisting()) {
				IBOCE_ADF_BuyerDetails adf_BuyerDetails = (IBOCE_ADF_BuyerDetails) factory
						.getStatelessNewInstance(IBOCE_ADF_BuyerDetails.BONAME);
				adf_BuyerDetails.setF_BUYERPARTYID(buyerDetail.getSellerPartyID());
				adf_BuyerDetails.setF_BUYERPARTYNAME(buyerDetail.getSellerPartyName());
				adf_BuyerDetails.setF_DUEAMOUNT(buyerDetail.getPastDueAmount().getCurrencyAmount());
				adf_BuyerDetails.setF_NATIONALID(buyerDetail.getSellerNationalID());
				adf_BuyerDetails.setF_PARTYID(sellerDetails.getSellerPartyID());
				adf_BuyerDetails.setF_PARTYTYPE(buyerDetail.getSellerPartyType());
				adf_BuyerDetails.setF_REMAININGAMOUNT(buyerDetail.getRemainingAmount().getCurrencyAmount());
				adf_BuyerDetails.setF_SELLERDOCDTLSID(documentID);
				factory.create(IBOCE_ADF_BuyerDetails.BONAME, adf_BuyerDetails);
			}
		}
		for (SellerTitleDeedDetails titleDeedDetail : titleDeedDetails) {
			if (titleDeedDetail.isIsExisting()==null || !titleDeedDetail.isIsExisting()) {
				IBOCE_ADF_SellerTitleDeedDtls adf_SellerTitleDeedDtls = (IBOCE_ADF_SellerTitleDeedDtls) factory
						.getStatelessNewInstance(IBOCE_ADF_SellerTitleDeedDtls.BONAME);
				adf_SellerTitleDeedDtls.setF_BRANCH(titleDeedDetail.getBranch());
				adf_SellerTitleDeedDtls.setF_FARMLOCATION(titleDeedDetail.getFarmLocation());
				adf_SellerTitleDeedDtls.setF_ISUSEDINCOLLATERAL(titleDeedDetail.getIsUsedinCollateral());
				adf_SellerTitleDeedDtls.setF_ISUSEDINTECHANALYSIS(titleDeedDetail.getIsUsedinTechAnalysis());
				adf_SellerTitleDeedDtls.setF_LANDPLANNUMBER(titleDeedDetail.getLandPlanNumber());
				adf_SellerTitleDeedDtls.setF_LANDPLOTNUMBER(titleDeedDetail.getLandPlotNumber());
				adf_SellerTitleDeedDtls.setF_PARTYID(sellerDetails.getSellerPartyID());
				adf_SellerTitleDeedDtls.setF_PASTDUEAMOUNT(titleDeedDetail.getPastDueAmount().getCurrencyAmount());
				adf_SellerTitleDeedDtls.setF_REMAININGAMOUNT(titleDeedDetail.getRemainingAmount().getCurrencyAmount());
				adf_SellerTitleDeedDtls.setF_TITLEDEEDNUMBER(titleDeedDetail.getTitleDeedNumber());
				adf_SellerTitleDeedDtls.setF_TITLEDEEDSOURCE(titleDeedDetail.getTitleDeedSource());
				adf_SellerTitleDeedDtls.setF_TITLEDEEDTYPE(titleDeedDetail.getTitleDeedType());
				adf_SellerTitleDeedDtls.setF_TITLEDEEDYEAR(Integer.parseInt(titleDeedDetail.getTitleDeedYear()));
				adf_SellerTitleDeedDtls.setF_SELLERDOCDTLSID(documentID);
				factory.create(IBOCE_ADF_SellerTitleDeedDtls.BONAME, adf_SellerTitleDeedDtls);
			}
		}
		IBCommonUtils.raiseUnparameterizedEvent(44000460);
	}

	private void validateBuyerSeller(BuyerSellerAgreement buyerSellerAgreement) {
		/*-- "Letter Type" ==== LTRTYP 
		-- "Seller Party ID" ===== CUSTOMER_CODE 
		-- "is Used in Tech Analysis"    if yes return 1 else 0 =====  LOAN_IND 
		-- "Issuing Authority" ===== APP_IS_BY 
		-- "Remaining Amount"  ===== TOT_FARM_BAL
		-- "Past Due Amount"  ===== TOT_FARM_DUE 
		-- "Remaining Amount"  ===== TOT_BAL 
		-- "Past Due Amount"   ===== TOT_MAT 
		-- "Past Due Amount" for all buyers ===== BUYER_TOT_MAT 
		-- "is Used in Collateral" if yes return 1 else 0  ===== RAHN_IND 
		-- "Mortgage Type" ===== END_RAHN_IND*/
		String lettertype = CommonConstants.EMPTY_STRING;

		String isUsedinTech = "0";
		String issuingAuthority = CommonConstants.EMPTY_STRING;
		BigDecimal remainingAmountTD = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal pastDueAmountTD = CommonConstants.BIGDECIMAL_ZERO;

		BigDecimal pastDueAmountAllBuyer = CommonConstants.BIGDECIMAL_ZERO;
		String isUsedColl = "0";
		String mortgageType = CommonConstants.EMPTY_STRING;
		SellerDetails sellerDetails = buyerSellerAgreement.getSellerDetails();
		BuyerDetails[] buyerDetails = buyerSellerAgreement.getBuyerDetailsList();
		SellerDocumentDetails[] documentDetails = buyerSellerAgreement.getSellerDocumentDetailsList();
		SellerTitleDeedDetails[] titleDeedDetails = buyerSellerAgreement.getSellerTitleDeedDetailsList();
		String sellerPartyID = sellerDetails.getSellerPartyID();
		BigDecimal remainingAmountSeller = sellerDetails.getRemainingAmount().getCurrencyAmount();
		BigDecimal pastDueAmountSeller = sellerDetails.getPastDueAmount().getCurrencyAmount();
		//validateBuyerSeller(buyerSellerAgreement);
		for (SellerDocumentDetails documentDetail : documentDetails) {
			if (documentDetail.isIsExisting()==null || !documentDetail.isIsExisting()) {
				lettertype = documentDetail.getLetterType();
				issuingAuthority = documentDetail.getIssuingAuthority();
				mortgageType = documentDetail.getMortgageType();
			}
		}
		for (SellerTitleDeedDetails titleDeedDetail : titleDeedDetails) {
			if (titleDeedDetail.isIsExisting()==null || !titleDeedDetail.isIsExisting()) {
				remainingAmountTD = remainingAmountTD.add(titleDeedDetail.getRemainingAmount().getCurrencyAmount());
				pastDueAmountTD = pastDueAmountTD.add(titleDeedDetail.getPastDueAmount().getCurrencyAmount());
				if (titleDeedDetail.getIsUsedinTechAnalysis().equalsIgnoreCase("Yes")) {
					isUsedinTech = "1";
				}
				if (titleDeedDetail.getIsUsedinCollateral().equalsIgnoreCase("Yes")) {
					isUsedColl = "1";
				}
			}
		}
		for (BuyerDetails buyerDetail : buyerDetails) {
			if (buyerDetail.isIsExisting()==null || !buyerDetail.isIsExisting()) {
				pastDueAmountAllBuyer = pastDueAmountAllBuyer.add(buyerDetail.getPastDueAmount().getCurrencyAmount());
			}
		}
		
			String response = callValidateBuyerProc(lettertype, sellerPartyID, isUsedinTech, issuingAuthority, pastDueAmountTD,
					remainingAmountTD, remainingAmountSeller, pastDueAmountSeller, pastDueAmountAllBuyer, isUsedColl,
					mortgageType);
			if(response!=null && !response.isEmpty()) {
				String[] msgArgs= new String[1];
				msgArgs[0]=response;
				IBCommonUtils.raiseParametrizedEvent(44000807, msgArgs);
			}
		
		
	}

	private String callValidateBuyerProc(String lettertype, String sellerPartyID, String isUsedinTech,
			String issuingAuthority, BigDecimal pastDueAmountTD, BigDecimal remainingAmountTD,
			BigDecimal remainingAmountSeller, BigDecimal pastDueAmountSeller, BigDecimal pastDueAmountAllBuyer,
			String isUsedColl, String mortgageType) {
		// return "13|24|35|46|false|error occured";
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		factory.beginTransaction();
		Connection _Connection = factory.getJDBCConnection();
		CallableStatement cs = null;
		String _ProcedureName = "{ CALL CUSTOMEXTN.ValidateBuyerSeller";
		try {
			// prepare store procedure command with parameters count
			_ProcedureName += " (";
			for (int i = 1; i <= 12; i++)
				_ProcedureName += "?,";
			_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

			// prepare the callable statement
			cs = _Connection.prepareCall(_ProcedureName);

			// set value for each parameter
			cs.setString(1, lettertype);
			cs.setString(2, sellerPartyID);
			cs.setString(3, isUsedinTech);
			cs.setString(4, issuingAuthority);
			cs.setBigDecimal(5, pastDueAmountTD);
			cs.setBigDecimal(6, remainingAmountTD);
			cs.setBigDecimal(7, remainingAmountSeller);
			cs.setBigDecimal(8, pastDueAmountSeller);
			cs.setBigDecimal(9, pastDueAmountAllBuyer);
			cs.setString(10, isUsedColl);
			cs.setString(11, mortgageType);

			// set output parameters ...
			
			cs.registerOutParameter(12, java.sql.Types.VARCHAR);

			// execute the stored procedures
			cs.execute();

			// return result
			return cs.getString(12);

		} catch (Exception e) {
			System.err.println(e.getLocalizedMessage());
			factory.rollbackTransaction();
		} finally {
			factory.commitTransaction();
			if (cs != null)
				try {
					cs.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			try {
				_Connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return CommonConstants.EMPTY_STRING;
	}

}