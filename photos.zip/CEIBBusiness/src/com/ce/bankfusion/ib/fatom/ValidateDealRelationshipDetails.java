package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateDealRelationshipDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyStatus;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipDtls;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;

public class ValidateDealRelationshipDetails extends AbstractCE_IB_ValidateDealRelationshipDetails {

	private static final long serialVersionUID = 1L;

	private static final String whereClause = " WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + " = ? AND "
			+ IBOIB_IDI_DealCustomerDetail.ASSOCIATIONTYPE + " = ? ";

	private static final transient Log LOGGER = LogFactory.getLog(ValidateDealRelationshipDetails.class.getName());

	public ValidateDealRelationshipDetails() {
		super();
	}

	public ValidateDealRelationshipDetails(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
	  validateStatus();
  	validatePartyForSameRelationshipType();
		validatePartyForRelType18();
		validateGuaranteeToPayDtls();
		mandateSiloYearAndSiloArea();
		validatePartyForOtherRelType(env, getF_IN_relationshipDetails().getPartyId());
		if (isF_IN_onSave()) {
			validateAtleastOneAgent();
		}
	}

	private void validateStatus() {
	   RelationshipDtls[] relationList = getF_IN_dealRelationshipDetails().getRelationshipDtls();
	   for(RelationshipDtls relation : relationList) {
	       if(relation.getSelect()) {
	           if(null != relation.getDealStatus() && relation.getDealStatus().equals("DELETED")) {
	               IBCommonUtils.raiseUnparameterizedEvent(44000288);  //This request cannot be modified
	           }
	       }
	   }
	  }

    private void validatePartyForSameRelationshipType() {
		LOGGER.info("Validating party for same relationshiptype: " + getF_IN_relationshipDetails().getPartyId());

		if (getF_IN_relationshipDetails() != null
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getPartyId())
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getRelationshipType())
				&& getF_IN_dealRelationshipDetails() != null
				&& getF_IN_dealRelationshipDetails().getRelationshipDtlsCount() > 0) {
			for (RelationshipDtls relationshipDtls : getF_IN_dealRelationshipDetails().getRelationshipDtls()) {
				if (!getF_IN_relationshipDetails().getRelationshipDtlId()
						.equals(relationshipDtls.getRelationshipDtlId())
						&& relationshipDtls.getPartyId().equals(getF_IN_relationshipDetails().getPartyId())
						&& relationshipDtls.getRelationshipType()
								.equals(getF_IN_relationshipDetails().getRelationshipType())) {
					LOGGER.info("Validating party for same relationshiptype: success");
					String relationshipType = IBCommonUtils
							.getGCFromCode("IBRELATIONSHIPTYPE", getF_IN_relationshipDetails().getRelationshipType())
							.getReadCodeValueDetails().getGcCodeDetails().getCodeDescription();
					String[] arguments = new String[2];
					arguments[0] = getF_IN_relationshipDetails().getPartyId();
					arguments[1] = relationshipType;
					IBCommonUtils.raiseParametrizedEvent(CeConstants.E_PARTY_WITH_SAME_REL_TYPE_CANNOT_BE_ADDED_IB,
							arguments);
				}
			}
		}

	}

	private void mandateSiloYearAndSiloArea() {
		LOGGER.info(
				"validating mandatory for Silo year and Silo area: " + getF_IN_relationshipDetails().getPledgeType());
		if (getF_IN_relationshipDetails() != null && getF_IN_relationshipDetails().getDisplayGuranteeToPay()
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getPledgeType())
				&& getF_IN_relationshipDetails().getPledgeType().equals("1")
				&& (IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getSiloArea())
						|| IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getSiloYear()))) {
			LOGGER.info("validating mandatory for Silo year and Silo area: success ");
			String pledgeType = IBCommonUtils
					.getGCFromCode("IBPLEDGETYPE", getF_IN_relationshipDetails().getPledgeType())
					.getReadCodeValueDetails().getGcCodeDetails().getCodeDescription();
			String[] arguments = new String[1];
			arguments[0] = pledgeType;
			IBCommonUtils.raiseParametrizedEvent(CeConstants.E_SILO_YEAR_AND_SILO_AREA_IS_MANDATORY_IB, arguments);
		}

	}

	private void validateAtleastOneAgent() {
		LOGGER.info("validating atleast one agent " + getF_IN_relationshipDetails().getDisplayAgents());
		if (getF_IN_relationshipDetails() != null && getF_IN_relationshipDetails().getDisplayAgents()
				&& (getF_IN_dealRelationshipDetails().getRelationshipAgentsCount() == 0
						|| (getF_IN_dealRelationshipDetails().getRelationshipAgentsCount() == 1 && IBCommonUtils
								.isEmpty(getF_IN_dealRelationshipDetails().getRelationshipAgents(0).getPartyId())))) {
			LOGGER.info("validating atleast one agent :success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_ATLEAST_ONEAGENT_IS_NEEDED_IB);
		}

	}

	private void validatePartyForOtherRelType(BankFusionEnvironment env, String partyId) {
		LOGGER.info(
				"validating party for other relationship types " + getF_IN_relationshipDetails().getRelationshipType());
		String ADFEmployee = CommonConstants.EMPTY_STRING;

		if (getF_IN_relationshipDetails() != null
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getRelationshipType())
				&& !IBCommonUtils.isNullOrEmpty(partyId)) {

			getDealCustomerAdditionalInfo getDealCustomerAdditionalInfo = new getDealCustomerAdditionalInfo(env);
			getDealCustomerAdditionalInfo.setF_IN_partyId(partyId);
			getDealCustomerAdditionalInfo.process(env);
			if ((getF_IN_relationshipDetails().getRelationshipType().equals("3")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("11")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("15")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("22")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("23")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("25")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("27")
					|| getF_IN_relationshipDetails().getRelationshipType().equals("28"))) {
				ADFEmployee = getDealCustomerAdditionalInfo.getF_OUT_ceDealCustomerInfo().getAdfEmployee();

				validateIfADFEmployee(ADFEmployee);

				validateIfPartyHasAnyLiability(env);

				validateIfCustomerIsDeceased();
			}

			if (getF_IN_relationshipDetails().getRelationshipType().equals("3"))
				validateIfPartyIsFrozen(getDealCustomerAdditionalInfo);
		}
	}

	private void validateIfCustomerIsDeceased() {
		LOGGER.info("validating customer deceased " + getF_IN_relationshipDetails().getPartyId());
		String WHERE_CLAUSE = " WHERE " + IBOPT_PFN_PartyStatus.INTERNALPARTYID + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_relationshipDetails().getPartyId());

		List<IBOPT_PFN_PartyStatus> partyStatusDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOPT_PFN_PartyStatus.BONAME, WHERE_CLAUSE, params, null, true);

		if (partyStatusDtls != null && !partyStatusDtls.isEmpty()
				&& partyStatusDtls.get(0).getF_PARTYSTATUSID().equals("007")) {
			LOGGER.info("validating customer deceased :success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DECEASED_PARTY_CANNOT_BE_ADDED_IB);
		}
	}

	private void validateIfPartyHasAnyLiability(BankFusionEnvironment env) {
		LOGGER.info("Validating if Customer has any liability during Deal Relationship for Party:"
				+ getF_IN_relationshipDetails().getPartyId());
		boolean partyHasAnyLiability = false;
		ReadLoanDetailsRs readLoanDetailsRs;
		HashMap inputParams = new HashMap();
		try {
			inputParams.put("PartyID", getF_IN_relationshipDetails().getPartyId());
			HashMap outputParams = MFExecuter.executeMF("IB_DLI_CustomerDealDetails_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
			VectorTable customerDealDetailsList = (VectorTable) outputParams.get("PaginatedData");
			if (customerDealDetailsList != null) {
				for (int i = 0; i < customerDealDetailsList.size(); i++) {
					HashMap record = customerDealDetailsList.getRowTags(i);
					String dealNo = (String) record.get("dealNo");
					IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealNo);
					if (dealDetails != null && !IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId())) {
						readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealNo);
						if (readLoanDetailsRs != null
								&& readLoanDetailsRs.getDealDetails().getLoanBasicDetails() != null
								&& readLoanDetailsRs.getDealDetails().getLoanBasicDetails()
										.getArrearDealAmount() != null
								&& readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount()
										.compareTo(BigDecimal.ZERO) > 0) {
							partyHasAnyLiability = true;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.info(
					"Error occured during validating if Customer has any liability during Deal Relationship for Party:"
							+ e.getLocalizedMessage());
		}

		if (partyHasAnyLiability) {
			LOGGER.info("Validating if Customer has any liability during Deal Relationship for Party : success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_WITH_DUE_LIABILITIES_CANNOT_BE_ADDED_IB);
		}

	}

	private void validateIfPartyIsFrozen(getDealCustomerAdditionalInfo getDealCustomerAdditionalInfo) {
		LOGGER.info("Validating if party if frozen:" + getF_IN_relationshipDetails().getPartyId());
		// validating if party is frozen
		if (getDealCustomerAdditionalInfo.getF_OUT_ceDealCustomerInfo().getValidateRelationShipInfo()) {
			LOGGER.info("Validating if party if frozen:success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FREEZED_PARTY_CANNOT_BE_ADDED_IB);
		}
		setF_OUT_isPartyFrozen(
				getDealCustomerAdditionalInfo.getF_OUT_ceDealCustomerInfo().getValidateRelationShipInfo());
	}

	private void validateIfADFEmployee(String ADFEmployee) {
		LOGGER.info("Validating if ADF employee:" + getF_IN_relationshipDetails().getPartyId());
		// validating if party is an ADF employee
		ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("BOOLEANYESNO");	    
        for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
            if(ADFEmployee.equals(gcCode.getCodeDescription())){
            	ADFEmployee=gcCode.getCodeValue();
            }
        }
		if (!IBCommonUtils.isNullOrEmpty(ADFEmployee) && !ADFEmployee.equals("false") ) {
			LOGGER.info("Validating if ADF employee:success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_ADF_EMPLOYEE_CANNOT_BE_ADDED_IB);
		}
	}

	private void validatePartyForRelType18() {
		LOGGER.info("Validating for relationtype 18:" + getF_IN_relationshipDetails().getPartyId());
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_dealRelationshipDetails().getDealId());
		params.add("PC");

		List<IBOIB_IDI_DealCustomerDetail> dealPartyDetails = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, whereClause, params, null, true);

		if (getF_IN_relationshipDetails() != null
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getRelationshipType())
				&& getF_IN_relationshipDetails().getRelationshipType().equals("18")
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDetails().getPartyId()) && dealPartyDetails != null
				&& !(dealPartyDetails.get(0).getF_CUSTOMERID().equals(getF_IN_relationshipDetails().getPartyId()))) {
			LOGGER.info("Validating for relationtype 18:success");
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_ID_PARTYID_BELONG_TO_MAIN_CUSTOMER);
		}
	}

	private void validateGuaranteeToPayDtls() {
		LOGGER.info("Validating gurantee To Pay details");
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_dealId());
		if (dealDetails != null && getF_IN_relationshipDetails() != null) {
			if (getF_IN_relationshipDetails().getPledgeAmount() != null && (getF_IN_relationshipDetails()
					.getPledgeAmount().getCurrencyAmount().compareTo(dealDetails.getF_DealAmt()) > 0))
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PLEDGEAMT_CANNOT_BE_GREATER_THAN_DEAL_AMT_IB);

			if (getF_IN_relationshipDetails().getFromDate() != null
					&& !CalendarUtil.isDateNullOrDefaultDate(getF_IN_relationshipDetails().getFromDate())
					&& getF_IN_relationshipDetails().getFromDate().compareTo(dealDetails.getF_DealStartDate()) < 0)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FROM_DATE_SHOULD_BE_GREATER_THAN_DEAL_DATE_IB);

			if (getF_IN_relationshipDetails().getToDate() != null
					&& !CalendarUtil.isDateNullOrDefaultDate(getF_IN_relationshipDetails().getToDate())
					&& getF_IN_relationshipDetails().getToDate().compareTo(dealDetails.getF_LastRepaymentDate()) > 0)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TO_DATE_LESSTHAN_MARTURITY_DATE_IB);

			if (getF_IN_relationshipDetails().getToDate() != null && getF_IN_relationshipDetails().getFromDate() != null
					&& !CalendarUtil.isDateNullOrDefaultDate(getF_IN_relationshipDetails().getFromDate())
					&& !CalendarUtil.isDateNullOrDefaultDate(getF_IN_relationshipDetails().getToDate())
					&& getF_IN_relationshipDetails().getFromDate()
							.compareTo(getF_IN_relationshipDetails().getToDate()) > 0)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TO_DATE_CANNOT_BE_LESSTHAN_FROM_DATE_IB);
		}
	}

}
