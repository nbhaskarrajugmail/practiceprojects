package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveTechExistingAssets;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

public class SaveTechExistingAssets extends AbstractCE_IB_SaveTechExistingAssets {

	private static final long serialVersionUID = 1L;
	private static final int E_CATEGORY_ID_AND_ATTRIBUTES_MAND_IB = 44000412;
	private static final transient Log LOG = LogFactory.getLog(SaveTechExistingAssets.class.getName());
	public SaveTechExistingAssets(BankFusionEnvironment env) {
		super(env);

	}

	public SaveTechExistingAssets() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		if (getF_IN_technicalAssetDtl().getAssetCategory().getCategory() == null
				|| getF_IN_technicalAssetDtl().getAssetCategory().getCategory().equals(CommonConstants.EMPTY_STRING)) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_CATEGORY_ID_AND_ATTRIBUTES_MAND_IB,
					new Object[] {}, LOG, env);
		}
		if (null == getF_IN_assetUDFsCollection() || getF_IN_assetUDFsCollection().getAssetUDFsCount() == 0) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_CATEGORY_ID_AND_ATTRIBUTES_MAND_IB,
					new Object[] {}, LOG, env);
		}
	}
}
