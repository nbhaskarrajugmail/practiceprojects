package com.ce.bankfusion.ib.fatom;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RemoveTechFarmDtls;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;

public class RemoveTechFarmDtls extends AbstractCE_IB_RemoveTechFarmDtls {

	private static final long serialVersionUID = 1L;
	private static final transient Log LOG = LogFactory.getLog(RemoveTechFarmDtls.class.getName());

	public RemoveTechFarmDtls() {
		super();

	}

	public RemoveTechFarmDtls(BankFusionEnvironment env) {
		super(env);

	}

	@Override
	public void process(BankFusionEnvironment env) {

		TechnicalFarmDtlList technicalFarmDtlList = getF_IN_technicalFarmDtlList();
		TechnicalFarmDtlList hiddenTechFarmDtlList = getF_IN_hiddenTechFarmDtlList();
		TechnicalCropDtlList hiddenTechCropDtlList = getF_IN_hiddenTechCropDtlList();
		TechnicalAreaDtlList hiddenTechAreaDtlList = getF_IN_hiddenTechAreaDtlList();
		TechincalAssetDtlsList hiddenTechAssetDtlList = getF_IN_hiddenTechAssetDtlList();
		TechnicalAreaCoordinateDtlList hiddenTechAreaCoordinateDtlList = getF_IN_hiddenTechAreaCoordinateDtlList();
		AssetUDFsCollection assetUDFCollection = getF_IN_hiddenAssetUDFList();
		TechnicalWellDtlsList hiddenTechWellDtlsList = getF_IN_hiddenTechnicalWellDtlsList();

		for (TechnicalFarmDtl farmDtl : technicalFarmDtlList.getTechnicalFarmDtlList()) {

			if (farmDtl.getSelect()) {
				for (TechnicalFarmDtl hiddenFarmDtl : hiddenTechFarmDtlList.getTechnicalFarmDtlList())

				{
					if (!StringUtils.isEmpty(farmDtl.getReferenceNumber()) && farmDtl.getReferenceNumber().equals(hiddenFarmDtl.getReferenceNumber())) {
						hiddenTechFarmDtlList.removeTechnicalFarmDtlList(hiddenFarmDtl);
					}
				}

				for (TechnicalCropDtl cropDtl : hiddenTechCropDtlList.getTechnicalCropDtlList()) {
					if (!StringUtils.isEmpty(farmDtl.getReferenceNumber()) &&farmDtl.getReferenceNumber().equals(cropDtl.getReferenceNumber())) {
						hiddenTechCropDtlList.removeTechnicalCropDtlList(cropDtl);
					}
				}
				for (TechnicalWellDtl  wellDtls: hiddenTechWellDtlsList.getTechnicalWellDtlList()) {
					if (!StringUtils.isEmpty(farmDtl.getReferenceNumber()) &&farmDtl.getReferenceNumber().equals(wellDtls.getReferenceNumber())) {
						hiddenTechWellDtlsList.removeTechnicalWellDtlList(wellDtls);
					}
				}
				for (TechnicalAreaDtl areaDtl : hiddenTechAreaDtlList.getTechnicalAreaDtlList()) {
					if (!StringUtils.isEmpty(farmDtl.getReferenceNumber()) &&farmDtl.getReferenceNumber().equals(areaDtl.getReferenceNumber())) {

						for (TechnicalAreaCoordinateDtl areaCoordinateDtl : hiddenTechAreaCoordinateDtlList
								.getTechnicalAreaCoordinateDtlList()) {
							if ((areaDtl.getReferenceNumber().equals(areaCoordinateDtl.getReferenceNumber()))
									&& (areaDtl.getTitleDeedId().equals(areaCoordinateDtl.getTitleDeedId())))

							{
								hiddenTechAreaCoordinateDtlList.removeTechnicalAreaCoordinateDtlList(areaCoordinateDtl);
							}
						}
						hiddenTechAreaDtlList.removeTechnicalAreaDtlList(areaDtl);
					}
				}

				for (TechnicalAssetDtl assetDtl : hiddenTechAssetDtlList.getTechincalAssetDtlsList()) {
					if (!StringUtils.isEmpty(farmDtl.getReferenceNumber()) &&farmDtl.getReferenceNumber().equals(assetDtl.getReferenceNumber())) {
						for (AssetUDF assetUDF : assetUDFCollection.getAssetUDFs()) {
							if (assetDtl.getAssetId().equals(assetUDF.getAssetid())) {
								assetUDFCollection.removeAssetUDFs(assetUDF);
							}
						}
						hiddenTechAssetDtlList.removeTechincalAssetDtlsList(assetDtl);
					}
				}
			}
		}

		TechnicalAnalysisDtls hiddenTechnicalAnalysis = new TechnicalAnalysisDtls();
		hiddenTechnicalAnalysis.setTechnicalAreaCoordinatesList(hiddenTechAreaCoordinateDtlList);
		hiddenTechnicalAnalysis.setTechnicalAreaDtlsList(hiddenTechAreaDtlList);
		hiddenTechnicalAnalysis.setTechnicalAssetDtlsList(hiddenTechAssetDtlList);
		hiddenTechnicalAnalysis.setTechnicalAssetUDFs(assetUDFCollection);
		hiddenTechnicalAnalysis.setTechnicalCropDtlsList(hiddenTechCropDtlList);
		hiddenTechnicalAnalysis.setTechnicalWellDtlsList(hiddenTechWellDtlsList);
		hiddenTechnicalAnalysis.setTechnicalFarmDtlsList(hiddenTechFarmDtlList);

		setF_OUT_hiddenTechnicalAnalysis(hiddenTechnicalAnalysis);
	}
}
