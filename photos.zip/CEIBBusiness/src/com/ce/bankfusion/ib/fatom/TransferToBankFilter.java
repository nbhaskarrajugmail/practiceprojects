/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SurplusTransfer;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_TransferToBankDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOPayDetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_TransferToBankFilter;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.toolkit.expression.function.ConvertToTimestamp;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TPT_ThirdPartyDetails;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Party;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.ib.types.TransferToBank;

/**
 * @author Aklesh
 *
 */
public class TransferToBankFilter extends AbstractCE_ADF_TransferToBankFilter {

	private static final long serialVersionUID = 7137308733675905581L;

	private static final String PO_PAYMENT_WHERE_CLAUSE = "WHERE " + IBOCE_IB_IssuePOPayDetail.IBDEBITBANK + "=? AND ("
			+ IBOCE_IB_IssuePOPayDetail.IBCURRENCYCODE + "=? OR " + IBOCE_IB_IssuePOPayDetail.IBCURRENCYCODE
			+ " IS NULL) AND " + IBOCE_IB_IssuePOPayDetail.IBTRANSFERID + " IS NULL AND "
			+ IBOCE_IB_IssuePOPayDetail.IBPURCHASEORDERID + " IN(SELECT " + IBOCE_IB_IssuePODetail.IBPURCHASEORDERID
			+ " FROM " + IBOCE_IB_IssuePODetail.BONAME + " WHERE " + IBOCE_IB_IssuePODetail.IBPODATEG + ">=? AND "
			+ IBOCE_IB_IssuePODetail.IBPODATEG + " <=? AND " + IBOCE_IB_IssuePODetail.IBSTATUS + "=?)";
	private static final String where_clause = "WHERE "+IBOCE_ADF_TransferToBankDetails.TRANSACTIONID+"=?";
	private static final String SURPLUS_WHERE_CLAUSE = "WHERE " + IBOCE_ADF_SurplusTransfer.DEBITBANK+ "=? AND " +IBOCE_ADF_SurplusTransfer.TRANSACTIONNDATE
			+ ">=? AND " + IBOCE_ADF_SurplusTransfer.TRANSACTIONNDATE + "<=? AND " + IBOCE_ADF_SurplusTransfer.STATUS
			+ "=?";

	private static final String RIYADH = "riyadh";
	private static final String PAYMENT_DESC = "Payment_Desc";
	String paymentDesc= BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
            PAYMENT_DESC, "", CeConstants.ADFIBCONFIGLOCATION);
	
	public TransferToBankFilter(BankFusionEnvironment env) {
		super(env);

	}

	public TransferToBankFilter() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		getF_OUT_transferToBankDetails().removeAllTransferToBankList();
		BigDecimal totalAmount = BigDecimal.ZERO;
		int srno = 1;
		Date valueDate = getF_IN_transferHeaderDetails().getValueDate()!=null && getF_IN_transferHeaderDetails().getValueDate().compareTo(new Date(0))<0?null:getF_IN_transferHeaderDetails().getValueDate();
		if (getF_IN_transferHeaderDetails().getTransactionID().isEmpty()) {
			Date fromDate = getF_IN_transferHeaderDetails().getPoDateFrom();
			Date toDate = getF_IN_transferHeaderDetails().getPoDateTo();
			ArrayList params = new ArrayList<>();
			params.add(getF_IN_transferHeaderDetails().getBankID());
			params.add("SAR");
			params.add(ConvertToTimestamp.run(fromDate));
			params.add(ConvertToTimestamp.run(toDate));
			params.add("Processed");
			List<IBOCE_IB_IssuePOPayDetail> poList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_IssuePOPayDetail.BONAME, PO_PAYMENT_WHERE_CLAUSE, params, null, true);

			HashMap output = MFExecuter.executeMF("CE_ADF_ListAllBankDetails_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), null);
			VectorTable allBanksList= (VectorTable) output.get("Result");
			Map<String, String> nscToBSCMap = new HashMap<>();
			for (int i = 0; i < allBanksList.size(); i++) {
				HashMap row = allBanksList.getRowTags(i);
				nscToBSCMap.put((String) row.get("BOID"), (String) row.get("BRANCHSORTCODE"));
			}
			for (IBOCE_IB_IssuePOPayDetail issuePOPayDetail : poList) {
				TransferToBank transferToBank = new TransferToBank();
				transferToBank.setAmount(issuePOPayDetail.getF_IBPAYMENTAMOUNT());
				totalAmount = totalAmount.add(issuePOPayDetail.getF_IBPAYMENTAMOUNT());
				transferToBank.setBeneficiaryAddress(RIYADH);
				transferToBank.setBeneficiaryBank(nscToBSCMap.get(issuePOPayDetail.getF_IBBENIFICIARYBANK()));
				transferToBank.setBeneficiaryIBAN(issuePOPayDetail.getF_IBIBAN());
				String beneficiaryName = issuePOPayDetail.getF_IBCUSTOMERNAME();
				String partyID = CommonConstants.EMPTY_STRING;
				if(issuePOPayDetail.getF_IBPAYMENTOPTION().equals("Third Party")) {
					 partyID = ((IBOIB_TPT_ThirdPartyDetails)BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_TPT_ThirdPartyDetails.BONAME, issuePOPayDetail.getF_IBTHIRDPARTYID(), true)).getF_INTERNALPARTYID();
				}else if(issuePOPayDetail.getF_IBPAYMENTOPTION().equals("Relationship")) {
					partyID = issuePOPayDetail.getF_IBRELATIONSHIPID();
				}
				if(!partyID.isEmpty()) {
					beneficiaryName = ((IBOPT_PFN_Party)BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOPT_PFN_Party.BONAME, partyID, true)).getF_NAME();
				}
				transferToBank.setBeneficiaryName(beneficiaryName);
				transferToBank.setCurrency("SAR");
				transferToBank.setLoanAccountID(paymentDesc);
				transferToBank.setSrno(srno++);
				transferToBank.setTransactionID("");
				transferToBank.setValueDate(valueDate);
				transferToBank.setExclude(false);
				transferToBank.setIssuePOPayDtlsID(issuePOPayDetail.getBoID());
				getF_OUT_transferToBankDetails().addTransferToBankList(transferToBank);
			}
			//Below code will read Other Type of financials on the customer IBAN
			totalAmount = populateSurplusPostings(totalAmount,nscToBSCMap,srno,valueDate);
		} else {
			if (getF_IN_mode().equals("Generate") && getF_IN_transferHeaderDetails().getProcessReference().isEmpty()) {
				valueDate = getF_IN_transferHeaderDetails().getValueDate();
				DefaultPricingData defaultPricingData = new DefaultPricingData(env);
				defaultPricingData.process(env);
				valueDate = getF_IN_transferHeaderDetails().getValueDate();
				CustomAutoNumFatom autoNum = new CustomAutoNumFatom(env);
				autoNum.setF_IN_BONAME("CE_ADF_TransferToBank");
				autoNum.setF_IN_Prefix(defaultPricingData.getF_OUT_currentYear() + "-");
				autoNum.process(env);
				String batchreference = autoNum.getF_OUT_PrimKey();
				getF_OUT_transferToBankDetails().getTransferHeaderDetails().setProcessReference(batchreference);
				getF_OUT_transferToBankDetails().getTransferHeaderDetails()
						.setProcessDate(IBCommonUtils.getBFBusinessDate());
			} else {
				getF_OUT_transferToBankDetails().getTransferHeaderDetails()
						.setProcessReference(getF_IN_transferHeaderDetails().getProcessReference());
				getF_OUT_transferToBankDetails().getTransferHeaderDetails()
						.setProcessDate(getF_IN_transferHeaderDetails().getProcessDate());
			}
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_transferHeaderDetails().getTransactionID());
			List<IBOCE_ADF_TransferToBankDetails> bankDetails = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_ADF_TransferToBankDetails.BONAME, where_clause, params, null, true);
			for (IBOCE_ADF_TransferToBankDetails transferToBankDetails : bankDetails) {

				TransferToBank transferToBank = new TransferToBank();
				transferToBank.setAmount(transferToBankDetails.getF_AMOUNT());
				
				transferToBank.setBeneficiaryAddress(transferToBankDetails.getF_BENEFICIARYADDRESS());
				transferToBank.setBeneficiaryBank(transferToBankDetails.getF_BENEFICIARYBANK());
				transferToBank.setBeneficiaryIBAN(transferToBankDetails.getF_BENEFICIARYIBAN());
				transferToBank.setBeneficiaryName(transferToBankDetails.getF_BENEFICIARYNAME());
				transferToBank.setCurrency(transferToBankDetails.getF_CURRENCY());
				transferToBank.setLoanAccountID(transferToBankDetails.getF_LOANACCOUNTID());
				transferToBank.setSrno(srno++);
				transferToBank.setTransactionID(transferToBankDetails.getF_TRANSACTIONID());
				transferToBank.setValueDate(valueDate);
				if (getF_IN_mode().equals("Enquiry")) {
					transferToBank.setValueDate(transferToBankDetails.getF_VALUEDATE());
				}

				transferToBank.setExclude(transferToBankDetails.isF_EXCLUDE());
				transferToBank.setIssuePOPayDtlsID(transferToBankDetails.getF_ISSUEPOPAYDTLSID());
				if (getF_IN_mode().equals("Generate")) {
					if (!transferToBankDetails.isF_EXCLUDE()) {
						getF_OUT_transferToBankDetails().addTransferToBankList(transferToBank);
						totalAmount = totalAmount.add(transferToBankDetails.getF_AMOUNT());
					}
				} else {
					getF_OUT_transferToBankDetails().addTransferToBankList(transferToBank);
					totalAmount = totalAmount.add(transferToBankDetails.getF_AMOUNT());
				}
			}
		}
		if (getF_IN_transferHeaderDetails().getValueDate() == null) {
			getF_OUT_transferToBankDetails().getTransferHeaderDetails().setValueDate(IBCommonUtils.getBFBusinessDate());
		} else {
			getF_OUT_transferToBankDetails().getTransferHeaderDetails().setValueDate(valueDate);
		}
		setF_OUT_totalAmount(totalAmount);
		setF_OUT_totalAmount_CurrCode("SAR");
		setF_OUT_totalBeneficiaries(getF_OUT_transferToBankDetails().getTransferToBankListCount());
	}

	private BigDecimal populateSurplusPostings(BigDecimal totalAmount, Map<String, String> gcCodes, int srno, Date valueDate) {
		Date fromDate = getF_IN_transferHeaderDetails().getPoDateFrom();
		Date toDate = getF_IN_transferHeaderDetails().getPoDateTo();
		ArrayList params = new ArrayList<>();
		params.add(getF_IN_transferHeaderDetails().getBankID());
		params.add(ConvertToTimestamp.run(fromDate));
		params.add(ConvertToTimestamp.run(toDate));
		params.add(false);
		List<IBOCE_ADF_SurplusTransfer> surplusDetail = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_ADF_SurplusTransfer.BONAME, SURPLUS_WHERE_CLAUSE, params, null, true);
		for (IBOCE_ADF_SurplusTransfer surplusTransfer : surplusDetail) {

			TransferToBank transferToBank = new TransferToBank();
			transferToBank.setAmount(surplusTransfer.getF_AMOUNT());
			totalAmount = totalAmount.add(surplusTransfer.getF_AMOUNT());
			transferToBank.setBeneficiaryAddress(RIYADH);
			transferToBank.setBeneficiaryBank(gcCodes.get(surplusTransfer.getF_BENEFICIARYBANK()));
			transferToBank.setBeneficiaryIBAN(surplusTransfer.getF_BENEFICIARYIBAN());
			transferToBank.setBeneficiaryName(surplusTransfer.getF_BENEFICIARYNAME());
			transferToBank.setCurrency("SAR");
			transferToBank.setLoanAccountID(paymentDesc);
			transferToBank.setSrno(srno++);
			transferToBank.setTransactionID("");
			transferToBank.setValueDate(valueDate);
			transferToBank.setExclude(false);
			transferToBank.setIssuePOPayDtlsID(surplusTransfer.getBoID());
			getF_OUT_transferToBankDetails().addTransferToBankList(transferToBank);
		
		}
		return totalAmount;
	}
}