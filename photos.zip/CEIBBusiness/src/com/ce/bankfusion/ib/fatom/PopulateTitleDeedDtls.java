package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;

import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.dealcustcollateral.dtls.ib.types.CoOrdinateDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CoOrdinateDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.OwnerDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.OwnersDetailsList;
import bf.com.misys.ib.spi.types.CustomerDetails;


public class PopulateTitleDeedDtls {
	
	public static HashMap populateCoOrdinateAndOwnerDtls(String titleDeedID, int versionNum, BankFusionEnvironment env) {
	
		ListShareHolderDtlsType listShareHolderDtlsType = new ListShareHolderDtlsType();
		ListTitleDeedLocDtlsType listTitleDeedLocDtlsType = new ListTitleDeedLocDtlsType();
		
		HashMap param = new HashMap();
        param.clear();
        param.put("titleDeedId",titleDeedID);
        param.put("versionNumber", versionNum);
        HashMap outputParams = MFExecuter.executeMF("CE_PTY_ViewTitleDeedDetails_SRV", env, param);
        listTitleDeedLocDtlsType= (ListTitleDeedLocDtlsType) outputParams.get("titleDeedLocDtlsList");
        listShareHolderDtlsType= (ListShareHolderDtlsType) outputParams.get("shareHolderDtlsTypeList"); 
        CoOrdinateDetailsList coOrdinateList = new CoOrdinateDetailsList();
            coOrdinateList.removeAllCoOrdinateDetailsList();
            
        if(listTitleDeedLocDtlsType.getTitleDeedLocDtlsCount()>0) {
            coOrdinateList= populateCoOrdinateDtls(listTitleDeedLocDtlsType);
        }
        OwnersDetailsList ownerList = new OwnersDetailsList();
            ownerList.removeAllOwnersDetailsList();
        
        if(listShareHolderDtlsType.getShareHolderDetailsCount()>0) {
            ownerList = populateOwnerDtls(listShareHolderDtlsType, env);
        }
        HashMap params = new HashMap();
        params.put("CoOrdinateDtlsList",coOrdinateList);
        params.put("OwnersDtlsList", ownerList);
        
        return params;
	}

	public static CoOrdinateDetailsList populateCoOrdinateDtls(ListTitleDeedLocDtlsType listTitleDeedLocDtlsType) {
		        
        CoOrdinateDetailsList coOrdinateDtlslist= new CoOrdinateDetailsList();
        for(TitleDeedLocationdtlsType titleDeedLocDetails: listTitleDeedLocDtlsType.getTitleDeedLocDtls()) {
        	
        	CoOrdinateDetails coOrdinateDtls = new CoOrdinateDetails();
        	coOrdinateDtls.setTitleDeedIDPK(titleDeedLocDetails.getTitleDeedId());
        	coOrdinateDtls.setNorthCoOrdinateO(titleDeedLocDetails.getLocationNorthDegree());
        	coOrdinateDtls.setNorthCoOrdinate(titleDeedLocDetails.getLocationNorthSection());
        	coOrdinateDtls.setEastCoOrdinateO(titleDeedLocDetails.getLocationEastDegree());
        	coOrdinateDtls.setEastCoOrdinate(titleDeedLocDetails.getLocationEastSection());
        	
        	coOrdinateDtlslist.addCoOrdinateDetailsList(coOrdinateDtls);
        }
        return coOrdinateDtlslist;
	}

	public static OwnersDetailsList populateOwnerDtls(ListShareHolderDtlsType listShareHolderDtlsType, BankFusionEnvironment env) {

        OwnersDetailsList ownerDtlsList = new OwnersDetailsList();
        for(ShareHolderDtlsType shareHolderDetails: listShareHolderDtlsType.getShareHolderDetails()) {
    		
        	CustomerDetails readCustomerdata = IBCommonUtils.getPartyDetailsFromPartyID(shareHolderDetails.getPartId(), env);
        	
        	OwnerDetails ownerDtls= new OwnerDetails();
        	ownerDtls.setCustomerID(shareHolderDetails.getPartId());
        	ownerDtls.setCustomerName(shareHolderDetails.getPartyName());
        	ownerDtls.setLegalStatus(shareHolderDetails.getOwnershipType());
        	ownerDtls.setOwnershipStatus(shareHolderDetails.getOwnershipStatus());
        	ownerDtls.setNotes(shareHolderDetails.getNotes()); 
        	ownerDtls.setNationalID(readCustomerdata.getPersonalDetails().getNationality());
        	
        	ownerDtlsList.addOwnersDetailsList(ownerDtls);
        }
      
        return ownerDtlsList;
	}
}
