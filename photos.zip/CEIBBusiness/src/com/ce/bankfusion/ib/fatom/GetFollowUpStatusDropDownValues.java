package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetFollowUpStatusDropDownValues;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.types.GcCodeDetail;

public class GetFollowUpStatusDropDownValues extends AbstractCE_IB_GetFollowUpStatusDropDownValues {

	public GetFollowUpStatusDropDownValues(BankFusionEnvironment env) {
		super(env);
	}

	public GetFollowUpStatusDropDownValues() {
		super();
	}

	@Override
	public void process(BankFusionEnvironment env) {
		getF_OUT_listGenericCodeRs()
				.setGcCodeDetails(IBCommonUtils.getGCList(CeConstants.GCPARENT_CEFOLLOWUPSTATUS).getGcCodeDetails());

		if (getF_OUT_listGenericCodeRs() != null && getF_OUT_listGenericCodeRs().getGcCodeDetailsCount() > 0) {
			for (GcCodeDetail gcCodeDetail : getF_OUT_listGenericCodeRs().getGcCodeDetails()) {
				if (gcCodeDetail.getCodeReference().equals(CeConstants.FOLLOWUP_ASSIGN_STATUS_INPROGRESS))
					getF_OUT_listGenericCodeRs().removeGcCodeDetails(gcCodeDetail);
			}
		}
	}
}
