package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveTechCropDtls;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;

public class SaveTechCropDtls extends AbstractCE_IB_SaveTechCropDtls {

	private static final long serialVersionUID = 1L;

	public SaveTechCropDtls(BankFusionEnvironment env) {
		super(env);

	}

	public SaveTechCropDtls() {
		super();

	}

	private static final transient Log LOG = LogFactory.getLog(SaveTechCropDtls.class.getName());

	public static final int CROP_CATEGORY_ID_CANNOT_BE_SAME = 44000206;

	private static final int FARM_TYPE_FARM_STATUS_COMB_NOT_ALLOWED = 44000244;

	private static final int CROP_TYPE_FOR_PALM_MANDATORY = 44000245;

	@Override
	public void process(BankFusionEnvironment env) {
		TechnicalCropDtl eachCrop = getF_IN_technicalCropDtl();
		TechnicalCropDtlList technicalCropListInput = getF_IN_technicalCropListInput();
		BigDecimal totalAreaForAllCrops = BigDecimal.ZERO;
		TechnicalCropDtlList techCropList = new TechnicalCropDtlList();
		if((getF_IN_farmType().equals("1")||getF_IN_farmType().equals("3"))&& eachCrop.getStatus().equals("1")){
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(FARM_TYPE_FARM_STATUS_COMB_NOT_ALLOWED, new Object[] {},
					LOG, env);
		}
		if(eachCrop.getCropType().equals("13")&&eachCrop.getForPalm().equals(CommonConstants.EMPTY_STRING)) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(CROP_TYPE_FOR_PALM_MANDATORY, new Object[] {},
					LOG, env);
		}
		int count = 0;
		if (technicalCropListInput.getTechnicalCropDtlList().length > 0) {
			for (int i = 0; i < technicalCropListInput.getTechnicalCropDtlListCount(); i++) {

				// get all the totals from grid data
				totalAreaForAllCrops = totalAreaForAllCrops
						.add(new BigDecimal(technicalCropListInput.getTechnicalCropDtlList(i).getArea()));
				if (technicalCropListInput.getTechnicalCropDtlList(i).getCropType()
						.equals(eachCrop.getCropType())) {
					count++; // grid already contains the crop category id
					totalAreaForAllCrops = totalAreaForAllCrops
							.subtract(new BigDecimal(technicalCropListInput.getTechnicalCropDtlList(i).getArea()))
							.add(new BigDecimal(eachCrop.getArea()));
					techCropList.addTechnicalCropDtlList(eachCrop);

				} else {

					techCropList.addTechnicalCropDtlList(i, technicalCropListInput.getTechnicalCropDtlList(i));
				}

			}
		}
		if (count == 0) {
			for (int i = 0; i < techCropList.getTechnicalCropDtlListCount(); i++) {
				validateCropCategoryId(techCropList.getTechnicalCropDtlList(i).getCropType(), eachCrop.getCropType(),
						env);
			}
			// grid + new area
			totalAreaForAllCrops = totalAreaForAllCrops.add(new BigDecimal(eachCrop.getArea()));
			techCropList.addTechnicalCropDtlList(eachCrop);
		}

		// setting the same totals to each row
		for (int i = 0; i < techCropList.getTechnicalCropDtlListCount(); i++) {
			TechnicalCropDtl vTechnicalCropDtlList = new TechnicalCropDtl();
			vTechnicalCropDtlList = techCropList.getTechnicalCropDtlList(i);
			vTechnicalCropDtlList.setTotalAreaForAlCrop(totalAreaForAllCrops.toString());
			techCropList.setTechnicalCropDtlList(i, vTechnicalCropDtlList);
		}

		setF_OUT_technicalCropDtlListOutput(techCropList);
	}

	private void validateCropCategoryId(String categoryFromGrid, String newCategory, BankFusionEnvironment env) {

		if (categoryFromGrid.equals(newCategory))
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(CROP_CATEGORY_ID_CANNOT_BE_SAME, new Object[] {},
					LOG, env);
	}

}
