/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchTxnNationalIDMap;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_ReverseLoanRepayments;
import com.ce.financialgateway.BatchCollectionConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.fbe.common.util.CommonUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepaymentHistory;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.spi.types.messages.CancelRepaymentRq;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.DealIDInput;

/**
 * @author Aklesh
 *
 */
public class ReverseLoanRepayments extends AbstractCE_ADF_ReverseLoanRepayments {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String WHERE_CLAUSE = "WHERE " + IBOCE_ADF_BatchTxnNationalIDMap.BATCHID+"=? AND " +IBOCE_ADF_BatchTxnNationalIDMap.LOANACCOUNTID + "=?";
	private static final String DEAL_DETAILS_WHERE_CLAUSE = "WHERE " + IBOIB_DLI_DealDetails.DealAccountId+"=?";
	private static final String REPAY_HIST_WHERE_CLAUSE = "WHERE " + IBOLoanRepaymentHistory.ACCOUNTID+"=? ORDER BY "+IBOLoanRepaymentHistory.PAYMENTDTTM+" DESC";
	public ReverseLoanRepayments(BankFusionEnvironment env) {
		super(env);

	}

	public ReverseLoanRepayments() {
		super();
	}

	@Override
	public void process(BankFusionEnvironment env) {
		//TODO: Need to check transactionID matching with last repayment done.
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String batchRecId = getF_IN_batchRecId();
		String batchreference = getF_IN_batchReference();
		String loanAccountID = getF_IN_loanAccountID();
		String dealID = CommonConstants.EMPTY_STRING;
		ArrayList params = new ArrayList<>();
		params.add(batchRecId);
		params.add(loanAccountID);
		List<IBOCE_ADF_BatchTxnNationalIDMap> nationalIDMaps = factory.findByQuery(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, WHERE_CLAUSE, params, null, true);
		
		ArrayList param = new ArrayList<>();
		param.add(loanAccountID);
		List<IBOLoanRepaymentHistory> repayHistory = factory.findByQuery(IBOLoanRepaymentHistory.BONAME, REPAY_HIST_WHERE_CLAUSE, param, null, true);
		if(repayHistory!=null && nationalIDMaps!=null) {
			if(!repayHistory.get(0).getF_TRANSACTIONID().equals(nationalIDMaps.get(0).getF_TRANSACTIONID())) {
				CommonUtil.handleUnParameterizedEvent(44000803);
			}
		}
		
		param.clear();
		param.add(loanAccountID);
		List<IBOIB_DLI_DealDetails> dealDetails = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, DEAL_DETAILS_WHERE_CLAUSE, param, null, true);
		
		if(dealDetails!=null) {
			dealID = dealDetails.get(0).getBoID();
		}
		
        CancelRepaymentRq cancelRepaymentRq = new CancelRepaymentRq();
        DealIDInput dealIdInput = new DealIDInput();
        dealIdInput.setDealID(dealID);
        dealIdInput.setDealBranch("");
        dealIdInput.setSubProductID("");
        AccountInput dealAccountInput = new AccountInput();
        dealAccountInput.setAccountID(loanAccountID);
        dealAccountInput.setAccountFormatType("STA");
        cancelRepaymentRq.setDealID(dealIdInput);
        cancelRepaymentRq.setLoanAccountNo(dealAccountInput);
        //cancelRepaymentRq.setTransactionID(transactionId);

        HashMap<String, Object> inputParams = new HashMap<String, Object>();
        inputParams.put("cancelRepaymentRq", cancelRepaymentRq);
        MFExecuter.executeMF("IB_SPI_ReverseLoanRepayment_SRV", env, inputParams);
    
		
		for (IBOCE_ADF_BatchTxnNationalIDMap iboce_ADF_BatchTxnNationalIDMap : nationalIDMaps) {
			iboce_ADF_BatchTxnNationalIDMap.setF_DUEAMOUNTPAID(BigDecimal.ZERO);
			iboce_ADF_BatchTxnNationalIDMap.setF_PROCESS(false);
			iboce_ADF_BatchTxnNationalIDMap.setF_TRANSACTIONID(CommonConstants.EMPTY_STRING);
		}
		IBOCE_BATCHTXNDETAIL batchTxn = (IBOCE_BATCHTXNDETAIL) factory.findByPrimaryKey(IBOCE_BATCHTXNDETAIL.BONAME, batchRecId, true);
		batchTxn.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PARTPROCESSED);
		batchTxn.setF_PROCESSING("N");
		IBOCE_BATCHFILEDETAIL batchFile = (IBOCE_BATCHFILEDETAIL) factory.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, batchreference, true);
		batchFile.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PARTPROCESSED);
		CommonUtil.handleUnParameterizedEvent(44000801);
	}
}