/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import static com.misys.bankfusion.util.IBCommonUtils.STRING_N;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetVendorNameById;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TPT_ThirdPartyDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TPT_ThirdPartyTypeDetails;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.party.impl.PartyServiceImpl;
import com.misys.ib.party.service.IPartyService;
import com.misys.party.api.utils.PartyDetailsDTO;
import com.misys.party.api.utils.PartyServiceImplConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * @author chethabn
 *
 */
public class GetVendorNameById extends AbstractCE_IB_GetVendorNameById {

	private static final long serialVersionUID = 7137308733675905581L;

	public GetVendorNameById(BankFusionEnvironment env) {
		super(env);

	}

	public GetVendorNameById() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String vendorId = getF_IN_vendorId();
		if (StringUtils.isEmpty(vendorId)) {
			String[] msgArgss = { vendorId };
			IBCommonUtils.raiseParametrizedEvent(40312223, msgArgss);
		}
		setF_OUT_vendorName(getPartyNameByID(vendorId));
		setF_OUT_vendorTypeName(getVendorName(vendorId));

	}

	public String getPartyNameByID(String vendorId) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_TPT_ThirdPartyDetails details= (IBOIB_TPT_ThirdPartyDetails) factory.findByPrimaryKey(IBOIB_TPT_ThirdPartyDetails.BONAME, vendorId, true);
		if(details==null) {
			IBCommonUtils.raiseUnparameterizedEvent(35100069);
		}
		String partyId = (details).getF_INTERNALPARTYID();
		IPartyService partySrv = new PartyServiceImpl();
		PartyDetailsDTO partyDtls = partySrv.readParty(partyId, STRING_N,
				PartyServiceImplConstants.PARTY_DETAILS_IDENTIFIER);
		return partyDtls.getPartyBasicDetails().getShortName();
	}

	public String getVendorName(String vendorId) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(vendorId);

		String result = StringUtils.EMPTY;

		String query = "SELECT tpd." + IBOIB_TPT_ThirdPartyTypeDetails.THIRDPARTYTYPENAME + " AS "
				+ IBOIB_TPT_ThirdPartyTypeDetails.THIRDPARTYTYPENAME + " from " + IBOIB_TPT_ThirdPartyTypeDetails.BONAME
				+ " as tpd where tpd." + IBOIB_TPT_ThirdPartyTypeDetails.THIRDPARTYTYPEID + " = (select tp."
				+ IBOIB_TPT_ThirdPartyDetails.THIRDPARTYTYPE + " from " + IBOIB_TPT_ThirdPartyDetails.BONAME
				+ " as tp where tp." + IBOIB_TPT_ThirdPartyDetails.THIRDPARTYDETAILSID + " = ?)";
		List<SimplePersistentObject> resultSet = factory.executeGenericQuery(query, params, null, false);

		if (!resultSet.isEmpty()) {
			for (SimplePersistentObject obj : resultSet) {
			result = (String) obj.getDataMap().get(IBOIB_TPT_ThirdPartyTypeDetails.THIRDPARTYTYPENAME);
			}
		}
		return result;
	}
}
