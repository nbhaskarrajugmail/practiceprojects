package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ApplyInstOnCustomizedSchedule;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.bankfusion.ib.util.ScheduleUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.CeAssetProfile;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class ApplyInstOnCustomizedSchedule extends AbstractCE_IB_ApplyInstOnCustomizedSchedule {

	public ApplyInstOnCustomizedSchedule() {
	}

	public ApplyInstOnCustomizedSchedule(BankFusionEnvironment env) {
		super(env);
	}

	private static final Log LOGGER = LogFactory.getLog(ApplyInstOnCustomizedSchedule.class);

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		if (!IBCommonUtils.isNullOrEmpty(getF_IN_mode())) {
			LOGGER.info("Applying instructions on customized schedule with mode: " + getF_IN_mode());
			truncateDecimals();
			switch (getF_IN_mode()) {
			case "ADD":
				addRepayment();
				break;
			case "DELETE":
				deleteRepayment();
				break;
			case "SAVE":
				saveRepayment();
				break;
			case "SELECT":
				selectRepayment();
				break;
			}
			setF_OUT_dealRescheduleDetails(getF_IN_dealRescheduleDetails());
			setF_OUT_newNoOfInstallments(getF_IN_dealRescheduleDetails().getNewScheduleCount());
			setF_OUT_reschedulePaymentDate(getF_IN_dealRescheduleDetails().getNewSchedule(0).getRepaymentDate());
		}
	}

	private void truncateDecimals() {
		if(getF_IN_paymentSchedule() != null) {
			if(getF_IN_paymentSchedule().getPrincipalAmount() != null) {
				BigDecimal principalAmount = new BigDecimal(getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount().intValue());
				getF_IN_paymentSchedule().getPrincipalAmount().setCurrencyAmount(principalAmount);
			}
			
			if(getF_IN_paymentSchedule().getProfitAmount() != null) {
				BigDecimal profitAmount = new BigDecimal(getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount().intValue());
				getF_IN_paymentSchedule().getProfitAmount().setCurrencyAmount(profitAmount);
			}
			
			if(getF_IN_paymentSchedule().getFeesAmount() != null) {
				BigDecimal feesAmount = new BigDecimal(getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount().intValue());
				getF_IN_paymentSchedule().getFeesAmount().setCurrencyAmount(feesAmount);
			}
			
			if(getF_IN_paymentSchedule().getSubsidyAmount() != null) {
				BigDecimal subsidyAmount = new BigDecimal(getF_IN_paymentSchedule().getSubsidyAmount().getCurrencyAmount().intValue());
				getF_IN_paymentSchedule().getSubsidyAmount().setCurrencyAmount(subsidyAmount);
			}
			
			if(getF_IN_paymentSchedule().getTotalRepaymentAmount() != null) {
				BigDecimal totalRepaymentAmount = new BigDecimal(getF_IN_paymentSchedule().getTotalRepaymentAmount().getCurrencyAmount().intValue());
				getF_IN_paymentSchedule().getTotalRepaymentAmount().setCurrencyAmount(totalRepaymentAmount);
			}
		}
	}

	private void selectRepayment() {
		if (getF_IN_dealRescheduleDetails() != null && getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0) {
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				if (paymentSchedule.getSelect()) {
					setF_OUT_paymentSchedule(paymentSchedule);
				}
			}
		}
	}

	private void saveRepayment() {
		LOGGER.info("Applying Save instruction on customized schedule : begin");
		validateInputs();
		if (getF_IN_dealRescheduleDetails() != null && getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0) {
			boolean sameDateRepExists = false;
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				if (!CalendarUtil.isDateNullOrDefaultDate(paymentSchedule.getRepaymentDate())
						&& CalendarUtil.IsDate1EqualsToDate2(getF_IN_paymentSchedule().getRepaymentDate(),
								paymentSchedule.getRepaymentDate())) {
					sameDateRepExists = true;
				}
				if (!CalendarUtil.isDateNullOrDefaultDate(paymentSchedule.getRepaymentDate())
						&& paymentSchedule.isSelect()) {
					paymentSchedule.setFeesAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
					paymentSchedule
							.setPrincipalAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
					paymentSchedule
							.setProfitAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
					paymentSchedule
							.setSubsidyAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
					paymentSchedule.setTotalRepaymentAmount(
							CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
                    if (!CalendarUtil.IsDate1EqualsToDate2(getF_IN_paymentSchedule().getRepaymentDate(),
                            paymentSchedule.getRepaymentDate())) {
                        for (CeAssetProfile assetProfileDetails : getF_IN_dealRescheduleDetails().getAssetProfileDetails()
                                .getAssetProfileList()) {
                            for (int j = 0; j < getF_IN_dealRescheduleDetails().getAssetProfileDetails()
                                    .getAssetBasedPaymentScheduleCount(); j++) {
                                if (getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetBasedPaymentSchedule(j)
                                        .getAssetId().equals(assetProfileDetails.getAssetId())
                                        && CalendarUtil.IsDate1EqualsToDate2(
                                                getF_IN_dealRescheduleDetails().getAssetProfileDetails()
                                                        .getAssetBasedPaymentSchedule(j).getRepaymentDate(),
                                                        paymentSchedule.getRepaymentDate())) {
                                    getF_IN_dealRescheduleDetails().getAssetProfileDetails().removeAssetBasedPaymentScheduleAt(j);
                                    break;
                                }
                            }
                        }
                    }
					    
					
				}
			}

			updateAssetBasedPaymentSchedule(sameDateRepExists);

			addToExistingRepayment();
			ArrayList<CePaymentSchedule> list = new ArrayList<>();
			for(CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				list.add(paymentSchedule);
			}
			//sorting the schedule 
			com.ce.bankfusion.ib.util.ScheduleUtils.sortCEPaymentSchedule(list);
			getF_IN_dealRescheduleDetails().removeAllNewSchedule();
			if(!list.isEmpty()) {
				int repaymentNo = 1;
				for(CePaymentSchedule cePaymentSchedule : list) {
					cePaymentSchedule.setSelect(false);
					if(CalendarUtil.IsDate1EqualsToDate2(getF_IN_paymentSchedule().getRepaymentDate(), cePaymentSchedule.getRepaymentDate()))
						cePaymentSchedule.setSelect(true);
					cePaymentSchedule.setRepaymentNo(repaymentNo);
					getF_IN_dealRescheduleDetails().addNewSchedule(cePaymentSchedule);
					++repaymentNo;
				}
			}
			
			LOGGER.info("Applying Save instruction on customized schedule : end");
		}
	}

	private void updateAssetBasedPaymentSchedule(boolean sameDateRepExists) {
		LOGGER.info("Updating hidden grids on applying the instruction on customized schedule : begin");
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		if (getF_IN_paymentSchedule() != null
				&& getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetBasedPaymentScheduleCount() > 0) {
			ReadAssetData readAssetData = CeUtils.readAssetData(getF_IN_islamicBankingObject());
			BigDecimal assetSubsidyPercentage = BigDecimal.ZERO;
			String assetSubsidyPercentageStr = CommonConstants.EMPTY_STRING;
			BigDecimal repaymentPrincipalAmnt = getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount();
			BigDecimal repaymentProfitAmnt = getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount();
			BigDecimal repaymentFeeAmnt = getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount();
			BigDecimal assetRepaymentFeesAmount = repaymentFeeAmnt.divide(new BigDecimal(
					getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetBasedPaymentScheduleCount()), 0,
					RoundingMode.FLOOR);
			BigDecimal totalRepaymentAmount = getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount()
					.add(getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount())
					.add(getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount());
			int i = 1;
			for (CeAssetProfile assetProfileDetails : getF_IN_dealRescheduleDetails().getAssetProfileDetails()
					.getAssetProfileList()) {
				assetSubsidyPercentageStr = CeUtils.getAssetSubsidyPercentage(readAssetData,
						assetProfileDetails.getAssetId());
				if (!IBCommonUtils.isNullOrEmpty(assetSubsidyPercentageStr)) {
					assetSubsidyPercentage = new BigDecimal(assetSubsidyPercentageStr);
				}

				AssetBasedPaymentSchedule assetBasedPaymentSchedule = new AssetBasedPaymentSchedule();
				assetBasedPaymentSchedule.setAssetId(assetProfileDetails.getAssetId());
				assetBasedPaymentSchedule.setRepaymentDate(getF_IN_paymentSchedule().getRepaymentDate());
				assetBasedPaymentSchedule
						.setPrincipalAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				assetBasedPaymentSchedule
						.setProfitAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				assetBasedPaymentSchedule
						.setScheduleFeesAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				assetBasedPaymentSchedule
						.setSubsidyAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				assetBasedPaymentSchedule
				.setTotalRepaymentAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				if (i != getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetProfileListCount()) {
					BigDecimal assetPrincipalAmnt = (repaymentPrincipalAmnt
							.multiply(assetProfileDetails.getPrincipalPercentageOfTotalPrincipal()))
							.divide(ScheduleUtils.hundred, 0, RoundingMode.HALF_EVEN);
					BigDecimal assetProfitAmnt = (repaymentProfitAmnt
							.multiply(assetProfileDetails.getProfitPercentageOfTotalProfit()))
							.divide(ScheduleUtils.hundred, 0, RoundingMode.HALF_EVEN);
					assetBasedPaymentSchedule.getPrincipalAmount().setCurrencyAmount(assetPrincipalAmnt);
					assetBasedPaymentSchedule.getProfitAmount().setCurrencyAmount(assetProfitAmnt);
					assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(assetRepaymentFeesAmount);
				} else {
					assetBasedPaymentSchedule.getPrincipalAmount().setCurrencyAmount(repaymentPrincipalAmnt);
					assetBasedPaymentSchedule.getProfitAmount().setCurrencyAmount(repaymentProfitAmnt);
					assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(repaymentFeeAmnt);
				}
				if (getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().isIncludeSubsidy()
						&& assetSubsidyPercentage.compareTo(BigDecimal.ZERO) > 0) {
					assetBasedPaymentSchedule.getSubsidyAmount()
							.setCurrencyAmount((assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount()
									.multiply(assetSubsidyPercentage)).divide(ScheduleUtils.hundred, 0,
											RoundingMode.UP));
				} else {
					assetBasedPaymentSchedule
							.setSubsidyAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				}

				assetBasedPaymentSchedule.getTotalRepaymentAmount().setCurrencyAmount(totalRepaymentAmount);
				repaymentPrincipalAmnt = repaymentPrincipalAmnt
						.subtract(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount());
				repaymentProfitAmnt = repaymentProfitAmnt
						.subtract(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount());
				repaymentFeeAmnt = repaymentFeeAmnt.subtract(assetRepaymentFeesAmount);
				subsidyAmount = subsidyAmount.add(assetBasedPaymentSchedule.getSubsidyAmount().getCurrencyAmount());
				++i;

				if (sameDateRepExists) {
					for (int j = 0; j < getF_IN_dealRescheduleDetails().getAssetProfileDetails()
							.getAssetBasedPaymentScheduleCount(); j++) {
						if (getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetBasedPaymentSchedule(j)
								.getAssetId().equals(assetProfileDetails.getAssetId())
								&& CalendarUtil.IsDate1EqualsToDate2(
										getF_IN_dealRescheduleDetails().getAssetProfileDetails()
												.getAssetBasedPaymentSchedule(j).getRepaymentDate(),
										getF_IN_paymentSchedule().getRepaymentDate())) {
							getF_IN_dealRescheduleDetails().getAssetProfileDetails()
									.removeAssetBasedPaymentScheduleAt(j);
							break;
						}
					}
				}
				getF_IN_dealRescheduleDetails().getAssetProfileDetails()
						.addAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
			}
		}
		getF_IN_paymentSchedule().getSubsidyAmount().setCurrencyAmount(subsidyAmount);
		LOGGER.info("Updating hidden grids on applying the instruction on customized schedule : end");
	}

	private void addToExistingRepayment() {
		BigDecimal totalRepaymentAmount;
		boolean existingModification = false;
		int repayNumGettingModified = 0;
		for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
			if (!CalendarUtil.isDateNullOrDefaultDate(paymentSchedule.getRepaymentDate())
					&& CalendarUtil.IsDate1EqualsToDate2(paymentSchedule.getRepaymentDate(),
							getF_IN_paymentSchedule().getRepaymentDate())) {
				existingModification = true;
				repayNumGettingModified = paymentSchedule.getRepaymentNo();
			}
		}

		for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
			if ((existingModification && CalendarUtil.IsDate1EqualsToDate2(paymentSchedule.getRepaymentDate(),
					getF_IN_paymentSchedule().getRepaymentDate())) || paymentSchedule.isSelect()) {
				paymentSchedule.getPrincipalAmount()
						.setCurrencyAmount(getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount());
				paymentSchedule.getProfitAmount()
						.setCurrencyAmount(getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount());
				paymentSchedule.getFeesAmount()
						.setCurrencyAmount(getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount());
				totalRepaymentAmount = paymentSchedule.getPrincipalAmount().getCurrencyAmount()
						.add(paymentSchedule.getProfitAmount().getCurrencyAmount())
						.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
				paymentSchedule.getSubsidyAmount().setCurrencyAmount(paymentSchedule.getSubsidyAmount()
						.getCurrencyAmount().add(getF_IN_paymentSchedule().getSubsidyAmount().getCurrencyAmount()));
				paymentSchedule.getTotalRepaymentAmount().setCurrencyAmount(totalRepaymentAmount);
				paymentSchedule.setRepaymentDate(getF_IN_paymentSchedule().getRepaymentDate());
				break;
			}
		}
		if (existingModification) {
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				if (CalendarUtil.isDateNullOrDefaultDate(paymentSchedule.getRepaymentDate()))
					getF_IN_dealRescheduleDetails().removeNewSchedule(paymentSchedule);
				if (paymentSchedule.getRepaymentNo() == repayNumGettingModified)
					paymentSchedule.setSelect(true);
				else
					paymentSchedule.setSelect(false);
			}
		}
	}

	private void validateInputs() {
		LOGGER.info("validating inputs on save instruction: begin");
		if (getF_IN_paymentSchedule() != null) {
			BigDecimal scheduledPrincipalAmount = BigDecimal.ZERO;
			BigDecimal scheduledProfitAmount = BigDecimal.ZERO;
			BigDecimal scheduledFeesAmount = BigDecimal.ZERO;

			BigDecimal remPrincipalAmount = BigDecimal.ZERO;
			BigDecimal remProfitAmount = BigDecimal.ZERO;
			BigDecimal remFeesAmount = BigDecimal.ZERO;
			BigDecimal outstandingFees = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
					.getScheduleFeesAmount().getCurrencyAmount().add(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
					.getOutstandingFees().getCurrencyAmount());

			// validating if date field is blank
			if (CalendarUtil.isDateNullOrDefaultDate(getF_IN_paymentSchedule().getRepaymentDate()))
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DATE_CANNOT_BE_BLANK_CE_IB);
			/*if(CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), getF_IN_paymentSchedule().getRepaymentDate()))
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCHEDULE_INST_DATE_MIN_VALID_CEIB);*/
			RescheduleUtils.validateReschedulePaymentDate(getF_IN_paymentSchedule().getRepaymentDate());
			// validating if any of the amount fields is blank
			if (getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) == 0) {
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_VALIDATE_AMNTS_ON_SAVE_INST_CEIB);
			}

			if (getF_IN_dealRescheduleDetails() != null && getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0) {
				for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
					if (!paymentSchedule.isSelect()) {
						scheduledPrincipalAmount = scheduledPrincipalAmount
								.add(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
						scheduledProfitAmount = scheduledProfitAmount
								.add(paymentSchedule.getProfitAmount().getCurrencyAmount());
						scheduledFeesAmount = scheduledFeesAmount
								.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
					}
				}
			}
			remPrincipalAmount = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinPrincipal()
					.getCurrencyAmount().subtract(scheduledPrincipalAmount);
			remProfitAmount = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinProfit()
					.getCurrencyAmount().subtract(scheduledProfitAmount);
			remFeesAmount = outstandingFees.subtract(scheduledFeesAmount);
			// validating principal amount
			if (getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyAmount().compareTo(remPrincipalAmount) > 0) {
				String[] msgArgs = { remPrincipalAmount.toString(),
						getF_IN_paymentSchedule().getPrincipalAmount().getCurrencyCode() };
				IBCommonUtils.raiseParametrizedEvent(CeConstants.E_SCHEDULE_PRINCIPAL_AMOUNT_MAX_VALID_CEIB, msgArgs);
			}
			// validating profit amount
			if (getF_IN_paymentSchedule().getProfitAmount().getCurrencyAmount().compareTo(remProfitAmount) > 0) {
				String[] msgArgs = { remProfitAmount.toString(),
						getF_IN_paymentSchedule().getProfitAmount().getCurrencyCode() };
				IBCommonUtils.raiseParametrizedEvent(CeConstants.E_SCHEDULE_PROFIT_AMOUNT_MAX_VALID_CEIB, msgArgs);
			}
			// validating fees amount
			if (getF_IN_paymentSchedule().getFeesAmount().getCurrencyAmount().compareTo(remFeesAmount) > 0) {
				String[] msgArgs = { remFeesAmount.toString(),
						getF_IN_paymentSchedule().getFeesAmount().getCurrencyCode() };
				IBCommonUtils.raiseParametrizedEvent(CeConstants.E_SCHEDULE_FEES_AMOUNT_MAX_VALID_CEIB, msgArgs);
			}
		}
		LOGGER.info("validating inputs on save instruction: end");
	}

	private void deleteRepayment() {
		LOGGER.info("Applying Delete instruction on customized schedule : begin");
		CePaymentSchedule cePaymentSchedule = null;
		int rowIndex = 0;
		if (getF_IN_dealRescheduleDetails() != null && getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0) {
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				if (paymentSchedule.getSelect()) {
					rowIndex = paymentSchedule.getRepaymentNo();
					cePaymentSchedule = paymentSchedule;
					getF_IN_dealRescheduleDetails().removeNewSchedule(paymentSchedule);
				}
			}
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				if (paymentSchedule.getRepaymentNo() == rowIndex - 1) {
					paymentSchedule.setSelect(true);
				}
			}
			// correcting the repayment no
			int newRepaymentNo = 1;
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				paymentSchedule.setRepaymentNo(newRepaymentNo);
				++newRepaymentNo;
			}
			// deleting the repayment from asset based payment schedule
			if (!CalendarUtil.isDateNullOrDefaultDate(cePaymentSchedule.getRepaymentDate())
					&& getF_IN_dealRescheduleDetails().getAssetProfileDetails() != null
					&& getF_IN_dealRescheduleDetails().getAssetProfileDetails()
							.getAssetBasedPaymentScheduleCount() > 0) {
				for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_dealRescheduleDetails()
						.getAssetProfileDetails().getAssetBasedPaymentSchedule()) {
					if (cePaymentSchedule != null && CalendarUtil.IsDate1EqualsToDate2(
							cePaymentSchedule.getRepaymentDate(), assetBasedPaymentSchedule.getRepaymentDate())) {
						getF_IN_dealRescheduleDetails().getAssetProfileDetails()
								.removeAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
					}
				}
			}
		}
		LOGGER.info("Applying Delete instruction on customized schedule : end");
	}

	private void addRepayment() {
		LOGGER.info("Applying Add instruction on customized schedule : begin");
		BigDecimal totalPrincipalAmount = BigDecimal.ZERO;
		BigDecimal totalProfitAmount = BigDecimal.ZERO;
		BigDecimal totalFeesAmount = BigDecimal.ZERO;
		BigDecimal outstandingFees = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
						.getScheduleFeesAmount().getCurrencyAmount().add(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
						.getOutstandingFees().getCurrencyAmount());
		if (getF_IN_dealRescheduleDetails() != null && getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0) {
			for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
				totalPrincipalAmount = totalPrincipalAmount
						.add(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
				totalProfitAmount = totalProfitAmount.add(paymentSchedule.getProfitAmount().getCurrencyAmount());
				totalFeesAmount = totalFeesAmount.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
			}
			if (totalPrincipalAmount
					.compareTo(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinPrincipal()
							.getCurrencyAmount()) == 0
					&& totalProfitAmount.compareTo(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
							.getOutstandinProfit().getCurrencyAmount()) == 0
					&& totalFeesAmount.compareTo(outstandingFees) == 0) {
				// validating if there is any outstanding amounts left
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_OUTSTANDING_AMNT_LEFT_CEIB);
				setF_OUT_displayInstructionScalars(false);
			} else {
				setF_OUT_displayInstructionScalars(true);
				for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
					paymentSchedule.setSelect(false);
				}
				CePaymentSchedule cePaymentSchedule = new CePaymentSchedule();
				cePaymentSchedule.setRepaymentNo(getF_IN_dealRescheduleDetails().getNewScheduleCount() + 1);
				cePaymentSchedule.setFeesAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				cePaymentSchedule.setPrincipalAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				cePaymentSchedule.setProfitAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				cePaymentSchedule.setSubsidyAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				cePaymentSchedule.setTotalRepaymentAmount(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
				cePaymentSchedule.setSelect(true);
				// adding empty row to grid
				getF_IN_dealRescheduleDetails().addNewSchedule(getF_IN_dealRescheduleDetails().getNewScheduleCount(),
						cePaymentSchedule);
			}
		}
		LOGGER.info("Applying Add instruction on customized schedule : end");
	}
}
