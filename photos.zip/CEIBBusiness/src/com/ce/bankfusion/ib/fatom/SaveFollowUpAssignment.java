package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import bf.com.misys.followup.ib.types.FollowUpAssignmentCnf;

import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;
import com.trapedza.bankfusion.utils.GUIDGen;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveFollowUpConfList;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;

public class SaveFollowUpAssignment extends AbstractCE_IB_SaveFollowUpConfList {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static final transient Log LOG = LogFactory.getLog(SaveFollowUpAssignment.class.getName());

    public static final int ASSIGNED_SUCCESSFULLY = 44000202;

    public SaveFollowUpAssignment(BankFusionEnvironment env) {
        super(env);

    }

    public SaveFollowUpAssignment() {
        super();

    }

    @Override
    public void process(BankFusionEnvironment env) {

        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        FollowUpAssignmentCnf[] followUpList = getF_IN_followUpConfList().getFollowUpAssignmentCnfDtls();
        String followUpId = "";
        for (FollowUpAssignmentCnf cfg : followUpList) {
            if (cfg.isSelect()) {
                ArrayList<String> params = new ArrayList<String>();
                params.add(cfg.getDealId());
                // check if exists already
                List<IBOCE_IB_FollowUpListConf> existingFollowUpList = factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME,
                    " where " + IBOCE_IB_FollowUpListConf.IBDEALID + " = ? ", params, null, true);
                IBOCE_IB_FollowUpListConf folowUpDtlsObj_Check = existingFollowUpList.size() > 0 ? existingFollowUpList.get(0) : null;
                if (folowUpDtlsObj_Check != null) {
                    folowUpDtlsObj_Check.setF_IBFOLLOWUPBRANCH(cfg.getFollowUpBranch());
                    folowUpDtlsObj_Check.setF_IBINSPECTORNAME(cfg.getInspectorName());
                    BusinessEventSupport.getInstance().raiseBusinessInfoEvent(ASSIGNED_SUCCESSFULLY, new Object[] {}, LOG, env);
                    RaiseFollowUpNotification followUpNotification = new RaiseFollowUpNotification();
                    followUpNotification.raiseNotification(cfg.getInspectorName(),cfg.getLoanAccountID());
                }
                else {
                    IBOCE_IB_FollowUpListConf followUpNewCfg =
                        (IBOCE_IB_FollowUpListConf) factory.getStatelessNewInstance(IBOCE_IB_FollowUpListConf.BONAME);
                    followUpId = GUIDGen.getNewGUID();
                    followUpNewCfg.setBoID(followUpId);
                    followUpNewCfg.setF_IBCURRENTFOLLOWUPSTATUS(cfg.getCurrentFollowUpStatus());
                    followUpNewCfg.setF_IBCUSTOMERID(cfg.getCustomerId());
                    followUpNewCfg.setF_IBCUSTOMERNAME(cfg.getCustomerName());
                    followUpNewCfg.setF_IBDEALID(cfg.getDealId());
                    followUpNewCfg.setF_IBDEALBRANCH(cfg.getDealBranch());
                    followUpNewCfg.setF_IBINSPECTORNAME(cfg.getInspectorName());
                    followUpNewCfg.setF_IBLASTFOLLOWUPDATE(cfg.getLastFollowUpDate());
                    followUpNewCfg.setF_IBPROCESSNAME(cfg.getProcessName());
                    followUpNewCfg.setF_IBSUBPRODUCTNAME(cfg.getSubProductName());
                    followUpNewCfg.setF_IBFOLLOWUPBRANCH(cfg.getFollowUpBranch());
                    factory.create(IBOCE_IB_FollowUpListConf.BONAME, followUpNewCfg);
                    BusinessEventSupport.getInstance().raiseBusinessInfoEvent(ASSIGNED_SUCCESSFULLY, new Object[] {}, LOG, env);
                    RaiseFollowUpNotification followUpNotification = new RaiseFollowUpNotification();
                    followUpNotification.raiseNotification(cfg.getInspectorName(),cfg.getLoanAccountID());
                }
            }
        }
    }
}
