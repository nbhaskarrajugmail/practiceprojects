package com.ce.bankfusion.ib.fatom;

import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidationConfScreenHandler;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.ib.types.ManageAssignUserGroup;
import bf.com.misys.ib.types.ManageAssignUserGroupList;
import bf.com.misys.ib.types.Validation;
import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationList;

public class ValidationConfScreenHandler extends AbstractCE_IB_ValidationConfScreenHandler{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5458939055544326380L;

	public ValidationConfScreenHandler()
	{
		super();
	}

	public ValidationConfScreenHandler(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();

		switch(context)
		{
		case "LIST_VALIDATIONS" :
			listValidations();
			break;
		case "LIST_PROCESS" :
			listProcesses();
			break;
		case "LIST_STEP" :
			listStepForTheProcess();
			break;
		case "LIST_ALL_STEP" :
			listAllTheSteps();
			break;
		case "GET_VALIDATION_DESC" :
			getValidationDesc();
			break;
		case "SEARCH_USER" :
			processUserSearchResult();
			break;
		case "ACTION_LIST_APPROVAL" :
			getActionGCListForApproval();
			break;
		case "ACTION_TYPE_SELECT" :
			disableAndResetFields();
			break;
		default:
			break;
		}
	}

	private void disableAndResetFields() {
		boolean disablefilterBasedOnBranch = true;
		boolean disableUserSearch = true;
		ValidationConf conf = getF_IN_validationConf();
		if(ValidationExceptionConstants.ACTION_APPROVAL.equals(conf.getActionType()))
		{
			disableUserSearch = false;
			setF_OUT_approverUser(conf.getApprovalUserName());
			setF_OUT_approverUserID(conf.getApprovalUserID());
			setF_OUT_isGroup(null != conf.isIsGroup()?conf.isIsGroup():false);
			if(null != conf.isIsGroup() && conf.isIsGroup())
			{
				disablefilterBasedOnBranch = false;
				setF_OUT_isFilterBasedOnBranch(true);
			}
		}
		else
		{
			setF_OUT_approverUser(CommonConstants.EMPTY_STRING);
			setF_OUT_approverUserID(CommonConstants.EMPTY_STRING);
			setF_OUT_isGroup(false);
			setF_OUT_isFilterBasedOnBranch(false);
		}
		setF_OUT_disableUserSearch(disableUserSearch);
		setF_OUT_disableFilterOnBranch(disablefilterBasedOnBranch);
	}
	
	private void getActionGCListForApproval() {
		setF_OUT_genericCodeListRs(ValidationsUtil.getStatusActionList());
		
	}

	private void processUserSearchResult() {
		ManageAssignUserGroupList userList = getF_IN_userGroupList();
		if(null != userList)
		{
			for (ManageAssignUserGroup user : userList.getManageAssignUserGroup())
			{
				if(user.isSelect())
				{
					setF_OUT_approverUser(user.getUserOrGroupName());
					setF_OUT_approverUserID(user.getUserOrGroupID());
					Boolean isGroup = "Group".equalsIgnoreCase(user.getUserOrGroupType())?true:false;
					setF_OUT_isGroup(isGroup);//isGroup - will be the default value for isFilterBasedOnBranch
					setF_OUT_isFilterBasedOnBranch(isGroup);
					setF_OUT_disableFilterOnBranch(!isGroup);
					break;
				}
			}
		}
		
	}

	private void getValidationDesc() {
		String validationID = getF_IN_validationID();
		Validation validation = ValidationsUtil.getValidation(validationID);
		String description = validation.getDescription();
		setF_OUT_validationDesc(description);
	}

	private void listAllTheSteps() {
		ListGenericCodeRs stepListAll = ValidationsUtil.getAllStepList();
		setF_OUT_genericCodeListRs(stepListAll);
	}

	private void listStepForTheProcess() {
		ListGenericCodeRs stepListForTheProcees = ValidationsUtil.getStepList(getF_IN_processConfigID());
		setF_OUT_genericCodeListRs(stepListForTheProcees);
	}

	private void listProcesses() {
		ListGenericCodeRs proessList = ValidationsUtil.getProcessList();
		setF_OUT_genericCodeListRs(proessList);
	}

	private void listValidations() {
		ValidationList validationList = new ValidationList();
		Map<String, Validation> validations = ValidationsUtil.getValidationList();
		for(String key : validations.keySet())
		{
			validationList.addValidations(validations.get(key));
		}
		setF_OUT_validationList(validationList);
	}
}
