package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PickListForProjectNewTech;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.PickList;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class PickListForProjectNewTech extends AbstractCE_IB_PickListForProjectNewTech{
	
	public PickListForProjectNewTech(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		ListGenericCodeRs projectNewTechGCList = IBCommonUtils.getGCList(CeConstants.PROJECTNEWTECH);
		getF_OUT_pickListCollection().removeAllPickListCollValues();

		if (projectNewTechGCList != null && projectNewTechGCList.getGcCodeDetailsCount() > 0) {
			for (GcCodeDetail gcCodeDetail : projectNewTechGCList.getGcCodeDetails()) {
					PickList pickListItem = CeUtils.getPisckListObject();
					pickListItem.setDescription(gcCodeDetail.getCodeDescription());
					pickListItem.setValues(gcCodeDetail.getCodeReference());
					getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
			}
		}
	}
}
