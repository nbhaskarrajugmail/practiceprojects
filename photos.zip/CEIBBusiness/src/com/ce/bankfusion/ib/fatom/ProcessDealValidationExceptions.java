package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ProcessDealValidationExceptions;
import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.ContextIDs;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.StepNotesCreate;
import bf.com.misys.ib.types.StepNotesCreateRq;

public class ProcessDealValidationExceptions extends AbstractCE_IB_ProcessDealValidationExceptions{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7220598524386138380L;

	public ProcessDealValidationExceptions()
	{
		super();
	}
	
	public ProcessDealValidationExceptions(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ? AND "
				+IBOCE_IB_DealValidations.IBSTEPID + " = ? AND "
				+ IBOCE_IB_DealValidations.IBPROCESSCONFIGID + " = ?";
		String dealID = getF_IN_islamicBankingObject().getDealID();
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		params.add(getF_IN_islamicBankingObject().getStepID());
		params.add(getF_IN_islamicBankingObject().getProcessConfigID());
		List<IBOCE_IB_DealValidations> dealValidationsList = factory.findByQuery(IBOCE_IB_DealValidations.BONAME, whereClause, params, null, false);
		ArrayList<IBOCE_IB_DealValidations> stopList = new ArrayList<>();
		ArrayList<IBOCE_IB_DealValidations> warnigList = new ArrayList<>();
		ArrayList<IBOCE_IB_DealValidations> approvalList = new ArrayList<>();
		for(IBOCE_IB_DealValidations dealValidation : dealValidationsList)
		{
			if(ValidationExceptionConstants.STATUS_PENDING.equals(dealValidation.getF_IBSTATUS()))
			{
				continue;
			}

			IBOCE_IB_ValidationConfiguration conf = ValidationsUtil.getValidationConf(dealValidation.getF_IBVALIDATIONCONFID());

			if(ValidationExceptionConstants.ACTION_STOP.equalsIgnoreCase(conf.getF_IBACTIONTYPE()))
			{
				stopList.add(dealValidation);
			}
			else if(ValidationExceptionConstants.ACTION_WARNING_NOTE.equalsIgnoreCase(conf.getF_IBACTIONTYPE()))
			{
				warnigList.add(dealValidation);
			}
			else
			{
				approvalList.add(dealValidation);
			}
		}
		for(IBOCE_IB_DealValidations dealValidation : stopList)
		{
			IBCommonUtils.raiseParametrizedEvent(ValidationExceptionConstants.E_VALIDATION_STOP_EVENT, new String[] {ValidationsUtil.getValidation(
					ValidationsUtil.getValidationID(dealValidation.getF_IBVALIDATIONCONFID())).getDescription()});
		}
		for(IBOCE_IB_DealValidations dealValidation : warnigList)
		{
			String validationDesc = ValidationsUtil.getValidation(
					ValidationsUtil.getValidationID(dealValidation.getF_IBVALIDATIONCONFID())).getDescription();
			IBCommonUtils.raiseParametrizedEvent(ValidationExceptionConstants.W_VALIDATION_WARNING_EVENT, new String[] {validationDesc});
			dealValidation.setF_RECLASTMODIFIEDDATE(SystemInformationManager.getInstance().getBFBusinessDateTime());
			dealValidation.setF_RECLASTMODIFIEDBY(BankFusionThreadLocal.getUserId());
		}
		HashSet<String> processLaunchedFor = new HashSet<>();
		for(IBOCE_IB_DealValidations dealValidation : approvalList)
		{
			IBOCE_IB_ValidationConfiguration conf = ValidationsUtil.getValidationConf(dealValidation.getF_IBVALIDATIONCONFID());
			String user = conf.getF_IBAPPROVALUSERID();
			String processLaunchFor = new StringBuilder().append(conf.getF_IBAPPROVALUSERID()).
					append(conf.isF_IBGROUP()).append(conf.isF_IBFILTERBYBRANCH()).toString();
			//this if check is to make sure that multiple processes are not assigned to a given user/group
			//in case of multiple validations with same approver user/group
			if(!processLaunchedFor.contains(processLaunchFor))
			{
				//setting the threadLocalAppData
				ContextIDs contextID = new ContextIDs();
				contextID.addConetextID(ValidationExceptionConstants.CI_VALIDATION_CONF_ID+conf.getBoID());
				contextID.addConetextID(ValidationExceptionConstants.CI_ORIG_USER+BankFusionThreadLocal.getUserId());
				BankFusionThreadLocal.setThreadLocalApplicationData(IBConstants.IB_OBJ_CONTEXT_ID_THREADLOCAL_DATA, contextID);
				DealValidationUtil.initiateTheProcess(dealID,user);
				processLaunchedFor.add(processLaunchFor);
			}
			if(ValidationExceptionConstants.STATUS_APPROVED.equals(dealValidation.getF_IBSTATUS()))
			{
				dealValidation.setF_IBREAPPROVAL(true);
			}
			dealValidation.setF_IBSTATUS(ValidationExceptionConstants.STATUS_PENDING);
			dealValidation.setF_RECLASTMODIFIEDDATE(SystemInformationManager.getInstance().getBFBusinessDateTime());
			dealValidation.setF_RECLASTMODIFIEDBY(BankFusionThreadLocal.getUserId());
		}
	}
	
}
