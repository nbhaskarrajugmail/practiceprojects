package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateAssetCost;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class ValidateAssetCost extends AbstractCE_IB_ValidateAssetCost {
	private static final long serialVersionUID = -2637816799576358202L;
	private static final transient Log LOG = LogFactory.getLog(ValidateAssetCost.class.getName());
	private static final int TOTAL_COST_CANT_EXCEED_TOTAL_AGREED_FINANCE_AMT = 44000230;

	public ValidateAssetCost(BankFusionEnvironment env) {
		super(env);
	}

	public ValidateAssetCost() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String dealId = getF_IN_dealId();
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
		BigDecimal oldPrincipalAmount = BigDecimal.ZERO;
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		String gridData = getF_IN_gridData();
		if (!StringUtils.isEmpty(dealDtls.getF_DealAccountId())) {
			oldPrincipalAmount = dealDtls.getF_PrincipleAmt();
			String[] arr = gridData.split("\\|");
			for (int i = 0; i < arr.length; i++) {
				String[] assetIdAndCost = arr[i].split("\\,");
				String eachAssetCost = assetIdAndCost[1];
				BigDecimal eachAssetCostAmt = new BigDecimal(eachAssetCost);
				totalAssetCost = totalAssetCost.add(eachAssetCostAmt);
			}
		}

		setF_OUT_totalAssetCost(totalAssetCost);
		setF_OUT_oldPrincipalCost(oldPrincipalAmount);
		
		  if(totalAssetCost.compareTo(oldPrincipalAmount)>0) { 
			  //The user can add new assets and remove assets, but the total price should not exceed the total agreed Finance amount
			  setF_OUT_isAssetCostGreaterThanPrincipalAmt(true);
		 }
		  else {
			  setF_OUT_isAssetCostGreaterThanPrincipalAmt(false);
		  }
		 
	}
}
