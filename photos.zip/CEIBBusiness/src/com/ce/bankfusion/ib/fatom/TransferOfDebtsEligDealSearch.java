package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TrnsDebtsEligDealSearch;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.ListTrnsfDbtsElgDealsRq;
import bf.com.misys.ib.types.ListTrnsfDbtsElgDealsRs;
import bf.com.misys.ib.types.TrnsfDbtsElgDeal;
import bf.com.misys.party.ws.ReadPartyWSRq;
import bf.com.misys.party.ws.ReadPartyWSRs;

public class TransferOfDebtsEligDealSearch extends AbstractCE_IB_TrnsDebtsEligDealSearch{

	/**
	 * 
	 */
	
	//dealInvalidStatuses = IBConstants.CLOSED,IBConstants.CANCELLED,CeConstants.DEAL_STATUS_EXPIRED,IBConstants.REJECTED
	private static final long serialVersionUID = 3301554624408480061L;
	private static final transient Log LOG = LogFactory.getLog(TransferOfDebtsEligDealSearch.class.getName());
	private static final String selectQuery = "SELECT * FROM (SELECT DISTINCT ROW_NUMBER() OVER (ORDER BY a.IBDEALNOPK) rn,"
			+ "b.IBINTERNALPARTYID, a.IBISOCURRENCYCODE, a.IBBRANCHSORTCODE, a.IBPRODUCTID," 
			+ "a.IBDEALNOPK, a.IBPRODUCTCONTEXTCODE, a.IBSTATUS ";
	private static final String countSelectQuery = "select count(*) as count ";
	private static final String fromClause = "FROM IBTB_DEALDETAILS a, IBTB_DEALPARTYDTL b, LOANDETAILS c ";
	private static final String wherClause1 = "WHERE (b.IBDEALNO = a.IBDEALNOPK AND b.IBASSOCIATIONTYPE = 'PC') "
			+ "AND (a.IBDEALNOPK = c.LOANREFERENCE AND c.LOANSTATUS"; 
	private static final String wherClause2 = " IN ('2410','2411')) AND a.IBDEALNOPK like  '%";
	private static final String wherClause3 = "%' AND b.IBINTERNALPARTYID like '%";
	private static final String wherClause4 = "%' AND (a.IBSYSTEMSTATUS NOT IN ('" + IBConstants.DEAL_CLOSED_STATUS + "','" + CeConstants.DEAL_STATUS_TD_INITIATED
			+ "') OR a.IBSYSTEMSTATUS IS NULL)";
	private static final String wherClause5 = ") temp WHERE rn BETWEEN ";
	public TransferOfDebtsEligDealSearch()
	{
		super();
	}

	public TransferOfDebtsEligDealSearch(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		ListTrnsfDbtsElgDealsRq listRq = getF_IN_listTrnsfDbtsElgDealsRq();
		String dealNum = null != listRq.getTrnsfDbtsElgDealSearch().getDealID()?listRq.getTrnsfDbtsElgDealSearch().getDealID():CommonConstants.EMPTY_STRING;
		String custId = null != listRq.getTrnsfDbtsElgDealSearch().getPartyID()?listRq.getTrnsfDbtsElgDealSearch().getPartyID():CommonConstants.EMPTY_STRING;
		Integer reqPage = listRq.getPagedQuery().getPagingRequest().getRequestedPage();
		reqPage = (null == reqPage || reqPage <= 0)?1:reqPage;
		Integer noOfRows = listRq.getPagedQuery().getPagingRequest().getNumberOfRows();
		noOfRows = (null == noOfRows || noOfRows <= 0)?10:noOfRows;
		int fromRow = (noOfRows * (reqPage-1))+1;
		int toRow = (noOfRows * reqPage);
		ListTrnsfDbtsElgDealsRs listDealsRs =new ListTrnsfDbtsElgDealsRs();
		String isDealFullyDisbursedUDFId = CeUtils.getIsDealFullyDisbursedUDFId();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		Connection jdbcConnection = factory.getJDBCConnection();
		HashMap<String, String> partyLoaded = new HashMap<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		String countQuery = new StringBuilder().append(countSelectQuery).append(fromClause).append(wherClause1).append(wherClause2).append(dealNum).
				append(wherClause3).append(custId).append(wherClause4).toString();
		int count = 0;
		try {
			ps = jdbcConnection.prepareStatement(countQuery);
			rs = ps.executeQuery();
			if(rs.next())
			{
				count = Integer.parseInt(rs.getString("COUNT"));
			}
			if(count > 0)
			{
				String finalSelectQuery = new StringBuilder().append(selectQuery).append(fromClause).append(wherClause1).append(wherClause2).append(dealNum).
						append(wherClause3).append(custId).append(wherClause4).append(wherClause5).
						append(fromRow).append(" AND ").append(toRow).toString();
				ps1 = jdbcConnection.prepareStatement(finalSelectQuery);
				rs1 = ps1.executeQuery();
				while(rs1.next())
				{
					TrnsfDbtsElgDeal trnsfDbtsElgDeal = new TrnsfDbtsElgDeal();
					trnsfDbtsElgDeal.setBranchID(rs1.getString("IBBRANCHSORTCODE"));
					trnsfDbtsElgDeal.setDealID(rs1.getString("IBDEALNOPK"));
					trnsfDbtsElgDeal.setProductID(rs1.getString("IBPRODUCTID"));
					trnsfDbtsElgDeal.setStatus(rs1.getString("IBSTATUS"));
					trnsfDbtsElgDeal.setSubproductID(rs1.getString("IBPRODUCTCONTEXTCODE"));
					String dealCurrecny = rs1.getString("IBISOCURRENCYCODE");
					
					String partyID =  rs1.getString("IBINTERNALPARTYID");
					trnsfDbtsElgDeal.setPartyID(partyID);
					if(!partyLoaded.containsKey(partyID))
					{
						ReadPartyWSRq partyWSRq = new ReadPartyWSRq();
						partyWSRq.setPartyID(partyID);
						ReadPartyWSRs partyWSRs = SadadPaymentUtils.readParty(partyWSRq, BankFusionThreadLocal.getBankFusionEnvironment());
						String partyName =partyWSRs.getPartyBasicDetails().getName();
						trnsfDbtsElgDeal.setPartyName(partyName);
						partyLoaded.put(partyID, partyName);
					}
					else
					{
						trnsfDbtsElgDeal.setPartyName(partyLoaded.get(partyID));
					}
					
					BigDecimal dealAmt = CommonConstants.BIGDECIMAL_ZERO;
					BigDecimal paidAmt = CommonConstants.BIGDECIMAL_ZERO;
					String whereClause = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
					ArrayList<String> params = new ArrayList<>();
					params.add(trnsfDbtsElgDeal.getDealID());
					List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupList = factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClause, params, null, false);
					if(null != paymentSchBreakupList && !paymentSchBreakupList.isEmpty())
					{
						for(IBOCE_IB_PaymentSchBreakup paymentSchBreakup : paymentSchBreakupList ) 
						{
							dealAmt = dealAmt.add(paymentSchBreakup.getF_IBPRINCIPALAMT().add(
									paymentSchBreakup.getF_IBPROFITAMT()).add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
							paidAmt = paidAmt.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID().add(
									paymentSchBreakup.getF_IBPROFITAMTPAID()).add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()));
						}
					}
					
					BFCurrencyAmount dealAmtBFC = new BFCurrencyAmount();
					dealAmtBFC.setCurrencyAmount(IBCommonUtils.getDealDetails(trnsfDbtsElgDeal.getDealID()).getF_DealAmt());
					dealAmtBFC.setCurrencyCode(dealCurrecny);
					trnsfDbtsElgDeal.setDealAmt(dealAmtBFC);
					BFCurrencyAmount outstandingAmtBFC = new BFCurrencyAmount();
					outstandingAmtBFC.setCurrencyAmount(dealAmt.subtract(paidAmt));
					outstandingAmtBFC.setCurrencyCode(dealCurrecny);
					trnsfDbtsElgDeal.setOutstandingAmt(outstandingAmtBFC);
					trnsfDbtsElgDeal.setSelect(false);
					listDealsRs.addTrnsfDbtsElgDeals(trnsfDbtsElgDeal);
				}
			}
		}
		catch (Exception e) {
            try {
                factory.rollbackTransaction();
            } catch (Exception exception) {
                LOG.error(exception.getStackTrace());
            } finally {
                BankFusionThreadLocal.cleanUp();
            }
            LOG.error(e.getMessage());
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    LOG.error(e.getStackTrace());
                }
            }
            if (ps1 != null) {
                try {
                    ps1.close();
                } catch (SQLException e) {
                    LOG.error(e.getStackTrace());
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    LOG.error(e.getStackTrace());
                }
            }
            if (rs1 != null) {
                try {
                    rs1.close();
                } catch (SQLException e) {
                    LOG.error(e.getStackTrace());
                }
            }
        }
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(noOfRows);
		pagingRequest.setRequestedPage(reqPage);
		int totalPages;
		if(count > 0 )
		{
			totalPages = count/noOfRows;
			totalPages = count%noOfRows > 0?totalPages+1:totalPages;
		}
		else
		{
			totalPages = 1;
		}
		pagingRequest.setTotalPages(totalPages);
		pagedQuery.setPagingRequest(pagingRequest );
		listDealsRs.setPagedQuery(pagedQuery );

		setF_OUT_listTrnsfDbtsElgDealsRs(listDealsRs);
	}

}
