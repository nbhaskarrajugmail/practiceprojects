package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DealFollowUpAction;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class DealFollowUpAction extends AbstractCE_IB_DealFollowUpAction {

	public DealFollowUpAction(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		IBOCE_IB_DealFollowUpDtls followUpDetails = DealFollowUpUtils
				.getPreviousFollowUpDtls(getF_IN_islamicBankingObject().getDealID());
		if (followUpDetails != null && !followUpDetails.isF_IBFOLLOWUPDONE()) {
			IBOCE_IB_FollowUpListConf followUpListConfObj = DealFollowUpUtils
					.getFollowUpConfObj(getF_IN_islamicBankingObject().getDealID());
			if (followUpListConfObj != null) {
				if (followUpDetails.getF_IBFOLLOWUPSTATUS().equals(CeConstants.FOLLOWUP_STATUS_POSITIVE)) {
					followUpListConfObj.setF_IBINSPECTORNAME(CommonConstants.EMPTY_STRING);
					followUpDetails.setF_IBFOLLOWUPDONE(true);
				} else {
					followUpListConfObj.setF_IBINSPECTORNAME(BankFusionThreadLocal.getUserSession().getUserId());
				}
				followUpListConfObj.setF_IBCURRENTFOLLOWUPSTATUS(followUpDetails.getF_IBFOLLOWUPSTATUS());
				followUpListConfObj.setF_IBLASTFOLLOWUPDATE(IBCommonUtils.getBFBusinessDate());
				followUpDetails.setF_IBFOLLOWUPDATE(IBCommonUtils.getBFBusinessDateTime());
			}
		}
	}

}
