package com.ce.bankfusion.ib.fatom;

import bf.com.misys.dealreschedule.dtls.ib.types.RescheduleHistory;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetRescheduleHistoryPaymentSchedule;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.util.IBCommonUtils;

public class GetRescheduleHistoryPaymentSchedule extends AbstractCE_IB_GetRescheduleHistoryPaymentSchedule {

    private static final long serialVersionUID = 1L;

    public GetRescheduleHistoryPaymentSchedule() {
        super();
    }

    public GetRescheduleHistoryPaymentSchedule(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        if (!IBCommonUtils.isNullOrEmpty(getF_IN_requestId()) && !IBCommonUtils.isNullOrEmpty(getF_IN_dealId())) {
            String currencyCode = IBCommonUtils.getDealDetails(getF_IN_dealId()).getF_IsoCurrencyCode();
            CePaymentSchedule[] paymentSchedule = RescheduleUtils.getNewSchedule(getF_IN_dealId(), getF_IN_requestId(), currencyCode);
            RescheduleHistory history = new RescheduleHistory();
            history.setHistorySchedule(paymentSchedule);
            setF_OUT_rescheduleHistory(history);

        }
    }

}
