package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDFEES;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateRefundFees;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.RefundFeesDtls;
import bf.com.misys.ib.types.RefundFeesDtlsList;

public class PopulateRefundFees extends AbstractCE_IB_PopulateRefundFees{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;
	
	private static final Log LOGGER = LogFactory.getLog(PopulateRefundFees.class);

	public PopulateRefundFees()
	{
		super();
	}
	
	public PopulateRefundFees(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		String dealId = ibObject.getDealID();
		
		RefundFeesDtlsList refundFeesDtls = new RefundFeesDtlsList();
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealAllFeesClause = "WHERE "+ IBOIB_DLI_DealAssetChargesdtls.DealNo+"=?";
		String dealRefundedFeesClause = "WHERE "+ IBOCE_IB_REFUNDFEES.IBDEALID+"=?";
		
		ArrayList params = new ArrayList<>();
		params.add(dealId);
		
		List<IBOCE_IB_REFUNDFEES> dealRefundedFeesList = factory.findByQuery(IBOCE_IB_REFUNDFEES.BONAME, dealRefundedFeesClause, params, null, false);
		
		List<IBOIB_DLI_DealAssetChargesdtls> dealFeesList=factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, dealAllFeesClause, params, null, false);
		
		//For Fees Refunded Records
		for(IBOCE_IB_REFUNDFEES dealrefundFees: dealRefundedFeesList) {
						
				RefundFeesDtls refundFeeDtl = new RefundFeesDtls();
				
				refundFeeDtl.setRefundId(dealrefundFees.getBoID());
				refundFeeDtl.setDealAssetChargeDetailId(dealrefundFees.getF_IBDEALASSETCHARGEDTLID());
				refundFeeDtl.setFeeID(dealrefundFees.getF_IBFEEID());
				refundFeeDtl.setFeeName(dealrefundFees.getF_IBFEENAME());
				refundFeeDtl.setCustomerId(dealrefundFees.getF_IBPARTYID());
				BFCurrencyAmount bfCurrAmount = new BFCurrencyAmount();
				bfCurrAmount.setCurrencyAmount(dealrefundFees.getF_IBAMOUNT());
				bfCurrAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setAmount(bfCurrAmount);
				BFCurrencyAmount bfPaidAmount = new BFCurrencyAmount();
				bfPaidAmount.setCurrencyAmount(dealrefundFees.getF_IBPAIDAMT());
				bfPaidAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setPaidAmount(bfPaidAmount);
				BFCurrencyAmount bfRemAmount = new BFCurrencyAmount();
				bfRemAmount.setCurrencyAmount(dealrefundFees.getF_IBREMAMT());
				bfRemAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setUser(ibObject.getUserID());
				refundFeeDtl.setTransactionDateTime(dealrefundFees.getF_IBTRANSACTIONDTTM());
				refundFeeDtl.setDescription(dealrefundFees.getF_IBDESCRIPTION());				
				refundFeeDtl.setBankAccountId(dealrefundFees.getF_IBPARTYBANKACCOUNTID());
				refundFeeDtl.setRefundStatus(dealrefundFees.getF_IBREFUNDSTATUS());
				
				refundFeesDtls.addRefundFeesDtls(refundFeeDtl);
				
		
		}
		
		
		//For Fees Paid Records
		for(IBOIB_DLI_DealAssetChargesdtls dealFees: dealFeesList) {
			if(dealFees.getF_UNPAIDCHARGEAMOUNT().compareTo(dealFees.getF_ChargeAmount()) < 0) {
				
				
				boolean addRecord = true;
				RefundFeesDtls refundFeeDtl = new RefundFeesDtls();
				
				refundFeeDtl.setDealAssetChargeDetailId(dealFees.getBoID());
				refundFeeDtl.setFeeID(dealFees.getF_FEESCONFIGID());
				refundFeeDtl.setFeeName(dealFees.getF_DUPLICATECHARGENAME());
				refundFeeDtl.setCustomerId(IBCommonUtils.getDealPrimaryPartyID(dealId));
				BFCurrencyAmount bfCurrAmount = new BFCurrencyAmount();
				bfCurrAmount.setCurrencyAmount(dealFees.getF_ChargeAmount());
				bfCurrAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setAmount(bfCurrAmount);
				BFCurrencyAmount bfPaidAmount = new BFCurrencyAmount();
				bfPaidAmount.setCurrencyAmount(dealFees.getF_ChargeAmount().subtract(dealFees.getF_UNPAIDCHARGEAMOUNT()));
				bfPaidAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setPaidAmount(bfPaidAmount);
				BFCurrencyAmount bfRemAmount = new BFCurrencyAmount();
				bfRemAmount.setCurrencyAmount(dealFees.getF_UNPAIDCHARGEAMOUNT());
				bfRemAmount.setCurrencyCode(ibObject.getCurrency());
				refundFeeDtl.setRemainingAmount(bfRemAmount);
				refundFeeDtl.setUser(ibObject.getUserID());
				refundFeeDtl.setTransactionDateTime(IBCommonUtils.getBFBusinessDateTime());
				
				for(RefundFeesDtls refunddtl: refundFeesDtls.getRefundFeesDtls()) {
					if(refunddtl.getRefundStatus().equalsIgnoreCase("SCHEDULED") && dealFees.getBoID().equalsIgnoreCase(refundFeeDtl.getDealAssetChargeDetailId())) {
						addRecord = false;
					}
				}
				
				if(addRecord)
				refundFeesDtls.addRefundFeesDtls(refundFeeDtl);
				
			}
		}
		
		setF_OUT_refundFeesDtlsList(refundFeesDtls);
		
		//View Mode Or Edit Mode
		IBOIB_CFG_BuildingBlockConfig buildingBlockConfig = IBCommonUtils.getConfiguredBuildingBlock(ibObject.getPhaseID(), ibObject.getProductID(), ibObject.getSubProductID(), ibObject.getStepID(), ibObject.getProcessConfigID());
		boolean disableFields = false;
		
		String mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
		
		if(mode.equalsIgnoreCase(IBConstants.VIEWMODE)) {
			disableFields = true;
		}
		
		setF_OUT_viewMode(disableFields);
	}

}
