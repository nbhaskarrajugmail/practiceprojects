package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_BenBankDesc;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ib.types.PaymentDetails;

public class BenBankDesc extends AbstractCE_IB_BenBankDesc{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public BenBankDesc() {
        super();
      }

      @SuppressWarnings("deprecation")
      public BenBankDesc(BankFusionEnvironment env) {
        super(env);
      }

      @Override
      public void process(BankFusionEnvironment env) throws BankFusionException {
          PaymentDetails[] payments = getF_IN_issuePayOrderDtls().getPaymentDetails();
          for(PaymentDetails payment : payments) {
              if(payment.isSelect()) {
                  ListGenericCodeRs genericCodeRs = IBCommonUtils.getGCList("OTHERBANKNAME");
                  for (GcCodeDetail gcCodeDtls : genericCodeRs.getGcCodeDetails()) {
                      if(payment.getBeneficiaryBank().equals(gcCodeDtls.getCodeValue())) {
                          setF_OUT_bankNameDesc(gcCodeDtls.getCodeDescription());
                          break;
                      }
                  }
              }
          }
      }
}
