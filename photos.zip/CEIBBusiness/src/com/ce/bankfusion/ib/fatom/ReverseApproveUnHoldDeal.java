package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReverseApproveUnHoldDeal;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class ReverseApproveUnHoldDeal extends AbstractCE_IB_ReverseApproveUnHoldDeal{
    public ReverseApproveUnHoldDeal() {
        super();
    }
    @SuppressWarnings("deprecation")
    public ReverseApproveUnHoldDeal(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        DealHoldUtil.reverseApproveUnHoldDeal(getF_IN_islamicBankingObject().getDealID());
    }

}
