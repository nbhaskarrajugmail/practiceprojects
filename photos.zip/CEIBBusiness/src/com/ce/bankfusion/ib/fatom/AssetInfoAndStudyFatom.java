package com.ce.bankfusion.ib.fatom;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetMigrationData;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetInfoAndStudy;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtimeworkbench.util.udf.UserDefinedFieldsUtil;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetThirdPartyDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_AssetCatAttrbts;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.AdditionalFieldConstants;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.UDFDataCollection;
import bf.com.misys.bankfusion.attributes.UDFInformation;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.services.ReadModuleConfigurationRq;
import bf.com.misys.cbs.services.ReadModuleConfigurationRs;
import bf.com.misys.cbs.types.ModuleConfigDetails;
import bf.com.misys.cbs.types.ModuleKeyRq;
import bf.com.misys.ib.types.AssetBasicDtls;
import bf.com.misys.ib.types.AssetBasicDtlsList;
import bf.com.misys.ib.types.AssetCategoryAttributeInfo;
import bf.com.misys.ib.types.AssetCategoryBasicInfo;
import bf.com.misys.ib.types.AssetCategoryDtls;
import bf.com.misys.ib.types.AssetThirdPartyAttributePanelVisibility;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.AssetThirdPartyDtls;
import bf.com.misys.ib.types.AssetThirdPartyDtlsList;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ThirdPtyBasicDtls;

public class AssetInfoAndStudyFatom extends AbstractCE_IB_AssetInfoAndStudy {

    private static final long serialVersionUID = 1L;

    private transient final static Log LOGGER = LogFactory.getLog(AssetInfoAndStudyFatom.class.getName());

	private static final String MIGRATED_DATA_DELETE = " WHERE " + IBOCE_IB_AssetMigrationData.IBDEALNO + "= ? AND "+IBOCE_IB_AssetMigrationData.IBPROCESSED+"=?";

    private final String BB_ID = "ASSETANDSTUDYINFO";

    Properties confProperties = new Properties();

    private static String BOTH = "Both";

    private static String GET_ALL_ATTRIBUTES_OF_CATEGORY_QUERY = " where ";

    private static String migragtedDataByDealQuery = " WHERE " + IBOCE_IB_AssetMigrationData.IBDEALNO + "= ?";

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    @SuppressWarnings("deprecation")
    public AssetInfoAndStudyFatom(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) {
        String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
        String filePath = confPath.concat(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE);
        loadProperties(filePath);
        IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(getF_IN_islamicBankingObject().getPhaseID(),
            getF_IN_islamicBankingObject().getProductID(), getF_IN_islamicBankingObject().getSubProductID(),
            getF_IN_islamicBankingObject().getStepID(), getF_IN_islamicBankingObject().getProcessConfigID());

        if (getF_IN_mode().equalsIgnoreCase("SAVE")) {
            save();
        } else if (getF_IN_mode().equalsIgnoreCase("REPLACEACTION")&& getF_IN_islamicBankingObject().getPhaseID().equals(CeConstants.ASSET_REPLACEMENT_SYS_BB)
            && getF_IN_islamicBankingObject().getMode().equals(IBConstants.BB_MODE_ACTION)) {
        	List<String> existingAssets= getAssetListFromDB();
            AssetThirdPartyDetailsList assetStudyDetail = new AssetThirdPartyDetailsList();
            AssetThirdPartyAttributePanelVisibility attributePanelVisibility = new AssetThirdPartyAttributePanelVisibility();
            assetStudyDetail.setAssetThirdPartyAttributePanelVisibility(attributePanelVisibility);
            setMigratedData(assetStudyDetail);
            setF_IN_assetThirdPartyDetailsList(assetStudyDetail);
            saveAssetDetailsinIBTable(true);
            updatePaymentScheduleHistory(existingAssets);
        } else {
            if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_REPLACEMENT_MODE)) {
                List<IBOCE_IB_AssetMigrationData> migratedDataList = getAssetMigratedData();
                if (null != migratedDataList && !migratedDataList.isEmpty()) {
                    if (bbConfig.getF_BUILDINGBLOCKMODE().equals("EDIT") && !isAssetReplacementProcessed())
                        retrieveAssetInfo(false);
                    else {
                        AssetThirdPartyDetailsList assetStudyDetail = new AssetThirdPartyDetailsList();
                        AssetThirdPartyAttributePanelVisibility attributePanelVisibility = new AssetThirdPartyAttributePanelVisibility();
                        assetStudyDetail.setAssetThirdPartyAttributePanelVisibility(attributePanelVisibility);
                        setMigratedData(assetStudyDetail);
                        setF_OUT_assetThirdPartyDetailsList(assetStudyDetail);
                        setF_OUT_allAssetRegistryList(
                            AssetStudyAndInfoUtil.getDealAssetRegistryDetails(getF_IN_islamicBankingObject().getDealID(), null));
                    }
                }
                else
                    retrieveAssetInfo(true);
            } else
                retrieveAssetInfo(false);

        }
    }

    private List<String> getAssetListFromDB() {
    	List<String> assets = new ArrayList<>();
    	ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_islamicBankingObject().getDealID());
        String whereClause= "where "+IBOIB_DLI_DealAssetThirdPartyDTL.DealNo+"=?";
        List<IBOIB_DLI_DealAssetThirdPartyDTL> dealAssetThirdParties =
            factory.findByQuery(IBOIB_DLI_DealAssetThirdPartyDTL.BONAME, whereClause, params, null, true);
		if (null != dealAssetThirdParties) {
			for (IBOIB_DLI_DealAssetThirdPartyDTL tp : dealAssetThirdParties)
				assets.add(tp.getF_AssetId());
		}
		return assets;
	}

	private void updatePaymentScheduleHistory(List<String> existingAssets) {
		AssetThirdPartyDetails[] assetThirdPartyDetails = getF_IN_assetThirdPartyDetailsList()
				.getAssetThirdPartyDetails();
		if (existingAssets != null && !existingAssets.isEmpty()) {
			ArrayList<Date> futureAssetPaymentDates = getExistingPayScheduleHistory(existingAssets.get(0),
					getF_IN_islamicBankingObject().getDealID());
			for (AssetThirdPartyDetails assetThirdPartyDetail : assetThirdPartyDetails) {
				if (!existingAssets.contains(assetThirdPartyDetail.getAssetSerial())) {
					for (Date date : futureAssetPaymentDates) {
						IBOCE_IB_PaymentScheduleHistory newPaymentScheduleHistory = (IBOCE_IB_PaymentScheduleHistory) (BankFusionThreadLocal
								.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentScheduleHistory.BONAME));
						newPaymentScheduleHistory.setF_IBASSETID(assetThirdPartyDetail.getAssetSerial());
						newPaymentScheduleHistory.setF_IBDEALID(getF_IN_islamicBankingObject().getDealID());
						newPaymentScheduleHistory.setF_IBPRINCIPALAMOUNT(CommonConstants.BIGDECIMAL_ZERO);
						newPaymentScheduleHistory.setF_IBPROFITAMOUNT(CommonConstants.BIGDECIMAL_ZERO);
						newPaymentScheduleHistory.setF_IBREPAYMENTDATE(date);
						newPaymentScheduleHistory.setF_IBRESCHEDULEID(getF_IN_islamicBankingObject().getDealID());
						newPaymentScheduleHistory.setF_IBSCHEDULEFEESAMOUNT(CommonConstants.BIGDECIMAL_ZERO);
						newPaymentScheduleHistory.setF_IBREPAYMENTSTATUS(IBConstants.REPAYMENT_STATUS_UNPAID);
						newPaymentScheduleHistory.setF_IBSUBSIDYAMOUNT(CommonConstants.BIGDECIMAL_ZERO);

						BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_PaymentScheduleHistory.BONAME,newPaymentScheduleHistory);
					}
				}
			}
		}
	}

	private ArrayList<Date> getExistingPayScheduleHistory(String assetID, String dealID) {
		ArrayList<Date> futureAssetPaymentDates = new ArrayList<Date>();
		List<IBOCE_IB_PaymentScheduleHistory> paymentsForDealAsset = RescheduleUtils
				.getExistingPaymentScheduleHistoryBreakupRecord(assetID, dealID);
		if (null != paymentsForDealAsset && !paymentsForDealAsset.isEmpty()) {
			for (IBOCE_IB_PaymentScheduleHistory history : paymentsForDealAsset) {
				if (!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
						history.getF_IBREPAYMENTDATE())) {
					futureAssetPaymentDates.add(history.getF_IBREPAYMENTDATE());
				}
			}
		}
		return futureAssetPaymentDates;
	}

	private void retrieveAssetInfo(boolean isAssetReplacementMode) {
        AssetThirdPartyDetailsList assetStudyDetail = new AssetThirdPartyDetailsList();
        AssetThirdPartyAttributePanelVisibility attributePanelVisibility = new AssetThirdPartyAttributePanelVisibility();
        assetStudyDetail.setAssetThirdPartyAttributePanelVisibility(attributePanelVisibility);
        Map inputParams = new HashMap<>();
        inputParams.put("IslamicBankingObject", getF_IN_islamicBankingObject());
        HashMap outputParams =
            MFExecuter.executeMF("IB_IDI_ReadAssetData_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
        AssetBasicDtlsList assetBasicDtlsList = (AssetBasicDtlsList) outputParams.get("AssetBasicDtlsList");
        AssetThirdPartyDtlsList assetThirdPartyDtlsList = (AssetThirdPartyDtlsList) outputParams.get("AssetThirdPartyDtlsList");
        AssetUDFsCollection udfs = (AssetUDFsCollection) outputParams.get("assetUdfCollection");
        AssetUDF assetUDFs[] = udfs.getAssetUDFs();
        for (AssetBasicDtls basicDetails : assetBasicDtlsList.getAssetBasicDtls()) {

            AssetThirdPartyDetails aTPDtls = new AssetThirdPartyDetails();
            IBCommonUtils.intializeDefaultvalues(aTPDtls);
            aTPDtls.setAssetCategory(basicDetails.getAsstCategory());
            aTPDtls.setAssetName(basicDetails.getAssetName());
            aTPDtls.setAssetSerial(basicDetails.getAssetId());
            aTPDtls.setAssetType(basicDetails.getAssetType());
            aTPDtls.setOriginalAssetCost(basicDetails.getAssetPrincipalAmount());
            aTPDtls.setAssetStudyCost(basicDetails.getAssetPrincipalAmount());

            for (AssetThirdPartyDtls atpdtl : assetThirdPartyDtlsList.getAssetThirdPartyDtls()) {
                if (atpdtl.getAssetID().equals(basicDetails.getAssetId())) {

                    ThirdPtyBasicDtls thirdPtyBasicDtl = atpdtl.getThirdPtyBasicDtls();
                    aTPDtls.setVendorId(thirdPtyBasicDtl.getThirdpartyDetailsId());
                    aTPDtls.setVendorName(thirdPtyBasicDtl.getPartyName());
                    aTPDtls.setVendorOffice(thirdPtyBasicDtl.getBranch());
                    aTPDtls.setVendorType(thirdPtyBasicDtl.getThirdpartyTypeName());
                    ReadModuleConfigurationRq ReadModuleConfigurationRq = new ReadModuleConfigurationRq();
                    ModuleKeyRq ModuleKeyRq = new ModuleKeyRq();
                    ModuleKeyRq.setModuleId(AdditionalFieldConstants.MODULE_ID);
                    ModuleKeyRq.setKey("DefaultThirdPartyID");
                    ReadModuleConfigurationRq.setModuleKeyRq(ModuleKeyRq);
                    HashMap param = new HashMap();
                    param.put("ReadModuleConfigurationRq", ReadModuleConfigurationRq);
                    HashMap<String, Object> outputParam = MFExecuter.executeMF(AdditionalFieldConstants.CB_CMN_READMODULECONFIGURATION_SRV,
                        IBCommonUtils.getBankFusionEnvironment(), param);
                    ReadModuleConfigurationRs ReadModuleConfigurationRs =
                        (ReadModuleConfigurationRs) outputParam.get("ReadModuleConfigurationRs");
                    ModuleConfigDetails moduleConfigDetails = ReadModuleConfigurationRs.getModuleConfigDetails();
                    if (aTPDtls.getVendorId().equals(moduleConfigDetails.getValue())) {
                        aTPDtls.setPartyType("Customer");
                    } else {
                        aTPDtls.setPartyType("Third Party");
                    }
                    break;
                }
            }

            Map<String, UDFInformation> assetUDFInfo = getAllUDFInformation(basicDetails.getAsstCategory().getCategory());
            for (String attr : assetUDFInfo.keySet()) {
                Object udfName = assetUDFInfo.get(attr).getUDFNAME();
                for (AssetUDF assetUDF : assetUDFs) {
                    if ((basicDetails.getAssetId().equals(assetUDF.getAssetid()) && (udfName.equals(assetUDF.getFieldId())))) {

                        BigDecimal value = new BigDecimal(0);
                        if (assetUDF.getFieldValue() != null && !"null".equals(assetUDF.getFieldValue())
                            && (!assetUDF.getFieldValue().equals("true")) && (!assetUDF.getFieldValue().equals("false"))) {
                            value = new BigDecimal(assetUDF.getFieldValue());
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-1"))) {
                            aTPDtls.setAttribute1(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-2"))) {
                            aTPDtls.setAttribute2(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-3"))) {
                            aTPDtls.setAttribute3(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-4"))) {
                            aTPDtls.setAttribute4(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-5"))) {
                            aTPDtls.setAttribute5(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-6"))) {
                            aTPDtls.setAttribute6(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-7"))) {
                            aTPDtls.setAttribute7(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-8"))) {
                            aTPDtls.setAttribute8(value);
                        }
                        if (attr.equals(confProperties.getProperty("Attribute-9"))) {
                            aTPDtls.setAttribute9(value);
                        }
                        if (attr.equals(confProperties.getProperty("MaxRateChangeAllowed"))) {
                            aTPDtls.setMaxRateChangeAllowed(value);
                        }
                        if (attr.equals(confProperties.getProperty("SubsidyPercentage"))) {
                            aTPDtls.setSubsidyPercentage(value);
                        }
                        if (attr.equals(confProperties.getProperty("GRP_CD"))) {
                            aTPDtls.setGroupCD(Integer.parseInt(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("TOOLNO"))) {
                            aTPDtls.setToolNO(Integer.parseInt(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("AssetType"))) {
                            aTPDtls.setAssetType(String.valueOf(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("Dividable"))) {
                            aTPDtls.setIsAssetDividable(Boolean.parseBoolean(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("Priced"))) {
                            aTPDtls.setIsAssetPriced(Boolean.parseBoolean(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("DisbursmentPeriodInYears"))) {
                            aTPDtls.setDisbursementPeriod(Integer.parseInt(assetUDF.getFieldValue()));
                        }
                        if (attr.equals(confProperties.getProperty("Asset_Tenor_in_years"))) {
                            aTPDtls.setAssetTenure(Integer.parseInt(assetUDF.getFieldValue()));

                        }
                        if (attr.equals(confProperties.getProperty("MaxAssetAllowedPerdeal"))) {
                            aTPDtls.setMaxAssetAllowed(Integer.parseInt(assetUDF.getFieldValue()));
                        }

                    }
                }
            }
            setCostFields(aTPDtls, assetUDFs);

            if (!aTPDtls.getAssetType().equals("1")) {
                String udfNames = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                    "DisbursmentPeriodInYears", "", CeConstants.ADFIBCONFIGLOCATION);
                aTPDtls.setDisbursementPeriod(getValueFromBasicInfo(udfNames));

                String udfNames1 = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, "numberOfinstallment",
                    "", CeConstants.ADFIBCONFIGLOCATION);
                aTPDtls.setAssetTenure(getValueFromBasicInfo(udfNames1));

            }

            assetStudyDetail.addAssetThirdPartyDetails(aTPDtls);
        }
        Arrays.sort(assetStudyDetail.getAssetThirdPartyDetails(), new Comparator<AssetThirdPartyDetails>() {

            @Override
            public int compare(AssetThirdPartyDetails o1, AssetThirdPartyDetails o2) {
                return o2.getAssetSerial().compareTo(o1.getAssetSerial());
            }
        });
        if(!isAssetReplacementMode)
            getProcessedMigratedData(assetStudyDetail);
        else setMigratedData(assetStudyDetail);
        setF_OUT_assetThirdPartyDetailsList(assetStudyDetail);
        setF_OUT_allAssetRegistryList(AssetStudyAndInfoUtil.getDealAssetRegistryDetails(getF_IN_islamicBankingObject().getDealID(), null));
    }

    private void setCostFields(AssetThirdPartyDetails aTPDtls, AssetUDF[] assetUDFs) {
        for (AssetUDF assetUDF : assetUDFs) {
            if (aTPDtls.getAssetSerial().equals(assetUDF.getAssetid())) {
                if (assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_ORIGINAL_COST)) {
                    BFCurrencyAmount cost = new BFCurrencyAmount();
                    cost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                    cost.setCurrencyAmount(BigDecimal.valueOf(Double.valueOf(assetUDF.getFieldValue())));
                    aTPDtls.setOriginalAssetCost(cost);
                }
                if (assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_STUDY_COST)) {
                    BFCurrencyAmount cost = new BFCurrencyAmount();
                    cost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                    cost.setCurrencyAmount(BigDecimal.valueOf(Double.valueOf(assetUDF.getFieldValue())));
                    aTPDtls.setAssetStudyCost(cost);
                }
                if (assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_GRANT_APPROVAL_COST)) {
                    BFCurrencyAmount cost = new BFCurrencyAmount();
                    cost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                    cost.setCurrencyAmount(BigDecimal.valueOf(Double.valueOf(assetUDF.getFieldValue())));
                    aTPDtls.setGrantApprovalCost(cost);
                }
                if (assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_FINAL_COST)) {
                    BFCurrencyAmount cost = new BFCurrencyAmount();
                    cost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                    cost.setCurrencyAmount(BigDecimal.valueOf(Double.valueOf(assetUDF.getFieldValue())));
                    aTPDtls.setFinalCost(cost);
                }
                if (assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.MACHINE_TYPE)) {
                    aTPDtls.setMachineType(assetUDF.getFieldValue());
                }
                if (assetUDF.getFieldId().equals("assetNotes")) {
                    aTPDtls.setAssetNotes(assetUDF.getFieldValue());
                }
            }
        }
        IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
        IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, ibObj.getProductID(),
            ibObj.getSubProductID(), ibObj.getStepID(), ibObj.getProcessConfigID());
        if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_ONLY_MODE)) {
            aTPDtls.setDisplayCost(aTPDtls.getOriginalAssetCost());
        } else if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE)) {
            if (aTPDtls.getAssetStudyCost() != null && aTPDtls.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getAssetStudyCost());
            } else {
                aTPDtls.setDisplayCost(aTPDtls.getOriginalAssetCost());
            }
        } else if (bbConfig.getF_EDITMODES().equals(CeConstants.STUDY_AND_GRANTAPPROVAL_ONLY_MODE)) {
            if (aTPDtls.getGrantApprovalCost() != null
                && aTPDtls.getGrantApprovalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getGrantApprovalCost());
            } else if (aTPDtls.getAssetStudyCost() != null
                && aTPDtls.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getAssetStudyCost());
            } else {
                aTPDtls.setDisplayCost(aTPDtls.getOriginalAssetCost());
            }
        } else if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE)) {
            if (aTPDtls.getFinalCost() != null && aTPDtls.getFinalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getFinalCost());
            } else if (aTPDtls.getGrantApprovalCost() != null
                && aTPDtls.getGrantApprovalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getGrantApprovalCost());
            } else if (aTPDtls.getAssetStudyCost() != null
                && aTPDtls.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getAssetStudyCost());
            } else {
                aTPDtls.setDisplayCost(aTPDtls.getOriginalAssetCost());
            }
        } else if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_REPLACEMENT_MODE)) {
            if (aTPDtls.getFinalCost() != null && aTPDtls.getFinalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getFinalCost());
            } else if (aTPDtls.getGrantApprovalCost() != null
                && aTPDtls.getGrantApprovalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getGrantApprovalCost());
            } else if (aTPDtls.getAssetStudyCost() != null
                && aTPDtls.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0) {
                aTPDtls.setDisplayCost(aTPDtls.getAssetStudyCost());
            } else {
                aTPDtls.setDisplayCost(aTPDtls.getOriginalAssetCost());
            }
        }
        if (bbConfig.getF_BUILDINGBLOCKMODE().equals(BuildingBlockConstants.MODE_VIEW)) {
            aTPDtls.setDisplayCost(aTPDtls.getFinalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0 ? aTPDtls.getFinalCost()
                : aTPDtls.getGrantApprovalCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0 ? aTPDtls.getGrantApprovalCost()
                    : aTPDtls.getAssetStudyCost().getCurrencyAmount().compareTo(BigDecimal.ZERO) != 0 ? aTPDtls.getAssetStudyCost()
                        : aTPDtls.getOriginalAssetCost());
        }

    }

    private void save() {
        IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
        IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, ibObj.getProductID(),
            ibObj.getSubProductID(), ibObj.getStepID(), ibObj.getProcessConfigID());
        if (bbConfig.getF_EDITMODES().equals(CeConstants.ASSET_REPLACEMENT_MODE) && bbConfig.getF_BUILDINGBLOCKMODE().equals(BuildingBlockConstants.MODE_EDIT)) {
            saveAssetMigrationData();
        } else {
            saveAssetDetailsinIBTable(false);
        }
    }

    private void saveAssetDetailsinIBTable(boolean persistMigratedData) {
    	Map<String, BigDecimal> assetDisbursedAmount = new HashMap<String, BigDecimal>();
    	Map inputParams = new HashMap<>();
        AssetBasicDtlsList assetBasicDtlsList = new AssetBasicDtlsList();
        AssetThirdPartyDtlsList assetThirdPartyDtlsList = new AssetThirdPartyDtlsList();
        AssetUDFsCollection udfs = new AssetUDFsCollection();
        if(persistMigratedData)
        	assetDisbursedAmount = AssetStudyAndInfoUtil.getDisbursedAmount(getF_IN_islamicBankingObject());
        
        populateThirdPartyDetails(assetThirdPartyDtlsList, assetBasicDtlsList, udfs, persistMigratedData,assetDisbursedAmount);
        inputParams.put("AssetBasicDtlsList", assetBasicDtlsList);
        inputParams.put("AssetThirdPartyDtlsList", assetThirdPartyDtlsList);
        inputParams.put("IslamicBankingObject", getF_IN_islamicBankingObject());
        inputParams.put("assetUdfCollection", udfs);
        HashMap outputParams =
            MFExecuter.executeMF("IB_IDI_PersistAssetData_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
        // Saving the Asset Registry List
        if (getF_IN_allAssetRegistryList() != null && getF_IN_allAssetRegistryList().getAssetRegistryList() != null
            && getF_IN_allAssetRegistryList().getAssetRegistryList().length > 0) {
            AssetStudyAndInfoUtil.saveDealAssetRegistryDtls(getF_IN_islamicBankingObject().getDealID(), getF_IN_allAssetRegistryList());
        }
        if (persistMigratedData) {
            List<IBOCE_IB_AssetMigrationData> migratedData = getAssetMigratedData();
			for (IBOCE_IB_AssetMigrationData md : migratedData) {
				if (md.isF_IBPROCESSED())
					continue;
				if (md.isF_IBASSETREPLACED() == false
						|| (md.isF_IBASSETREPLACED() && (assetDisbursedAmount.get(md.getF_IBASSETSERIAL())!=null && assetDisbursedAmount.get(md.getF_IBASSETSERIAL())
								.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO))) {
					factory.remove(IBOCE_IB_AssetMigrationData.BONAME, md.getBoID(), true);
				}
				if (md.isF_IBASSETREPLACED())
					md.setF_IBPROCESSED(true);
			}
        }
    }

    private void populateThirdPartyDetails(AssetThirdPartyDtlsList assetThirdPartyDtlsList, AssetBasicDtlsList assetBasicDtlsList,
        AssetUDFsCollection udfs, boolean persistMigratedData, Map<String, BigDecimal> assetDisbursedAmount) {
        AssetThirdPartyDetailsList assetStudyDetail = getF_IN_assetThirdPartyDetailsList();
        String dealCurrency = getF_IN_islamicBankingObject().getCurrency();
        List<String> migratedIds = getMigratedAssetIds();
        
        for (AssetThirdPartyDetails assetTPDtl : assetStudyDetail.getAssetThirdPartyDetails()) {
			if ((persistMigratedData == false && migratedIds != null && migratedIds.contains(assetTPDtl.getAssetSerial()))) {
				continue;
			}
			if (null != assetTPDtl.getReplaced() && assetTPDtl.getReplaced()) {
				BigDecimal disbursedAmount = assetDisbursedAmount.get(assetTPDtl.getAssetSerial());
				if (disbursedAmount != null	&& disbursedAmount.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
					assetTPDtl.getFinalCost().setCurrencyAmount(disbursedAmount);
				} else {
					continue;
				}
			}
            Map<String, UDFInformation> assetUDFInfo = getAllUDFInformation(assetTPDtl.getAssetCategory().getCategory());
            assetTPDtl.getOriginalAssetCost().setCurrencyCode(dealCurrency);
            AssetThirdPartyDtls thirdPartyDetail = new AssetThirdPartyDtls();
            ThirdPtyBasicDtls tpBasicDetail = new ThirdPtyBasicDtls();

            BFCurrencyAmount assetCost = new BFCurrencyAmount();
            assetCost.setCurrencyAmount(assetTPDtl.getDisplayCost().getCurrencyAmount());
            assetCost.setCurrencyCode(dealCurrency);

            tpBasicDetail.setAmountInclusionType(BOTH);
            tpBasicDetail.setIncludeInPaymentOrder(true);
            tpBasicDetail.setPartyId(assetTPDtl.getVendorId());
            tpBasicDetail.setPartyName(assetTPDtl.getVendorName());
            tpBasicDetail.setThirdpartyDetailsId(assetTPDtl.getVendorId());
            tpBasicDetail.setBranch(assetTPDtl.getVendorOffice());
            tpBasicDetail.setThirdpartyType(assetTPDtl.getPartyType());
            tpBasicDetail.setAmount(assetCost);
            tpBasicDetail.setPaymentCurrency(dealCurrency);
            BFCurrencyAmount downPaymentAmount = new BFCurrencyAmount();
            downPaymentAmount.setCurrencyAmount(new BigDecimal(0));
            downPaymentAmount.setCurrencyCode(dealCurrency);
            tpBasicDetail.setDownPaymentAmount(downPaymentAmount);
            thirdPartyDetail.setAssetID(assetTPDtl.getAssetSerial());
            thirdPartyDetail.setThirdPtyBasicDtls(tpBasicDetail);
            assetThirdPartyDtlsList.addAssetThirdPartyDtls(thirdPartyDetail);

            AssetBasicDtls assetBasicDtl = new AssetBasicDtls();
            ExtensionDetails extnDetails = new ExtensionDetails();
            extnDetails.setUserExtension(new UserDefinedFields());
            assetBasicDtl.setExtensionDetails(extnDetails);
            assetBasicDtl.setPaymentCurrency(dealCurrency);
            assetBasicDtl.setResidualValue(downPaymentAmount);
            assetBasicDtl.setAssetSellingPricePrincipalAmount(assetCost);
            assetBasicDtl.setAssetSellingPriceProfitAmount(assetCost);
            assetBasicDtl.setAssetPrincipalAmountAfterResidual(assetCost);
            assetBasicDtl.setAssetProfitAmountAfterResidual(assetCost);
            assetBasicDtl.setAssetPurchOrderAmt(assetCost);
            assetBasicDtl.setAssetProfitAmount(assetCost);
            assetBasicDtl.setCost(assetCost);
            assetBasicDtl.setAssetName(assetTPDtl.getAssetName());
            assetBasicDtl.setAsstCategory(assetTPDtl.getAssetCategory());
            // assetBasicDtl.setAssetType(assetTPDtl.getAssetType());
            assetBasicDtl.setAssetId(assetTPDtl.getAssetSerial());
            assetBasicDtl.setAssetPrincipalAmount(assetCost);
            assetBasicDtl.setAssetSellingPricePrincipalAmount(assetCost);
            BFCurrencyAmount assetDownPaymentAmt = new BFCurrencyAmount();
            assetDownPaymentAmt.setCurrencyAmount(new BigDecimal(0));
            assetDownPaymentAmt.setCurrencyCode(dealCurrency);
            assetBasicDtl.setAssetDownPaymentAmt(assetDownPaymentAmt);

            for (String attr : assetUDFInfo.keySet()) {
                AssetUDF assetUDF = new AssetUDF();
                assetUDF.setAssetid(assetTPDtl.getAssetSerial());
                assetUDF.setFieldId(assetUDFInfo.get(attr).getUDFNAME());
                if (attr.equals(confProperties.getProperty("Attribute-1"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute1()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-2"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute2()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-3"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute3()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-4"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute4()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-5"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute5()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-6"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute6()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-7"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute7()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-8"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute8()));
                }
                if (attr.equals(confProperties.getProperty("Attribute-9"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAttribute9()));
                }
                if (attr.equals(confProperties.getProperty("GRP_CD"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getGroupCD()));
                }
                if (attr.equals(confProperties.getProperty("TOOLNO"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getToolNO()));
                }
                if (attr.equals(confProperties.getProperty("DisbursmentPeriodInYears"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getDisbursementPeriod()));
                }
                if (attr.equals(confProperties.getProperty("Asset_Tenor_in_years"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAssetTenure()));
                }
                if (attr.equals(confProperties.getProperty("MaxAssetAllowedPerdeal"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getMaxAssetAllowed()));
                }
                if (attr.equals(confProperties.getProperty("MaxRateChangeAllowed"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getMaxRateChangeAllowed()));
                }
                if (attr.equals(confProperties.getProperty("AssetType"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getAssetType()));
                }
                if (attr.equals(confProperties.getProperty("Dividable"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getIsAssetDividable()));
                }
                if (attr.equals(confProperties.getProperty("Priced"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getIsAssetPriced()));
                }
                if (attr.equals(confProperties.getProperty("SubsidyPercentage"))) {
                    assetUDF.setFieldValue(String.valueOf(assetTPDtl.getSubsidyPercentage()));
                }
                udfs.addAssetUDFs(assetUDF);
            }
            AssetUDF assetOCUDF = new AssetUDF();
            assetOCUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetOCUDF.setFieldId(AssetStudyAndInfoUtil.ASSET_ORIGINAL_COST);
            assetOCUDF.setFieldValue(String.valueOf(assetTPDtl.getOriginalAssetCost().getCurrencyAmount()));
            udfs.addAssetUDFs(assetOCUDF);
            AssetUDF assetSCUDF = new AssetUDF();
            assetSCUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetSCUDF.setFieldId(AssetStudyAndInfoUtil.ASSET_STUDY_COST);
            assetSCUDF.setFieldValue(String.valueOf(assetTPDtl.getAssetStudyCost().getCurrencyAmount()));
            udfs.addAssetUDFs(assetSCUDF);
            AssetUDF assetGACUDF = new AssetUDF();
            assetGACUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetGACUDF.setFieldId(AssetStudyAndInfoUtil.ASSET_GRANT_APPROVAL_COST);
            assetGACUDF.setFieldValue(String.valueOf(assetTPDtl.getGrantApprovalCost().getCurrencyAmount()));
            udfs.addAssetUDFs(assetGACUDF);
            AssetUDF assetFCUDF = new AssetUDF();
            assetFCUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetFCUDF.setFieldId(AssetStudyAndInfoUtil.ASSET_FINAL_COST);
            assetFCUDF.setFieldValue(String.valueOf(assetTPDtl.getFinalCost().getCurrencyAmount()));
            udfs.addAssetUDFs(assetFCUDF);
            AssetUDF assetMCUDF = new AssetUDF();
            assetMCUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetMCUDF.setFieldId(AssetStudyAndInfoUtil.MACHINE_TYPE);
            assetMCUDF.setFieldValue(assetTPDtl.getMachineType());
            udfs.addAssetUDFs(assetMCUDF);
            
            AssetUDF assetNotesUDF = new AssetUDF();
            assetNotesUDF.setAssetid(assetTPDtl.getAssetSerial());
            assetNotesUDF.setFieldId("assetNotes");
            assetNotesUDF.setFieldValue(assetTPDtl.getAssetNotes());
            udfs.addAssetUDFs(assetNotesUDF);
            
            assetBasicDtlsList.addAssetBasicDtls(assetBasicDtl);
        }
    }

    public Map<String, UDFInformation> getAllUDFInformation(String categoryId) {
        List<UDFInformation> udfList;
        AssetCategoryDtls assetCatDtls = new AssetCategoryDtls();
        List<String> categoryNamesList = new ArrayList<>();
        List<AssetCategoryBasicInfo> categoriesList = AssetCategoryUtil.getAllParentCategoryBasicInfo(categoryId,
            (com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory) BankFusionThreadLocal.getPersistanceFactory());
        List<String> categoryIds = new ArrayList<>();
        for (AssetCategoryBasicInfo basicInfo : categoriesList) {
            categoryNamesList.add(basicInfo.getName());
            categoryIds.add(basicInfo.getAssetCategoryid());
        }

        getAssetAttributesByCategory(assetCatDtls, categoryIds);

        List<UDFInformation> tempList = new ArrayList<>();
        return getAssetCategoryAttributes(assetCatDtls, tempList);
    }

    private void getAssetAttributesByCategory(AssetCategoryDtls assetCatDtls, List<String> categoryIds) {
        StringBuffer queryAttr = new StringBuffer(GET_ALL_ATTRIBUTES_OF_CATEGORY_QUERY);
        queryAttr.append("(");
        for (int i = 0; i < categoryIds.size(); i++) {
            queryAttr.append(IBOIB_IDI_AssetCatAttrbts.CATEGORYID + " = ? ");
            if ((i + 1) == categoryIds.size()) {
                queryAttr
                    .append(") AND " + IBOIB_IDI_AssetCatAttrbts.ISDELETE + "='N'  AND " + IBOIB_IDI_AssetCatAttrbts.ISACTIVE + " =  'Y'");
            } else {
                queryAttr.append(" OR ");
            }
        }
        queryAttr.append(" ORDER BY boID ASC");
        List<IBOIB_IDI_AssetCatAttrbts> attrResultSet = BankFusionThreadLocal.getPersistanceFactory()
            .findByQuery(IBOIB_IDI_AssetCatAttrbts.BONAME, queryAttr.toString(), (ArrayList) categoryIds, null, true);
        List<String> parentAttrIds = new ArrayList<String>();
        if (null != attrResultSet) {
            for (int i = (attrResultSet.size() - 1); i > -1; i--) {
                IBOIB_IDI_AssetCatAttrbts attribute = attrResultSet.get(i);
                AssetCategoryAttributeInfo attributeDetails = new AssetCategoryAttributeInfo();
                if (null != attribute.getF_PARENTATTRID() && attribute.getF_PARENTATTRID().length() > 0) {

                    parentAttrIds.add(attribute.getF_PARENTATTRID());
                }
                if (!parentAttrIds.contains(attribute.getBoID())) {
                    attributeDetails.setAttributeID(attribute.getBoID());
                    attributeDetails.setAttributeName(attribute.getF_ATTRID());
                    assetCatDtls.addCategoryAttributeInfo(attributeDetails);
                }
            }
        }
    }

    private Map<String, UDFInformation> getAssetCategoryAttributes(AssetCategoryDtls assetCatDtls, List<UDFInformation> tempList) {
        Map<String, UDFInformation> udfDealAssetMap = new HashMap<>();
        Map<String, String> UDFDealAssetAttrMap = new HashMap<>();
        List<UDFInformation> newList = null;
        if (assetCatDtls.getCategoryAttributeInfoCount() > 0) {
            ArrayList<String> udfIdList = new ArrayList<String>();
            for (int j = 0; j < assetCatDtls.getCategoryAttributeInfoCount(); j++) {
                udfIdList.add(assetCatDtls.getCategoryAttributeInfo(j).getAttributeID());
                UDFDealAssetAttrMap.put(assetCatDtls.getCategoryAttributeInfo(j).getAttributeID(),
                    assetCatDtls.getCategoryAttributeInfo(j).getAttributeName());
            }
            UDFDataCollection udfcollection = UserDefinedFieldsUtil.getSpecifiedUDFFieldsForBO(IBOIB_AST_AssetDetails.BONAME, udfIdList);
            newList = new ArrayList<UDFInformation>(Arrays.asList(udfcollection.getUDFDataGroup()));
        }
        if (newList != null && newList.size() > 0) {
            tempList.addAll(newList);
        }
        for (UDFInformation udfInfo : tempList) {

            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-1"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-1"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-2"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-2"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-3"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-3"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-4"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-4"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-5"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-5"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-6"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-6"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-7"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-7"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-8"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-8"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Attribute-9"))) {
                udfDealAssetMap.put(confProperties.getProperty("Attribute-9"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("GRP_CD"))) {
                udfDealAssetMap.put(confProperties.getProperty("GRP_CD"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("TOOLNO"))) {
                udfDealAssetMap.put(confProperties.getProperty("TOOLNO"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("DisbursmentPeriodInYears"))) {
                udfDealAssetMap.put(confProperties.getProperty("DisbursmentPeriodInYears"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Asset_Tenor_in_years"))) {
                udfDealAssetMap.put(confProperties.getProperty("Asset_Tenor_in_years"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("MaxAssetAllowedPerdeal"))) {
                udfDealAssetMap.put(confProperties.getProperty("MaxAssetAllowedPerdeal"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("MaxRateChangeAllowed"))) {
                udfDealAssetMap.put(confProperties.getProperty("MaxRateChangeAllowed"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("AssetType"))) {
                udfDealAssetMap.put(confProperties.getProperty("AssetType"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Dividable"))) {
                udfDealAssetMap.put(confProperties.getProperty("Dividable"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("Priced"))) {
                udfDealAssetMap.put(confProperties.getProperty("Priced"), udfInfo);
            }
            if (UDFDealAssetAttrMap.get(udfInfo.getUDFNAME()).equals(confProperties.getProperty("SubsidyPercentage"))) {
                udfDealAssetMap.put(confProperties.getProperty("SubsidyPercentage"), udfInfo);
            }
        }

        return udfDealAssetMap;
    }

    private void loadProperties(String absoluteFilePath) {
        try {
            FileReader reader = new FileReader(absoluteFilePath);
            if (reader != null) {
                confProperties.load(reader);
            } else {
                LOGGER.error("Attributes conf file of AssetStudyAndInfoBB(conf/business/assetStudyAndInfoConf.properties) not found");
                throw new FileNotFoundException("property file '" + absoluteFilePath + "' not found in the classpath");
            }
        } catch (Exception e) {
            LOGGER.error("Error occured in reading the attributes conf file for AssetStudyAndInfoBB : " + e);
        }
    }

    private int getValueFromBasicInfo(String udfName) {

        try {
            IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
            String whereClause = "WHERE " + IBOUDFEXTIB_DLI_DealDetails.DealNo + "= ?";
            ArrayList<String> queryParams = new ArrayList<String>();
            queryParams.add(getF_IN_islamicBankingObject().getDealID());

            List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD =
                factory.findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClause, queryParams, null, true);
            int udfValue = 0;
            for (IBOUDFEXTIB_DLI_DealDetails dealDetailUD : dealDetailsUD) {
                UserDefinedFields userDefinedFields = dealDetailUD.getUserDefinedFields();
                if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
                    for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
                        if (udfName.equals(userDefinedFld.getFieldName()) && null != userDefinedFld.getFieldValue()) {
                            udfValue = (Integer) userDefinedFld.getFieldValue();
                        }
                    }
                }
            }
            return udfValue;
        } catch (Exception se) {
            throw se;
        }
    }

    private void setMigratedData(AssetThirdPartyDetailsList assetStudyDetail) {
        // TODO Auto-generated method stub
        List<IBOCE_IB_AssetMigrationData> migratedDataList = getAssetMigratedData();
        if (migratedDataList != null && !migratedDataList.isEmpty()) {
            migratedDataList.stream().forEach(migratedData -> {
                AssetThirdPartyDetails tpDetail = new AssetThirdPartyDetails();
                tpDetail.setAssetName(migratedData.getF_IBASSETNAME());
                AsstCategory assetCategory = new AsstCategory();
                assetCategory.setCategory(migratedData.getF_IBASSETCATEGORY());
                String categoryHirachyName = AssetCategoryUtil.getCategoryQualifiedName(migratedData.getF_IBASSETCATEGORY(),
                    BankFusionThreadLocal.getPersistanceFactory(), null);
                categoryHirachyName = categoryHirachyName.replace(">", ">>");
                categoryHirachyName = (String) categoryHirachyName.subSequence(0, categoryHirachyName.lastIndexOf(">>"));
                assetCategory.setCategorization(categoryHirachyName);
                tpDetail.setAssetCategory(assetCategory);
                tpDetail.setAssetSerial(migratedData.getF_IBASSETSERIAL());
                tpDetail.setPartyType(migratedData.getF_IBPARTYTYPE());
                tpDetail.setVendorId(migratedData.getF_IBVENDORID());
                tpDetail.setVendorName(migratedData.getF_IBVENDORNAME());
                tpDetail.setVendorOffice(migratedData.getF_IBVENDOROFFICE());
                tpDetail.setVendorType(migratedData.getF_IBVENDORTYPE());
                tpDetail.setMachineType(migratedData.getF_IBMACHINETYPE());
                tpDetail.setAssetType(migratedData.getF_IBASSETTYPE());
                tpDetail.setAssetTenure(migratedData.getF_IBASSETTENURE());
                tpDetail.setDisbursementPeriod(migratedData.getF_IBDISBURSEMENTPERIOD());
                tpDetail.setMaxAssetAllowed(migratedData.getF_IBMAXNOTALLOWED());
                tpDetail.setSubsidyPercentage(migratedData.getF_IBSUBSIDYPERCENTAGE());
                tpDetail.setMaxRateChangeAllowed(migratedData.getF_IBMAXRATECHANGEALLOWED());
                tpDetail.setGroupCD(migratedData.getF_IBGROUPCD());
                tpDetail.setToolNO(migratedData.getF_IBTOOLNO());
                tpDetail.setAttribute1(migratedData.getF_IBATTR1());
                tpDetail.setAttribute2(migratedData.getF_IBATTR2());
                tpDetail.setAttribute3(migratedData.getF_IBATTR3());
                tpDetail.setAttribute4(migratedData.getF_IBATTR4());
                tpDetail.setAttribute5(migratedData.getF_IBATTR5());
                tpDetail.setAttribute6(migratedData.getF_IBATTR6());
                tpDetail.setAttribute7(migratedData.getF_IBATTR7());
                tpDetail.setAttribute8(migratedData.getF_IBATTR8());
                tpDetail.setAttribute9(migratedData.getF_IBATTR9());
                tpDetail.setAssetNotes(migratedData.getF_IBNOTES());
                if (migratedData.isF_IBASSETREPLACED())
                    tpDetail.setReplaced(true);
                else
                    tpDetail.setReplaced(false);
                BFCurrencyAmount oc = new BFCurrencyAmount();
                tpDetail.setSelect(false);
                oc.setCurrencyAmount(migratedData.getF_IBORIGINALCOST());
                oc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setOriginalAssetCost(oc);
                BFCurrencyAmount sc = new BFCurrencyAmount();
                sc.setCurrencyAmount(migratedData.getF_IBSTUDYCOST());
                sc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setAssetStudyCost(sc);
                BFCurrencyAmount act = new BFCurrencyAmount();
                act.setCurrencyAmount(migratedData.getF_IBGRANTAPPROVALCOST());
                act.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setGrantApprovalCost(act);
                BFCurrencyAmount fc = new BFCurrencyAmount();
                fc.setCurrencyAmount(migratedData.getF_IBFINALCOST());
                fc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setFinalCost(fc);
                tpDetail.setDisplayCost(fc);
                BFCurrencyAmount rc = new BFCurrencyAmount();
                rc.setCurrencyAmount(BigDecimal.ZERO);
                rc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setAvailableAmountForNewAsset(rc);
                tpDetail.setIsAssetDividable(migratedData.isF_IBDIVIDABLE());
                tpDetail.setIsAssetPriced(migratedData.isF_IBPRICED());
                assetStudyDetail.addAssetThirdPartyDetails(tpDetail);
            });
        }
    }

    private void saveAssetMigrationData() {
        isAssetAmountValid();
        List<String> assetIds=getProcessedMigratedAssetIds();
        deleteMigratedData();
        AssetThirdPartyDetails[] assetThirdPartyList = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
        if (assetThirdPartyList != null && assetThirdPartyList.length > 0) {
            for (AssetThirdPartyDetails tpDetail : assetThirdPartyList) {
            	if(assetIds.contains(tpDetail.getAssetSerial()))
            			continue;
            	
                IBOCE_IB_AssetMigrationData migrationDataObj =
                    (IBOCE_IB_AssetMigrationData) factory.getStatelessNewInstance(IBOCE_IB_AssetMigrationData.BONAME);
                migrationDataObj.setF_IBDEALNO(getF_IN_islamicBankingObject().getDealID());
                migrationDataObj.setF_IBASSETNAME(tpDetail.getAssetName());
                migrationDataObj.setF_IBASSETCATEGORY(tpDetail.getAssetCategory().getCategory());
                migrationDataObj.setF_IBASSETSERIAL(tpDetail.getAssetSerial());
                migrationDataObj.setF_IBPARTYTYPE(tpDetail.getPartyType());
                migrationDataObj.setF_IBVENDORID(tpDetail.getVendorId());
                migrationDataObj.setF_IBVENDORNAME(tpDetail.getVendorName());
                migrationDataObj.setF_IBVENDOROFFICE(tpDetail.getVendorOffice());
                migrationDataObj.setF_IBVENDORTYPE(tpDetail.getVendorType());
                migrationDataObj.setF_IBMACHINETYPE(tpDetail.getMachineType());
                migrationDataObj.setF_IBASSETTYPE(tpDetail.getAssetType());
                migrationDataObj.setF_IBASSETTENURE(tpDetail.getAssetTenure());
                migrationDataObj.setF_IBDISBURSEMENTPERIOD(tpDetail.getDisbursementPeriod());
                migrationDataObj.setF_IBMAXNOTALLOWED(tpDetail.getMaxAssetAllowed());
                migrationDataObj.setF_IBSUBSIDYPERCENTAGE(tpDetail.getSubsidyPercentage());
                migrationDataObj.setF_IBMAXRATECHANGEALLOWED(tpDetail.getMaxRateChangeAllowed());
                migrationDataObj.setF_IBGROUPCD(tpDetail.getGroupCD());
                migrationDataObj.setF_IBTOOLNO(tpDetail.getToolNO());
                migrationDataObj.setF_IBATTR1(tpDetail.getAttribute1());
                migrationDataObj.setF_IBATTR2(tpDetail.getAttribute2());
                migrationDataObj.setF_IBATTR3(tpDetail.getAttribute3());
                migrationDataObj.setF_IBATTR4(tpDetail.getAttribute4());
                migrationDataObj.setF_IBATTR5(tpDetail.getAttribute5());
                migrationDataObj.setF_IBATTR6(tpDetail.getAttribute6());
                migrationDataObj.setF_IBATTR7(tpDetail.getAttribute7());
                migrationDataObj.setF_IBATTR8(tpDetail.getAttribute8());
                migrationDataObj.setF_IBATTR9(tpDetail.getAttribute9());
                migrationDataObj.setF_IBASSETREPLACED(tpDetail.isReplaced() != null ? tpDetail.isReplaced() : false);
                migrationDataObj.setF_IBPRICED(tpDetail.getIsAssetPriced());
                migrationDataObj.setF_IBDIVIDABLE(tpDetail.getIsAssetDividable());
                migrationDataObj.setF_IBORIGINALCOST(tpDetail.getFinalCost().getCurrencyAmount());
                migrationDataObj.setF_IBSTUDYCOST(tpDetail.getAssetStudyCost().getCurrencyAmount());
                migrationDataObj.setF_IBGRANTAPPROVALCOST(tpDetail.getFinalCost().getCurrencyAmount());
                migrationDataObj.setF_IBFINALCOST(tpDetail.getFinalCost().getCurrencyAmount());
                migrationDataObj.setF_IBDISPLAYCOST(tpDetail.getFinalCost().getCurrencyAmount());
                migrationDataObj.setF_IBPROCESSED(false);
                migrationDataObj.setF_IBNOTES(tpDetail.getAssetNotes());
                factory.create(IBOCE_IB_AssetMigrationData.BONAME, migrationDataObj);
                factory.commitTransaction();
            }
        }
    }

    private void deleteMigratedData() {
    	ArrayList params = new ArrayList<>();
    	params.add(getF_IN_islamicBankingObject().getDealID());
    	params.add(false);
		BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_AssetMigrationData.BONAME, MIGRATED_DATA_DELETE, params);
		
	}

	private List<String> getMigratedAssetIds() {
        List<String> assetSerials = new ArrayList<>();
        List<IBOCE_IB_AssetMigrationData> migratedDataList = getAssetMigratedData();
        if (migratedDataList != null && !migratedDataList.isEmpty()) {
            assetSerials = migratedDataList.stream().map(IBOCE_IB_AssetMigrationData::getF_IBASSETSERIAL).collect(Collectors.toList());
        }
        return assetSerials;
    }
	private List<String> getProcessedMigratedAssetIds() {
        List<String> assetSerials = new ArrayList<>();
        List<IBOCE_IB_AssetMigrationData> migratedDataList = getAssetMigratedData();
        if (migratedDataList != null && !migratedDataList.isEmpty()) {
            for (IBOCE_IB_AssetMigrationData iboce_IB_AssetMigrationData : migratedDataList) {
				if(iboce_IB_AssetMigrationData.isF_IBPROCESSED())
					assetSerials.add(iboce_IB_AssetMigrationData.getF_IBASSETSERIAL());
			}
        }
        return assetSerials;
    }

    private List<IBOCE_IB_AssetMigrationData> getAssetMigratedData() {
        ArrayList<String> paramValues = new ArrayList<>();
        paramValues.add(getF_IN_islamicBankingObject().getDealID());
        List<IBOCE_IB_AssetMigrationData> migratedDataList = BankFusionThreadLocal.getPersistanceFactory()
            .findByQuery(IBOCE_IB_AssetMigrationData.BONAME, migragtedDataByDealQuery, paramValues, null, true);
        return migratedDataList;
    }

    private void isAssetAmountValid() {
        BigDecimal totalAssetCost = BigDecimal.ZERO;
        BigDecimal addedAssetCost = BigDecimal.ZERO;
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_islamicBankingObject().getDealID());
        String whereClause = "where " + IBOIB_DLI_DealAssetThirdPartyDTL.DealNo + "=?";
        List<IBOIB_DLI_DealAssetThirdPartyDTL> dealAssetThirdParties =
            factory.findByQuery(IBOIB_DLI_DealAssetThirdPartyDTL.BONAME, whereClause, params, null, true);
        if (null != dealAssetThirdParties && dealAssetThirdParties.size() > 0) {
            for (IBOIB_DLI_DealAssetThirdPartyDTL tp : dealAssetThirdParties)
                totalAssetCost = totalAssetCost.add(tp.getF_Amount());
        }
        AssetThirdPartyDetails[] assetThirdPartyList = getF_IN_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
        if (null != assetThirdPartyList && assetThirdPartyList.length > 0) {
            for (AssetThirdPartyDetails tpDetail : assetThirdPartyList) {
                if (null != tpDetail.getReplaced() && tpDetail.getReplaced())
                    continue;
                addedAssetCost = addedAssetCost.add(tpDetail.getFinalCost().getCurrencyAmount());
            }
        }
        if (addedAssetCost.compareTo(totalAssetCost)>0) {
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_VALIDATE_ASSET_COST_IN_ASSET_REPLACEMENT_IB);
        }
    }

    private boolean isAssetReplacementProcessed() {
        List<IBOCE_IB_AssetMigrationData> migratedData = getAssetMigratedData();
        for (IBOCE_IB_AssetMigrationData md : migratedData) {
            if (!md.isF_IBPROCESSED())
                return true;
        }
        return false;
    }
    
    private void getProcessedMigratedData(AssetThirdPartyDetailsList assetStudyDetail) {
        List<IBOCE_IB_AssetMigrationData> migratedDataList = getAssetMigratedData();
        if (migratedDataList != null && !migratedDataList.isEmpty()) {
            for (IBOCE_IB_AssetMigrationData migratedData : migratedDataList) {
                if(!migratedData.isF_IBPROCESSED())
                    continue;
                AssetThirdPartyDetails tpDetail = new AssetThirdPartyDetails();
                tpDetail.setAssetName(migratedData.getF_IBASSETNAME());
                AsstCategory assetCategory = new AsstCategory();
                assetCategory.setCategory(migratedData.getF_IBASSETCATEGORY());
                String categoryHirachyName = AssetCategoryUtil.getCategoryQualifiedName(migratedData.getF_IBASSETCATEGORY(),
                    BankFusionThreadLocal.getPersistanceFactory(), null);
                categoryHirachyName = categoryHirachyName.replace(">", ">>");
                categoryHirachyName = (String) categoryHirachyName.subSequence(0, categoryHirachyName.lastIndexOf(">>"));
                assetCategory.setCategorization(categoryHirachyName);
                tpDetail.setAssetCategory(assetCategory);
                tpDetail.setAssetSerial(migratedData.getF_IBASSETSERIAL());
                tpDetail.setPartyType(migratedData.getF_IBPARTYTYPE());
                tpDetail.setVendorId(migratedData.getF_IBVENDORID());
                tpDetail.setVendorName(migratedData.getF_IBVENDORNAME());
                tpDetail.setVendorOffice(migratedData.getF_IBVENDOROFFICE());
                tpDetail.setVendorType(migratedData.getF_IBVENDORTYPE());
                tpDetail.setMachineType(migratedData.getF_IBMACHINETYPE());
                tpDetail.setAssetType(migratedData.getF_IBASSETTYPE());
                tpDetail.setAssetTenure(migratedData.getF_IBASSETTENURE());
                tpDetail.setDisbursementPeriod(migratedData.getF_IBDISBURSEMENTPERIOD());
                tpDetail.setMaxAssetAllowed(migratedData.getF_IBMAXNOTALLOWED());
                tpDetail.setSubsidyPercentage(migratedData.getF_IBSUBSIDYPERCENTAGE());
                tpDetail.setMaxRateChangeAllowed(migratedData.getF_IBMAXRATECHANGEALLOWED());
                tpDetail.setGroupCD(migratedData.getF_IBGROUPCD());
                tpDetail.setToolNO(migratedData.getF_IBTOOLNO());
                tpDetail.setAttribute1(migratedData.getF_IBATTR1());
                tpDetail.setAttribute2(migratedData.getF_IBATTR2());
                tpDetail.setAttribute3(migratedData.getF_IBATTR3());
                tpDetail.setAttribute4(migratedData.getF_IBATTR4());
                tpDetail.setAttribute5(migratedData.getF_IBATTR5());
                tpDetail.setAttribute6(migratedData.getF_IBATTR6());
                tpDetail.setAttribute7(migratedData.getF_IBATTR7());
                tpDetail.setAttribute8(migratedData.getF_IBATTR8());
                tpDetail.setAttribute9(migratedData.getF_IBATTR9());
                if (migratedData.isF_IBASSETREPLACED())
                    tpDetail.setReplaced(true);
                else
                    tpDetail.setReplaced(false);
                BFCurrencyAmount oc = new BFCurrencyAmount();
                tpDetail.setSelect(false);
                oc.setCurrencyAmount(migratedData.getF_IBORIGINALCOST());
                oc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setOriginalAssetCost(oc);
                BFCurrencyAmount sc = new BFCurrencyAmount();
                sc.setCurrencyAmount(migratedData.getF_IBSTUDYCOST());
                sc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setAssetStudyCost(sc);
                BFCurrencyAmount act = new BFCurrencyAmount();
                act.setCurrencyAmount(migratedData.getF_IBGRANTAPPROVALCOST());
                act.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setGrantApprovalCost(act);
                BFCurrencyAmount fc = new BFCurrencyAmount();
                fc.setCurrencyAmount(migratedData.getF_IBFINALCOST());
                fc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setFinalCost(fc);
                tpDetail.setDisplayCost(fc);
                BFCurrencyAmount rc = new BFCurrencyAmount();
                rc.setCurrencyAmount(BigDecimal.ZERO);
                rc.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                tpDetail.setAvailableAmountForNewAsset(rc);
                tpDetail.setIsAssetDividable(migratedData.isF_IBDIVIDABLE());
                tpDetail.setIsAssetPriced(migratedData.isF_IBPRICED());
                assetStudyDetail.addAssetThirdPartyDetails(tpDetail);
            }
        }
    }
}
