package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RequestEvaluationPersonalFilter;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtlsList;
import bf.com.misys.dealrelationship.dtls.ib.types.DealRelationshipDetails;
import edu.emory.mathcs.backport.java.util.Arrays;

public class RequestEvaluationPersonalFilter extends AbstractCE_IB_RequestEvaluationPersonalFilter{
    
    public RequestEvaluationPersonalFilter() {
        super();
    }
    @SuppressWarnings("deprecation")
    public RequestEvaluationPersonalFilter(BankFusionEnvironment env) {
        super(env);
    }
  
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        DealRelationshipDetails dealRelationshipDetails = new DealRelationshipDetails();
        PersonalRequestdtlsList list = new PersonalRequestdtlsList();
        list.removeAllPersonalRequestdtlsList();
        dealRelationshipDetails.setDealId(getF_IN_islamicBankingObject().getDealID());
        
        StringBuffer dealRelationShipDtlsQuery =  new StringBuffer(" WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? AND "+ IBOCE_IB_DealRelationshipDetails.IBDEALSTATUS+ " != ?");
        
        
        String allowedTypes = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.COLLATERAL_CUSTOM_CONF_FILE,
            CeConstants.COLLATERAL_RELATIONSHIP_TYPES, "", CeConstants.ADFIBCONFIGLOCATION);
        List<String> relationshipType =IBCommonUtils.isNotEmpty(allowedTypes)?Arrays.asList(allowedTypes.split(",")):new ArrayList<String>();
        ArrayList<String> queryParams = new ArrayList<>();
        queryParams.add(getF_IN_islamicBankingObject().getDealID());
        queryParams.add("DELETED");
        int i=0;
        
        for(String e : relationshipType) {
          
          if(i==0) {
              dealRelationShipDtlsQuery.append(" AND ( " + IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE + " = ? ");
              queryParams.add(e);
              i++;
              continue;
          }
          if(i>0) {
              dealRelationShipDtlsQuery.append(" OR " + IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE + " = ? ");
              queryParams.add(e);
              i++;
              
          }
            
            
        }    
        dealRelationShipDtlsQuery.append(")");
        
        List<IBOCE_IB_DealRelationshipDetails> resultSet = IBCommonUtils.getPersistanceFactory().findByQuery(
            IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery.toString(), queryParams, null, true);
        
        if (resultSet != null && !resultSet.isEmpty()) {
            for (IBOCE_IB_DealRelationshipDetails dealRelationshipAgents : resultSet) {
                PersonalRequestdtls vPersonalRequestdtlsList = new PersonalRequestdtls();
                vPersonalRequestdtlsList.setCustomerId(dealRelationshipAgents.getF_IBPARTYID());
                ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
                String relationDesc = "";
                for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
                    if (dealRelationshipAgents.getF_IBRELATIONSHIPTYPE().equals(gcCode.getCodeReference())) {
                      relationDesc = gcCode.getCodeDescription();
                        break;
                    }
                }
                vPersonalRequestdtlsList.setRelationshipType(relationDesc);
                vPersonalRequestdtlsList.setRelationShipDtlsID(dealRelationshipAgents.getBoID());
                vPersonalRequestdtlsList.setName(dealRelationshipAgents.getF_IBPARTYNAME());
                vPersonalRequestdtlsList.setNationalID(dealRelationshipAgents.getF_IBPARTYNATIONALID());
                
                BFCurrencyAmount pledgeAmt= new BFCurrencyAmount();
                pledgeAmt.setCurrencyAmount(dealRelationshipAgents.getF_IBPLEDGEAMOUNT());
                pledgeAmt.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                vPersonalRequestdtlsList.setPledgeAmount(pledgeAmt);
                vPersonalRequestdtlsList.setSelect(false);
                vPersonalRequestdtlsList.setFromDate(dealRelationshipAgents.getF_IBFROMDATE());
                vPersonalRequestdtlsList.setToDate(dealRelationshipAgents.getF_IBTODATE());
                vPersonalRequestdtlsList.setPledgeType(dealRelationshipAgents.getF_IBPLEDGETYPE());
                vPersonalRequestdtlsList.setSiloYear(dealRelationshipAgents.getF_IBSILOYEAR());
                vPersonalRequestdtlsList.setSiloArea(dealRelationshipAgents.getF_IBSILOAREA());

                list.addPersonalRequestdtlsList(vPersonalRequestdtlsList);
                
            
            }
            
            
            }
        setF_OUT_personalRequestdtlsList(list);
        
        
        
    }

}
