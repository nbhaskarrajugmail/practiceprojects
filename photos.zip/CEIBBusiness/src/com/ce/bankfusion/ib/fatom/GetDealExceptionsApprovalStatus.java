package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealExceptionsApprovalStatus;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bf.attributes.ErrorResponse;

public class GetDealExceptionsApprovalStatus extends AbstractCE_IB_GetDealExceptionsApprovalStatus{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6837846311735596119L;
	private static Log LOGGER = LogFactory.getLog(GetDealExceptionsApprovalStatus.class);

	public GetDealExceptionsApprovalStatus()
	{
		super();
	}

	public GetDealExceptionsApprovalStatus(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		ErrorResponse errorResponse = new ErrorResponse();
		String overAllStaus = CommonConstants.EMPTY_STRING;
		boolean isRejected = false;
		boolean isPending = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealID = getF_IN_islamicBankingObject().getDealID();
		String stepID = getF_IN_islamicBankingObject().getStepID();
		String processConfigID = getF_IN_islamicBankingObject().getProcessConfigID();
		LOGGER.info("Inside Get Deal Exceptions Approval Status for the dealID : "+dealID);
		LOGGER.info("Inside Get Deal Exceptions Approval Status for the stepID : "+stepID);
		LOGGER.info("Inside Get Deal Exceptions Approval Status for the processConfigID : "+processConfigID);
		ArrayList<String> params = new ArrayList<>();
		String whereClause = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ?"
				+" AND " +IBOCE_IB_DealValidations.IBSTEPID + " = ? AND "
				+ IBOCE_IB_DealValidations.IBPROCESSCONFIGID + " = ?";
		params.clear();
		params.add(dealID);
		params.add(stepID);
		params.add(processConfigID);
		List<IBOCE_IB_DealValidations> dealValidationsList = factory.findByQuery(IBOCE_IB_DealValidations.BONAME, whereClause, params, null, false);
		if(null != dealValidationsList && !dealValidationsList.isEmpty())
		{
			for(IBOCE_IB_DealValidations dealValidations : dealValidationsList)
			{
				if(ValidationExceptionConstants.STATUS_REJECTED.equals(dealValidations.getF_IBSTATUS()))
				{
					isRejected = true;
					break;
				}
				else if(ValidationExceptionConstants.STATUS_PENDING.equals(dealValidations.getF_IBSTATUS()))
				{
					isPending = true;
				}
			}
		}
		if(isRejected)
		{
			overAllStaus = "REJECTED";
		}
		else if(isPending)
		{
			overAllStaus = "PENDING";
		}
		else
		{
			overAllStaus = "PROCEED";
		}
		LOGGER.info("After decision in Get Deal Exceptions Approval Status for the deal : "+dealID+". Decision : "+overAllStaus);
		errorResponse.setOVERALLSTATUS(overAllStaus);
		setF_OUT_errorResponse(errorResponse);
	}
}
