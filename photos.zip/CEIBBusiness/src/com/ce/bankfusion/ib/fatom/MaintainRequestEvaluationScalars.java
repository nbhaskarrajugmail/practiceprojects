package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PersonalRequestDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_MaintainRequestEvaluationScalars;
import com.ce.bankfusion.ib.util.CalculationRequestEvaluationUtils;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ExistingRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.NoEvalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class MaintainRequestEvaluationScalars extends AbstractCE_IB_MaintainRequestEvaluationScalars {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public MaintainRequestEvaluationScalars() {
        super();
    }

    public MaintainRequestEvaluationScalars(BankFusionEnvironment env) {

    }

    public void process(BankFusionEnvironment env) throws BankFusionException {

        String mode = getF_IN_mode();
        switch (mode) {
        case "SCALAR_NEW":
            addNewRow(env);
            break;

        case "SCALAR_SAVE":
            saveRow(env);
            break;
        case "SCALAR_REMOVE":
            removeRow(env);
            break;
        case "POPULATE":
            populateDataOnCheckBoxEvent(env);
            break;
        default:
            break;

        }
    }

    private void populateDataOnCheckBoxEvent(BankFusionEnvironment env) {
        IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
        CollateralRequestDetailsList collateralRqList = getF_IN_collateralRequestDetailsList();
        TitleDeedDetailsList titleDeedDetailsList = new TitleDeedDetailsList();
        // IBCommonUtils.intializeDefaultvalues(titleDeedDetailsList);
        for (CollateralRequestDetails colReqDtl : collateralRqList.getCollateralRequestDetailsList()) {
            if (colReqDtl.isSelect() && colReqDtl.getRequestType() != null) {
                if (colReqDtl.getRequestType().equals("No-Evaluation")) {
                    NoEvalRequestdtls noEvalRequestdtls = new NoEvalRequestdtls();
                    noEvalRequestdtls.setCoverValue(colReqDtl.getCoverValue());
                    noEvalRequestdtls.setDescription(colReqDtl.getDescription());
                    noEvalRequestdtls.setRequestID(colReqDtl.getRequestID());
                    colReqDtl.setNoEvalRequestdtls(noEvalRequestdtls);

                } else if (colReqDtl.getRequestType().equals("Existing")) {
                    ExistingRequestdtls existingRequestdtls = new ExistingRequestdtls();
                    existingRequestdtls.setAvailableCoverValue(colReqDtl.getAvailableBalance());
                    existingRequestdtls.setCollateralID(colReqDtl.getCollateralID());
                    existingRequestdtls.setDescription(colReqDtl.getDescription());
                    existingRequestdtls.setRequestID(colReqDtl.getRequestID());
                    existingRequestdtls.setUtilizeAmount(colReqDtl.getCoverValue());
                    colReqDtl.setExistingRequestdtls(existingRequestdtls);
                }

                else if (colReqDtl.getRequestType().equals("Personal")) {
                    String pledgeDesc = IBConstants.EMPTY_STRING;
                    PersonalRequestdtls personalRequest = new PersonalRequestdtls();
                    personalRequest.setAvailableBalance(colReqDtl.getPersonalRequest().getAvailableBalance());
                    personalRequest.setCoverValue(colReqDtl.getCoverValue());
                    personalRequest.setRequestID(colReqDtl.getRequestID());
                    personalRequest.setDescription(colReqDtl.getDescription());

                    IBOCE_IB_PersonalRequestDtls ib_PersonalRequestDtls =
                        CollateralRequestDtlsUtils.readPersonalRequestDtls(colReqDtl.getRequestID());
                    if (ib_PersonalRequestDtls != null) {
                        IBOCE_IB_DealRelationshipDetails dealRelationshipDetails =
                            CollateralRequestDtlsUtils.fetchDealRelationshipDtlByID(ib_PersonalRequestDtls.getF_IBRELATIONSIPDTLSID());
                        personalRequest.setCustomerId(dealRelationshipDetails.getF_IBPARTYID());
                        personalRequest.setFromDate(dealRelationshipDetails.getF_IBFROMDATE());
                        if (CalendarUtil.isDateNullOrDefaultDate(dealRelationshipDetails.getF_IBFROMDATE())) {
                            personalRequest.setFromDate(null);
                        }
                        personalRequest.setName(dealRelationshipDetails.getF_IBPARTYNAME());
                        personalRequest.setNationalID(dealRelationshipDetails.getF_IBPARTYNATIONALID());
                        personalRequest.setPersonalRequestdtlsID(ib_PersonalRequestDtls.getBoID());
                        personalRequest.setPledgeAmount(
                            IBCommonUtils.getBFCurrencyAmount(dealRelationshipDetails.getF_IBPLEDGEAMOUNT(), ibObj.getCurrency()));
                        ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("IBPLEDGETYPE");

                        for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                            if (dealRelationshipDetails.getF_IBPLEDGETYPE().equals(gcCode.getCodeReference())) {
                                pledgeDesc = gcCode.getCodeDescription();
                                break;
                            }
                        }
                        personalRequest.setPledgeType(pledgeDesc);
                        personalRequest.setRelationShipDtlsID(dealRelationshipDetails.getBoID());

                        ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
                        String relationDesc = "";
                        for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
                            if (dealRelationshipDetails.getF_IBRELATIONSHIPTYPE().equals(gcCode.getCodeReference())) {
                                relationDesc = gcCode.getCodeDescription();
                                break;
                            }
                        }

                        personalRequest.setRelationshipType(relationDesc);

                        ListGenericCodeRs lsGenericCodesSileArea = IBCommonUtils.getGCList("IBSILOAREACODE");
                        String siloArea = "";
                        for (GcCodeDetail gcCode : lsGenericCodesSileArea.getGcCodeDetails()) {
                            if (dealRelationshipDetails.getF_IBSILOAREA().equals(gcCode.getCodeReference())) {
                                siloArea = gcCode.getCodeDescription();
                                break;
                            }
                        }

                        personalRequest.setSiloArea(siloArea);
                        personalRequest.setSiloYear(dealRelationshipDetails.getF_IBSILOYEAR());
                        personalRequest.setToDate(dealRelationshipDetails.getF_IBTODATE());
                        if (CalendarUtil.isDateNullOrDefaultDate(dealRelationshipDetails.getF_IBTODATE())) {
                            personalRequest.setToDate(null);
                        }
                    } else {

                        personalRequest.setCustomerId(colReqDtl.getPersonalRequest().getCustomerId());
                        personalRequest.setFromDate(colReqDtl.getPersonalRequest().getFromDate());
                        personalRequest.setName(colReqDtl.getPersonalRequest().getName());
                        personalRequest.setNationalID(colReqDtl.getPersonalRequest().getNationalID());
                        // personalRequest.setPersonalRequestdtlsID(ib_PersonalRequestDtls.getBoID());
                        personalRequest.setPledgeAmount(colReqDtl.getPersonalRequest().getPledgeAmount());
                        personalRequest.setPledgeType(colReqDtl.getPersonalRequest().getPledgeType());
                        personalRequest.setRelationShipDtlsID(colReqDtl.getPersonalRequest().getRelationShipDtlsID());
                        personalRequest.setRelationshipType(colReqDtl.getPersonalRequest().getRelationshipType());
                        personalRequest.setSiloArea(colReqDtl.getPersonalRequest().getSiloArea());
                        personalRequest.setSiloYear(colReqDtl.getPersonalRequest().getSiloYear());
                        personalRequest.setToDate(colReqDtl.getPersonalRequest().getToDate());
                    }
                    colReqDtl.setPersonalRequest(personalRequest);

                }

                else if (colReqDtl.getRequestType().equals("Non-Personal")) {

                    TitleDeedDetailsList hiddenTitleDeedDetailsList = getF_IN_hidden_titleDeedDetails();// getf_in
                    IBCommonUtils.intializeDefaultvalues(hiddenTitleDeedDetailsList);
                    PopulateTitleDeedsDtlsForReqType populateTitleDeedsDtlsForReqType = new PopulateTitleDeedsDtlsForReqType();
                    titleDeedDetailsList =
                        populateTitleDeedsDtlsForReqType.getTitleDeedsDtlsList(colReqDtl.getRequestID(), hiddenTitleDeedDetailsList);

                }
                colReqDtl.setCategoryTypeDesc("");

                setF_OUT_collateralRequestDetails(colReqDtl);
            }

        }
        setF_OUT_titleDeedDtlsList(titleDeedDetailsList);
        setF_OUT_userExitEnable(true);
    }

    private void removeRow(BankFusionEnvironment env) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        CollateralRequestDetailsList newRow = getF_IN_collateralRequestDetailsList();
        BFCurrencyAmount totalCoverValue = getF_IN_reqEvalTotalAmount();
        ValidateRequestEvaluationBB.validateRequestID(getF_IN_islamicBankingObject().getDealID(), newRow);
        if (newRow.getCollateralRequestDetailsListCount() > 0) {
            CollateralRequestDetails[] colReq = newRow.getCollateralRequestDetailsList();
            for (CollateralRequestDetails collateralReq : colReq) {

                if (collateralReq.isSelect()) {
                    if (collateralReq.getCollateralID() == null
                        || (null != collateralReq.getCollateralID() && collateralReq.getCollateralID().isEmpty())
                        || (collateralReq.getRequestType().equals("Existing"))) {

                        if (getF_IN_islamicBankingObject().getTransactionName().equals("STANDALONE")) {
                            if (!collateralReq.getStatus().equals("DELETED")) {

                                ArrayList<String> params = new ArrayList<>();
                                params.add(getF_IN_islamicBankingObject().getDealID());
                                params.add(collateralReq.getRequestID());
                                String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? AND "
                                    + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTID + " = ?";
                                List<IBOCE_IB_CollateralRevaluationDetails> collateralReqDtls = factory
                                    .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
                                if (collateralReqDtls.size() == 0) {
                                    newRow.removeCollateralRequestDetailsList(collateralReq);
                                    totalCoverValue.setCurrencyAmount(
                                        totalCoverValue.getCurrencyAmount().subtract(collateralReq.getCoverValue().getCurrencyAmount()));
                                    // IBCommonUtils.raiseUnparameterizedEvent(44000288); //This request cannot be modified
                                } else {
                                    collateralReq.setStatus("DELETED");
                                    totalCoverValue.setCurrencyAmount(
                                        totalCoverValue.getCurrencyAmount().subtract(collateralReq.getCoverValue().getCurrencyAmount()));
                                }

                            }

                        } else {
                            totalCoverValue.setCurrencyAmount(
                                totalCoverValue.getCurrencyAmount().subtract(collateralReq.getCoverValue().getCurrencyAmount()));
                            newRow.removeCollateralRequestDetailsList(collateralReq);
                        }

                    } else {

                        IBCommonUtils.raiseUnparameterizedEvent(44000337);

                    }
                }

            }
            if (newRow.getCollateralRequestDetailsList().length > 0) {
                int sizeOfList = newRow.getCollateralRequestDetailsListCount();
                newRow.getCollateralRequestDetailsList(sizeOfList - 1).setSelect(true);

            }

            if (newRow.getCollateralRequestDetailsListCount() == 0) {
                CollateralRequestDetails param = new CollateralRequestDetails();
                IBCommonUtils.intializeDefaultvalues(param);
                setF_OUT_collateralRequestDetails(param);
            }
            setF_OUT_collateralRequestDetails(getF_IN_collateralRequestDetails());
            setF_OUT_newButtonVisible(false);
            // setF_OUT_saveButtonVisible(true);
            setF_OUT_reqEvalTotalAmount(totalCoverValue);
        }
        setF_OUT_collateralRequestDetailsList(newRow);
    }

    private void saveRow(BankFusionEnvironment env) {
        String statusDesc = IBConstants.EMPTY_STRING;
        CollateralRequestDetails collateralReqDtls = getF_IN_collateralRequestDetails();
        CollateralRequestDetailsList newRow = getF_IN_collateralRequestDetailsList();

        ValidateRequestEvaluationBB.validateRequestID(getF_IN_islamicBankingObject().getDealID(), newRow);
        if (newRow.getCollateralRequestDetailsListCount() > 0) {
            CollateralRequestDetails[] collateral = newRow.getCollateralRequestDetailsList();
            for (CollateralRequestDetails collateralDtls : collateral) {
                // IBCommonUtils.intializeDefaultvalues(collateralDtls);
                if (collateralDtls.isSelect()) {

                    if (collateralReqDtls.getRequestType().equals("Existing")) {
                        ValidateRequestEvaluationBB.validateCollateralIdExistingType(collateralReqDtls.getExistingRequestdtls());
                        ValidateRequestEvaluationBB.validateCoverValueExistingType(collateralReqDtls.getExistingRequestdtls());
                        // validate coverValue and collateralID
                        collateralDtls.setDescription(collateralReqDtls.getExistingRequestdtls().getDescription());
                        collateralDtls.setCoverValue(collateralReqDtls.getExistingRequestdtls().getUtilizeAmount());
                        collateralDtls.setAvailableBalance(collateralReqDtls.getExistingRequestdtls().getAvailableCoverValue());
                        collateralDtls.setCollateralID(collateralReqDtls.getExistingRequestdtls().getCollateralID());
                        collateralDtls.setStatus("Existing");
                        setF_OUT_hidden_titleDeedDtls(getF_IN_hidden_titleDeedDetails());
                        setF_OUT_hidden_buildingDtlsList(getF_IN_hidden_buildingsDetailsList());
                        setF_OUT_hidden_treesDtlsList(getF_IN_hidden_treesDetailsList());
                        setF_OUT_hidden_wellDtlsList(getF_IN_hidden_wellDetailsList());
                    } else if (collateralReqDtls.getRequestType().equals("No-Evaluation")) {

                        ValidateRequestEvaluationBB.validateCoverValueNoEvaluation(collateralReqDtls.getNoEvalRequestdtls());
                        // validate covervalue
                        collateralDtls.setDescription(collateralReqDtls.getNoEvalRequestdtls().getDescription());
                        collateralDtls.setCoverValue(collateralReqDtls.getNoEvalRequestdtls().getCoverValue());
                        collateralDtls.setStatus("New");
                        setF_OUT_hidden_titleDeedDtls(getF_IN_hidden_titleDeedDetails());
                        setF_OUT_hidden_buildingDtlsList(getF_IN_hidden_buildingsDetailsList());
                        setF_OUT_hidden_treesDtlsList(getF_IN_hidden_treesDetailsList());
                        setF_OUT_hidden_wellDtlsList(getF_IN_hidden_wellDetailsList());
                    } else if (collateralReqDtls.getRequestType().equals("Personal")) {

                        ValidateRequestEvaluationBB.validatePersonalPartyIdExist(collateralReqDtls, newRow);
                        String customerId = collateralReqDtls.getPersonalRequest().getCustomerId();
                        ValidateRequestEvaluationBB.validateCustomerIdPersonal(customerId);
                        // validate covervalue against available balance

                        collateralDtls.setDescription(collateralReqDtls.getPersonalRequest().getDescription());
                        collateralDtls.setCoverValue(collateralReqDtls.getPersonalRequest().getCoverValue());
                        collateralDtls.setStatus("New");

                        collateralDtls.setAvailableBalance(collateralReqDtls.getPersonalRequest().getAvailableBalance());
                        PersonalRequestdtls personalRequest = new PersonalRequestdtls();
                        personalRequest.setAvailableBalance(collateralReqDtls.getPersonalRequest().getAvailableBalance());
                        personalRequest.setDescription(collateralReqDtls.getPersonalRequest().getDescription());
                        personalRequest.setCoverValue(collateralReqDtls.getPersonalRequest().getCoverValue());
                        personalRequest.setRelationShipDtlsID(collateralReqDtls.getPersonalRequest().getRelationShipDtlsID());
                        personalRequest.setRelationshipType(collateralReqDtls.getPersonalRequest().getRelationshipType());
                        personalRequest.setRequestID(collateralReqDtls.getPersonalRequest().getRequestID());
                        personalRequest.setCustomerId(collateralReqDtls.getPersonalRequest().getCustomerId());
                        personalRequest.setName(collateralReqDtls.getPersonalRequest().getName());
                        personalRequest.setNationalID(collateralReqDtls.getPersonalRequest().getNationalID());
                        personalRequest.setPledgeAmount(collateralReqDtls.getPersonalRequest().getPledgeAmount());
                        personalRequest.setFromDate(collateralReqDtls.getPersonalRequest().getFromDate());
                        personalRequest.setToDate(collateralReqDtls.getPersonalRequest().getToDate());
                        if (CalendarUtil.isDateNullOrDefaultDate(collateralReqDtls.getPersonalRequest().getFromDate())) {
                            personalRequest.setFromDate(null);
                        }
                        if (CalendarUtil.isDateNullOrDefaultDate(collateralReqDtls.getPersonalRequest().getToDate())) {
                            personalRequest.setToDate(null);
                        }
                        personalRequest.setPledgeType(collateralReqDtls.getPersonalRequest().getPledgeType());
                        personalRequest.setSiloYear(collateralReqDtls.getPersonalRequest().getSiloYear());
                        personalRequest.setSiloArea(collateralReqDtls.getPersonalRequest().getSiloArea());

                        collateralDtls.setPersonalRequest(personalRequest);
                        collateralReqDtls.setPersonalRequest(personalRequest);

                        ValidateRequestEvaluationBB.validatePersonalTypeCount(newRow, collateralReqDtls); // validate
                        // personalTypeCount
                        ValidateRequestEvaluationBB.validateCoverValuePersonal(collateralDtls.getPersonalRequest());
                        setF_OUT_hidden_titleDeedDtls(getF_IN_hidden_titleDeedDetails());
                        setF_OUT_hidden_buildingDtlsList(getF_IN_hidden_buildingsDetailsList());
                        setF_OUT_hidden_treesDtlsList(getF_IN_hidden_treesDetailsList());
                        setF_OUT_hidden_wellDtlsList(getF_IN_hidden_wellDetailsList());

                    } else if (collateralReqDtls.getRequestType().equals("Non-Personal")) {
                        TitleDeedDetailsList TDDtlsList = getF_IN_titleDeedDetailsResidentialList();
                        TitleDeedDetailsList TDDtlsListAgri = getF_IN_titleDeedDtlsListAgriculture();
                        Boolean error = true;

                        if (collateralReqDtls.getCategoryType().equals("Residential")
                            || collateralReqDtls.getCategoryType().equals("Commercial")) {
                            for (TitleDeedDetails TDElement : TDDtlsList.getTitleDeedDetailsList()) {
                                if (TDElement.getResidentialDetails().getStatus().equals("Selected")) {
                                    if (TDElement.getResidentialDetails().getNetEvaluationValue().getCurrencyAmount()
                                        .compareTo(BigDecimal.ZERO) == 0) {
                                        IBCommonUtils.raiseUnparameterizedEvent(44000338);
                                    }
                                    error = false;
                                    break;
                                }
                            }
                        }
                        if (collateralReqDtls.getCategoryType().equals("Agricultural")) {
                            for (TitleDeedDetails TDElement : TDDtlsListAgri.getTitleDeedDetailsList()) {
                                if (TDElement.getAgricultureDetails().getStatus().equals("Selected")) {
                                    if (TDElement.getAgricultureDetails().getNetCoverValue().getCurrencyAmount()
                                        .compareTo(BigDecimal.ZERO) == 0) {
                                        IBCommonUtils.raiseUnparameterizedEvent(44000338);
                                    }
                                    error = false;
                                    break;
                                }
                            }

                        }
                        if (error) {
                            IBCommonUtils.raiseUnparameterizedEvent(44000329);
                        }
                        if (collateralReqDtls.getCategoryType().equals("Residential")
                            || collateralReqDtls.getCategoryType().equals("Commercial")) {

                            TitleDeedDetailsList titleDeedDtlsList = getF_IN_titleDeedDetailsResidentialList();// getf_in_titleDeedList
                            BigDecimal netEvaluationForResidential = BigDecimal.ZERO;
                            String description = CommonConstants.EMPTY_STRING;
                            for (TitleDeedDetails eachTitleDeed : titleDeedDtlsList.getTitleDeedDetailsList()) {
                                if (eachTitleDeed.getResidentialDetails().getStatus().equals("Selected")) {
                                    netEvaluationForResidential =
                                        eachTitleDeed.getResidentialDetails().getNetEvaluationValue().getCurrencyAmount();
                                    description = eachTitleDeed.getResidentialDetails().getDescription();
                                    collateralReqDtls.setTitleDeedIDPK(eachTitleDeed.getTitleDeedIDPK());
                                    collateralReqDtls.setTitleDeedNum(eachTitleDeed.getTitleDeedNum());
                                    eachTitleDeed.setRequestID(collateralReqDtls.getRequestID());
                                }
                            }

                            BFCurrencyAmount coverValue = new BFCurrencyAmount();
                            coverValue.setCurrencyAmount(netEvaluationForResidential);
                            coverValue.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
                            // validate titledeed in grid
                            ValidateRequestEvaluationBB.validatetitleDeedDtlsNonPersonal(getF_IN_titleDeedDetailsResidentialList());
                            collateralDtls.setCoverValue(coverValue);
                            collateralDtls.setDescription(description);

                            saveHiddenTitleDeed(titleDeedDtlsList, collateralReqDtls);

                        } else if (collateralReqDtls.getCategoryType().equals("Agricultural")) {

                            TitleDeedDetailsList titleDeedDtlsList = getF_IN_titleDeedDtlsListAgriculture();// getf_in_titleDeedList
                            BigDecimal netEvaluationForResidential = BigDecimal.ZERO;
                            String description = CommonConstants.EMPTY_STRING;
                            for (TitleDeedDetails eachTitleDeed : titleDeedDtlsList.getTitleDeedDetailsList()) {
                                if (eachTitleDeed.getAgricultureDetails().getStatus().equals("Selected")) {
                                    netEvaluationForResidential =
                                        eachTitleDeed.getAgricultureDetails().getNetCoverValue().getCurrencyAmount();
                                    description = eachTitleDeed.getAgricultureDetails().getDescription();
                                    collateralReqDtls.setTitleDeedIDPK(eachTitleDeed.getTitleDeedIDPK());
                                    collateralReqDtls.setTitleDeedNum(eachTitleDeed.getTitleDeedNum());
                                }
                            }
                            BFCurrencyAmount coverValue = new BFCurrencyAmount();
                            coverValue.setCurrencyAmount(netEvaluationForResidential);
                            coverValue.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());

                            ValidateRequestEvaluationBB.validatetitleDeedDtlsNonPersonal(getF_IN_titleDeedDtlsListAgriculture());
                            collateralDtls.setCoverValue(coverValue);
                            collateralDtls.setDescription(description);
                            saveHiddenTitleDeed(titleDeedDtlsList, collateralReqDtls);
                        }
                        collateralDtls.setCategoryType(collateralReqDtls.getCategoryType());
                        collateralDtls.setStatus("New");
                        collateralDtls.setTitleDeedIDPK(collateralReqDtls.getTitleDeedIDPK());
                        collateralDtls.setTitleDeedNum(collateralReqDtls.getTitleDeedNum());

                    }
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("REQ_TYP");

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                        if (collateralReqDtls.getRequestType().equals(gcCode.getCodeReference())) {
                            statusDesc = gcCode.getCodeDescription();
                            break;
                        }
                    }
                    BFCurrencyAmount amount = CalculationRequestEvaluationUtils.getCalculateTotalCoverValue(collateralReqDtls, newRow,
                        getF_IN_titleDeedDtlsResidential().getResidentialDetails(), getF_IN_titleDeedDetailsResidentialList(),
                        getF_IN_titleDeedDtlsAgriculture().getAgricultureDetails(), getF_IN_titleDeedDtlsListAgriculture(), getF_IN_well(),
                        getF_IN_wellDtlsList(), getF_IN_trees(), getF_IN_treesDtlsList(), getF_IN_buildings(), getF_IN_buildingsList(),
                        getF_IN_titleDeedNum(), getF_IN_islamicBankingObject());

                    setF_OUT_reqEvalTotalAmount(amount);

                    collateralDtls.setRequestTypeDesc(statusDesc);
                    collateralDtls.setRequestType(collateralReqDtls.getRequestType());
                    collateralDtls.setExistingRequestdtls(collateralReqDtls.getExistingRequestdtls());
                    collateralDtls.setNoEvalRequestdtls(collateralReqDtls.getNoEvalRequestdtls());
                    collateralDtls.setPersonalRequest(collateralReqDtls.getPersonalRequest());
                    collateralDtls.setCategoryTypeDesc("");

                }

            }

        }
        // CollateralRequestDetails vCollateralRequestDetails = new CollateralRequestDetails();

        // setF_OUT_collateralRequestDetails(vCollateralRequestDetails);
        setF_OUT_collateralRequestDetailsList(newRow);
        // setF_OUT_hidden_collateralRequestDetailsList(newRow);
        setF_OUT_newButtonVisible(false);

        // setF_OUT_saveButtonVisible(true);

    }

    private void saveHiddenTitleDeed(TitleDeedDetailsList titleDeedDtlsList, CollateralRequestDetails collateralReqDtls) {

        TitleDeedDetailsList hiddenTitleDeedList = getF_IN_hidden_titleDeedDetails();// getf_in
        WellDetailsList hiddenWellDtlsLIst = getF_IN_hidden_wellDetailsList();
        TreesDetailsList hiddenTreeList = getF_IN_hidden_treesDetailsList();// getf_in_hidden
        BuildingsDetailsList hiddenBuildingList = getF_IN_hidden_buildingsDetailsList();// getf_in_hidden

        if (hiddenTitleDeedList.getTitleDeedDetailsListCount() > 0
            && StringUtils.isEmpty(hiddenTitleDeedList.getTitleDeedDetailsList(0).getTitleDeedIDPK()))

        {

            hiddenTitleDeedList.removeTitleDeedDetailsListAt(0);

        }
        for (TitleDeedDetails eachHiddenTitleDeedDtl : hiddenTitleDeedList.getTitleDeedDetailsList()) {
            if (collateralReqDtls.getRequestID().equals(eachHiddenTitleDeedDtl.getRequestID())) {
                hiddenTitleDeedList.removeTitleDeedDetailsList(eachHiddenTitleDeedDtl);
            }
        }
        for (TitleDeedDetails eachTitleDeedDtl : titleDeedDtlsList.getTitleDeedDetailsList()) {
            TitleDeedDetails eachhiddenTitleDeed = new TitleDeedDetails();
            eachhiddenTitleDeed = eachTitleDeedDtl;
            eachhiddenTitleDeed.setRequestID(collateralReqDtls.getRequestID());
            hiddenTitleDeedList.addTitleDeedDetailsList(eachhiddenTitleDeed);

            // wells
            // hidden wells
            if (collateralReqDtls.getCategoryType().equals("Agricultural")) {

                for (WellDetails eachhiddenWellDtls : hiddenWellDtlsLIst.getWellDetailsList()) {
                    if (eachhiddenWellDtls.getRequestID() == null || eachhiddenWellDtls.getRequestID().isEmpty()) {
                        eachhiddenWellDtls.setRequestID(collateralReqDtls.getRequestID());
                    }
                }

                // trees

                for (TreeDetails eachhiddenTree : hiddenTreeList.getTreesDetailsList()) {
                    if (eachhiddenTree.getRequestID() == null || eachhiddenTree.getRequestID().isEmpty()) {
                        eachhiddenTree.setRequestID(collateralReqDtls.getRequestID());
                    }
                }

                // buildings

                for (BuildingDetails eachhiddenBuilding : hiddenBuildingList.getBuildingsDetailsList()) {
                    if (eachhiddenBuilding.getRequestID() == null || eachhiddenBuilding.getRequestID().isEmpty()) {
                        eachhiddenBuilding.setRequestID(collateralReqDtls.getRequestID());
                    }
                }
            }

        }
        setF_OUT_hidden_buildingDtlsList(hiddenBuildingList);
        setF_OUT_hidden_titleDeedDtls(hiddenTitleDeedList);
        setF_OUT_hidden_treesDtlsList(hiddenTreeList);
        setF_OUT_hidden_wellDtlsList(hiddenWellDtlsLIst);
        // setf_out all hidden

        // setf_out_hiddenTitleDeedList(hiddenTitleDeedList);

    }

    private void addNewRow(BankFusionEnvironment env) {
        BFCurrencyAmount totalCoverValue = getF_IN_reqEvalTotalAmount();
        CollateralRequestDetailsList newRow = getF_IN_collateralRequestDetailsList();
        CollateralRequestDetails[] collateralReq = newRow.getCollateralRequestDetailsList();
        int count = 0;
        if (collateralReq.length > 0) {
            for (CollateralRequestDetails colReqDtl : collateralReq) {

                if (colReqDtl.getRequestType().equals(CommonConstants.EMPTY_STRING)) {
                    colReqDtl.setSelect(true);
                    count++;
                } else {
                    colReqDtl.setSelect(false);
                }
            }
        }

        if (!(count > 0)) {
            CollateralRequestDetails vCollateralRequestDetailsList = new CollateralRequestDetails();
            //
            CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom(env);
            customAutoNumFatom.setF_IN_BONAME("COLLATERALREQUESTDTLS");
            customAutoNumFatom.setF_IN_isRightPad(false);
            customAutoNumFatom.setF_IN_Prefix("REQ");
            customAutoNumFatom.setF_IN_Suffix("");
            customAutoNumFatom.setF_IN_TotalLength(0);
            customAutoNumFatom.process(env);

            String requestDtlId = customAutoNumFatom.getF_OUT_PrimKey();

            ValidateRequestEvaluationBB.validateRequestID(getF_IN_islamicBankingObject().getDealID(), newRow);
            // validate request ID
            vCollateralRequestDetailsList.setRequestID(requestDtlId);
            vCollateralRequestDetailsList.setRequestTypeDesc(CommonConstants.EMPTY_STRING);
            vCollateralRequestDetailsList.setDescription(CommonConstants.EMPTY_STRING);
            BFCurrencyAmount coverValue = new BFCurrencyAmount();
            coverValue.setCurrencyAmount(BigDecimal.ZERO);
            coverValue.setCurrencyCode("");
            vCollateralRequestDetailsList.setCoverValue(coverValue);
            vCollateralRequestDetailsList.setSelect(true);

            newRow.addCollateralRequestDetailsList(vCollateralRequestDetailsList);

        }
        setF_OUT_collateralRequestDetailsList(newRow);
        CollateralRequestDetails param = new CollateralRequestDetails();
        setF_OUT_collateralRequestDetails(param);
        // setF_OUT_removeButtonVisible(true);
        setF_OUT_saveButtonVisible(false);
        setF_OUT_newButtonVisible(true);
        setF_OUT_reqEvalTotalAmount(totalCoverValue);

    }

}