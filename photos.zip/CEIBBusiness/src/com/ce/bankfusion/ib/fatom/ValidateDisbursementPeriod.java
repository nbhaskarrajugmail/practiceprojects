package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateDisbursementPeriod;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.util.CalendarUtil;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.msgs.v1r0.ThirdPartyPaymentsReadRs;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.PaymentScheduleThirdPartyDetails;

public class ValidateDisbursementPeriod extends AbstractCE_IB_ValidateDisbursementPeriod {

	public ValidateDisbursementPeriod(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		IslamicBankingObject islamicBankingObject = CeUtils.prepareIslamicBankingObject(getF_IN_dealId());
		ReadAssetData readAssetData = CeUtils.readAssetData(islamicBankingObject);

		String assetIdSelected = CommonConstants.EMPTY_STRING;
		ThirdPartyPaymentsReadRs thirdPartyPaymentsReadRs = getF_IN_thirdPartyPaymentsReadRs();
		if (thirdPartyPaymentsReadRs != null
				&& thirdPartyPaymentsReadRs.getPaymentScheduleThirdPartyDetailsCount() > 0) {
			for (PaymentScheduleThirdPartyDetails paymentScheduleThirdPartyDetails : thirdPartyPaymentsReadRs
					.getPaymentScheduleThirdPartyDetails()) {
				if (paymentScheduleThirdPartyDetails.getSelect())
					assetIdSelected = paymentScheduleThirdPartyDetails.getAssetDetailsId();
			}
		}
		int maxDisbursementPeriod = CeUtils.getDisbursementPeriodForAsset(readAssetData, assetIdSelected);

		int noOfMonths = (int) CalendarUtil.getMonthsBetweenDate1AndDate2(getF_IN_deliveryDate(),
				islamicBankingObject.getStartDate());

		if (noOfMonths + 1 > maxDisbursementPeriod * 12) {
			setF_OUT_raiseError(true);
		}
		setF_OUT_maxDisbursementPeriod(maxDisbursementPeriod);
	}
}
