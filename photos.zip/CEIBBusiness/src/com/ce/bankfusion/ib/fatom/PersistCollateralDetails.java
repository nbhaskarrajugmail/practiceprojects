package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PersonalRequestDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistCollateralDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_PersistCollateralDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CollateralUtil;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.types.AccountKeys;
import bf.com.misys.cbs.types.ChgAmtCalcDetails;
import bf.com.misys.cbs.types.ChgTaxAmtDetails;
import bf.com.misys.cbs.types.ExchangeRateDetails;
import bf.com.misys.cbs.types.OnlineChgKeyDtls;
import bf.com.misys.cbs.types.TaxAmtCalcDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.fbe.collateral.basic.types.ColAttributeDetails;
import bf.com.misys.fbe.collateral.basic.types.ColAttributeDetailsList;
import bf.com.misys.fbe.collateral.basic.types.CollateralBasicData;
import bf.com.misys.fbe.collateral.basic.types.CollateralBasicDataList;
import bf.com.misys.fbe.customer.collateral.CustomerCollateralDetails;
import bf.com.misys.fbe.customer.collateral.CustomerCollateralDetailsRs;
import bf.com.misys.fbe.insurance.types.InsuranceDetails;

public class PersistCollateralDetails extends AbstractCE_IB_PersistCollateralDetails implements ICE_IB_PersistCollateralDetails {

    private static final transient Log LOGGER = LogFactory.getLog(PersistCollateralDetails.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public PersistCollateralDetails() {
        // TODO Auto-generated constructor stub
    }

    public PersistCollateralDetails(BankFusionEnvironment env) {
        super(env);

    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        List<IBOCE_IB_DealCollateralDtls> createCollateralDetails = getNotPostedCollaterals();
        CollateralBasicDataList collateralBasicDataList = getCreateCollaterals(createCollateralDetails);
        if(collateralBasicDataList.getCollateralBasicDataCount()>0)
        {
            CustomerCollateralDetails customerCollateralDetails = new CustomerCollateralDetails();
            customerCollateralDetails.setCollateralBasicDataList(collateralBasicDataList);
            CustomerCollateralDetailsRs customerCollateralDetailsRs = CollateralUtil
                    .callPersistCollateralApi(customerCollateralDetails, env);

            if (CollateralUtil.ERROR.equals(customerCollateralDetailsRs.getRsHeader().getStatus().getOverallStatus())
                    || IBCommonUtils.isEmpty(customerCollateralDetailsRs.getCustColId())) {
                handleError(customerCollateralDetailsRs);
            }
            else {
                updateCollateralDetails(env,createCollateralDetails);
            }
        }
        LOGGER.info("Changing Status to COMPLETED" + getF_IN_ibObject().getDealID());
        statusChangeDealRelationship();
        statusChangeCollateral();
        StatusChangeReqEval();
        
    }

    private void statusChangeDealRelationship() {
        String dealRelationShipDtlsQuery = CeConstants.QUERYSTRING_WHERE
            + IBOCE_IB_DealRelationshipDetails.IBDEALID + " =?";
        ArrayList<String> queryParams = new ArrayList<>();
        queryParams.add(getF_IN_ibObject().getDealID());        
        List<IBOCE_IB_DealRelationshipDetails> resultSet = IBCommonUtils.getPersistanceFactory().findByQuery(
            IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery, queryParams, null, true);
        for(IBOCE_IB_DealRelationshipDetails dealRel : resultSet) {
            if(dealRel.getF_IBSTATUS().equals(CeConstants.APPROVE)||dealRel.getF_IBSTATUS().equals("SUBMIT")) {
                dealRel.setF_IBSTATUS(CeConstants.COMPLETED);
                dealRel.setF_IBTRANSACTIONID("");
                
            }
        }
        factory.commitTransaction();
        
        //need to fix the below code as the statement is not executing
        dealRelationShipDtlsQuery =  CeConstants.QUERYSTRING_WHERE
            + IBOCE_IB_DealRelationshipDetails.IBDEALID + " =? AND "+IBOCE_IB_DealRelationshipDetails.IBDEALSTATUS+" = ? AND "+IBOCE_IB_DealRelationshipDetails.IBSTATUS+" = ?";
        queryParams.clear();
        queryParams.add(getF_IN_ibObject().getDealID());  
        queryParams.add("DELETED");
        queryParams.add(CeConstants.COMPLETED);
        int res = factory.bulkDelete(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery, queryParams);
        
        factory.commitTransaction();
        factory.beginTransaction();
        
    }

    private void statusChangeCollateral() {
        String dealCollateralQuery =
            " WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + " =?";
                
        ArrayList<String> queryParams1 = new ArrayList<>();
        queryParams1.add(getF_IN_ibObject().getDealID());       
        List<IBOCE_IB_DealCollateralDtls> resultSet1 = IBCommonUtils.getPersistanceFactory().findByQuery(
                IBOCE_IB_DealCollateralDtls.BONAME, dealCollateralQuery, queryParams1, null, true);
        for(IBOCE_IB_DealCollateralDtls dealRel : resultSet1) {
             if(dealRel.getF_IBSTATUS().equals(CeConstants.APPROVE)||dealRel.getF_IBSTATUS().equals("SUBMIT")) {
                 dealRel.setF_IBSTATUS(CeConstants.COMPLETED);
                 dealRel.setF_IBTRANSACTIONID("");
                  factory.commitTransaction();
                  factory.beginTransaction();
               }
         }
        
    }

    private void StatusChangeReqEval() {
        String dealReEvaluationQuery =
            " WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " =?";
            ArrayList<String> queryParm = new ArrayList<>();
            queryParm.add(getF_IN_ibObject().getDealID());
            List<IBOCE_IB_CollateralRevaluationDetails> resultSet2 = IBCommonUtils.getPersistanceFactory().findByQuery(
                IBOCE_IB_CollateralRevaluationDetails.BONAME, dealReEvaluationQuery, queryParm, null, true);
            
            for(IBOCE_IB_CollateralRevaluationDetails dealReqEval : resultSet2) {
            if(dealReqEval.getF_IBSTEPSTATUS().equals(CeConstants.APPROVE)||dealReqEval.getF_IBSTEPSTATUS().equals("SUBMIT")) {
                dealReqEval.setF_IBSTEPSTATUS(CeConstants.COMPLETED);
                dealReqEval.setF_IBTRANSACTIONID("");
            
                }            
            }
            
            //detion of collateral from DB
            factory.commitTransaction();
            String dealDeleteReEvaluationQuery =
                " WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? AND "+IBOCE_IB_CollateralRevaluationDetails.IBSTATUS+" = ? AND  "+IBOCE_IB_CollateralRevaluationDetails.IBSTEPSTATUS+" = ?";

            queryParm.add("DELETED");
            queryParm.add(CeConstants.COMPLETED);
            int res = factory.bulkDelete(IBOCE_IB_CollateralRevaluationDetails.BONAME, dealDeleteReEvaluationQuery, queryParm);
            
            //resultSet2 = resultCopy;
            factory.commitTransaction();
            factory.beginTransaction();
    }

    private void updateCollateralDetails(BankFusionEnvironment env, List<IBOCE_IB_DealCollateralDtls> createCollateralDetails) {
        for (IBOCE_IB_DealCollateralDtls dealCollateralDtls : createCollateralDetails) {
            dealCollateralDtls.setF_IBSYSTEMSTATUS(CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED);
            dealCollateralDtls.setF_IBMODIFIEDBY(env.getUserID());
            dealCollateralDtls.setF_IBMODIFIEDDTTM(IBCommonUtils.getBFBusinessDateTime());

            IBOCE_IB_CollateralRevaluationDetails createRequestCollateralDetails = (IBOCE_IB_CollateralRevaluationDetails) factory
                    .findByPrimaryKey(IBOCE_IB_CollateralRevaluationDetails.BONAME, dealCollateralDtls.getF_IBREQUESTID(), true);
            createRequestCollateralDetails.setF_IBCOLLATERALID(dealCollateralDtls.getBoID());
            createRequestCollateralDetails.setF_IBSTATUS(CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED);
        }
    }

    private void handleError(CustomerCollateralDetailsRs customerCollateralDetailsRs) {
        StringBuilder builder = new StringBuilder(IBConstants.EMPTY_STRING);
        if (customerCollateralDetailsRs.getRsHeader().getStatus().getCodes().length > 0) {
            for (int i = 0; i < customerCollateralDetailsRs.getRsHeader().getStatus().getCodesCount(); i++) {
                builder.append(customerCollateralDetailsRs.getRsHeader().getStatus().getCodes(i).getDescription());
            }
        }
        else if (!customerCollateralDetailsRs.getRsHeader().getStatus().getOverallStatus().isEmpty()) {
            builder.append(customerCollateralDetailsRs.getRsHeader().getStatus().getOverallStatus());
        }
        String[] msgArgs = { builder.toString() };
        IBCommonUtils.raiseParametrizedEvent(35000102, msgArgs);
    }
    private CollateralBasicDataList getCreateCollaterals(List<IBOCE_IB_DealCollateralDtls> createCollateralDetails) {
        LOGGER.info("Entering into getCreateCollaterals method-->" + getF_IN_ibObject().getDealID());
        CollateralBasicDataList collateralBasicDataList = new CollateralBasicDataList();
        if (null != createCollateralDetails && !createCollateralDetails.isEmpty()) {
            IBOIB_IDI_DealCustomerDetail dealPrimaryPartyDetails = IBCommonUtils.getDealPrimaryPartyDetails(getF_IN_ibObject().getDealID());
            IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_ibObject().getDealID());
            String customerCode = dealPrimaryPartyDetails.getF_CUSTOMERID();
            if (IBCommonUtils.isEmpty(getF_IN_ibObject().getCustomerName()) && null != dealPrimaryPartyDetails) {
                getF_IN_ibObject().setCustomerName(PanelUtils.readPartyDetails(customerCode));
            }
            for (IBOCE_IB_DealCollateralDtls dealCollateralDtls : createCollateralDetails) {
                CollateralBasicData collateralBasicData = (CollateralBasicData) CollateralUtil.intializeDefaultvalues(new CollateralBasicData());
                setEmptyObjects(collateralBasicData);
                collateralBasicData.setCollateralDtlId(dealCollateralDtls.getBoID());
                collateralBasicData.setCollateralType(dealCollateralDtls.getF_IBCOLLATERALTYPE());
                collateralBasicData.setCollateralStatus(CollateralUtil.COLLATERAL_STATUS);
                collateralBasicData.setCustomerCode(customerCode);
                collateralBasicData.setCustomerName(getF_IN_ibObject().getCustomerName());
                collateralBasicData.setBranchSortCode(dealDetails.getF_BranchSortCode());
                collateralBasicData.setCollateralDesc(dealCollateralDtls.getF_IBDESCRIPTION());
                collateralBasicData.setCoverageCurrencyCd(dealDetails.getF_IsoCurrencyCode());
                collateralBasicData.setCoverValue(dealCollateralDtls.getF_IBCOVERVALUE());
                collateralBasicData.setEffectiveDate(IBCommonUtils.getBFBusinessDate());
                collateralBasicData.setExpiryDate(dealCollateralDtls.getF_IBEXPIRYDATE());
                collateralBasicData.setIsoCurrencyCode(dealDetails.getF_IsoCurrencyCode());
                collateralBasicData.setFaceValue(dealCollateralDtls.getF_IBCOVERVALUE());
                collateralBasicData.setFixedAmount(null);
                collateralBasicData.setForcedSaleValue(dealCollateralDtls.getF_IBCOVERVALUE());
                collateralBasicData.setLiquidationCost(BigDecimal.ZERO);
                collateralBasicData.setMarketValue(dealCollateralDtls.getF_IBCOVERVALUE());
                collateralBasicData.setReviewDate(AddDaysToDate.run(dealCollateralDtls.getF_IBEXPIRYDATE(), -1));
                collateralBasicData.setBankValue(dealCollateralDtls.getF_IBCOVERVALUE());
                collateralBasicData.setHaircut(new BigDecimal(100));
                setAttributesByRequestType(dealCollateralDtls, collateralBasicData);
                collateralBasicDataList.addCollateralBasicData(collateralBasicData);
            }
        }
        LOGGER.info("Exiting from getCreateCollaterals method-->" + getF_IN_ibObject().getDealID());
        return collateralBasicDataList;
    }

    private List<IBOCE_IB_DealCollateralDtls> getNotPostedCollaterals() {
        String queryCondition = " WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + " = ? and "+ IBOCE_IB_DealCollateralDtls.IBSYSTEMSTATUS + " = ?";
        ArrayList<String> param = new ArrayList<String>();
        param.add(getF_IN_ibObject().getDealID());
        param.add(CollateralUtil.COLLATERAL_SYSTEM_STATUS_NOTPOSTED);
        List<IBOCE_IB_DealCollateralDtls> createCollateralDetails = (ArrayList<IBOCE_IB_DealCollateralDtls>) factory
                .findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, queryCondition, param, null, true);
        return createCollateralDetails;
    }

    private void setEmptyObjects(CollateralBasicData collateralBasicData) {
        collateralBasicData.setChgTaxAmtDetails((ChgTaxAmtDetails) CollateralUtil.intializeDefaultvalues(new ChgTaxAmtDetails()));
        TaxAmtCalcDetails taxAmtCalcDetails =(TaxAmtCalcDetails) CollateralUtil.intializeDefaultvalues(new TaxAmtCalcDetails());
        ChgAmtCalcDetails chgAmtCalcDetails =(ChgAmtCalcDetails) CollateralUtil.intializeDefaultvalues(new ChgAmtCalcDetails());
        chgAmtCalcDetails.setChgExchRateDetails((ExchangeRateDetails) CollateralUtil.intializeDefaultvalues(new ExchangeRateDetails()));
        chgAmtCalcDetails.setChgRecAcct((AccountKeys) CollateralUtil.intializeDefaultvalues(new AccountKeys()));
        chgAmtCalcDetails.setOnlineChgKeyDtls((OnlineChgKeyDtls) CollateralUtil.intializeDefaultvalues(new OnlineChgKeyDtls()));
        collateralBasicData.getChgTaxAmtDetails().setBillerTaxAmtCalcDetails(taxAmtCalcDetails);
        collateralBasicData.getChgTaxAmtDetails().setBillerChgAmtCalcDetails(chgAmtCalcDetails);
        collateralBasicData.getChgTaxAmtDetails().setChgAmtCalcDetails(chgAmtCalcDetails);
        collateralBasicData.getChgTaxAmtDetails().setOriginalChgAmtCalcDetails(chgAmtCalcDetails);
        collateralBasicData.getChgTaxAmtDetails().setOriginalTaxAmtCalcDetails(taxAmtCalcDetails);
        collateralBasicData.getChgTaxAmtDetails().setTaxAmtCalcDetails(taxAmtCalcDetails);
        collateralBasicData.setInsuranceDetails((InsuranceDetails) CollateralUtil.intializeDefaultvalues(new InsuranceDetails()));
    }

    private void setAttributesByRequestType(IBOCE_IB_DealCollateralDtls dealCollateralDtls,
            CollateralBasicData collateralBasicData) {
        ColAttributeDetailsList colAttributeDetailsList = (ColAttributeDetailsList) CollateralUtil
                .intializeDefaultvalues(new ColAttributeDetailsList());
        String collateralType = dealCollateralDtls.getF_IBCOLLATERALTYPE();
        if (CollateralUtil.REQUSEST_TYPE_PERSONAL.equals(dealCollateralDtls.getF_IBREQUESTTYPE())) {
            String queryCondition = " WHERE " + IBOCE_IB_PersonalRequestDtls.IBREQUESTID + "= ? ";
            ArrayList<String> param = new ArrayList<String>();
            param.add(dealCollateralDtls.getF_IBREQUESTID());
            List<IBOCE_IB_PersonalRequestDtls> personalRequestDtls = (ArrayList<IBOCE_IB_PersonalRequestDtls>) factory
                    .findByQuery(IBOCE_IB_PersonalRequestDtls.BONAME, queryCondition, param, null, false);
            if (null != personalRequestDtls && !personalRequestDtls.isEmpty()) {
                IBOCE_IB_DealRelationshipDetails dealRelationshipDetails = (IBOCE_IB_DealRelationshipDetails) factory
                        .findByPrimaryKey(IBOCE_IB_DealRelationshipDetails.BONAME,
                                personalRequestDtls.get(0).getF_IBRELATIONSIPDTLSID(), true);
                if (null != dealRelationshipDetails) {
                    String guarantorCustNumUdf = BankFusionPropertySupport
                            .getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                                    collateralType + CollateralUtil.UDF_PERSONAL_GUARANTORS_CUSTOMER_NUMBER, "", CeConstants.ADFIBCONFIGLOCATION);
                    if(IBCommonUtils.isNotEmpty(guarantorCustNumUdf))
                        setCollateralAttributeDtls(guarantorCustNumUdf,
                                dealRelationshipDetails.getF_IBPARTYID(), colAttributeDetailsList);
                    else
                        LOGGER.info(collateralType + CollateralUtil.UDF_PERSONAL_GUARANTORS_CUSTOMER_NUMBER +" is empty");
                }
            }
        }
        else if (CollateralUtil.REQUSEST_TYPE_NONPERSONAL.equals(dealCollateralDtls.getF_IBREQUESTTYPE())) {
            TitleDeedDetails titleDeedDtls = getTitleDeedDetails(dealCollateralDtls);
            String titleDeedNumUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
                    CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE, collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_NO, "",
                    CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(titleDeedNumUdf))
                setCollateralAttributeDtls(titleDeedNumUdf, titleDeedDtls.getTitleDeedNum(), colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_NO +" is empty");
            String typeUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                    collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_TYPE, "", CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(typeUdf))
                setCollateralAttributeDtls(typeUdf,
                        (IBCommonUtils.getGCChildDesc(CollateralUtil.TITLE_DEED_TYPE_GC_REFERENCE, titleDeedDtls.getType())),
                        colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_TYPE +" is empty");
            String sourceUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                    collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_SOURCE, "", CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(sourceUdf))
                setCollateralAttributeDtls(sourceUdf,
                        (IBCommonUtils.getGCChildDesc(CollateralUtil.TITLE_DEED_SOURCE_GC_REFERENCE, titleDeedDtls.getSource())),
                        colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_SOURCE +" is empty");
            String yearUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                    collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_YEAR, "", CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(yearUdf))
                setCollateralAttributeDtls(yearUdf, titleDeedDtls.getYear(), colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_TITLE_DEED_YEAR +" is empty");
            String planUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                    collateralType + CollateralUtil.UDF_NONPERSONAL_LAND_PLAN_NO, "", CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(planUdf))
                setCollateralAttributeDtls(planUdf, titleDeedDtls.getPlan(), colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_LAND_PLAN_NO +" is empty");
            String landPlotNumUdf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
                    CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE, collateralType + CollateralUtil.UDF_NONPERSONAL_LAND_PLOT_NO, "",
                    CeConstants.ADFIBCONFIGLOCATION);
            if (IBCommonUtils.isNotEmpty(landPlotNumUdf))
                setCollateralAttributeDtls(landPlotNumUdf, titleDeedDtls.getLandPlotNum(), colAttributeDetailsList);
            else
                LOGGER.info(collateralType + CollateralUtil.UDF_NONPERSONAL_LAND_PLOT_NO +" is empty");
            updateCollateralDtlsWithLatestTitleDeedInfo(dealCollateralDtls, titleDeedDtls);
        }

        collateralBasicData.setColAttrList(colAttributeDetailsList);
    }

    private void setCollateralAttributeDtls(String attributeId,String attributeValue,ColAttributeDetailsList colAttributeDetailsList) {
        ColAttributeDetails colAttributeDetails = new ColAttributeDetails();
        colAttributeDetails.setAttrId(attributeId);
        colAttributeDetails.setAttrValue(attributeValue);
        colAttributeDetailsList.addColAttributeDetailsList(colAttributeDetails);
    }

    private void updateCollateralDtlsWithLatestTitleDeedInfo(IBOCE_IB_DealCollateralDtls dealCollateralDtls,
            TitleDeedDetails titleDeedDtls) {
        dealCollateralDtls.setF_IBTITLEDEEDIDPK(titleDeedDtls.getTitleDeedIDPK());
        dealCollateralDtls.setF_IBTITLEDEEDNUM(titleDeedDtls.getTitleDeedNum());
        dealCollateralDtls.setF_IBTITLEDEEEDTYPE(titleDeedDtls.getType());
        dealCollateralDtls.setF_IBTITLEDEEEDSOURCE(titleDeedDtls.getSource());
        dealCollateralDtls.setF_IBTITLEDEEEDYEAR(titleDeedDtls.getYear());
        dealCollateralDtls.setF_IBTITLEDEEEDPLANNO(titleDeedDtls.getPlan());
        dealCollateralDtls.setF_IBTITLEDEEEDPLOTNUM(titleDeedDtls.getLandPlotNum());
       /* factory.commitTransaction();
        factory.beginTransaction();*/
    }

    private TitleDeedDetails getTitleDeedDetails(IBOCE_IB_DealCollateralDtls dealCollateralDtls) {
        LOGGER.info("Entering into getTitleDeedDetails method");
        TitleDeedDetails titleDeedDetails = new TitleDeedDetails();
        IBOCE_IB_CollateralRevaluationDetails createRequestCollateralDetails = (IBOCE_IB_CollateralRevaluationDetails) factory
                .findByPrimaryKey(IBOCE_IB_CollateralRevaluationDetails.BONAME, dealCollateralDtls.getF_IBREQUESTID(), true);
        if (null != createRequestCollateralDetails ) {
            Map inputParams = new HashMap();
            SearchTitleDeedDtlsRqType rq = new SearchTitleDeedDtlsRqType();
            rq.setTitleDeedId(createRequestCollateralDetails.getF_IBTITLEDEEDIDPK());
            rq.setPartyId("");
            inputParams.put("searchTitleDeedDtlsRqType", rq);
            try {
                HashMap outputParams = MFExecuter.executeMF("CE_FilterTitleDeedDtl_SRV",
                        BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
                SearchTitleDeedDtlsRsType rs = (SearchTitleDeedDtlsRsType) outputParams.get("searchTitleDeedDtlsRs");
                if (rs != null && rs.getListTitleDeedIdDtls() != null) {
                    TitleDeedDetailsType vtitleDeedDetail = rs.getListTitleDeedIdDtls().getTitleDeedDetails(0);
                    if (IBCommonUtils.isNotEmpty(vtitleDeedDetail.getTitleDeedIdpk())) {
                        titleDeedDetails.setLandPlotNum(vtitleDeedDetail.getLandPlotNumber());
                        titleDeedDetails.setPlan(vtitleDeedDetail.getLandPlanNumber());
                        titleDeedDetails.setTitleDeedNum(vtitleDeedDetail.getTitleDeedNumber());
                        titleDeedDetails.setType(vtitleDeedDetail.getTitleDeedType());
                        titleDeedDetails.setSource(vtitleDeedDetail.getTitleDeedSource());
                        titleDeedDetails.setYear(String.valueOf(vtitleDeedDetail.getTitleDeedYear()));
                        titleDeedDetails.setTitleDeedIDPK(vtitleDeedDetail.getTitleDeedIdpk());
                    }
                }
            }
            catch (Exception e) {
                LOGGER.error("Exception in process method-->" + e.getMessage());
                e.printStackTrace();
            }
        }
        LOGGER.info("Exiting from getTitleDeedDetails method");
        return titleDeedDetails;
    }
}
