/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineConfigID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineConfig;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CreateProductAssetMapping;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_ProductAssetConfig;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

/**
 * @author chethabn
 * 
 *         Registry configuration excel upload
 *
 */
public class CreateProductAssetMapping extends AbstractCE_IB_CreateProductAssetMapping {
	private static final Log LOGGER = LogFactory.getLog(CreateProductAssetMapping.class);
	private static final long serialVersionUID = -6977453506304820463L;
	public static final String SELECT_DISTINCT_GRP_CD = "SELECT DISTINCT " + IBOCE_IB_PricingEngineConfig.GRP_CDPK
			+ " FROM " + IBOCE_IB_PricingEngineConfig.BONAME;

	public CreateProductAssetMapping(BankFusionEnvironment env) {
		super(env);

	}

	public CreateProductAssetMapping() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		try {
			getRegistryCfgByExcel();
		} catch (Exception e) {
			LOGGER.error("The File upload is failed " + e.getMessage());
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(44000206, new Object[] {}, LOGGER,
					IBCommonUtils.getBankFusionEnvironment());
		}
/*		BusinessEventSupport.getInstance().raiseBusinessInfoEvent(44000209, new Object[] {}, LOGGER,
				IBCommonUtils.getBankFusionEnvironment());*/
	}

	private void getRegistryCfgByExcel() throws IOException {
		String file = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
				"productAssetCfgLocation", "false");
		LOGGER.info(file + "is used to upload Registry Configuration");
		// Creating workbook from Excel
		Workbook workbook = null;
		try {
			// workbook = XSSFWorkbook

			try {
				workbook = WorkbookFactory.create(new File(file));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (Exception e) {
			LOGGER.error("The File " + file + " upload is failed " + e);
			throw e;
		}
		loadProductAssetMapping(workbook);
	}

	private final void loadProductAssetMapping(Workbook workbook) throws IOException {
		if (workbook != null) {
			// get the first sheet
			Sheet sheet = workbook.getSheetAt(0);
			DataFormatter dataFormatter = new DataFormatter();
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			// factory.bulkDeleteAll(IBOIB_IBF_ProductAssetConfig.BONAME);
			
			factory.bulkDeleteAll(IBOIB_IBF_ProductAssetConfig.BONAME);
			factory.commitTransaction();
			factory.beginTransaction();
			try {
				for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
					if (i >= 1) {
						String seq = dataFormatter.formatCellValue(sheet.getRow(i).getCell(0));
						LOGGER.info("Processing Row Seq  : " + seq);
						String subProductId = dataFormatter.formatCellValue(sheet.getRow(i).getCell(1));
						String GRP_CD1 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(2));
						String GRP_CD2 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(3));
						String GRP_CD3 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(4));
						String TOOL_NO = dataFormatter.formatCellValue(sheet.getRow(i).getCell(5));

						if (StringUtils.isNotEmpty(TOOL_NO)) {
							CE_IB_PricingEngineConfigID key = new CE_IB_PricingEngineConfigID();
							key.setF_GRP_CD(Integer.parseInt(GRP_CD1));
							key.setF_LISTSER(14);
							key.setF_TOOLNO(Integer.parseInt(TOOL_NO));
							LOGGER.info("Came in for astCatID update for GCD, TLN  : " + GRP_CD1 + " , " + TOOL_NO);
							IBOCE_IB_PricingEngineConfig pricingListFromDB = (IBOCE_IB_PricingEngineConfig) factory
									.findByPrimaryKey(IBOCE_IB_PricingEngineConfig.BONAME, key, true);
							if (null != pricingListFromDB
									&& StringUtils.isNotEmpty(pricingListFromDB.getF_ASSETCATEGORYID())) {
								String assetcategoryID = pricingListFromDB.getF_ASSETCATEGORYID();
								IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
										.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, assetcategoryID, true);
								String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
								if (StringUtils.isNotEmpty(parentCategoryID)) {
									IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
											.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
									productAssetConfig.setF_ASSETCATEGORYID(parentCategoryID);
									productAssetConfig.setF_PRODUCTID(subProductId);
									productAssetConfig.setF_PRODUCTTYPE("S");
									LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
									factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
								} else {
									LOGGER.info("Skipping updation for TOOL_NO-" + TOOL_NO);
								}
							}
						}
						if (StringUtils.isEmpty(TOOL_NO)) {
							String GRP_CD_WHERE_CLAUSE = "WHERE " + IBOCE_IB_PricingEngineConfig.GRP_CDPK + " =?";
							if (StringUtils.isNotEmpty(GRP_CD1) && !(GRP_CD1.equals("all groups"))) {
								LOGGER.info(
										"Came in for astCatID update for GCD1, TLN  : " + GRP_CD1 + " , " + TOOL_NO);
								ArrayList<String> params = new ArrayList<>();
								params.add(GRP_CD1);
								IPagingData pagingData = new PagingData(1, 10);
								pagingData.setRequiresTotalPages(true);
								List<IBOCE_IB_PricingEngineConfig> priceList = factory.findByQuery(
										IBOCE_IB_PricingEngineConfig.BONAME, GRP_CD_WHERE_CLAUSE, params, pagingData);
								if (priceList != null && !priceList.isEmpty()) {
									String categoryID = priceList.get(0).getF_ASSETCATEGORYID();
									if (StringUtils.isNotEmpty(categoryID)) {
										IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, categoryID, true);
										String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
										IBOIB_AST_AssetCategory parentAssetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, parentCategoryID,
														true);
										String superParentCategoryID = parentAssetCategory.getF_PARENTCATEGORY();
										if (StringUtils.isNotEmpty(superParentCategoryID)) {
											IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
													.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
											productAssetConfig.setF_ASSETCATEGORYID(superParentCategoryID);
											productAssetConfig.setF_PRODUCTID(subProductId);
											productAssetConfig.setF_PRODUCTTYPE("S");
											LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
											factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
										} else {
											LOGGER.info("Skipping updation for GRP_CD1-" + GRP_CD1);
										}
									}
								}
							}
							if (StringUtils.isNotEmpty(GRP_CD1) && (GRP_CD1.equals("all groups"))) {
								List<SimplePersistentObject> grpcds = factory
										.executeGenericQuery(SELECT_DISTINCT_GRP_CD, new ArrayList(), null, false);

								if (null != grpcds && grpcds.size() > 0) {
									for (SimplePersistentObject processtype : grpcds) {
										String GRP_CD = String.valueOf(processtype.getDataMap().get("0"));
										LOGGER.info("Came in for astCatID update for GCD, TLN for All Groups : "
												+ GRP_CD + " , " + TOOL_NO);
										ArrayList<String> params = new ArrayList<>();
										params.add(GRP_CD);
										IPagingData pagingData = new PagingData(1, 10);
										pagingData.setRequiresTotalPages(true);
										List<IBOCE_IB_PricingEngineConfig> priceList = factory.findByQuery(
												IBOCE_IB_PricingEngineConfig.BONAME, GRP_CD_WHERE_CLAUSE, params,
												pagingData);
										if (priceList != null && !priceList.isEmpty()) {
											String categoryID = priceList.get(0).getF_ASSETCATEGORYID();
											if (StringUtils.isNotEmpty(categoryID)) {
												IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
														.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, categoryID,
																true);
												String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
												IBOIB_AST_AssetCategory parentAssetCategory = (IBOIB_AST_AssetCategory) factory
														.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME,
																parentCategoryID, true);
												String superParentCategoryID = parentAssetCategory
														.getF_PARENTCATEGORY();
												if (StringUtils.isNotEmpty(superParentCategoryID)) {
													IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
															.getStatelessNewInstance(
																	IBOIB_IBF_ProductAssetConfig.BONAME);
													productAssetConfig.setF_ASSETCATEGORYID(superParentCategoryID);
													productAssetConfig.setF_PRODUCTID(subProductId);
													productAssetConfig.setF_PRODUCTTYPE("S");
													LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
													factory.create(IBOIB_IBF_ProductAssetConfig.BONAME,
															productAssetConfig);
												} else {
													LOGGER.info("Skipping updation for all Groups GRP_CD-" + GRP_CD);
												}
											}
										}
									}
								}
							}
							if (StringUtils.isNotEmpty(GRP_CD2)) {
								LOGGER.info(
										"Came in for astCatID update for GCD2, TLN  : " + GRP_CD2 + " , " + TOOL_NO);
								ArrayList<String> params = new ArrayList<>();
								params.add(GRP_CD2);
								IPagingData pagingData = new PagingData(1, 10);
								pagingData.setRequiresTotalPages(true);
								List<IBOCE_IB_PricingEngineConfig> priceList = factory.findByQuery(
										IBOCE_IB_PricingEngineConfig.BONAME, GRP_CD_WHERE_CLAUSE, params, pagingData);
								if (priceList != null && !priceList.isEmpty()) {
									String categoryID = priceList.get(0).getF_ASSETCATEGORYID();
									if (StringUtils.isNotEmpty(categoryID)) {
										IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, categoryID, true);
										String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
										IBOIB_AST_AssetCategory parentAssetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, parentCategoryID,
														true);
										String superParentCategoryID = parentAssetCategory.getF_PARENTCATEGORY();
										if (StringUtils.isNotEmpty(superParentCategoryID)) {
											IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
													.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
											productAssetConfig.setF_ASSETCATEGORYID(superParentCategoryID);
											productAssetConfig.setF_PRODUCTID(subProductId);
											productAssetConfig.setF_PRODUCTTYPE("S");
											LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
											factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
										} else {
											LOGGER.info("Skipping updation for GRP_CD2-" + GRP_CD2);
										}
									}
								}
							}
							if (StringUtils.isNotEmpty(GRP_CD3)) {
								ArrayList<String> params = new ArrayList<>();
								LOGGER.info(
										"Came in for astCatID update for GCD3, TLN  : " + GRP_CD3 + " , " + TOOL_NO);
								params.add(GRP_CD3);
								IPagingData pagingData = new PagingData(1, 10);
								pagingData.setRequiresTotalPages(true);
								List<IBOCE_IB_PricingEngineConfig> priceList = factory.findByQuery(
										IBOCE_IB_PricingEngineConfig.BONAME, GRP_CD_WHERE_CLAUSE, params, pagingData);
								if (priceList != null && !priceList.isEmpty()) {
									String categoryID = priceList.get(0).getF_ASSETCATEGORYID();
									if (StringUtils.isNotEmpty(categoryID)) {
										IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, categoryID, true);
										String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
										IBOIB_AST_AssetCategory parentAssetCategory = (IBOIB_AST_AssetCategory) factory
												.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, parentCategoryID,
														true);
										String superParentCategoryID = parentAssetCategory.getF_PARENTCATEGORY();
										if (StringUtils.isNotEmpty(superParentCategoryID)) {
											IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
													.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
											productAssetConfig.setF_ASSETCATEGORYID(superParentCategoryID);
											productAssetConfig.setF_PRODUCTID(subProductId);
											productAssetConfig.setF_PRODUCTTYPE("S");
											LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
											factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
										} else {
											LOGGER.info("Skipping updation for GRP_CD3-" + GRP_CD3);
										}
									}
								}
							}
						}

					}
				}

				// for Sheet2 for Machines
				Sheet sheet2 = workbook.getSheetAt(1);
				DataFormatter dataFormatter2 = new DataFormatter();
				/*
				 * IPersistenceObjectsFactory factory =
				 * BankFusionThreadLocal.getPersistanceFactory(); //
				 * factory.bulkDeleteAll(IBOIB_IBF_ProductAssetConfig.BONAME); final String
				 * REG_LIST_WHERECLAUSE = "WHERE " + IBOIB_IBF_ProductAssetConfig.PRODUCTID +
				 * " !=?"; ArrayList<String> param = new ArrayList<>();
				 * param.add("DUMMYPRODUCT");
				 * factory.bulkDelete(IBOIB_IBF_ProductAssetConfig.BONAME, REG_LIST_WHERECLAUSE,
				 * param); factory.commitTransaction(); factory.beginTransaction();
				 */
				String GRP_CD_WHERE_CLAUSE = "WHERE " + IBOCE_IB_PricingEngineConfig.TOOLNOPK + " =? AND "+IBOCE_IB_PricingEngineConfig.LISTSERPK+ " =?";
				String PRODUCT = "WHERE " + IBOIB_IBF_ProductAssetConfig.PRODUCTID + " =? AND "+IBOIB_IBF_ProductAssetConfig.ASSETCATEGORYID+ " =?";
				for (int i = 0; i < sheet2.getPhysicalNumberOfRows(); i++) {
					if (i >= 1) {
						String TOOL_NO = dataFormatter2.formatCellValue(sheet2.getRow(i).getCell(0));
						LOGGER.info("Processing Row for Machines and TOOL_NO  : " + TOOL_NO);
						try {
							if (StringUtils.isNotEmpty(TOOL_NO)) {
								ArrayList<String> params = new ArrayList<>();
								params.add(TOOL_NO);
								params.add("14");
								IPagingData pagingData = new PagingData(1, 100);
								pagingData.setRequiresTotalPages(true);
								List<IBOCE_IB_PricingEngineConfig> priceList = factory.findByQuery(
										IBOCE_IB_PricingEngineConfig.BONAME, GRP_CD_WHERE_CLAUSE, params, pagingData);
								if (priceList != null && !priceList.isEmpty()) {
									for (IBOCE_IB_PricingEngineConfig iboce_IB_PricingEngineConfig : priceList) {
										String categoryID = iboce_IB_PricingEngineConfig.getF_ASSETCATEGORYID();
										if (StringUtils.isNotEmpty(categoryID)) {
											IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) factory
													.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, categoryID, true);
											String parentCategoryID = assetCategory.getF_PARENTCATEGORY();

											if (StringUtils.isNotEmpty(parentCategoryID)) {
												IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
														.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
												productAssetConfig.setF_ASSETCATEGORYID(parentCategoryID);
												productAssetConfig.setF_PRODUCTID("DUMMYPRODUCT");
												productAssetConfig.setF_PRODUCTTYPE("S");
												LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
												factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
											} else {
												LOGGER.info("Skipping updation for Machines TOOL_NO-" + TOOL_NO);
											}
											
											try {
											IBOIB_AST_AssetCategory parentAssetCategory = (IBOIB_AST_AssetCategory) factory
													.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, parentCategoryID,
															true);
											String superParentCategoryID = parentAssetCategory.getF_PARENTCATEGORY();
											params.clear();
											params.add("DUMMYPRODUCT");
											params.add(superParentCategoryID);
											List<IBOIB_IBF_ProductAssetConfig> products=factory.findByQuery(IBOIB_IBF_ProductAssetConfig.BONAME, PRODUCT, params, pagingData);
											if (products==null ||products.size()==0) {
												IBOIB_IBF_ProductAssetConfig productAssetConfig = (IBOIB_IBF_ProductAssetConfig) factory
														.getStatelessNewInstance(IBOIB_IBF_ProductAssetConfig.BONAME);
												productAssetConfig.setF_ASSETCATEGORYID(superParentCategoryID);
												productAssetConfig.setF_PRODUCTID("DUMMYPRODUCT");
												productAssetConfig.setF_PRODUCTTYPE("S");
												LOGGER.info("Product: "+productAssetConfig.getF_PRODUCTID()+",Type: "+productAssetConfig.getF_PRODUCTTYPE()+",Category "+productAssetConfig.getF_ASSETCATEGORYID());
												factory.create(IBOIB_IBF_ProductAssetConfig.BONAME, productAssetConfig);
											} else {
												LOGGER.info("Skipping updation for Machines TOOL_NO-" + TOOL_NO);
											}
											}catch(Exception ee) {
												LOGGER.info("Skipping updation for Machines TOOL_NO-" + TOOL_NO);
											}
										}
									}
									
								}
							}
						} catch (Exception ee) {
							LOGGER.info("Skipping Row for Machines and TOOL_NO  : " + TOOL_NO + "Due to "
									+ ee.getLocalizedMessage());
						}
					}
				}
			} catch (Exception e) {
				workbook.close();
				LOGGER.info("failed Processing : " + e.getLocalizedMessage());
				throw e;

			} finally {
				workbook.close();
			}
		}
	}

}
