package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipPanel;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealRelationshipDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.DealRelationshipDetails;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipDtls;
import bf.com.misys.ib.types.IslamicBankingObject;

public class GetDealRelationshipDetails extends AbstractCE_IB_GetDealRelationshipDetails {

	public GetDealRelationshipDetails(BankFusionEnvironment env) {
		super(env);
	}


	private static String dealRelationshipPanelDisplayQuery = CeConstants.QUERYSTRING_WHERE
			+ IBOCE_IB_DealRelationshipPanel.IBDEALRELATIONSHIPDTLID + " =?";

	public void process(BankFusionEnvironment env) throws BankFusionException {
	    StringBuilder dealRelationShipDtlsQuery = new StringBuilder(CeConstants.QUERYSTRING_WHERE
	        + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? ");
	    IslamicBankingObject ibo = getF_IN_ibObject();
	    if(null != ibo.getTransactionID() && !ibo.getTransactionID().equals(getF_IN_dealId())) {
	        if(!dealRelationShipDtlsQuery.toString().contains(ibo.getTransactionID())) {
	        dealRelationShipDtlsQuery.append(" OR "+IBOCE_IB_DealRelationshipDetails.IBTRANSACTIONID+ " = '"+ ibo.getTransactionID()+"'");
	        }
	    }else {
	        dealRelationShipDtlsQuery.append(" AND ("+IBOCE_IB_DealRelationshipDetails.IBTRANSACTIONID+ " = '' OR "+IBOCE_IB_DealRelationshipDetails.IBTRANSACTIONID+" IS NULL OR "+IBOCE_IB_DealRelationshipDetails.IBDEALSTATUS+" ='DELETED')");
	    }
		DealRelationshipDetails dealRelationshipDetails = new DealRelationshipDetails();
		dealRelationshipDetails.removeAllRelationshipAgents();
		dealRelationshipDetails.removeAllRelationshipDtls();
		dealRelationshipDetails.setDealId(getF_IN_dealId());
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(getF_IN_dealId());
		List<IBOCE_IB_DealRelationshipDetails> resultSet = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery.toString(), queryParams, null, true);
		
		
    if (resultSet != null && !resultSet.isEmpty()) {
			for (IBOCE_IB_DealRelationshipDetails dealRelationshipAgents : resultSet) {
				RelationshipDtls vRelationshipDtls = new RelationshipDtls();
				vRelationshipDtls.setFromDate(dealRelationshipAgents.getF_IBFROMDATE());
				vRelationshipDtls.setPartnershipPercentage(dealRelationshipAgents.getF_IBPARTNERSHIPPER());
				vRelationshipDtls.setPartnerStatus(dealRelationshipAgents.getF_IBPARTNERSTATUS());
				vRelationshipDtls.setPartyId(dealRelationshipAgents.getF_IBPARTYID());
				vRelationshipDtls.setPartyName(dealRelationshipAgents.getF_IBPARTYNAME());
				vRelationshipDtls.setPartyNationalId(dealRelationshipAgents.getF_IBPARTYNATIONALID());
				vRelationshipDtls.setPledgeAmount(IBCommonUtils
						.getBFCurrencyAmount(dealRelationshipAgents.getF_IBPLEDGEAMOUNT(), getF_IN_dealCurrency()));
				vRelationshipDtls.setPledgeType(dealRelationshipAgents.getF_IBPLEDGETYPE());
				vRelationshipDtls.setRelationshipDtlId(dealRelationshipAgents.getBoID());
				vRelationshipDtls.setRelationshipType(dealRelationshipAgents.getF_IBRELATIONSHIPTYPE());
				vRelationshipDtls.setSiloArea(dealRelationshipAgents.getF_IBSILOAREA());
				vRelationshipDtls.setSiloYear(dealRelationshipAgents.getF_IBSILOYEAR());
				vRelationshipDtls.setToDate(dealRelationshipAgents.getF_IBTODATE());
				vRelationshipDtls.setRelationshipDtlId(dealRelationshipAgents.getBoID());
				vRelationshipDtls.setTransactionID(dealRelationshipAgents.getF_IBTRANSACTIONID());
				vRelationshipDtls.setDealStatus(null==dealRelationshipAgents.getF_IBDEALSTATUS() || dealRelationshipAgents.getF_IBDEALSTATUS().isEmpty()?"NEW":dealRelationshipAgents.getF_IBDEALSTATUS());
				vRelationshipDtls.setSelect(false);
				getPanelDisplayDetails(dealRelationshipAgents.getBoID(), vRelationshipDtls);
				dealRelationshipDetails.addRelationshipDtls(vRelationshipDtls);
			}
		}
		setF_OUT_dealRelationshipDetails(dealRelationshipDetails);
	}

	private void getPanelDisplayDetails(String boID, RelationshipDtls relationshipDtls) {
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(boID);
		List<IBOCE_IB_DealRelationshipPanel> resultSet = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealRelationshipPanel.BONAME, dealRelationshipPanelDisplayQuery, queryParams, null, true);
		if (resultSet != null && !resultSet.isEmpty()) {
			relationshipDtls.setDisplayAgents(resultSet.get(0).isF_IBAGENTSPANEL());
			relationshipDtls.setDisplayGuranteeToPay(resultSet.get(0).isF_IBGURANTEETOPAYPANEL());
			relationshipDtls.setDisplayPartners(resultSet.get(0).isF_IBPARTNERSPANEL());
		}
	}
}
