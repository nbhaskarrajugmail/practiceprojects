package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ProcessSadadPayments;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ProcessSadadPayments extends AbstractCE_IB_ProcessSadadPayments{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1024524267746621934L;

	public ProcessSadadPayments()
	{
		super();
	}
	
	public ProcessSadadPayments(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String status_in_string = "'"+CeConstants.SADAD_PYMT_SCHEDULED+"','"
				+CeConstants.SADAD_PYMT_CANCEL+"','"+
				CeConstants.SADAD_PYMT_UPDATE+"'";
		String whereClause = "WHERE "+IBOCE_IB_SadadPayments.IBDEALID + " = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTEPID + " = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTATUS + " IN ("
				+ status_in_string + ")";

		ArrayList<String> params = new ArrayList();
		params.add(ibObj.getDealID());
		params.add(ibObj.getStepID());
		List<IBOCE_IB_SadadPayments> paymentsToBeProcessed = factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, whereClause, params , null, false);
		String nationalID = CommonConstants.EMPTY_STRING;;
		if(null != paymentsToBeProcessed && !paymentsToBeProcessed.isEmpty())
		{
			String partyID = CommonConstants.EMPTY_STRING;
			try {
				partyID = ADFTechGrantAssetUtils.getDealCustomer(ibObj.getDealID());
			} catch (Exception e2) {
				e2.printStackTrace();
			}

			nationalID = SadadPaymentUtils.getNationalId(partyID);
		}
		
		for(IBOCE_IB_SadadPayments paymentToBeProcessed : paymentsToBeProcessed)
		{
			if(CeConstants.SADAD_PYMT_SCHEDULED.equals(paymentToBeProcessed.getF_IBSTATUS()))
			{
				String invoiceId = CommonConstants.EMPTY_STRING;
				//creating a new invoice - start
				String chargeDtlsID = paymentToBeProcessed.getF_IBDEALCHARGEDTLID();
				BigDecimal taxAmount =  CommonConstants.BIGDECIMAL_ZERO;
				BigDecimal chargeAmount = CommonConstants.BIGDECIMAL_ZERO;
				IBOIB_DLI_DealAssetChargesdtls chargeDtl = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, chargeDtlsID, false);
				if("STEP".equalsIgnoreCase(chargeDtl.getF_CHARGETYPE()))
				{
					taxAmount = chargeDtl.getF_TaxAmount();
					chargeAmount = chargeDtl.getF_ChargeAmount().add(chargeDtl.getF_TaxAmount());
				}
				else
				{
					taxAmount = chargeDtl.getF_UNPAIDTAXAMOUNT();
					chargeAmount = chargeDtl.getF_UNPAIDCHARGEAMOUNT().add(chargeDtl.getF_UNPAIDTAXAMOUNT());
				}
				invoiceId = SadadPaymentUtils.createSadadInvoice(nationalID, ibObj.getDealID(), chargeAmount, taxAmount, chargeDtl.getF_FEESCONFIGID());
				//creating a new invoice - end
				//updating the status and invoiceID
				paymentToBeProcessed.setF_IBSTATUS(CeConstants.SADAD_PYMT_ON_SADAD);
				paymentToBeProcessed.setF_IBINVOICEID(invoiceId);
				paymentToBeProcessed.setF_IBINVOICEDATE(SystemInformationManager.getInstance().getBFBusinessDate());
			}
			else if(CeConstants.SADAD_PYMT_CANCEL.equals(paymentToBeProcessed.getF_IBSTATUS()))
			{
				//canceling the invoice
				SadadPaymentUtils.cancelInvoice(paymentToBeProcessed.getF_IBINVOICEID(), paymentToBeProcessed.getF_IBDEALCHARGEDTLID());
				//updating the status
				paymentToBeProcessed.setF_IBSTATUS(CeConstants.SADAD_PYMT_CANCELLED);
			}
			else if(CeConstants.SADAD_PYMT_UPDATE.equals(paymentToBeProcessed.getF_IBSTATUS()))
			{
				String invoiceID = CommonConstants.EMPTY_STRING;
				//canceling the original invoice
				String originalInvoiceID = paymentToBeProcessed.getF_IBINVOICEID();
				SadadPaymentUtils.cancelInvoice(originalInvoiceID, paymentToBeProcessed.getF_IBDEALCHARGEDTLID());
				//updating the originalInvoiceID
				paymentToBeProcessed.setF_IBORIGINVOICEID(originalInvoiceID);
				//creating a new invoice - start
				String chargeDtlsID = paymentToBeProcessed.getF_IBDEALCHARGEDTLID();
				BigDecimal taxAmount =  CommonConstants.BIGDECIMAL_ZERO;
				BigDecimal chargeAmount = CommonConstants.BIGDECIMAL_ZERO;
				IBOIB_DLI_DealAssetChargesdtls chargeDtl = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, chargeDtlsID, false);
				if("STEP".equalsIgnoreCase(chargeDtl.getF_CHARGETYPE()))
				{
					taxAmount = chargeDtl.getF_TaxAmount();
					chargeAmount = chargeDtl.getF_ChargeAmount().add(chargeDtl.getF_TaxAmount());
				}
				else
				{
					taxAmount = chargeDtl.getF_UNPAIDTAXAMOUNT();
					chargeAmount = chargeDtl.getF_UNPAIDCHARGEAMOUNT().add(chargeDtl.getF_UNPAIDTAXAMOUNT());
				}
				invoiceID = SadadPaymentUtils.createSadadInvoice(nationalID, ibObj.getDealID(), chargeAmount, taxAmount, chargeDtl.getF_FEESCONFIGID());
				//creating a new invoice - end
				//updating the status and invoiceID
				paymentToBeProcessed.setF_IBINVOICEID(invoiceID);
				paymentToBeProcessed.setF_IBINVOICEDATE(SystemInformationManager.getInstance().getBFBusinessDate());
				paymentToBeProcessed.setF_IBSTATUS(CeConstants.SADAD_PYMT_ON_SADAD);
				
			}
		}
	}

}
