package com.ce.bankfusion.ib.fatom;

import java.util.Calendar;
import java.util.Date;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DefaultPricingData;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListCfg;

public class DefaultPricingData extends AbstractCE_IB_DefaultPricingData{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DefaultPricingData(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		Date  currentDate =SystemInformationManager.getInstance().getBFBusinessDate();
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		int year = cal.get(Calendar.YEAR);
		setF_OUT_currentYear(year);
	}
}
