package com.ce.bankfusion.ib.fatom;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_TransferToBank;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_TransferToBankEnquiry;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.runtime.toolkit.expression.function.ConvertToTimestamp;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class TransferToBankEnquiry extends AbstractCE_ADF_TransferToBankEnquiry {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(TransferToBankEnquiry.class.getName());

	ArrayList<Object> params = new ArrayList();
	String query = "";
	int pageNo;
	int totalPages;
	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;

	public TransferToBankEnquiry(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		getQuery();

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		IPagingData pagingData = null;

		if (getF_IN_PagingQuery() != null && getF_IN_PagingQuery().getPagingRequest() != null) {
			pageSize = getF_IN_PagingQuery().getPagingRequest().getNumberOfRows();
			pageNo = getF_IN_PagingQuery().getPagingRequest().getRequestedPage();
		}

		if (pageSize == 0)
			pageSize = PAGE_SIZE;
		if (pageNo == 0)
			pageNo = PAGE_NO;

		pagingData = new PagingData(pageNo, pageSize);
		pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
		this.runQuery(query, pagingData);
	}

	private VectorTable runQuery(String dynamicQuery, IPagingData pagingData) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Query used to fetch the data :" + dynamicQuery);
			LOGGER.info("Parameter Values for Query : " + params);
			LOGGER.info("Result Page Number : " + pagingData.getCurrentPageNumber());
		}
		List<SimplePersistentObject> resultSet = null;
		if (query.length() > 7) {
			resultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_ADF_TransferToBank.BONAME, query,
					params, pagingData, true);
		}
		VectorTable newResultVector = getVectorTableFromList(resultSet, pagingData.getCurrentPageNumber());
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		// pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		newResultVector.setPagingData(pageData);

		setF_OUT_result(newResultVector);
		setF_OUT_PaginatedData(newResultVector);
		totalPages = pagingData.getTotalPages();
		pagingData.getCurrentPageNumber();
		return newResultVector;
	}

	private VectorTable getVectorTableFromList(List<SimplePersistentObject> list, int pageNumber) {
		//List<GcDetails> listGcYnN = GenericCodes.getInstance().getGenricCodes("BOOLEANVALUES", 1);
		VectorTable vectorTable = new VectorTable();
		if (list != null && !list.isEmpty()) {
			Iterator var7 = list.iterator();
			int idx = (pageNumber - 1) * 10 + 1;
			while (var7.hasNext()) {
				IBOCE_ADF_TransferToBank transferToBank = (IBOCE_ADF_TransferToBank) var7.next();
				Map<String, Object> attribute = new HashMap<>();
				attribute.put("BANKID", transferToBank.getF_BANKID());
				attribute.put("CURRENCY", transferToBank.getF_CURRENCY());
				attribute.put("NOTES", transferToBank.getF_NOTES());
				attribute.put("SRNO", idx++);
				attribute.put("SELECT", false);
				attribute.put("POFROMDATE", transferToBank.getF_POFROMDATE());
				attribute.put("BOID", transferToBank.getBoID());
				attribute.put("POTODATE", transferToBank.getF_POTODATE());
				attribute.put("PROCESSDATE", transferToBank.getF_PROCESSDATE());
				attribute.put("PROCESSREFERENCE", transferToBank.getF_PROCESSREFERENCE());
				attribute.put("VALUEDATE", transferToBank.getF_VALUEDATE());
				

				vectorTable.addAll(new VectorTable(attribute));
			}
		}
		return vectorTable;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		Map supportedData = pagingState.getPagingHelper().getPagingModel();
		supportedData.put("PAGING_QUERY", query);
		supportedData.put("PAGING_PARAMS", params);
		return pagingState;
	}

	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map map) {

		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		query = (String) pagingModel.get("PAGING_QUERY");
		params = (ArrayList<Object>) pagingModel.get("PAGING_PARAMS");

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (map.containsKey("PAGENO")) {
			pageNo = (Integer) map.get("PAGENO");
		}
		if (map.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) map.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			resultVector = runQuery(query, pagingData);

		}
		return resultVector;
	}

	private void getQuery() {
		StringBuffer QUERY = new StringBuffer();
		String bankID = getF_IN_transferToBankEnquiry().getBankID();
		String currency = getF_IN_transferToBankEnquiry().getCurrency();
		String notes = getF_IN_transferToBankEnquiry().getNotes();
		String processReference = getF_IN_transferToBankEnquiry().getProcessReference();
		Date poDateFrom = getF_IN_transferToBankEnquiry().getPoDateFrom();
		Date poDateTo = getF_IN_transferToBankEnquiry().getPoDateTo();
		Date processDate = getF_IN_transferToBankEnquiry().getProcessDate();
		Date valueDate = getF_IN_transferToBankEnquiry().getValueDate();
		
		params.clear();
		if (!notes.isEmpty()) {
			QUERY.append(" WHERE " + IBOCE_ADF_TransferToBank.NOTES + " like '%" + notes + "%'");
		}else {
			QUERY.append(" WHERE ");
		}
		if (!bankID.isEmpty()) {
			QUERY.append(" AND " + IBOCE_ADF_TransferToBank.BANKID + " =? ");
			params.add(bankID);
		} 
		
		if (poDateFrom != null&& !poDateFrom.equals(new Date(0))) {
			Timestamp fromDate = ConvertToTimestamp.run(poDateFrom);
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_ADF_TransferToBank.POFROMDATE + " >= ? ");
			} else {
				QUERY.append(IBOCE_ADF_TransferToBank.POFROMDATE + " >= ? ");
			}
			params.add(fromDate);
		}
		if (poDateTo != null&& !poDateTo.equals(new Date(0))) {
			Timestamp toDate = ConvertToTimestamp.run(poDateTo);
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_ADF_TransferToBank.POTODATE + " <= ? ");
			} else {
				QUERY.append(IBOCE_ADF_TransferToBank.POTODATE + " <= ? ");
			}
			params.add(toDate);
		}
		if (processDate != null&& !processDate.equals(new Date(0))) {
			Timestamp valueDateT = ConvertToTimestamp.run(processDate);
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_ADF_TransferToBank.PROCESSDATE + " = ? ");
			} else {
				QUERY.append(IBOCE_ADF_TransferToBank.PROCESSDATE + " = ? ");
			}
			params.add(valueDateT);
		}
		if (valueDate != null&& !valueDate.equals(new Date(0))) {
			Timestamp valueDateT = ConvertToTimestamp.run(valueDate);
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_ADF_TransferToBank.VALUEDATE + " = ? ");
			} else {
				QUERY.append(IBOCE_ADF_TransferToBank.VALUEDATE + " = ? ");
			}
			params.add(valueDateT);
		}
		if (!processReference.isEmpty()) {
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_ADF_TransferToBank.PROCESSREFERENCE + " = ? ");
			} else {
				QUERY.append(IBOCE_ADF_TransferToBank.PROCESSREFERENCE  + " = ? ");
			}
			params.add(processReference);
		}
		query = QUERY.toString();
	}
	
}
