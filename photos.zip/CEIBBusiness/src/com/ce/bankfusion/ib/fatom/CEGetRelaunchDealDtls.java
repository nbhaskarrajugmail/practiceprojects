package com.ce.bankfusion.ib.fatom;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;

public class CEGetRelaunchDealDtls {
	
	private static Set<String> relaunchingDeals = new HashSet<>();
	private static Map<String,String> dealStepUserIDMap = new HashMap<>();
	private transient final static Log logger = LogFactory.getLog(CEGetRelaunchDealDtls.class.getName());
	private static final String bfConfLocation = "BFconfigLocation";
	
	public static Set<String> loadRelaunchingDeals() {
		String config = getADFIBConfigLocation();
		StringBuilder confLoc = new StringBuilder(CommonConstants.EMPTY_STRING);
		if(relaunchingDeals.isEmpty())
		{
			try {
				confLoc.append(config);
				confLoc.append("/conf/");
				confLoc.append("relaunchingDeals.txt");
				
				logger.info("CEGetRelaunchDealDtls :: loadRelaunchingDeals :: The file path :: " + confLoc.toString());

				try (BufferedReader br = new BufferedReader(new FileReader(confLoc.toString()))) {
					String line;
					while ((line = br.readLine()) != null) {
						relaunchingDeals.add(line.toString());
					}
				}
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("CEGetRelaunchDealDtls :: loadRelaunchingDeals :: The file read failed!" );
			}
		}
		//logger.info("CEGetInProgressDealDtls :: exipredDeals set length is :: " + relaunchingDeals.size());
		return relaunchingDeals;
	}
	
	public static Map<String, String> loadDealStepUserIDMapping() {
		String config = getADFIBConfigLocation();
		StringBuilder confLoc = new StringBuilder(CommonConstants.EMPTY_STRING);
		Properties tempProp = new Properties();
		if(dealStepUserIDMap.isEmpty())
		{

			try {
				confLoc.append(config);
				confLoc.append("/conf/");
				confLoc.append("dealStepUserIDMapping.properties");
				
				logger.info("CEGetRelaunchDealDtls :: loadDealStepUserIDMapping :: The file path :: " + confLoc.toString());

				InputStream stream = new FileInputStream(confLoc.toString());
				tempProp.load(stream);
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("CEGetRelaunchDealDtls :: loadDealStepUserIDMapping :: The file read failed!" );
			}
			for(Entry<Object, Object> eachEntry : tempProp.entrySet())
			{
				dealStepUserIDMap.put(eachEntry.getKey().toString(), eachEntry.getValue().toString());
			}
		}
		//logger.info("CEGetInProgressDealDtls :: dealStepUserIDMap map length is :: " + dealStepUserIDMap.size());
		return dealStepUserIDMap;
	}
	
	private static String getADFIBConfigLocation() {
		String confLocation = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
		if ((confLocation == null)) {
			try {
				File f = new File(System.getProperty(bfConfLocation));
				StringBuilder confLoc = new StringBuilder(CommonConstants.EMPTY_STRING);
				return confLoc.append(f.getCanonicalPath()).append("/").toString();
			} catch (Exception e) {
				logger.error(e.getStackTrace());
				return null;
			}

		} else if (confLocation.equals(CommonConstants.EMPTY_STRING)) {
			try {
				File f = new File(confLocation);
				StringBuilder confLoc = new StringBuilder(CommonConstants.EMPTY_STRING);
				return confLoc.append(f.getCanonicalPath()).append("/").toString();
			} catch (Exception e) {
				logger.error(e.getStackTrace());
				return null;
			}
		} else {
			try {
				File f = new File(confLocation);
				StringBuilder confLoc = new StringBuilder(CommonConstants.EMPTY_STRING);
				return confLoc.append(f.getCanonicalPath()).append("/").toString();
			} catch (Exception e) {
				logger.error(e.getStackTrace());
				return null;
			}
		}
	}

}
