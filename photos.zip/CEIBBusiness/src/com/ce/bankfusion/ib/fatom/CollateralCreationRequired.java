package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CollateralCreationRequired;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CollateralCreationRequired extends AbstractCE_IB_CollateralCreationRequired{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public CollateralCreationRequired()
	{
		super();
	}
	
	public CollateralCreationRequired(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		ErrorResponse errorResponse = new ErrorResponse();
		
		boolean isPersonal = false;
		boolean isNonPersonal = false;
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		
		String whereClause = " WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ?";
		
		ArrayList params = new ArrayList<>();
		params.add(ibObject.getDealID());
		List<IBOCE_IB_CollateralRevaluationDetails> evaluationDtls=factory.findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause, params, null, false);
		
		for(IBOCE_IB_CollateralRevaluationDetails evaludationDtl: evaluationDtls) {
			if(evaludationDtl.getF_IBCOLLATERALID()==null || evaludationDtl.getF_IBCOLLATERALID().isEmpty()) {
			if(evaludationDtl.getF_IBREQUESTTYPE()!=null && (evaludationDtl.getF_IBREQUESTTYPE().equalsIgnoreCase("Personal") || 
					evaludationDtl.getF_IBREQUESTTYPE().equalsIgnoreCase("No-Evaluation")))
				isPersonal = true;
			if(evaludationDtl.getF_IBREQUESTTYPE()!=null && evaludationDtl.getF_IBREQUESTTYPE().equalsIgnoreCase("Non-Personal"))
				isNonPersonal = true;
			}
		}
		
		if(isNonPersonal || isPersonal)
			errorResponse.setOVERALLSTATUS("REQUIRED");
		else
			errorResponse.setOVERALLSTATUS("NOTREQUIRED");

		setF_OUT_response(errorResponse);
		setF_OUT_islamicBankingObject(ibObject);
		
	}

}
