package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RegisterSubsidyAmountForAE;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CMN_TxnHeader;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.FeeUtils;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AccEntriesRegistrationDtls;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.EarlyAssetPayoffCollDtls;

public class RegisterSubsidyAmountForAE extends AbstractCE_IB_RegisterSubsidyAmountForAE {
	private static final Log LOGGER = LogFactory.getLog(RegisterSubsidyAmountForAE.class);
	private IBOCE_IB_EarlyAssetPayoffDtls earlyAssetPayoffDtlObj;

	public RegisterSubsidyAmountForAE(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		EarlyAssetPayoffCollDtls assetPayoffCollDtls = getAssetPayOffCollDtls();
		if (assetPayoffCollDtls.isReverseSubsidyPaid()
				&& assetPayoffCollDtls.getTotalSubsidyPaid()
						.getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) {
			EarlyAssetPayoffUtils.insertPayrecDetails(assetPayoffCollDtls, getF_IN_islamicBankingObject());
		}

		registerSubsidyAmountForAE(assetPayoffCollDtls);
	}

	private EarlyAssetPayoffCollDtls getAssetPayOffCollDtls() {
		EarlyAssetPayoffCollDtls assetPayoffCollDtls = new EarlyAssetPayoffCollDtls();
		earlyAssetPayoffDtlObj = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils.getPersistanceFactory().findByPrimaryKey(
				IBOCE_IB_EarlyAssetPayoffDtls.BONAME, getF_IN_islamicBankingObject().getTransactionID(), true);
		if (earlyAssetPayoffDtlObj != null) {
			assetPayoffCollDtls.setDealId(getF_IN_islamicBankingObject().getDealID());
			assetPayoffCollDtls.setInternalAccountNum(earlyAssetPayoffDtlObj.getF_IBACCOUNTNUMBER());
			assetPayoffCollDtls.setNarrative(earlyAssetPayoffDtlObj.getF_IBNARRATIVE());
			assetPayoffCollDtls.setReverseSubsidyPaid(earlyAssetPayoffDtlObj.isF_IBREVSUBSIDYPAID());
			assetPayoffCollDtls.setTotalSubsidyPaid(IBCommonUtils.getBFCurrencyAmount(
					earlyAssetPayoffDtlObj.getF_IBTOTALSUBSIDYAMOUNT(), getF_IN_islamicBankingObject().getCurrency()));
		}
		return assetPayoffCollDtls;
	}

	private void registerSubsidyAmountForAE(EarlyAssetPayoffCollDtls assetPayoffCollDtls) {
		IBOIB_CMN_TxnHeader txnHeader = IBCommonUtils.getTransactionHeaderDetails(
				getF_IN_islamicBankingObject().getDealID(), getF_IN_islamicBankingObject().getTransactionID());
		if (null != txnHeader )
			FeeUtils.deletePreExistingAERegistration(getF_IN_islamicBankingObject(),
					CeConstants.PAYMENTAMOUNTTYPE_EARLYASSETPAYOFF, getF_IN_islamicBankingObject().getTransactionID());

		if (assetPayoffCollDtls != null && assetPayoffCollDtls.isReverseSubsidyPaid()
				&& assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) {
			LOGGER.info(
					"Registering the subsidy amount for AE, for DealId " + getF_IN_islamicBankingObject().getDealID());
			LOGGER.info("Payment Amount: " + assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount());
			Amount paymentAmount = new Amount();
			paymentAmount.setAmountEdited(assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount());
			paymentAmount.setIsoCurrencyCode(getF_IN_islamicBankingObject().getCurrency());

			AccEntriesRegistrationDtls accEntriesRegDtls = new AccEntriesRegistrationDtls();
			accEntriesRegDtls.setAccountID(assetPayoffCollDtls.getInternalAccountNum());
			accEntriesRegDtls.setAmountInAccCurr(paymentAmount);
			accEntriesRegDtls.setBaseEquivalent(paymentAmount);
			accEntriesRegDtls.setDealId(getF_IN_islamicBankingObject().getDealID());
			accEntriesRegDtls.setEntityContext(CeConstants.PAYMENTAMOUNTTYPE_EARLYASSETPAYOFF);
			accEntriesRegDtls.setEntityId(getF_IN_islamicBankingObject().getTransactionID());
			accEntriesRegDtls.setExchangeRate(BigDecimal.ONE);
			accEntriesRegDtls.setExchangeRateType(CommonConstants.EMPTY_STRING);
			accEntriesRegDtls.setNarrative(assetPayoffCollDtls.getNarrative());
			accEntriesRegDtls.setProcessId(getF_IN_islamicBankingObject().getProcessConfigID());
			accEntriesRegDtls.setStepId(getF_IN_islamicBankingObject().getStepID());
			accEntriesRegDtls.setTransactionId(getF_IN_islamicBankingObject().getTransactionID());
			accEntriesRegDtls.setTransactionDt(IBCommonUtils.getBFBusinessDate());
			accEntriesRegDtls.setTxnAmount(paymentAmount);
			accEntriesRegDtls.setTxnCurrency(getF_IN_islamicBankingObject().getCurrency());
			accEntriesRegDtls.setTxnType(IBConstants.TRANSACTIONTYPE_DEBIT);
			accEntriesRegDtls.setValueDt(IBCommonUtils.getBFBusinessDate());

			HashMap param = new HashMap();
			param.put(CeConstants.REGSERVICE_ACCENTRIES_INPUT1, accEntriesRegDtls);
			param.put(CeConstants.REGSERVICE_ACCENTRIES_INPUT2, CeConstants.REGSERVICE_CALLING_MODE);
			HashMap<String, Object> outputParams = MFExecuter.executeMF(IBConstants.REGSERVICE_ACCENTRIES,
					BankFusionThreadLocal.getBankFusionEnvironment(), param);
			String txnDetailsId = ((String) outputParams.get(CeConstants.REGSERVICE_ACCENTRIES_OUTPUT1));
			updateTxnDtlsId(txnDetailsId);
		}
	}

	private void updateTxnDtlsId(String txnDetailsId) {
		if (earlyAssetPayoffDtlObj != null) {
			earlyAssetPayoffDtlObj.setF_IBTXNDETAILSID(txnDetailsId);
		}
	}
}
