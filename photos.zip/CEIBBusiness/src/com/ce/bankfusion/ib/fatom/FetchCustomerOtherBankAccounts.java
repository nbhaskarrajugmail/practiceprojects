package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FetchCustomerOtherBankAccounts;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Party;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyExternalBankDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.PartyOtherBankDtls;
import bf.com.misys.ib.types.PartyOtherBankDtlsList;

public class FetchCustomerOtherBankAccounts extends AbstractCE_IB_FetchCustomerOtherBankAccounts{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public FetchCustomerOtherBankAccounts()
	{
		super();
	}
	
	public FetchCustomerOtherBankAccounts(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		
		String partyId = getF_IN_partyId();
		PartyOtherBankDtlsList partyOtherBankDtlsList = new PartyOtherBankDtlsList();
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		
		String partyExternalBankAccounts = "WHERE "+ IBOPT_PFN_PartyExternalBankDetails.INTERNALPARTYID+"=?";
		
		ArrayList params = new ArrayList<>();
		params.clear();
		params.add(partyId);
		
		List<IBOPT_PFN_PartyExternalBankDetails> partyExternalBankAccountsList = factory.findByQuery(IBOPT_PFN_PartyExternalBankDetails.BONAME, partyExternalBankAccounts, params, null, false);
		
		for(IBOPT_PFN_PartyExternalBankDetails externalBankDtl :partyExternalBankAccountsList) {
			PartyOtherBankDtls partyOtherBankDtls = new PartyOtherBankDtls();
			
			IBOPT_PFN_Party partyDtls = (IBOPT_PFN_Party) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOPT_PFN_Party.BONAME, partyId, true);
			
			partyOtherBankDtls.setBankName(externalBankDtl.getF_ACCOUNTNAME());
			partyOtherBankDtls.setBranchCode(externalBankDtl.getF_EXTBRANCHSORTCODE());
			partyOtherBankDtls.setAccountNumber(externalBankDtl.getF_EXTACCOUNTNO());
			partyOtherBankDtls.setAccountName(partyDtls.getF_NAME());
			partyOtherBankDtls.setAccountType(externalBankDtl.getF_ACCOUNTTYPE());
			partyOtherBankDtls.setDateOpened(externalBankDtl.getF_ACCOUNTOPENDATE());
			
			partyOtherBankDtlsList.addPartyOtherBankDtls(partyOtherBankDtls);
		
		}
		
		setF_OUT_partyOtherBankDtlsList(partyOtherBankDtlsList);
		
		
	}

}
