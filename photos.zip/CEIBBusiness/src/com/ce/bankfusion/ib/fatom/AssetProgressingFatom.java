package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressPricingDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressing;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressPricingDtl;
import bf.com.misys.ib.types.AssetProgressPricingList;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetails;

public class AssetProgressingFatom extends AbstractCE_IB_AssetProgressing{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(AssetProgressingFatom.class.getName());
	
	private final String DISBURSED = "Disbursed";
  private final String NEW="New";
	public static final String SAVE = "SAVE";
	public static final String RETRIEVE = "RETRIEVE";
	private static final String BB_ID = "ASSETPROGRESSING";
	Properties confProperties = new Properties();
	
	private static String GET_REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBDEALNO+" = ?";
	private static String GET_ASSETPROGRESS_BY_REPORT = " WHERE "+IBOCE_IB_AssetProgressDtl.IBREPORTID+" = ?";
	private static String DELETE_REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBREPORTID+" = ?";
	private static String DELETE_ASSETPROGRESS_BY_REPORT = " WHERE "+IBOCE_IB_AssetProgressDtl.IBREPORTID+" = ?";
	private static String ASSET_PRICING_LIST_BY_REPORT = " WHERE "+IBOCE_IB_AssetProgressPricingDtl.IBREPORTID+" = ?";
	private static String ASSETPROGRESS_BY_DEAL_AND_STATUS =" WHERE " +IBOCE_IB_AssetProgressReport.IBDEALNO + " = ? AND " + IBOCE_IB_AssetProgressReport.IBSTATUS + " = ?";
	
	private static Map<Integer,	String> disbursedReportMap = new HashMap<Integer, String>();
	private static Map<String, BigDecimal> assetReportaccuMap = new HashMap<String, BigDecimal>();
	private static Map<String, BigDecimal> assetReportaccuFinalMap = new HashMap<String, BigDecimal>();
	
	private static Integer E_ASSET_PROGRESS_NET_AMOUNT_NEGATIVE = 44000380;
	
        

	@SuppressWarnings("deprecation")
    public AssetProgressingFatom(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	disbursedReportMap.clear();
    	assetReportaccuMap.clear();
    	assetReportaccuFinalMap.clear();
    	if(getF_IN_mode().equalsIgnoreCase(SAVE)) {
    		IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, getF_IN_islamicBankingObject().getProductID(), getF_IN_islamicBankingObject().getSubProductID(), getF_IN_islamicBankingObject().getStepID(), getF_IN_islamicBankingObject().getProcessConfigID());
    		if (bbConfig.getF_BUILDINGBLOCKMODE().equalsIgnoreCase("EDIT") && bbConfig.getF_EDITMODES().contains("F")) {
    			save();
    		}
    	}else if(getF_IN_mode().equalsIgnoreCase(RETRIEVE)){
    		retrieve(env);
    	}
    }

	private void retrieve(BankFusionEnvironment env) {
		AssetProgressReportDetails asstProgressReportDtls = new AssetProgressReportDetails();
		
		populateAssetProgressReport(asstProgressReportDtls);
		populateAssetProgressDetails(asstProgressReportDtls, env);
		populatePreviousAmounts(asstProgressReportDtls);
		for (AssetProgressDetails assetProgressDetails : asstProgressReportDtls.getAssetProgressDetailsList()) {
			BigDecimal previousUndisbursedAmount = assetProgressDetails.getAllowedFinalCost().getCurrencyAmount()
					.subtract(assetProgressDetails.getNetFinalCost().getCurrencyAmount());
			assetProgressDetails.getPrevouslyUnDisbursedAmount()
					.setCurrencyAmount(previousUndisbursedAmount.compareTo(CommonConstants.BIGDECIMAL_ZERO) > 0
							? previousUndisbursedAmount
							: CommonConstants.BIGDECIMAL_ZERO);
		}
		setF_OUT_assetProgressReportDetails(asstProgressReportDtls);
		List<String> specialLoanProcessesList = new ArrayList<>();
		String specialLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.SPECIAL_LOAN_SUBPRODUCTS, "",CeConstants.ADFIBCONFIGLOCATION);

		if (specialLoanProcesses != null && !specialLoanProcesses.isEmpty()) {
			specialLoanProcessesList = IBCommonUtils.isNotEmpty(specialLoanProcesses)? Arrays.asList(specialLoanProcesses.split(",")): new ArrayList<String>();
		}
		if (specialLoanProcessesList.contains(getF_IN_islamicBankingObject().getSubProductID())) {
			setF_OUT_isSpecialLoan(true);
		}
	}
	
	private void populatePreviousAmounts(AssetProgressReportDetails asstProgressReportDtls) {
		for(AssetProgressDetails asset : asstProgressReportDtls.getAssetProgressDetailsList()) {
			Integer disbursementNo = 0;
			for(Integer i : disbursedReportMap.keySet()) {
				if(disbursedReportMap.get(i).equals(asset.getReportID())) {
					disbursementNo = i;
					break;
				}
			}
			if(disbursementNo>1) {
				calculateAndSetPreviousCosts(asset, disbursementNo);
			}
		}
	}

	private void calculateAndSetPreviousCosts(AssetProgressDetails asset, Integer disbursementNo) {
		BigDecimal previousAccumCost = BigDecimal.ZERO;
		BigDecimal previousAccumFinalCost = BigDecimal.ZERO;
		disbursementNo--;

		if (disbursementNo > 0) {
			String reportID = disbursedReportMap.get(disbursementNo);
			previousAccumCost = previousAccumCost
					.add(assetReportaccuMap.get(asset.getAssetID() + "_" + reportID) == null ? BigDecimal.ZERO
							: assetReportaccuMap.get(asset.getAssetID() + "_" + reportID));
			previousAccumFinalCost = previousAccumFinalCost
					.add(assetReportaccuFinalMap.get(asset.getAssetID() + "_" + reportID) == null ? BigDecimal.ZERO
							: assetReportaccuFinalMap.get(asset.getAssetID() + "_" + reportID));
		}
		BFCurrencyAmount previousAccumAmount = new BFCurrencyAmount();
		previousAccumAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		previousAccumAmount.setCurrencyAmount(previousAccumCost);
		BFCurrencyAmount previousAccumFinalAmount = new BFCurrencyAmount();
		previousAccumFinalAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		previousAccumFinalAmount.setCurrencyAmount(previousAccumFinalCost);

		asset.setPreviousCalculatedCost(previousAccumAmount);
		asset.setPreviousFinalCost(previousAccumFinalAmount);
		asset.setPrevouslyDisbursedAmount(previousAccumFinalAmount);
		if (asset.getAccumulatedCalculatedCost().getCurrencyAmount()
				.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
			BFCurrencyAmount calculatedNetAmount = new BFCurrencyAmount();
			calculatedNetAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			calculatedNetAmount.setCurrencyAmount(
					asset.getAccumulatedCalculatedCost().getCurrencyAmount().subtract(previousAccumCost));
			BFCurrencyAmount finalNetAmount = new BFCurrencyAmount();
			finalNetAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			finalNetAmount.setCurrencyAmount(
					asset.getAccumulatedFinalCost().getCurrencyAmount().subtract(previousAccumFinalCost));

			asset.setNetCalculatedCost(calculatedNetAmount);
			asset.setNetFinalCost(finalNetAmount);
		}
	}

	private void populateAssetPricingList(String reportId, AssetProgressPricingList assetProgressPricingList) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(reportId);
		List<IBOCE_IB_AssetProgressPricingDtl> assetProgressPricingListDB = factory.findByQuery(IBOCE_IB_AssetProgressPricingDtl.BONAME, ASSET_PRICING_LIST_BY_REPORT, params, null, true);
		for(IBOCE_IB_AssetProgressPricingDtl pricingDetail : assetProgressPricingListDB) {
			AssetProgressPricingDtl pricingDtl = new AssetProgressPricingDtl();
			pricingDtl.setAssetSerial(pricingDetail.getF_IBASSETID());
			pricingDtl.setPricingListID(pricingDetail.getF_IBREPORTID());
			pricingDtl.setPricingAssetID(pricingDetail.getF_IBPRICELISTASSETID());
			pricingDtl.setReportID(pricingDetail.getF_IBREPORTID());
			BFCurrencyAmount defaultCost = new BFCurrencyAmount();
			defaultCost.setCurrencyAmount(new BigDecimal(0));
			defaultCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			pricingDtl.setPrice(defaultCost);
			assetProgressPricingList.addAssetRegistryList(pricingDtl);
		}
	}

	private void save() {
		AssetProgressReportDetails asstProgressReportDtls = getF_IN_assetProgressReportDetails();
		AssetProgressReport[] assetProgressReportList = asstProgressReportDtls.getAssetProgressReportList();
		AssetProgressDetails[] assetProgressDetailsList = asstProgressReportDtls.getAssetProgressDetailsList();
		if(asstProgressReportDtls.getAssetProgressReportListCount()==0) {
			IBCommonUtils.raiseUnparameterizedEvent(44000416);
		}
		for(AssetProgressDetails assetProgressDetail : assetProgressDetailsList) {
			if(assetProgressDetail.getNetCalculatedCost()!=null && assetProgressDetail.getNetCalculatedCost().getCurrencyAmount()!=null && 
					assetProgressDetail.getNetCalculatedCost().getCurrencyAmount().compareTo(BigDecimal.ZERO)<0) {
				String[] parms = new String[1];
				parms[0] = assetProgressDetail.getAssetID();
				IBCommonUtils.raiseParametrizedEvent(E_ASSET_PROGRESS_NET_AMOUNT_NEGATIVE, parms);
			}
		}
		deleteAssetProgressData();  // remove old data having status as New
		boolean isReportAvailable=false;		
		for(AssetProgressReport assetProgressReport : assetProgressReportList) {
			if(!assetProgressReport.getReportStatus().equalsIgnoreCase(DISBURSED)) {
			    isReportAvailable=true;
				deleteAssetProgressReport(assetProgressReport.getReportID());
				deleteAssetProgressDetails(assetProgressReport.getReportID());
				deleteAssetProgressPricing(assetProgressReport.getReportID());
				saveAssetProgressReport(assetProgressReport);
				for(AssetProgressDetails assetProgressDetail : assetProgressDetailsList) {
					if(assetProgressDetail.getReportID().equals(assetProgressReport.getReportID())) {
						saveAssetProgressDetail(assetProgressDetail);
					}
				}
			}		
		}
		//stopping user if proceeding without adding report
	  if(!isReportAvailable) {
        IBCommonUtils.raiseUnparameterizedEvent(44000416);  
    }
		saveAssetProgressPricingList();
	}

	private void saveAssetProgressPricingList() {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		AssetProgressPricingList assetPricingList = getF_IN_allAssetProgressPricingList();
		for(AssetProgressPricingDtl assetPricingDtl : assetPricingList.getAssetRegistryList()) {
			IBOCE_IB_AssetProgressPricingDtl dbAssetPricinDtl = (IBOCE_IB_AssetProgressPricingDtl) factory.getStatelessNewInstance(IBOCE_IB_AssetProgressPricingDtl.BONAME);
			dbAssetPricinDtl.setBoID(GUIDGen.getNewGUID());
			dbAssetPricinDtl.setF_IBASSETID(assetPricingDtl.getAssetSerial());
			dbAssetPricinDtl.setF_IBREPORTID(assetPricingDtl.getReportID());
			dbAssetPricinDtl.setF_IBPRICELISTASSETID(assetPricingDtl.getPricingAssetID());
			factory.create(IBOCE_IB_AssetProgressPricingDtl.BONAME, dbAssetPricinDtl);
		}
		
	}

	private void saveAssetProgressReport(AssetProgressReport assetProgressReport) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_AssetProgressReport assetProgressReportBOD = (IBOCE_IB_AssetProgressReport) factory.getStatelessNewInstance(IBOCE_IB_AssetProgressReport.BONAME);
		assetProgressReportBOD.setBoID(GUIDGen.getNewGUID());
		assetProgressReportBOD.setF_IBDEALNO(getF_IN_islamicBankingObject().getDealID());
		assetProgressReportBOD.setF_IBREPORTID(assetProgressReport.getReportID());
		assetProgressReportBOD.setF_IBISCOORDINATESMATCH(assetProgressReport.getCoordinateMatch());
		assetProgressReportBOD.setF_IBINSPECTOR(assetProgressReport.getInspectorName());
		assetProgressReportBOD.setF_IBREVIEWER(assetProgressReport.getReviewerName());
		assetProgressReportBOD.setF_IBVISITDATEG(assetProgressReport.getProgressVisitDateG());
		assetProgressReportBOD.setF_IBVISITDATEH(assetProgressReport.getProgressVisitDateH());
		assetProgressReportBOD.setF_IBNOTES(assetProgressReport.getReportNotes());
		assetProgressReportBOD.setF_IBDISBURSEMENTNO(assetProgressReport.getDisbursementNumber());
		assetProgressReportBOD.setF_IBTOTALPROGRESSPERCENT(assetProgressReport.getTotalProgressPercentage());
		assetProgressReportBOD.setF_IBISLASTDISBURSED(assetProgressReport.getLastDisbursement());
		assetProgressReportBOD.setF_IBISVISITDONE(assetProgressReport.getProgressVisitDone());
		assetProgressReportBOD.setF_IBSTATUS(assetProgressReport.getReportStatus());
		assetProgressReportBOD.setF_IBTOTALDISBURSEDAMT(assetProgressReport.getTotalDisbursementAmount().getCurrencyAmount());
		assetProgressReportBOD.setF_IBCOLLECTADVANCEPAY(assetProgressReport.getCollectAdvancePayment());
		factory.create(IBOCE_IB_AssetProgressReport.BONAME, assetProgressReportBOD);
	}
	
	private void saveAssetProgressDetail(AssetProgressDetails assetProgressDetail) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_AssetProgressDtl assetProgressDtlBOD = (IBOCE_IB_AssetProgressDtl) factory.getStatelessNewInstance(IBOCE_IB_AssetProgressDtl.BONAME);
		assetProgressDtlBOD.setBoID(GUIDGen.getNewGUID());
		assetProgressDtlBOD.setF_IBREPORTID(assetProgressDetail.getReportID());
		assetProgressDtlBOD.setF_IBASSETID(assetProgressDetail.getAssetID());
		assetProgressDtlBOD.setF_IBISINVOICE(assetProgressDetail.getInvoiceRequired());
		assetProgressDtlBOD.setF_IBINVOICEAMT(assetProgressDetail.getInvoiceAmount().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBCOMPLETIONPERCENT(assetProgressDetail.getInvoiceCompletionPercentage());
		assetProgressDtlBOD.setF_IBPRICELISTNO(assetProgressDetail.getPriceListNumber());
		assetProgressDtlBOD.setF_IBPRICELISTYEAR(assetProgressDetail.getPriceListYear());
		assetProgressDtlBOD.setF_IBMACHINENO(assetProgressDetail.getMachineNumber());
		assetProgressDtlBOD.setF_IBMACHINETYPE(assetProgressDetail.getMachineType());
		assetProgressDtlBOD.setF_IBATTR7(assetProgressDetail.getAttribute7());
		assetProgressDtlBOD.setF_IBATTR8(assetProgressDetail.getAttribute8());
		assetProgressDtlBOD.setF_IBATTR9(assetProgressDetail.getAttribute9());
		assetProgressDtlBOD.setF_IBACCUMULATEDCALCCOST(assetProgressDetail.getAccumulatedCalculatedCost().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBACCUMULATEDFINALCOST(assetProgressDetail.getAccumulatedFinalCost().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBADDITIONALNOTES(assetProgressDetail.getAssetNotes());
		assetProgressDtlBOD.setF_IBNORTHCOORDINATEO(assetProgressDetail.getNorthCoordinateO());
		assetProgressDtlBOD.setF_IBNORTHCOORDINATE(assetProgressDetail.getNorthCoordinate());
		assetProgressDtlBOD.setF_IBEASTCOORDINATEO(assetProgressDetail.getEastCoordinateO());
		assetProgressDtlBOD.setF_IBEASTCOORDINATE(assetProgressDetail.getEastCoordinate());
		assetProgressDtlBOD.setF_IBADDNLNUMBER(assetProgressDetail.getBoatMachineNumber());
		assetProgressDtlBOD.setF_IBADDNLNAME(assetProgressDetail.getBoatMachineName());
		assetProgressDtlBOD.setF_IBADDNLSERIALNO(assetProgressDetail.getBoatSerialNumber());
		
		assetProgressDtlBOD.setF_IBACTUALFINALCOST(assetProgressDetail.getActualFinalCost().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBALLOWEDFINALCOST(assetProgressDetail.getAllowedFinalCost().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBDEDUCTIONAMOUNT(assetProgressDetail.getDeductionAmount().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBFINALCOSTAFTERDEDUCTION(assetProgressDetail.getFinalCostAfterDeduction().getCurrencyAmount());
		assetProgressDtlBOD.setF_IBDEDUCTIONREASON(assetProgressDetail.getDeductionreason());
		
		factory.create(IBOCE_IB_AssetProgressDtl.BONAME, assetProgressDtlBOD);
		
	}
	
	private void populateAssetProgressReport(AssetProgressReportDetails asstProgressReportDtls) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		AssetProgressPricingList assetProgressPricingList = new AssetProgressPricingList();
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
		for(IBOCE_IB_AssetProgressReport report : assetProgressReportList) {
			AssetProgressReport assetProgressReport = new AssetProgressReport();
			assetProgressReport.setReportID(report.getF_IBREPORTID());
			assetProgressReport.setDealID(report.getF_IBDEALNO());
			assetProgressReport.setCoordinateMatch(report.isF_IBISCOORDINATESMATCH());
			assetProgressReport.setInspectorName(report.getF_IBINSPECTOR());
			assetProgressReport.setReviewerName(report.getF_IBREVIEWER());
			assetProgressReport.setProgressVisitDateG(report.getF_IBVISITDATEG());
			assetProgressReport.setProgressVisitDateH(report.getF_IBVISITDATEH());
			assetProgressReport.setReportNotes(report.getF_IBNOTES());
			assetProgressReport.setDisbursementNumber(report.getF_IBDISBURSEMENTNO());
			disbursedReportMap.put(report.getF_IBDISBURSEMENTNO(), report.getF_IBREPORTID());
			assetProgressReport.setTotalProgressPercentage(report.getF_IBTOTALPROGRESSPERCENT());
			assetProgressReport.setLastDisbursement(report.isF_IBISLASTDISBURSED());
			assetProgressReport.setProgressVisitDone(report.isF_IBISVISITDONE());
			assetProgressReport.setReportStatus(report.getF_IBSTATUS());
			assetProgressReport.setCollectAdvancePayment(report.getF_IBCOLLECTADVANCEPAY());
			BFCurrencyAmount amount = new BFCurrencyAmount();
			amount.setCurrencyAmount(report.getF_IBTOTALDISBURSEDAMT());
			amount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			assetProgressReport.setTotalDisbursementAmount(amount);
			asstProgressReportDtls.addAssetProgressReportList(assetProgressReport);
			populateAssetPricingList(report.getF_IBREPORTID(), assetProgressPricingList);
		}
		setF_OUT_allAssetProgressPricingList(assetProgressPricingList);
	}
	
	private void populateAssetProgressDetails(AssetProgressReportDetails asstProgressReportDtls, BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		AssetInfoAndStudyFatom andStudyFatom = new AssetInfoAndStudyFatom(env);
        andStudyFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
        andStudyFatom.setF_IN_mode("RETRIEVE");
        andStudyFatom.process(env);
        AssetThirdPartyDetails [] assetTPDetails= andStudyFatom.getF_OUT_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
		for(AssetProgressReport report : asstProgressReportDtls.getAssetProgressReportList()) {
			ArrayList<String> params = new ArrayList<>();
			params.add(report.getReportID());
			List<IBOCE_IB_AssetProgressDtl> assetProgressDetailsList = factory.findByQuery(IBOCE_IB_AssetProgressDtl.BONAME, GET_ASSETPROGRESS_BY_REPORT, params, null, true);
			for(IBOCE_IB_AssetProgressDtl progressDtl : assetProgressDetailsList) {
				for (AssetThirdPartyDetails assetThirdPartyDetails : assetTPDetails) {
					if(progressDtl.getF_IBASSETID().equals(assetThirdPartyDetails.getAssetSerial())) {
						AssetProgressDetails assetProgressDtl = new AssetProgressDetails();
						assetProgressDtl.setReportID(progressDtl.getF_IBREPORTID());
						assetProgressDtl.setAssetID(progressDtl.getF_IBASSETID());
						assetProgressDtl.setInvoiceRequired(progressDtl.isF_IBISINVOICE());
						BFCurrencyAmount invoiceamount = new BFCurrencyAmount();
						invoiceamount.setCurrencyAmount(progressDtl.getF_IBINVOICEAMT());
						invoiceamount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						assetProgressDtl.setInvoiceAmount(invoiceamount);
						assetProgressDtl.setInvoiceCompletionPercentage(progressDtl.getF_IBCOMPLETIONPERCENT());
						assetProgressDtl.setPriceListNumber(progressDtl.getF_IBPRICELISTNO());
						assetProgressDtl.setPriceListYear(progressDtl.getF_IBPRICELISTYEAR());
						assetProgressDtl.setMachineNumber(progressDtl.getF_IBMACHINENO());
						assetProgressDtl.setMachineType(progressDtl.getF_IBMACHINETYPE());
						assetProgressDtl.setIsAssetPriced(assetThirdPartyDetails.getIsAssetPriced());
						assetProgressDtl.setIsAssetDividable(assetThirdPartyDetails.getIsAssetDividable());
						assetProgressDtl.setAttribute7(progressDtl.getF_IBATTR7());
						assetProgressDtl.setAttribute8(progressDtl.getF_IBATTR8());
						assetProgressDtl.setAttribute9(progressDtl.getF_IBATTR9());
						BFCurrencyAmount calculatedCost = new BFCurrencyAmount();
						calculatedCost.setCurrencyAmount(progressDtl.getF_IBACCUMULATEDCALCCOST());
						calculatedCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						assetProgressDtl.setAccumulatedCalculatedCost(calculatedCost);
						BFCurrencyAmount finalCost = new BFCurrencyAmount();
						finalCost.setCurrencyAmount(progressDtl.getF_IBACCUMULATEDFINALCOST());
						finalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						assetProgressDtl.setAccumulatedFinalCost(finalCost);
						BFCurrencyAmount defaultCost = new BFCurrencyAmount();
						defaultCost.setCurrencyAmount(new BigDecimal(0));
						defaultCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						if(null!=disbursedReportMap.get(1) && disbursedReportMap.get(1).equals(progressDtl.getF_IBREPORTID())) {
							assetProgressDtl.setNetCalculatedCost(calculatedCost);
							assetProgressDtl.setNetFinalCost(finalCost);
						}else {
							assetProgressDtl.setNetCalculatedCost(defaultCost);
				            assetProgressDtl.setNetFinalCost(defaultCost);
						}
						assetReportaccuMap.put(progressDtl.getF_IBASSETID()+"_"+progressDtl.getF_IBREPORTID(), progressDtl.getF_IBACCUMULATEDCALCCOST());
						assetReportaccuFinalMap.put(progressDtl.getF_IBASSETID()+"_"+progressDtl.getF_IBREPORTID(), progressDtl.getF_IBACCUMULATEDFINALCOST());
						
						BFCurrencyAmount actualFinalCost = new BFCurrencyAmount();
						actualFinalCost.setCurrencyAmount(progressDtl.getF_IBACTUALFINALCOST());
						actualFinalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						
						BFCurrencyAmount allowedFinalCost = new BFCurrencyAmount();
						allowedFinalCost.setCurrencyAmount(progressDtl.getF_IBALLOWEDFINALCOST());
						allowedFinalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						
						BFCurrencyAmount deductionAmount = new BFCurrencyAmount();
						deductionAmount.setCurrencyAmount(progressDtl.getF_IBDEDUCTIONAMOUNT());
						deductionAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						
						BFCurrencyAmount finalCostAfterDeduction = new BFCurrencyAmount();
						finalCostAfterDeduction.setCurrencyAmount(progressDtl.getF_IBFINALCOSTAFTERDEDUCTION());
						finalCostAfterDeduction.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						
						BFCurrencyAmount previousUndisbursedAmount = new BFCurrencyAmount();
						previousUndisbursedAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
						previousUndisbursedAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						
						assetProgressDtl.setActualFinalCost(actualFinalCost);
						assetProgressDtl.setAllowedFinalCost(allowedFinalCost);
						assetProgressDtl.setDeductionAmount(deductionAmount);
						assetProgressDtl.setFinalCostAfterDeduction(finalCostAfterDeduction);
						assetProgressDtl.setPrevouslyUnDisbursedAmount(previousUndisbursedAmount);
						assetProgressDtl.setDeductionreason(progressDtl.getF_IBDEDUCTIONREASON());
						
						assetProgressDtl.setAssetNotes(progressDtl.getF_IBADDITIONALNOTES());
						assetProgressDtl.setNorthCoordinate(progressDtl.getF_IBNORTHCOORDINATE());
						assetProgressDtl.setNorthCoordinateO(progressDtl.getF_IBNORTHCOORDINATEO());
						assetProgressDtl.setEastCoordinate(progressDtl.getF_IBEASTCOORDINATE());
						assetProgressDtl.setEastCoordinateO(progressDtl.getF_IBEASTCOORDINATEO());
						assetProgressDtl.setBoatMachineNumber(progressDtl.getF_IBADDNLNUMBER());
						assetProgressDtl.setBoatMachineName(progressDtl.getF_IBADDNLNAME());
						assetProgressDtl.setBoatSerialNumber(progressDtl.getF_IBADDNLSERIALNO());

						//populating the asset attributes from Asset and study info
			            assetProgressDtl.setAssetCategory(assetThirdPartyDetails.getAssetCategory());
			            assetProgressDtl.setAssetName(assetThirdPartyDetails.getAssetName());
			            assetProgressDtl.setGroupCD(assetThirdPartyDetails.getGroupCD());
			            assetProgressDtl.setListNumber(0);
			            if(assetProgressDtl.getStudyAttribute7()==null || assetProgressDtl.getStudyAttribute7().compareTo(BigDecimal.ZERO)==0) {
			            	assetProgressDtl.setStudyAttribute7(assetThirdPartyDetails.getAttribute7());
			            }
			            if(assetProgressDtl.getStudyAttribute8()==null || assetProgressDtl.getStudyAttribute8().compareTo(BigDecimal.ZERO)==0) {
			            	assetProgressDtl.setStudyAttribute8(assetThirdPartyDetails.getAttribute8());
			            }
			            if(assetProgressDtl.getStudyAttribute9()==null || assetProgressDtl.getStudyAttribute9().compareTo(BigDecimal.ZERO)==0) {
			            	assetProgressDtl.setStudyAttribute9(assetThirdPartyDetails.getAttribute9());
			            }
			            assetProgressDtl.setToolNO(assetThirdPartyDetails.getToolNO());
			           
			            assetProgressDtl.setOriginalAssetStudyCost(assetThirdPartyDetails.getAssetStudyCost());
			            assetProgressDtl.setOriginalFinalCost(assetThirdPartyDetails.getFinalCost());
			            assetProgressDtl.setPreviousCalculatedCost(defaultCost);
			            assetProgressDtl.setPreviousFinalCost(defaultCost);
			            
						
						asstProgressReportDtls.addAssetProgressDetailsList(assetProgressDtl);
					}
				}
			}
		}
	}
	
	private void deleteAssetProgressDetails(String reportID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(reportID);
		factory.bulkDelete(IBOCE_IB_AssetProgressDtl.BONAME, DELETE_ASSETPROGRESS_BY_REPORT, params);
	}

	private void deleteAssetProgressReport(String reportID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(reportID);
		factory.bulkDelete(IBOCE_IB_AssetProgressReport.BONAME, DELETE_REPORTS_BY_DEAL_QUERY, params);
	}
	
	private void deleteAssetProgressPricing(String reportID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(reportID);
		factory.bulkDelete(IBOCE_IB_AssetProgressPricingDtl.BONAME, ASSET_PRICING_LIST_BY_REPORT, params);
	}
	
  private void deleteAssetProgressData() {
      IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      params.add(NEW);
      List<IBOCE_IB_AssetProgressReport> assetProgressReports =
          factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, ASSETPROGRESS_BY_DEAL_AND_STATUS, params, null, true);
      ArrayList<String> reportIds = new ArrayList<>();
      if (!IBCommonUtils.isNullOrEmpty(assetProgressReports)) {
          for (IBOCE_IB_AssetProgressReport assetProgressReport : assetProgressReports) {
              reportIds.add(assetProgressReport.getF_IBREPORTID());
          }
      }
      if (!IBCommonUtils.isNullOrEmpty(reportIds)) {
          for (String reportId : reportIds) {
              deleteAssetProgressReport(reportId);
              deleteAssetProgressDetails(reportId);
              deleteAssetProgressPricing(reportId);
          }
      }
  }
}
