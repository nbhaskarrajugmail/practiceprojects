package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateFollowUpInspector;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;

public class ValidateFollowUpInspector extends AbstractCE_IB_ValidateFollowUpInspector {

    private static final long serialVersionUID = 1L;

    public static final int INSPECTOR_NAME_WARNING = 44000201;

    private static final transient Log LOG = LogFactory.getLog(ValidateFollowUpInspector.class.getName());

    public ValidateFollowUpInspector() {
        super();
    }

    public ValidateFollowUpInspector(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {

        if (!IBCommonUtils.isNullOrEmpty(getF_IN_dealId()) && !IBCommonUtils.isNullOrEmpty(getF_IN_inspectorName()))
        {
            ArrayList<String> params = new ArrayList<String>();
            params.add(getF_IN_dealId());
            List<IBOCE_IB_FollowUpListConf> existingFollowUpList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
                IBOCE_IB_FollowUpListConf.BONAME, " where " + IBOCE_IB_FollowUpListConf.IBDEALID + " = ? ", params, null, true);
            IBOCE_IB_FollowUpListConf folowUpDtlsObj_Check = existingFollowUpList.size() > 0 ? existingFollowUpList.get(0) : null;
            if (null != folowUpDtlsObj_Check) {
                if (!folowUpDtlsObj_Check.getF_IBINSPECTORNAME().equals(getF_IN_inspectorName()))
                    BusinessEventSupport.getInstance().raiseBusinessWarningEvent(INSPECTOR_NAME_WARNING, new Object[] {}, LOG, env);
            }
            setF_OUT_isValidForSave(true);
        }
        else setF_OUT_isValidForSave(false);

    }

}
