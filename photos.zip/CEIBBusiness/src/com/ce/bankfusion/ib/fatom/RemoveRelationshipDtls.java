package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipAgents;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RemoveRelationShipDtls;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipDtls;
import bf.com.misys.ib.types.IslamicBankingObject;

public class RemoveRelationshipDtls extends AbstractCE_IB_RemoveRelationShipDtls {

    private static final long serialVersionUID = 1L;

    private static final transient Log LOG = LogFactory.getLog(RemoveRelationshipDtls.class.getName());

    public RemoveRelationshipDtls() {
        super();

    }

    public RemoveRelationshipDtls(BankFusionEnvironment env) {
        super(env);

    }

    @Override
    public void process(BankFusionEnvironment env) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String mode = getF_IN_mode();
        IslamicBankingObject ibo = getF_IN_ibo();
        getF_OUT_dealRelationShipDtls().removeAllRelationshipDtls();
        // mode remove. remove the entry from list if deal service else change status.
        if (mode.equals("REMOVE")) {
            RelationshipDtls[] relations = getF_IN_dealRealtionShipDtls().getRelationshipDtls();
            for (RelationshipDtls eachRelation : relations) {
                if(null == eachRelation.getPledgeAmount().getCurrencyCode()) {
                    eachRelation.getPledgeAmount().setCurrencyCode("");
                }
                if (eachRelation.isSelect() && ibo.getTransactionName().equals("STANDALONE")) {
                    String relationDtlsWhereClause = " where " + IBOCE_IB_DealRelationshipDetails.IBDEALID + " = ? AND "
                        + IBOCE_IB_DealRelationshipDetails.IBDEALRELATIONSHIPDTLID + " = ?";
                    ArrayList<String> paramsList = new ArrayList<String>();
                    paramsList.add(ibo.getDealID());
                    paramsList.add(eachRelation.getRelationshipDtlId());
                    List<IBOCE_IB_DealRelationshipDetails> resultSet =
                        factory.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, relationDtlsWhereClause, paramsList, null, true);

                    if (resultSet.size() == 0) {
                        getF_OUT_dealRelationShipDtls().removeRelationshipDtls(eachRelation);
                        // IBCommonUtils.raiseUnparameterizedEvent(44000288); //This request cannot be modified
                    } else {
                        eachRelation.setDealStatus("DELETED");
                        eachRelation.setSelect(false);
                        getF_OUT_dealRelationShipDtls().addRelationshipDtls(eachRelation);
                        
                    }

                } else {

                    if (getF_IN_ibo().getTransactionName().equals("STANDALONE")) {
                        eachRelation.setSelect(false);
                        getF_OUT_dealRelationShipDtls().addRelationshipDtls(eachRelation);
                        
                        continue;
                    }
                    if (!(eachRelation.isSelect() && getF_IN_ibo().getTransactionName().equals("DEAL"))) {
                        eachRelation.setSelect(false);
                        getF_OUT_dealRelationShipDtls().addRelationshipDtls(eachRelation);
                        
                    }

                }
                
            }

        }
        LOG.info(" Count of dealRelationshipDtls " + getF_OUT_dealRelationShipDtls().getRelationshipDtlsCount() );

    }
}
