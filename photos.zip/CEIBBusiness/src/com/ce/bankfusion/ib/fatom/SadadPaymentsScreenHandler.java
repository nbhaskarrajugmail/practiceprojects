package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SadadPaymentsScreenHandler;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.SadadPaymentDtlsList;
import bf.com.misys.ib.types.SadadPayments;

public class SadadPaymentsScreenHandler extends AbstractCE_IB_SadadPaymentsScreenHandler{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7636668395002022381L;

	public SadadPaymentsScreenHandler()
	{
		super();
	}

	public SadadPaymentsScreenHandler(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();
		switch(context)
		{
		case "saveRow":
			saveRow();
			break;
		case "selectRow":
			disableScalars();
			break;
		case "screenDisplay":
			getScreenDisplayDecision();
			break;
		default:
			break;
		}
	}

	private void getScreenDisplayDecision() {
		boolean displayScreen = false;
		if(isF_IN_isViewMode() && (getF_IN_noOfRows() > 0 || (getF_IN_noOfRows() == 0 && !isF_IN_isSupressIfBlank())))
		{
			displayScreen = true;
		}
		else if(!isF_IN_isViewMode() && isF_IN_isUserActionApplicable())
		{
			displayScreen = true;
		}
		setF_OUT_displayScreen(displayScreen);
	}

	private void disableScalars() {
		
		SadadPayments selectScalarValue = getF_IN_sadadPayment();
		boolean disableSave = true;
		if(!isF_IN_isViewMode() && (CeConstants.SADAD_PYMT_ON_SADAD.equalsIgnoreCase(selectScalarValue.getStatus()) || selectScalarValue.isDelete())){
			disableSave = false;
		}
		setF_OUT_disableSave(disableSave);
	}

	private void saveRow() {
		SadadPayments selectScalarValue = getF_IN_sadadPayment();
		SadadPaymentDtlsList gridData = getF_IN_sadadPaymentList();
		if(null != gridData && gridData.getSadadPaymentDtlsCount() > 0)
		{
			for(SadadPayments eachGridPayment : gridData.getSadadPaymentDtls())
			{
				if(eachGridPayment.isSelect())
				{
					eachGridPayment.setDelete(selectScalarValue.getDelete());
					if(selectScalarValue.isDelete())
					{
						eachGridPayment.setStatus(CeConstants.SADAD_PYMT_CANCEL);
						eachGridPayment.setStepId(getF_IN_islamicBankingObj().getStepID());
					}
					else
					{
						eachGridPayment.setStatus(CeConstants.SADAD_PYMT_ON_SADAD);
						String chargeDtlID = selectScalarValue.getFeeID();
						IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
						IBOIB_DLI_DealAssetChargesdtls chargeDtls = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, 
								chargeDtlID, false);
						eachGridPayment.setStepId(chargeDtls.getF_STEPID());
					}
				}
			}
		}
		setF_OUT_sadadPaymentListOut(gridData);
	}
}
