package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_GovtSubsidy;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_PartyLoanDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_FilterSubsidyDetailsPaginated;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.fbe.common.util.CommonUtil;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class FilterSubsidyDetailsPaginated extends AbstractCE_ADF_FilterSubsidyDetailsPaginated {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(FilterSubsidyDetailsPaginated.class.getName());

	ArrayList<Object> params = new ArrayList();
	String query = "";
	String batchReference = "";
	String action = "";
	int pageNo;
	int totalPages;
	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
	private static final String viewQuery = " WHERE " + IBOCE_ADF_PartyLoanDetails.CEPARTYID + " =? AND "+ IBOCE_ADF_PartyLoanDetails.CETYPE + " =?";
	public FilterSubsidyDetailsPaginated(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		getQuery();
		batchReference = getF_IN_batchReferenceGenerated();
		action = getF_IN_action();
		
		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		IPagingData pagingData = null;

		if (getF_IN_PagedQuery() != null && getF_IN_PagedQuery().getPagingRequest() != null) {
			pageSize = getF_IN_PagedQuery().getPagingRequest().getNumberOfRows();
			pageNo = getF_IN_PagedQuery().getPagingRequest().getRequestedPage();
		}

		if (pageSize == 0)
			pageSize = PAGE_SIZE;
		if (pageNo == 0)
			pageNo = PAGE_NO;

		pagingData = new PagingData(pageNo, pageSize);
		pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
		this.runQuery(query, pagingData);
	}

	private VectorTable runQuery(String dynamicQuery, IPagingData pagingData) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Query used to fetch the data :" + dynamicQuery);
			LOGGER.info("Parameter Values for Query : " + params);
			LOGGER.info("Result Page Number : " + pagingData.getCurrentPageNumber());
		}
		List<IBOCE_ADF_GovtSubsidy> resultSet = null;
		if (query.length() > 7) {
			resultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_ADF_GovtSubsidy.BONAME, query,
					params, pagingData, true);
		} 
		VectorTable newResultVector = getVectorTableFromList(resultSet, pagingData.getCurrentPageNumber());
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		// pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		newResultVector.setPagingData(pageData);

		// setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
		setF_OUT_PaginatedData(newResultVector);
		totalPages = pagingData.getTotalPages();
		pagingData.getCurrentPageNumber();
		return newResultVector;
	}

	private VectorTable getVectorTableFromList(List<IBOCE_ADF_GovtSubsidy> list, int pageNumber) {
		//List<GcDetails> listGcYnN = GenericCodes.getInstance().getGenricCodes("BOOLEANVALUES", 1);
		VectorTable vectorTable = new VectorTable();
		
		if (list != null && !list.isEmpty()) {
			Iterator var7 = list.iterator();
			int idx = (pageNumber - 1) * 10 + 1;
			while (var7.hasNext()) {
				IBOCE_ADF_GovtSubsidy govtSubsidy = (IBOCE_ADF_GovtSubsidy) var7.next();
				Map<String, Object> attribute = new HashMap<>();
				attribute.put("recordID", govtSubsidy.getBoID());
				attribute.put("currentDueAmount", govtSubsidy.getF_IBCURRENTDUEAMOUNT());
				attribute.put("serialNumber", idx++);
				attribute.put("select", false);
				attribute.put("nationalID", govtSubsidy.getF_IBNATIONALID());
				attribute.put("partyName", govtSubsidy.getF_IBPARTYNAME());
				attribute.put("partyContactNum", govtSubsidy.getF_IBCONTACTNUM());
				attribute.put("processingDate", govtSubsidy.getF_IBPROCESSEDDATE());
				attribute.put("processingYear", govtSubsidy.getF_IBPROCESSINGYEAR());
				attribute.put("processedBatchRef", govtSubsidy.getF_IBPROCESSREF());
				attribute.put("reason", govtSubsidy.getF_IBREASON());
				attribute.put("isProcessed", govtSubsidy.getF_IBSTATUS().equals("Y")?true:false);
				attribute.put("uploadedDueAmount", govtSubsidy.getF_IBUPLOADAMOUNT());
				attribute.put("isRescheduleDone", govtSubsidy.isF_IBHASRESCHEDULE());
				attribute.put("isUnhold", govtSubsidy.isF_IBUNHOLD());
				attribute.put("hasZeroDues", govtSubsidy.isF_IBHASZERO());
				attribute.put("manualExclude", govtSubsidy.isF_IBMANUALEXCLUDE());
				/*if(govtSubsidy.getF_IBSTATUS().equals("N")) {
					ArrayList<Object> localParams = new ArrayList<>();
					localParams.clear();
					localParams.add(govtSubsidy.getF_IBPARTYID());
					localParams.add("Party");
					List<IBOCE_ADF_PartyLoanDetails> partyLoanDetails = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_ADF_PartyLoanDetails.BONAME, viewQuery,
							localParams, null,true);
					BigDecimal currentDueAmount = BigDecimal.ZERO;
					attribute.put("hasZeroDues", true);
					if (partyLoanDetails != null && partyLoanDetails.size() > CommonConstants.INTEGER_ZERO) {
						for (IBOCE_ADF_PartyLoanDetails partyLoan : partyLoanDetails) {
							if(partyLoan.getF_CEHASRESCHEDULE().equals("1")) {
								attribute.put("isRescheduleDone", true);
							}
							if(partyLoan.getF_CETOTALDUE()!=null)
								currentDueAmount = currentDueAmount.add(partyLoan.getF_CETOTALDUE());
						}
						if (currentDueAmount.compareTo(BigDecimal.ZERO) > CommonConstants.INTEGER_ZERO) {
							attribute.put("currentDueAmount", currentDueAmount);
							attribute.put("hasZeroDues", false);
						}
					}
				}*/
				vectorTable.addAll(new VectorTable(attribute));
			}
		}
		return vectorTable;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		Map supportedData = pagingState.getPagingHelper().getPagingModel();
		supportedData.put("PAGING_QUERY", query);
		supportedData.put("PAGING_PARAMS", params);
		supportedData.put("ACTION", action);
		supportedData.put("BATCH_REFERENCE", batchReference);
		return pagingState;
	}

	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map map) {

		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		query = (String) pagingModel.get("PAGING_QUERY");
		params = (ArrayList<Object>) pagingModel.get("PAGING_PARAMS");
		action = (String) pagingModel.get("ACTION");
		batchReference = (String) pagingModel.get("BATCH_REFERENCE");
		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (map.containsKey("PAGENO")) {
			pageNo = (Integer) map.get("PAGENO");
		}
		if (map.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) map.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			resultVector = runQuery(query, pagingData);

		}
		return resultVector;
	}

	private void getQuery() {
		int year = getF_IN_year();
		String nationalID = getF_IN_nationalID();
		String action = getF_IN_action();
		String processedBatchReference = getF_IN_processedBatchReference();
		if(year==0 || action.isEmpty()) {
			CommonUtil.handleUnParameterizedEvent(44000804);
		}
		params.clear();

		StringBuffer QUERY = new StringBuffer(" WHERE " + IBOCE_ADF_GovtSubsidy.IBPROCESSINGYEAR + " =? ");
		/*if(action.equals("Upload")) {
			year = 0;
		}*/
		params.add(year);
		if (!nationalID.isEmpty()) {
			QUERY.append(" AND " + IBOCE_ADF_GovtSubsidy.IBNATIONALID + " = ? ");
			params.add(nationalID);
		}
		if (!processedBatchReference.isEmpty()) {
			QUERY.append(" AND " + IBOCE_ADF_GovtSubsidy.IBPROCESSREF + " = ? ");
			params.add(processedBatchReference);
		}
		if (!action.isEmpty()) {
			if(action.equals("Create")) {
				QUERY.append(" AND " + IBOCE_ADF_GovtSubsidy.IBSTATUS +"=? ");
				params.add("N");
			}else if(action.equals("Fetch")) {
				QUERY.append(" AND " + IBOCE_ADF_GovtSubsidy.IBPROCESSREF + " IS NOT NULL AND "+ IBOCE_ADF_GovtSubsidy.IBSTATUS +"=? ");
				params.add("Y");
			}
		}
		query = QUERY.toString();
	}
	
}
