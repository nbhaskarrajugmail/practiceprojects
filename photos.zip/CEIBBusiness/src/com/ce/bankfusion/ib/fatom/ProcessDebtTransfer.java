package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ProcessDebtTransfer;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.ce.bankfusion.ib.util.TransferOfDebtsUtil;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.calendar.functions.SubtractDateFromDate;
import com.misys.bankfusion.common.BankFusionMessages;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetUdfDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentScheduleDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.ReadSchedules;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.msgs.v1r0.MaintainDisbursementDetails;
import bf.com.misys.ib.spi.types.DisbursementAccountDetail;
import bf.com.misys.ib.spi.types.DisbursementScheduleDetail;
import bf.com.misys.ib.spi.types.DisbursementScheduleInputDetails;
import bf.com.misys.ib.spi.types.DownPaymentAndUtilizationDetail;
import bf.com.misys.ib.spi.types.EarlySettlementDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.EarlySettlementDetailsRq;
import bf.com.misys.ib.spi.types.messages.LoanDetails;
import bf.com.misys.ib.spi.types.messages.MaintainDisbursementDetailsRq;
import bf.com.misys.ib.spi.types.messages.MaintainDisbursementDetailsRs;
import bf.com.misys.ib.spi.types.messages.ReadAccountKeys;
import bf.com.misys.ib.spi.types.messages.ReadAccountRq;
import bf.com.misys.ib.spi.types.messages.ReadAccountRs;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanDetailsInput;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRq;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRs;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.DealIDInput;
import bf.com.misys.ib.types.DisbursementInfo;
import bf.com.misys.ib.types.DownPaymentDetails;
import bf.com.misys.ib.types.EarlyAssetPayoffCollection;
import bf.com.misys.ib.types.EarlyAssetPayoffDtls;
import bf.com.misys.ib.types.FreqDtls;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.Term;
import bf.com.misys.ib.types.header.RqHeader;

public class ProcessDebtTransfer extends AbstractCE_IB_ProcessDebtTransfer{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8154143871183216575L;
	private static final String READACCOUNT = "IB_SPI_ReadAccount_SRV";
	public static final String CREDIT_PARAM_NAME = "2149_CR";
	public static final String DEBIT_PARAM_NAME = "2149_DR";
	public static final String LENDING_MODULE = "LENDING";
	private static String currencyCode;
	private ProductConfiguration productDetails;
	private ReadLoanDetailsRs readLoanDetails;
	private ReadLoanDetailsRs oldReadLoanDetails;
	private IBOIB_DLI_DealDetails dealDetails;
	private LoanPayments businessDatePayment = null;
	private boolean businessDatePaymentAlreadyExists = false;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	
	private static final transient Log LOGGER = LogFactory.getLog(ProcessDebtTransfer.class.getName());

	public ProcessDebtTransfer()
	{
		super();
	}

	public ProcessDebtTransfer(BankFusionEnvironment env)
	{
		super(env);
		
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
		productDetails = IBCommonUtils.loadProductConfiguration(ibObj.getDealID());
		readLoanDetails = IBCommonUtils.getLoanDetails(ibObj.getDealID());
		dealDetails = IBCommonUtils.getDealDetails(ibObj.getDealID());
		IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls = TransferOfDebtsUtil.getTDRequestByNewDealID(ibObj.getDealID());
		
		
		
		if(null != transferOfDebtDtls)
		{
			IBOIB_DLI_DealDetails origDealdtls = IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID());
			//cancel all fee sadad invoice of old deal
			SadadPaymentUtils.cancelAllInvoiceForTheDeal(transferOfDebtDtls.getF_IBOLDDEALID());
			//perform early settlement of the old loan
			settleOrigDeal(transferOfDebtDtls, origDealdtls, env, ibObj);
			//update the status in new table as Transferred
			transferOfDebtDtls.setF_IBTDSTATUS(CeConstants.TD_STATUS_TRANSFERRED);
			//update original Deal status as CLOSED
			origDealdtls.setF_SYSTEMSTATUS(IBConstants.DEAL_CLOSED_STATUS);
			origDealdtls.setF_Status(IBConstants.DEAL_CLOSED_STATUS);
			//Update the isDealFullyDisbursed for the new deal
			CeUtils.updateIsDealFullyDisbursed(ibObj.getDealID());
			updateAssetLevelDisbursementFlag(ibObj);
		}
		
		if(IBCommonUtils.getLoanDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt().compareTo(BigDecimal.ZERO)>0) {
			
			ArrayList params = new ArrayList();
			params.add(ibObj.getDealID());		
			String thirdPartyPaymentClause = "WHERE " + IBOIB_IDI_ThirdPartyPaymentDetails.DEALNO + "= ?";
			
			List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartyPayments = IBCommonUtils.getPersistanceFactory()
					.findByQuery(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, thirdPartyPaymentClause, params, null, true);
			
			BigDecimal disbursedCost=BigDecimal.ZERO;
			for(IBOIB_IDI_ThirdPartyPaymentDetails thirdPartyPayment: thirdPartyPayments) {
				disbursedCost = disbursedCost.add(thirdPartyPayment.getF_REGULARTOTALPAYMENTAMT());
			}
			
			financeDisbursementAPI(env,disbursedCost, ibObj);
			
			BigDecimal currentDisbProfitAmt = ibObj.getProfitAmount();
			if (null!=currentDisbProfitAmt && currentDisbProfitAmt.compareTo(BigDecimal.ZERO) > 0) {
				String debitAcctId = RescheduleUtils.getInterestRecAccountID(dealDetails.getF_DealAccountId(),
						dealDetails.getF_BranchSortCode(), dealDetails.getF_IsoCurrencyCode());
				String creditAcctId = RescheduleUtils.getUnearnedAcc(dealDetails.getF_BranchSortCode(),
						dealDetails.getF_IsoCurrencyCode());
				String narrative = "Transfer Of Debts Profit Posting";
				
				CEUtil ceUtil = new CEUtil();
			    String drTxnCode = null;
			    String crTxnCode = null;
			    drTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, DEBIT_PARAM_NAME);
			    crTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, CREDIT_PARAM_NAME);
			
				RescheduleUtils.callBackOfficePostingRequest(dealDetails.getF_DealAccountId(),
						ibObj.getDealID(), ibObj.getTransactionID().concat("1"), currentDisbProfitAmt,
						creditAcctId, debitAcctId, dealDetails.getF_DealAccountId()+"$"+narrative,drTxnCode,crTxnCode);
			}
			
		}
		
	}

	private void updateAssetLevelDisbursementFlag(IslamicBankingObject ibObj) {
		ArrayList<String> params = new ArrayList<String>();
		String assetdisbursedUDF = CeUtils.getUDFIDForIsAssetDisbursed();
		String assetDtlswhereClause = "WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + "=? ";
		params.add(ibObj.getDealID());
		List<IBOIB_DLI_DealAssetDtls> dealAssets = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, assetDtlswhereClause, params, null, true);
		params.clear();
		String whereClause = "WHERE " + IBOIB_AST_AssetUdfDetails.DEALID + "=? and "
				+ IBOIB_AST_AssetUdfDetails.FIELDID + " = ?";
		params.add(ibObj.getDealID());
		params.add(assetdisbursedUDF);
		BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOIB_AST_AssetUdfDetails.BONAME, whereClause,
				params);
		BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
		BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
		if (dealAssets != null && !dealAssets.isEmpty()) {
			for (IBOIB_DLI_DealAssetDtls dealAsset : dealAssets) {
				IBOIB_AST_AssetUdfDetails iboAssetUdfDetail = (IBOIB_AST_AssetUdfDetails) BankFusionThreadLocal
						.getPersistanceFactory().getStatelessNewInstance(IBOIB_AST_AssetUdfDetails.BONAME);
				iboAssetUdfDetail.setF_ASSETID(dealAsset.getF_ASSETDETAILSID());
				iboAssetUdfDetail.setF_FIELDID(assetdisbursedUDF);
				iboAssetUdfDetail.setF_FIELDVALUE("YES");
				iboAssetUdfDetail.setF_DEALID(ibObj.getDealID());
				BankFusionThreadLocal.getPersistanceFactory().create(IBOIB_AST_AssetUdfDetails.BONAME,
						iboAssetUdfDetail);
			}
		}
	}
	
	private void settleOrigDeal(IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls, IBOIB_DLI_DealDetails origDealdtls, BankFusionEnvironment env, IslamicBankingObject ibObj)
	{
		//prepare request
		//EarlySettlementDetailsRq earlySettlementDetailsRq =prepareRequest(origDealdtls);
		//call SPI MF
		//HashMap<String, Object> inputs = new HashMap<String, Object>();
		//inputs.put("earlySettlementDetailsRq", earlySettlementDetailsRq);
		//MFExecuter.executeMF("IB_SPI_CreateLoanPayOff_SRV",
		//		BankFusionThreadLocal.getBankFusionEnvironment(), inputs);
		
		getF_IN_islamicBankingObject().setDealID(transferOfDebtDtls.getF_IBOLDDEALID());
		getF_IN_islamicBankingObject().setSearchPageID("116b02fe4cfd02j9");
		EarlyAssetPayoffDtls assetPayoffDtl = null;
		assetPayoffDtl = getAssetPayOffDtls(env,"ON_LOAD", assetPayoffDtl);
		
		for(int i=0;i<assetPayoffDtl.getEarlyAssetPayoffCollectionCount();i++) {
			assetPayoffDtl.getEarlyAssetPayoffCollection(i).setSelect(true);
		}
		
		EarlyAssetPayoffDtls assetPayoffDtls = getAssetPayOffDtls(env,"ON_SELECT", assetPayoffDtl);
		
		oldReadLoanDetails =  IBCommonUtils.getLoanDetails(transferOfDebtDtls.getF_IBOLDDEALID());
		regenerateSchedule(oldReadLoanDetails, assetPayoffDtls);
		oldReadLoanDetails.getDealDetails().getLoanBasicDetails().setLoanMaturityDate(SystemInformationManager.getInstance().getBFBusinessDate());
		
		updateScheduleInHost(assetPayoffDtls, oldReadLoanDetails, env);
		
			CEUtil ceUtil = new CEUtil();
			String drTxnCode = null;
			String crTxnCode = null;
			drTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, DEBIT_PARAM_NAME);
			crTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, CREDIT_PARAM_NAME);
			
				
		RescheduleUtils.callBackOfficePostingRequest(IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getF_DealAccountId(),
				ibObj.getDealID(), ibObj.getTransactionID(), IBCommonUtils.getLoanDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getDealDetails().getLoanBasicDetails().getOutstandingDealAmt(),
				IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getF_DealAccountId(),
				RescheduleUtils.getBankAccountID(IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getF_IsoCurrencyCode(), IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getF_BranchSortCode(), "Swing1104"),
				IBCommonUtils.getDealDetails(transferOfDebtDtls.getF_IBOLDDEALID()).getF_DealAccountId()+"$"+"Transfer Of Debt Settle",drTxnCode,crTxnCode);
		getF_IN_islamicBankingObject().setDealID(transferOfDebtDtls.getF_IBNEWDEALID());
		getF_IN_islamicBankingObject().setSearchPageID("DEAL");
		
	}
	
	private EarlyAssetPayoffDtls getAssetPayOffDtls(BankFusionEnvironment env, String assetPayOffMode, EarlyAssetPayoffDtls assetPayDtls) {
		GetAssetPayOffDtls assetPayOffDtls = new GetAssetPayOffDtls(env);
		assetPayOffDtls.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		assetPayOffDtls.setF_IN_mode(assetPayOffMode);
		if(assetPayOffMode.equalsIgnoreCase("ON_SELECT"))
		assetPayOffDtls.setF_IN_earlyAssetPayoffDtls(assetPayDtls);
		assetPayOffDtls.setF_IN_BBMode("EDIT");
		assetPayOffDtls.process(env);
		return assetPayOffDtls.getF_OUT_earlyAssetPayoffDtls();
	}
	
	private EarlySettlementDetailsRq prepareRequest(IBOIB_DLI_DealDetails origDealdtls)
	{
		
		EarlySettlementDetailsRq earlySettlementDetailsRq = new EarlySettlementDetailsRq();
		EarlySettlementDetails earlySettlementDetails = new EarlySettlementDetails();
		DealIDInput dealID = new DealIDInput();
		dealID.setDealBranch(origDealdtls.getF_BranchSortCode());
		dealID.setDealID(origDealdtls.getBoID());
		dealID.setSubProductID(origDealdtls.getF_ProductContextCode());
		earlySettlementDetails.setDealID(dealID);
		earlySettlementDetails.setProduct(origDealdtls.getF_ProductCode());
		String narrative = BankFusionMessages.getFormattedMessage(BankFusionMessages.MESSAGE_LEVEL, 44000385, 
				BankFusionThreadLocal.getBankFusionEnvironment(), new Object[] {});
		earlySettlementDetails.setNarratives(narrative);
		Amount refundOfUnearnedProfitAmount = new Amount();
		refundOfUnearnedProfitAmount.setAmountEdited(CommonConstants.BIGDECIMAL_ZERO);
		earlySettlementDetails.setRefundOfUnearnedProfitAmount(refundOfUnearnedProfitAmount );
		AccountInput repaymentAccount =new AccountInput();
		repaymentAccount.setAccountFormatType(CeConstants.PSEUDONYM_FORMAT_TYPE);
		repaymentAccount.setAccountID(TransferOfDebtsUtil.getLoanSettlemenetAcc());
		earlySettlementDetails.setRepaymentAccount(repaymentAccount);;
		earlySettlementDetails.setSettlementCurrency(origDealdtls.getF_IsoCurrencyCode());
		earlySettlementDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDate());
		earlySettlementDetailsRq.setEarlySettlementDetails(earlySettlementDetails );
		return earlySettlementDetailsRq;
	}
	
	private void financeDisbursementAPI(BankFusionEnvironment env, BigDecimal fullDisbursedAmount, IslamicBankingObject ibObj) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		MaintainDisbursementDetailsRq maintainDisbursementDetailsRq = new MaintainDisbursementDetailsRq();
		DisbursementScheduleInputDetails disbursementScheduleInputDetails = new DisbursementScheduleInputDetails();
		IBOIB_DLI_DealDetails dealDtl = IBCommonUtils.getDealDetails(ibObj.getDealID());
		String account = dealDtl.getF_DealAccountId();
		currencyCode = dealDtl.getF_IsoCurrencyCode();
		disbursementScheduleInputDetails.setLoanAccountNumber(account);
		String branch = dealDtl.getF_BranchSortCode();
		disbursementScheduleInputDetails.setBranchId(branch);
		disbursementScheduleInputDetails.setProductId(dealDtl.getF_ProductCode());
		disbursementScheduleInputDetails.setSubProductId(dealDtl.getF_ProductContextCode());

		ReadAccountRq readAccountRq = new ReadAccountRq();
		ReadAccountKeys accountKeys = new ReadAccountKeys();
		accountKeys.setAccountID(account);
		readAccountRq.setAccountKeys(accountKeys);
		//TODO This API call can be avoided
		HashMap params = new HashMap();
		params.put("ReadAccountRq", readAccountRq);
		HashMap output = MFExecuter.executeMF(READACCOUNT, env, params);
		ReadAccountRs readAccountRs = (ReadAccountRs) output.get("ReadAccountRs");
		disbursementScheduleInputDetails.setAccountFormatType(readAccountRs.getAccountDetails().getAccountBasicDetails()
				.getAccountKeys().getInputAccount().getAccountFormatType());
		ReadSchedules readSchedules = new ReadSchedules();
		readSchedules.setF_IN_dealId(ibObj.getDealID());
		readSchedules.process(env);
		MaintainDisbursementDetails maintainDisbursementDetails = readSchedules.getF_OUT_maintainDisbursementDetails();
		disbursementScheduleInputDetails.setConstructionEndDate(maintainDisbursementDetails.getConstructEndDate());
		disbursementScheduleInputDetails.setDealId(ibObj.getDealID());
		disbursementScheduleInputDetails
				.setDisbursementScheduleDetails(prepareDisbursementSchedulDetail(maintainDisbursementDetails, env,fullDisbursedAmount));
		disbursementScheduleInputDetails.setDownPaymentAndUtilizationDetails(
				prepareDownPaymentDetails(maintainDisbursementDetails.getDownPaymentDetails(), env));
		// disbursementScheduleInputDetails.setPaymentSchedules(vPaymentSchedulesArray);
		// This set is required only for EQ
		maintainDisbursementDetailsRq.setDisbursementScheduleInputDetails(disbursementScheduleInputDetails);
		param.clear();
		param.put("maintainDisbursementDetailsRq", maintainDisbursementDetailsRq);
		HashMap outputParams = MFExecuter.executeMF(IBSPIConstants.MAINTAIN_DISBURSEMENT_MFID, env, param);
		MaintainDisbursementDetailsRs maintainDisbursementRs = (MaintainDisbursementDetailsRs) outputParams.get(IBSPIConstants.MAINTAIN_DISBURSEMENT_MF_OUTPUT_PARAMNAME);
	}
	
	private DisbursementScheduleDetail[] prepareDisbursementSchedulDetail(
			MaintainDisbursementDetails maintainDisbursementDetails, BankFusionEnvironment env, BigDecimal fullPaymentOrderAmount) {
		BigDecimal disburseAmount = BigDecimal.ZERO;
		String actionMode = "";
		ArrayList<DisbursementScheduleDetail> disScheduleDetails = new ArrayList<DisbursementScheduleDetail>();
		for (DisbursementInfo eachDisburse : maintainDisbursementDetails.getDisbursementInfo()) {
			disburseAmount = eachDisburse.getDisbursementAmount().getCurrencyAmount();
			actionMode = IBConstants.DISBURSEMENT_ACTION_REVERSE;
			DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
			disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails, eachDisburse, disburseAmount,
					actionMode, env);
			disScheduleDetails.add(disbursementScheduleDetail);
		}

		actionMode = IBConstants.DISBURSEMENT_ACTION_EXECUTE;
		DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
		DisbursementInfo eachDisburse = prepareOneCompleteDisburse(fullPaymentOrderAmount);

		disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails, eachDisburse, fullPaymentOrderAmount,
				actionMode, env);
		disScheduleDetails.add(disbursementScheduleDetail);

		return disScheduleDetails
				.toArray((DisbursementScheduleDetail[]) new DisbursementScheduleDetail[disScheduleDetails.size()]);
	}
	
	private DisbursementInfo prepareOneCompleteDisburse(BigDecimal fullPaymentOrderAmount) {
		DisbursementInfo disbursementInfo = new DisbursementInfo();
		BFCurrencyAmount fullPaymentOrderAmountCurr = new BFCurrencyAmount();
		fullPaymentOrderAmountCurr.setCurrencyAmount(fullPaymentOrderAmount);
		fullPaymentOrderAmountCurr.setCurrencyCode(currencyCode);
		disbursementInfo.setDisbursementAmount(fullPaymentOrderAmountCurr);
		disbursementInfo.setDisbursementDate(IBCommonUtils.getBFBusinessDate());
		disbursementInfo.setDisbursementNo(1);
		disbursementInfo.setDisbursementStatus(IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT);

		return disbursementInfo;
	}
	
	private DisbursementScheduleDetail disburseAPI(MaintainDisbursementDetails maintainDisbursementDetails,
			DisbursementInfo eachDisburse, BigDecimal disburseAmount, String actionMode, BankFusionEnvironment env) {
		boolean firstReadyDisbursementCheckFlag = false;
		if(BigDecimal.ZERO.compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount())!=0)
			firstReadyDisbursementCheckFlag = true;
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(maintainDisbursementDetails.getDealNo());
		DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
		disbursementScheduleDetail.setActionMode(actionMode);
		disbursementScheduleDetail.setDisbursementAmount(
				IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(), disburseAmount));
		disbursementScheduleDetail.setDisbursementCurrency(eachDisburse.getDisbursementAmount().getCurrencyCode());
		if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_EXECUTE)) {
			disbursementScheduleDetail.setDisbursementDate(IBCommonUtils.getBFBusinessDate());
		} else {
			disbursementScheduleDetail.setDisbursementDate(eachDisburse.getDisbursementDate());
		}

		disbursementScheduleDetail.setDisbursementId(eachDisburse.getDisbursementId());
		disbursementScheduleDetail.setDisbursementmentNo(eachDisburse.getDisbursementNo());
		disbursementScheduleDetail.setDisbursementNarrative(CommonConstants.EMPTY_STRING);
		if (!productDetails.isIsHostScheduleGenerator()
				&& IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT.equals(eachDisburse.getDisbursementStatus())
				&& !firstReadyDisbursementCheckFlag) {

			disbursementScheduleDetail.setProfitAmonut(dealDtls.getF_ProfitAmt());
			firstReadyDisbursementCheckFlag = true;
		} else {
			disbursementScheduleDetail.setProfitAmonut(BigDecimal.ZERO);
		}

		disbursementScheduleDetail.setDisbursementNarrative(CommonConstants.EMPTY_STRING);
		String status = getStatus(actionMode);
		disbursementScheduleDetail.setDisbursementStatus(status);
		disbursementScheduleDetail.setDisbursementType(IBConstants.DISBURSEMENT_TYPE_MANUAL);
		DisbursementAccountDetail spiDisbursementAccDtl = new DisbursementAccountDetail();
		String account = productDetails.getPrincipalReceivingAccount();
		spiDisbursementAccDtl.setDisbursementAccount(account);
		spiDisbursementAccDtl.setDisbursementAccountFormatType(IBCommonUtils.getAccountFormatType(account));
		spiDisbursementAccDtl.setDisbursementAmount(
				IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(), disburseAmount));
		spiDisbursementAccDtl.setDisbursementMode("2286");
		disbursementScheduleDetail.addDisbursementAccountDetailList(spiDisbursementAccDtl);
		return disbursementScheduleDetail;
	}
	
	private String getStatus(String actionMode) {
		String status = "";

		if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_CREATE)) {
			status = IBConstants.DISBURSEMENT_STATUS_FUTURE_DISBURSEMNT;

		}

		else if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_EXECUTE)) {
			status = IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT;
		}

		return status;
	}
	
	private DownPaymentAndUtilizationDetail[] prepareDownPaymentDetails(DownPaymentDetails[] downPayDetails,
			BankFusionEnvironment env) {

		ArrayList<DownPaymentAndUtilizationDetail> downPaymentDetails = new ArrayList<DownPaymentAndUtilizationDetail>();
		for (DownPaymentDetails downPaymentDtl : downPayDetails) {
			DownPaymentAndUtilizationDetail DownPaymentAndUtilDtl = new DownPaymentAndUtilizationDetail();
			DownPaymentAndUtilDtl.setAmount(IBCommonUtils.scaleAmount(currencyCode,
					downPaymentDtl.getDownPaymentAmount().getCurrencyAmount().abs()));
			DownPaymentAndUtilDtl.setDate(downPaymentDtl.getDownPaymentDate());
			DownPaymentAndUtilDtl.setType(
					(downPaymentDtl.getDownPaymentAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) ? "D"
							: "U");
			downPaymentDetails.add(DownPaymentAndUtilDtl);
		}

		return downPaymentDetails.toArray(
				(DownPaymentAndUtilizationDetail[]) new DownPaymentAndUtilizationDetail[downPaymentDetails.size()]);

	}
	
	private void regenerateSchedule(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls) {
		if (readLoanDetails != null) {
			LOGGER.info("Regenerate Schedule: Begin");
			HashMap<Date, BigDecimal> dateAndPrincipalAmountMap = new HashMap<>();
			HashMap<Date, BigDecimal> dateAndProfitAmountMap = new HashMap<>();

			// looping through the breakup schedule and preparing a map with date and amount
			// that has to be subtracted from original schedule
			getBreakUpSchedule(dateAndPrincipalAmountMap, dateAndProfitAmountMap, assetPayoffDtls);

			// looping through the date and amount map, and subtracting the amount from
			// original schedule
			removeAssetPayoffRepaymentAmounts(dateAndPrincipalAmountMap, dateAndProfitAmountMap, readLoanDetails);

			// add a new repayment with business date and with payment amount to the
			// original schedule
			addNewRepayment(readLoanDetails, assetPayoffDtls);
			LOGGER.info("Regenerate Schedule: End");
		}

	}
	
	private void addNewRepayment(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls) {
		if (readLoanDetails != null && assetPayoffDtls != null) {
			LOGGER.info("inside addNewRepayment : Begin");
			LOGGER.info("businessDatePaymentAlreadyExists"+businessDatePaymentAlreadyExists);
			BigDecimal profitAmount = assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingProfitAmount()
					.getCurrencyAmount().add(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingFeesAmount()
							.getCurrencyAmount());
			String status = CommonConstants.EMPTY_STRING;
			if(businessDatePayment != null)
			 status = businessDatePayment.getRepaymentStatus();
			// if there is already a business date repayment which is UNPAID in the
			// schedule, then add the
			// total remaining amount to the principal amount
			if (businessDatePaymentAlreadyExists
					&& !IBCommonUtils.isNullOrEmpty(status) && status.equals(IBConstants.REPAYMENT_STATUS_UNPAID)) {
				businessDatePayment.setPrincipleAmt(businessDatePayment.getPrincipleAmt().add(assetPayoffDtls
						.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment
						.setPrincipalAmtUnpaid(businessDatePayment.getPrincipalAmtUnpaid().add(assetPayoffDtls
								.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment.setProfitAmt(businessDatePayment.getProfitAmt().add(profitAmount));
				businessDatePayment.setProfitAmtUnpaid(businessDatePayment.getProfitAmtUnpaid().add(profitAmount));
				businessDatePayment.setRepaymentAmt(businessDatePayment.getRepaymentAmt().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
				businessDatePayment.setRepaymentAmtUnPaid(businessDatePayment.getRepaymentAmtUnPaid().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
			}
			// if there is no business date repayment exists in the current schedule, then
			// add a new repayment
			else {

				businessDatePayment = new LoanPayments();
				businessDatePayment.setIsoCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				businessDatePayment.setFeeAmt(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtUnpaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtUnpaid(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setPrincipleAmt(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setProfitAmt(profitAmount);
				businessDatePayment.setProfitAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setProfitAmtUnpaid(profitAmount);
				businessDatePayment.setProfitRate(dealDetails.getF_ProfitRate());
				businessDatePayment.setRepaymentAmt(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				businessDatePayment.setRepaymentAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setRepaymentAmtUnPaid(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				if (businessDatePaymentAlreadyExists
						&& !IBCommonUtils.isNullOrEmpty(status) && !status.equals(IBConstants.REPAYMENT_STATUS_UNPAID))
					businessDatePayment.setRepaymentDate(
							AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(), 1));
				else
					businessDatePayment.setRepaymentDate(IBCommonUtils.getBFBusinessDate());
				businessDatePayment.setRepaymentStatus(IBConstants.REPAYMENT_STATUS_UNPAID);
				businessDatePayment.setRepaymentType(IBConstants.REPAYMENT);
				readLoanDetails.getDealDetails().addPaymentSchedule(businessDatePayment);
			}
			int hj=0;
			List<LoanPayments> paymentScheduleList = Arrays
					.asList(readLoanDetails.getDealDetails().getPaymentSchedule());

			CeUtils.sortPaymentSchedule(paymentScheduleList);
			readLoanDetails.getDealDetails().removeAllPaymentSchedule();
			for (LoanPayments loanPayments : paymentScheduleList) {
				readLoanDetails.getDealDetails().addPaymentSchedule(loanPayments);
			}
			// outstanding amounts are not required to be set for reschedule
			//setOutStandingPrincipalAmnt(readLoanDetails);
		}
	}
	
	private void setOutStandingPrincipalAmnt(ReadLoanDetailsRs readLoanDetails) {
		int repaymentNo = 0;
		BigDecimal outStandingPrincipalAmnt = readLoanDetails.getDealDetails().getLoanBasicDetails()
				.getOriginalPrincipalAmt();
		for (LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
			++repaymentNo;
			/*
			 * if (!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
			 * loanPayments.getRepaymentDate())) {
			 */
			// loanPayments.setRepaymentNo(repaymentNo);
			loanPayments.setOutstandingPrincipalAmt(outStandingPrincipalAmnt.subtract(loanPayments.getPrincipleAmt()));
			loanPayments.setRepaymentAmt(loanPayments.getPrincipleAmt().add(loanPayments.getProfitAmt()));
			// }
			outStandingPrincipalAmnt = loanPayments.getOutstandingPrincipalAmt();

			/*
			 * if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
			 * loanPayments.getRepaymentDate()))
			 * readLoanDetails.getDealDetails().removePaymentSchedule(loanPayments);
			 */
		}
	}
	
	private void removeAssetPayoffRepaymentAmounts(HashMap<Date, BigDecimal> dateAndPrincipalAmountMap,
			HashMap<Date, BigDecimal> dateAndProfitAmountMap, ReadLoanDetailsRs readLoanDetails) {
		if (readLoanDetails != null) {
			for (LoanPayments loanPayment : readLoanDetails.getDealDetails().getPaymentSchedule()) {
				if (dateAndPrincipalAmountMap.containsKey(loanPayment.getRepaymentDate())
						&& !loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_FULLY_PAID)) {
					loanPayment.setPrincipleAmt(loanPayment.getPrincipleAmt()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setPrincipalAmtUnpaid(loanPayment.getPrincipalAmtUnpaid()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setProfitAmt(loanPayment.getProfitAmt()
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setProfitAmtUnpaid(loanPayment.getProfitAmtUnpaid()
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setRepaymentAmt(loanPayment.getPrincipleAmt().add(loanPayment.getProfitAmt()));
					loanPayment.setRepaymentAmtUnPaid(loanPayment.getRepaymentAmtUnPaid()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate()))
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
				}
				loanPayment.setRepaymentType(IBConstants.REPAYMENT);
				loanPayment.setProfitRate(dealDetails.getF_ProfitRate());
				// while subtracting the asset that is getting payed off, if the repayment
				// amount becomes zero, removing the payment
				if (loanPayment.getPrincipleAmt().compareTo(BigDecimal.ZERO) == 0
						|| loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_FULLY_PAID)
						|| loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_PARTIALLY_PAID))
					readLoanDetails.getDealDetails().removePaymentSchedule(loanPayment);
				if (CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
						loanPayment.getRepaymentDate())) {
					businessDatePaymentAlreadyExists = true;
					businessDatePayment = loanPayment;
				}
			}
		}

	}
	
	private void getBreakUpSchedule(HashMap<Date, BigDecimal> dateAndPrincipalAmountMap,
			HashMap<Date, BigDecimal> dateAndProfitAmountMap, EarlyAssetPayoffDtls assetPayoffDtls) {
		BigDecimal totalPrincipalAmnt = BigDecimal.ZERO;
		BigDecimal totalProfitAmnt = BigDecimal.ZERO;
		String whereQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_PaymentSchBreakup> paymentScheduleBreakupDtls = (ArrayList<IBOCE_IB_PaymentSchBreakup>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereQuery, param, null, true);

		if (paymentScheduleBreakupDtls != null && !paymentScheduleBreakupDtls.isEmpty()) {
			for (EarlyAssetPayoffCollection assetPayoffCollection : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
				for (int i = 0; i < paymentScheduleBreakupDtls.size(); i++) {
					IBOCE_IB_PaymentSchBreakup paymentSchBreakup = paymentScheduleBreakupDtls.get(i);
					if (assetPayoffCollection.isSelect()
							&& paymentSchBreakup.getF_IBASSETID().equals(assetPayoffCollection.getAssetId())
							&& CalendarUtil.IsDate1GreaterThanDate2(paymentSchBreakup.getF_IBBILLDATE(),
									IBCommonUtils.getBFBusinessDate())) {
						totalPrincipalAmnt = paymentSchBreakup.getF_IBPRINCIPALAMT();
						totalProfitAmnt = paymentSchBreakup.getF_IBPROFITAMT()
								.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						if (dateAndPrincipalAmountMap.containsKey(paymentSchBreakup.getF_IBBILLDATE())) {
							totalPrincipalAmnt = dateAndPrincipalAmountMap.get(paymentSchBreakup.getF_IBBILLDATE())
									.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
						}
						if (dateAndProfitAmountMap.containsKey(paymentSchBreakup.getF_IBBILLDATE())) {
							totalProfitAmnt = dateAndProfitAmountMap.get(paymentSchBreakup.getF_IBBILLDATE())
									.add(paymentSchBreakup.getF_IBPROFITAMT()
											.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
						}
						dateAndPrincipalAmountMap.put(paymentSchBreakup.getF_IBBILLDATE(), totalPrincipalAmnt);
						dateAndProfitAmountMap.put(paymentSchBreakup.getF_IBBILLDATE(), totalProfitAmnt);
					}
				}
			}
		}
	}

	private void updateScheduleInHost(EarlyAssetPayoffDtls assetPayoffDtls, ReadLoanDetailsRs readLoanDetails,
			BankFusionEnvironment env) {
		LOGGER.info("Update Schedule in host: Begin");
		/*isCompeleteDealSettlement = isCompleteDealSettlement(assetPayoffDtls);
		if (isCompeleteDealSettlement) {
			callRescheduleAPI(readLoanDetails, env);
			IBCommonUtils.getPersistanceFactory().commitTransaction();
			IBCommonUtils.getPersistanceFactory().beginTransaction();
			if (isScheduleUpdateSuccessfull) {
				// callEarlySettlementAPI
				addEntryIntoDealClosureDetails(assetPayoffDtls);
				HashMap<String, Object> inputMap = new HashMap<>();
				isScheduleUpdateSuccessfull = CancelPayoffUtil.callingCreateLoanPayoffSPI(
						getF_IN_islamicBankingObject(), inputMap, getF_IN_islamicBankingObject().getTransactionID());
				if (isScheduleUpdateSuccessfull) {
					ArrayList<String> param = new ArrayList<>();
					param.add(getF_IN_islamicBankingObject().getDealID());
					param.add(getF_IN_islamicBankingObject().getTransactionID());
					List<IBOIB_DLI_DealClosureDetails> closureDtls = (ArrayList<IBOIB_DLI_DealClosureDetails>) IBCommonUtils
							.getPersistanceFactory()
							.findByQuery(IBOIB_DLI_DealClosureDetails.BONAME, closureDtlsQuery, param, null, true);
					if (closureDtls != null)
						closureDtls.get(0).setF_STATUS("CLOSED");
				}
			}
		} else {*/
			callRescheduleAPI(readLoanDetails, env);
		//}
		LOGGER.info("Update Schedule in host: End");
	}

	private void callRescheduleAPI(ReadLoanDetailsRs readLoanDetails, BankFusionEnvironment env) {
		RescheduleLoanRq spiRescheduleLoanRq = convertScheduleDetailsToReschSPIType(readLoanDetails);
		HashMap<String, Object> param = new HashMap<>();
		param.clear();
		param.put(IBSPIConstants.SCH_AMENDMENT_MF_INPUT_PARAMNAME, spiRescheduleLoanRq);
		HashMap<String, Object> outputParams = MFExecuter.executeMF(IBSPIConstants.SCH_AMENDMENT_MFID, env, param);
		RescheduleLoanRs scheduleAmendRs = (RescheduleLoanRs) outputParams
				.get(IBSPIConstants.SCH_AMENDMENT_MF_OUTPUT_PARAMNAME);
		//if (scheduleAmendRs != null && scheduleAmendRs.getRsHeader().getStatus().getOverallStatus().equals("S"))
		//	isScheduleUpdateSuccessfull = true;
	}
	
	private RescheduleLoanRq convertScheduleDetailsToReschSPIType(ReadLoanDetailsRs readLoanDetails) {

		ProductConfiguration productConfiguration = IBCommonUtils
				.loadProductConfiguration(getF_IN_islamicBankingObject().getDealID());

		RescheduleLoanRq spiRescheduleLoanRq = new RescheduleLoanRq();
		RescheduleLoanDetailsInput rescheduleLoanDetailsInput = new RescheduleLoanDetailsInput();
		LoanDetails loanDetails = new LoanDetails();
		loanDetails.setDealBranch(dealDetails.getF_BranchSortCode());
		loanDetails.setDealCurrency(dealDetails.getF_IsoCurrencyCode());
		loanDetails.setDealID(dealDetails.getBoID());
		loanDetails.setLoanAccountNo(dealDetails.getF_DealAccountId());
		loanDetails.setIsHostScheduleGenerator(productConfiguration.getIsHostScheduleGenerator());
		loanDetails.setProductID(dealDetails.getF_ProductCode());
		loanDetails.setSubProductID(dealDetails.getF_ProductContextCode());
		loanDetails.setRepaymentType("REPAYMENT");
		loanDetails.setPaymentStartDate(IBCommonUtils.getBFBusinessDate());
		loanDetails.setEffectiveDate(dealDetails.getF_DEALEFFECTIVEDT());
		loanDetails.setMarginRate(dealDetails.getF_ProfitRate());
		loanDetails.setNoOfPayments(readLoanDetails.getDealDetails().getPaymentScheduleCount());
		loanDetails.setProfitRate(dealDetails.getF_ProfitRate());
		loanDetails.setScheduleEffectiveDate(SystemInformationManager.getInstance().getBFBusinessDate());
		loanDetails.setFirstAmountCanDiffer(false);

		String scheduleProfile = " WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOIB_DLI_ScheduleProfile> scheduleProfileList = null;
		scheduleProfileList = IBCommonUtils.getPersistanceFactory().findByQuery(IBOIB_DLI_ScheduleProfile.BONAME,
				scheduleProfile, params, null, false);
		if (scheduleProfileList != null) {
			for (IBOIB_DLI_ScheduleProfile profileRec : scheduleProfileList)
				if (profileRec.getF_ScheduleType().equals("Repayment")) {
					FreqDtls paymentFreq = new FreqDtls();
					paymentFreq.setFrequencyCode(profileRec.getF_FreqCode());
					paymentFreq.setFrequencyDay(ScheduleUtils.getRepaymentDay(dealDetails.getF_FirstRepaymentDate(),
							dealDetails.getF_RepayFreqcode()));
					paymentFreq.setFrequencyNum(profileRec.getF_FreqUnit());
					loanDetails.setPaymentFreq(paymentFreq);
				}
		}

		Term loanTerm = new Term();
		loanTerm.setPeriodNumber(SubtractDateFromDate.run(
				dealDetails.getF_LastRepaymentDate() != null ? dealDetails.getF_LastRepaymentDate() : new Date(0),
				dealDetails.getF_DEALEFFECTIVEDT() != null ? dealDetails.getF_DEALEFFECTIVEDT() : new Date(0)));
		loanTerm.setPeriodCode(DealInitiationConstants.TERM_DAY);
		loanDetails.setLoanTerm(loanTerm);

		rescheduleLoanDetailsInput.setLoanDetails(loanDetails);
		rescheduleLoanDetailsInput.setManualPaymentSchedule(readLoanDetails.getDealDetails().getPaymentSchedule());

		spiRescheduleLoanRq.setRescheduleLoanDetailsInput(rescheduleLoanDetailsInput);

		RqHeader rqHeader = new RqHeader();
		spiRescheduleLoanRq.setRqHeader(rqHeader);
		return spiRescheduleLoanRq;
	}
}
