package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SearchPricingListConfig;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.cfg.bo.PriceList;
import com.ce.ib.cfg.dto.PriceListDto;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.PagingData;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.PricingCfgSearchRs;
import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListAssetCfg;
import bf.com.misys.ib.types.PricingListCfg;

public class SearchPricingListConfig extends AbstractCE_IB_SearchPricingListConfig {

	private static final long serialVersionUID = -3977733044164516106L;

	private static final Integer PAGE_SIZE = 10;
  private static final Integer PAGE_NO = 1;
  private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
  private static final String LIKE = "  like ?";
	PriceList pricingList = new PriceList();
	
	public SearchPricingListConfig() {
		super();
	}

	@SuppressWarnings("deprecation")
  public SearchPricingListConfig(BankFusionEnvironment env) {
    super(env);

  }
	
	@Override
	public void process(BankFusionEnvironment env) {
	    int pageSize = PAGE_SIZE;
	    int pageNo = getF_IN_pricingSearchRq().getPagedQuery().getPagingRequest().getRequestedPage();
	    IPagingData pagingData = null;
	    
	    if (pageSize == 0)
	        pageSize = PAGE_SIZE;
	      if (pageNo == 0)
	        pageNo = PAGE_NO;

	        pagingData = new PagingData(pageNo, pageSize);
	        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
		this.getPriceList(pagingData, env);

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	 public VectorTable getPriceList(IPagingData pagingData, BankFusionEnvironment env) {
	     String referenceNo = getF_IN_pricingSearchRq().getRegCfgSearch().getReferenceNo(); 
	     Integer year = getF_IN_pricingSearchRq().getRegCfgSearch().getYear(); 
	     AsstCategory asstCategory = getF_IN_pricingSearchRq().getRegCfgSearch().getAsstCategory();
	     String asstCat = asstCategory.getCategory();
	     IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	     PriceListDto dto = new PriceListDto();
	     StringBuilder registyDtlsWhereClause1 = new StringBuilder("WHERE ");
	     ArrayList params = new ArrayList();
	     String and = " AND ";
	     if (StringUtils.isNotEmpty(referenceNo)) {
	       params.add(referenceNo);
	       registyDtlsWhereClause1.append(IBOCE_IB_PricingListCfg.IBREFERENCENUMBER + LIKE);
	     }
	     if (year > 0 && year != 1979) {
	       if (registyDtlsWhereClause1.length() > 6) {
	         registyDtlsWhereClause1.append(and);
	       }
	       params.add(year);
	       registyDtlsWhereClause1.append(IBOCE_IB_PricingListCfg.IBPRICELISTYEAR + " = ?");
	     }

	     List<IBOCE_IB_PricingListCfg> pricingList;
	     if (registyDtlsWhereClause1.toString().equals("WHERE ")) {
	       pricingList = factory.findAll(IBOCE_IB_PricingListCfg.BONAME, pagingData, true);
	     } else {
	       pricingList = factory.findByQuery(IBOCE_IB_PricingListCfg.BONAME, registyDtlsWhereClause1.toString(),
	           params, pagingData, true);
	     }
	     String[] pricingId = new String[pricingList.size()];
	     List<String> price = new ArrayList<>();
	     for (int i = 0; i < pricingList.size(); i++) {
	       price.add(pricingList.get(i).getBoID());
	       pricingId[i] = pricingList.get(i).getBoID();
	     }
	     return this.createResponse(pricingList, pagingData, null);
	   }
	 
	  private VectorTable createResponse(List<IBOCE_IB_PricingListCfg> pricingList, IPagingData pagingData, Object object) {
	      VectorTable vectorTable = new VectorTable();
	      PricingCfgSearchRs pricingSearchRs = new PricingCfgSearchRs();
	      PricingList pricingItem = new PricingList();
	      boolean select = false;
	      
	      if (pricingList != null) {
	          for (IBOCE_IB_PricingListCfg pricingType : pricingList) {
	              this.prepareListPricingType(pricingItem, pricingType, select);
	              select = false;
	              Map<String, Object> map = this.prepareMap(pricingType);
	              VectorTable newRow = new VectorTable(map);
	              vectorTable.addAll(newRow); 
	          }
	      }

	      PagedQuery pagedQuery = new PagedQuery();
	      PagingRequest pagingRequest = new PagingRequest();
	      pagingRequest.setNumberOfRows(pagingData.getPageSize());
	      pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
	      pagingRequest.setTotalPages(pagingData.getTotalPages());
	      pagedQuery.setPagingRequest(pagingRequest);
	      pagedQuery.setQueryData(pricingItem);

	      Object pageData[] = new Object[4];
	      pageData[0] = pagingRequest.getRequestedPage();
	      pageData[1] = pagingRequest.getNumberOfRows();
	      pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
	      vectorTable.setPagingData(pageData);

	      pricingSearchRs.setRegCfgSearch(pricingItem);
	      pricingSearchRs.setPagedQuery(pagedQuery);
	      setF_OUT_pricingSearchRs(pricingSearchRs);
	      setF_OUT_paginatedData(vectorTable);
	      return vectorTable;
	    }
	 
	  private Map<String, Object> prepareMap(IBOCE_IB_PricingListCfg pricingType) {
	      Map<String, Object> map = new HashMap<>();
        map.put("versionNumber", pricingType.getVersionNum());
        map.put("SELECT", Boolean.FALSE);
        map.put("IBPRICINGLISTIDPK", pricingType.getBoID());
        map.put("IBREFERENCENUMBER", pricingType.getF_IBREFERENCENUMBER());
        map.put("IBPRICELISTYEAR", pricingType.getF_IBPRICELISTYEAR());
        map.put("IBPRICINGLISTDATE", pricingType.getF_IBPRICELISTYEAR());
        map.put("IBDOCUMENTNUMBER", pricingType.getF_IBDOCUMENTNUMBER());
        map.put("IBDOCUMENTDATE", pricingType.getF_IBDOCUMENTDATE());
        map.put("IBVENDORID", pricingType.getF_IBVENDORID());
        map.put("IBVENDORNAME", pricingType.getF_IBVENDORNAME());
        map.put("IBVENDORTYPE", pricingType.getF_IBVENDORTYPE());
        
        return map;
    }

	  public ActivityStepPagingState createActivityStepPagingState() {
	      ActivityStepPagingState pagingState = super.createActivityStepPagingState();
	      return pagingState;
	    }
	    public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
	        @SuppressWarnings("rawtypes") Map map) {

	      VectorTable resultVector = new VectorTable();


	      int pageSize = PAGE_SIZE;
	      int pageNo = PAGE_NO;

	      if (map.containsKey("PAGENO")) {
	        pageNo = (Integer) map.get("PAGENO");
	      }
	      if (map.containsKey("NUMBEROFROWS")) {
	        pageSize = (Integer) map.get("NUMBEROFROWS");
	      }

	      IPagingData pagingData = new PagingData(pageNo, pageSize);

	      if (pagingData != null) {
	        pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
	        if (pagingData.getCurrentPageNumber() == 0)
	          pagingData.setCurrentPageNumber(pageNo);
	        if (pagingData.getPageSize() == 0)
	          pagingData.setPageSize(pageSize);

	        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);

	        resultVector = this.getPriceList(pagingData, env);
	      }
	      return resultVector;
	    }
	  
    private void prepareListPricingType(PricingList pricingItem, IBOCE_IB_PricingListCfg pricingType, boolean select) {
        PricingListCfg vPricingListDtls = new PricingListCfg();
        vPricingListDtls.setDocumentDate(pricingType.getF_IBDOCUMENTDATE());
        vPricingListDtls.setDocumentNumber(pricingType.getF_IBDOCUMENTNUMBER());
        vPricingListDtls.setReferenceNumber(pricingType.getF_IBREFERENCENUMBER());
        vPricingListDtls.setPriceListYear(pricingType.getF_IBPRICELISTYEAR());
        vPricingListDtls.setPricingListDate(pricingType.getF_IBPRICINGLISTDATE());
        vPricingListDtls.setPricingListId(pricingType.getBoID());
        vPricingListDtls.setVendorId(pricingType.getF_IBVENDORID());
        vPricingListDtls.setVendorName(pricingType.getF_IBVENDORNAME());
        vPricingListDtls.setVendorType(pricingType.getF_IBVENDORTYPE());
        vPricingListDtls.setSelect(select);
        pricingItem.addPricingListDtls(vPricingListDtls);  
        
    }

    public List<IBOCE_IB_PricingListAssetCfg> getPriceListAssetbyAsstCategory(String assetCat, String[] pricingId) {

	      IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	      StringBuilder whereClause = new StringBuilder(" Where " + IBOCE_IB_PricingListAssetCfg.IBPRICINGLISTID);
	      ArrayList params = new ArrayList();
	      String and = " AND ";
	      if (pricingId.length > 0) {
	        new StringBuilder(whereClause.append(" IN ("));
	        for (int i = 0; i < pricingId.length; i++) {
	          whereClause.append("?,");
	          params.add(pricingId[i]);
	        }
	        whereClause = new StringBuilder(whereClause.substring(0, whereClause.lastIndexOf(","))).append(")");
	      }
	      if (StringUtils.isNotEmpty(assetCat)) {
	        whereClause.append(and);
	        params.add(assetCat);
	        whereClause.append(IBOCE_IB_PricingListAssetCfg.IBASSETCATEGORY + " = ?");
	      }

	      List<IBOCE_IB_PricingListAssetCfg> priceAsstList = new ArrayList<>();
	      if (whereClause.toString().equals("WHERE ")) {
	        priceAsstList = factory.findAll(IBOCE_IB_PricingListAssetCfg.BONAME, null, true);
	      } else {
	        priceAsstList = factory.findByQuery(IBOCE_IB_PricingListAssetCfg.BONAME, whereClause.toString(), params,
	            null, true);
	      }
	      return priceAsstList;
	    }
	 
	 private void preparePricingList(PriceListDto dto, List<IBOCE_IB_PricingListCfg> pricingList) {
	     List<PricingListCfg> pricingLists = new ArrayList<>();

	     for (IBOCE_IB_PricingListCfg priceList : pricingList) {
	       PricingListCfg priceListcfg = new PricingListCfg();
	       priceListcfg.setPricingListId(priceList.getBoID());
	       priceListcfg.setDocumentDate(priceList.getF_IBDOCUMENTDATE());
	       priceListcfg.setDocumentNumber(priceList.getF_IBDOCUMENTNUMBER());
	       priceListcfg.setPriceListYear(priceList.getF_IBPRICELISTYEAR());
	       priceListcfg.setPricingListDate(priceList.getF_IBPRICINGLISTDATE());
	       priceListcfg.setReferenceNumber(priceList.getF_IBREFERENCENUMBER());
	       priceListcfg.setVendorId(priceList.getF_IBVENDORID());
	       priceListcfg.setVendorName(priceList.getF_IBVENDORNAME());
	       priceListcfg.setVendorType(priceList.getF_IBVENDORTYPE());
	       priceListcfg.setSelect(Boolean.FALSE);
	       pricingLists.add(priceListcfg);
	     }
	     PricingListCfg[] priceListArray = pricingLists.toArray(new PricingListCfg[pricingLists.size()]);
	     bf.com.misys.ib.types.PricingList pricLst = new bf.com.misys.ib.types.PricingList();
	     pricLst.setPricingListDtls(priceListArray);
	     dto.setPricingList(pricLst);
	   }
	 
	  private void preparePricingListAssets(PriceListDto priceList, List<IBOCE_IB_PricingListAssetCfg> priceAssetList) {
	      List<PricingListAssetCfg> priceListAsstCfg = new ArrayList<>();
	      for (IBOCE_IB_PricingListAssetCfg priceAsset : priceAssetList) {
	        PricingListAssetCfg asstCfg = new PricingListAssetCfg();
	        asstCfg.setAssetSerial(priceAsset.getBoID());
	        asstCfg.setAssetCategory(CeUtils.getAssetCategory(priceAsset.getF_IBASSETCATEGORY()));
	        asstCfg.setHorsePower(priceAsset.getF_IBHORSEPOWER());
	        asstCfg.setMachineNumber(priceAsset.getF_IBMACHINENUMBER());
	        asstCfg.setModel(priceAsset.getF_IBMODEL());
	        BFCurrencyAmount currency = new BFCurrencyAmount();
	        currency.setCurrencyAmount(priceAsset.getF_IBPRICE());
	        currency.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
	        asstCfg.setPrice(currency);
	        asstCfg.setPricingListId(priceAsset.getF_IBPRICINGLISTID());
	        asstCfg.setExtensionIndicator(priceAsset.isF_IBEXTENSIONINDICATOR());
	        asstCfg.setStatus((Boolean.compare(priceAsset.isF_IBSTATUS(), Boolean.TRUE) == 0) ? "ACTIVE" : "INACTIVE");
	        asstCfg.setAttribute1(priceAsset.getF_IBATTRIBUTE1());
	        asstCfg.setAttribute2(priceAsset.getF_IBATTRIBUTE2());
	        asstCfg.setAttribute3(priceAsset.getF_IBATTRIBUTE3());
	        asstCfg.setMachineType(priceAsset.getF_IBMACHINETYPE());
	        asstCfg.setRegistryId(priceAsset.getF_IBREGISTRYID());
	        asstCfg.setNewPricingListNum1(priceAsset.getF_NEWPRICELISTNUM1());
	        asstCfg.setNewPricingListNum2(priceAsset.getF_NEWPRICELISTNUM2());
	        asstCfg.setNewPLDate1(priceAsset.getF_NEWPLDATE1());
	        asstCfg.setNewPLDate2(priceAsset.getF_NEWPLDATE2());
	        asstCfg.setNewPLYear1(priceAsset.getF_NEWPLYEAR1());
	        asstCfg.setNewPLYear2(priceAsset.getF_NEWPLYEAR2());
	        priceListAsstCfg.add(asstCfg);
	      }

	      PricingListAssetCfg[] priceListAssets = priceListAsstCfg
	          .toArray(new PricingListAssetCfg[priceListAsstCfg.size()]);
	      priceList.getPricingList().setPricingListAssetDtls(priceListAssets);
	    }
	
}
