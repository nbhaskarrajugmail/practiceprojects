/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UploadRegistryCfgDtlsExcel;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.cfg.bo.Registry;
import com.ce.ib.cfg.dto.RegistryDto;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.common.functions.CB_CMN_AutoNumber;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.RegistryAssetListCfg;
import bf.com.misys.ib.types.RegistryList;
import bf.com.misys.ib.types.RegistryListCfg;

/**
 * @author chethabn
 * 
 *         Registry configuration excel upload
 *
 */
public class UploadRegistryCfgDtlsExcel extends AbstractCE_IB_UploadRegistryCfgDtlsExcel {
	private static final Log LOGGER = LogFactory.getLog(UploadRegistryCfgDtlsExcel.class);
	private static final long serialVersionUID = -6977453506304820463L;

	public UploadRegistryCfgDtlsExcel(BankFusionEnvironment env) {
		super(env);

	}

	public UploadRegistryCfgDtlsExcel() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		Registry registry = new Registry();
		RegistryDto dto = new RegistryDto();
		try {
			registry.saveRegistry(getRegistryCfgByExcel());
		} catch (Exception e) {
			LOGGER.error("The File upload is failed " + e.getMessage());
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(44000206, new Object[] {}, LOGGER,
					IBCommonUtils.getBankFusionEnvironment());
		}
		BusinessEventSupport.getInstance().raiseBusinessInfoEvent(44000209, new Object[] {}, LOGGER,
				IBCommonUtils.getBankFusionEnvironment());
	}

	private RegistryList getRegistryCfgByExcel() throws IOException {
		String file = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
				"registryCfgLocation", "false");
		LOGGER.info(file + "is used to upload Registry Configuration");
		// Creating workbook from Excel
		Workbook workbook = null;
		try {
			// workbook = XSSFWorkbook
			
				try {
					workbook = WorkbookFactory.create(new File(file));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		} catch (Exception e) {
			LOGGER.error("The File " + file + " upload is failed " + e);
			throw e;
		}

		return prepareRegistryListFromExcel(workbook);
	}

	private final RegistryList prepareRegistryListFromExcel(Workbook workbook) throws IOException {
		RegistryList regList = new RegistryList();
		if (workbook != null) {
			// get the first sheet
			Sheet sheet = workbook.getSheetAt(0);
			DataFormatter dataFormatter = new DataFormatter();
			List<RegistryListCfg> regitryListsCfg = new ArrayList<>();
			List<RegistryAssetListCfg> regAsstListsCfg = new ArrayList<>();
			GetVendorNameById byId = new GetVendorNameById();
			// 2. Or you can use a for-each loop to iterate over the rows and columns
			String regid = "NO_ID";
			for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
				if (i >= 1) {

					if (StringUtils.isNotEmpty(dataFormatter.formatCellValue(sheet.getRow(i).getCell(0)))) {
						RegistryListCfg regListCfg = new RegistryListCfg();
						regid = "Reg_" + CB_CMN_AutoNumber.run(IBOCE_IB_RegistryListCfg.BONAME,
								BankFusionThreadLocal.getBankFusionEnvironment());
						regListCfg.setRegistryId(regid);
						regListCfg.setReferenceNumber(dataFormatter.formatCellValue(sheet.getRow(i).getCell(0)));
						regListCfg.setRegistryDate(
								Date.valueOf(dataFormatter.formatCellValue(sheet.getRow(i).getCell(1))));
						regListCfg.setDocumentNumber(dataFormatter.formatCellValue(sheet.getRow(i).getCell(2)));
						regListCfg.setDocumentDate(
								Date.valueOf(dataFormatter.formatCellValue(sheet.getRow(i).getCell(3))));
						regListCfg.setRegistryStatus(dataFormatter.formatCellValue(sheet.getRow(i).getCell(4)));
						regListCfg.setSelect(true);
						regitryListsCfg.add(regListCfg);
					}

					RegistryAssetListCfg regAsstListCfg = new RegistryAssetListCfg();
					regAsstListCfg.setRegistryId(regid);
					regAsstListCfg.setAssetSerial(CB_CMN_AutoNumber.run(IBOCE_IB_RegistryAssetCfg.BONAME,
							BankFusionThreadLocal.getBankFusionEnvironment()));
					regAsstListCfg.setAssetCategory(
							CeUtils.getAssetCategory(dataFormatter.formatCellValue(sheet.getRow(i).getCell(5))));
					regAsstListCfg.setModel(dataFormatter.formatCellValue(sheet.getRow(i).getCell(6)));
					regAsstListCfg
							.setHorsePower(new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(7))));
					BFCurrencyAmount amount = new BFCurrencyAmount();
					amount.setCurrencyAmount(new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(8))));
					amount.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
					regAsstListCfg.setPrice(amount);
					String vendorID = dataFormatter.formatCellValue(sheet.getRow(i).getCell(9));
					regAsstListCfg.setVendorId(vendorID);
					regAsstListCfg.setVendorName(byId.getPartyNameByID(vendorID));
					String attribute1 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(11));
					String attribute2 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(12));
					String attribute3 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(13));
					BigDecimal attr1 = new BigDecimal(0);
					if(!attribute1.equals(""))
						attr1=new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(11)));
					
					BigDecimal attr2 = new BigDecimal(0);
					if(!attribute2.equals(""))
						attr2=new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(12)));
					
					BigDecimal attr3 = new BigDecimal(0);
					if(!attribute3.equals(""))
						attr3=new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(13)));
					
					regAsstListCfg.setMachineType(dataFormatter.formatCellValue(sheet.getRow(i).getCell(10)));
					regAsstListCfg.setAttribute1(attr1);
					regAsstListCfg.setAttribute2(attr2);
					regAsstListCfg.setAttribute3(attr3);
					regAsstListCfg.setSelect(true);
					regAsstListsCfg.add(regAsstListCfg);
				}
			}
			regList.setRegistryAssetListDtls(regAsstListsCfg.toArray(new RegistryAssetListCfg[regAsstListsCfg.size()]));
			regList.setRegistryListDtls(regitryListsCfg.toArray(new RegistryListCfg[regitryListsCfg.size()]));

			workbook.close();
		}
		return regList;
	}

}
