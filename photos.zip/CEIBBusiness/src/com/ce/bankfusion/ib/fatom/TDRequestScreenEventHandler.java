package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TDScreenEvntHandler;
import com.ce.bankfusion.ib.util.TransferOfDebtsUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.header.MessageStatus;
import bf.com.misys.cbs.types.header.RsHeader;
import bf.com.misys.cbs.types.header.SubCode;
import bf.com.misys.ib.types.ListTrnsfDbtsElgDealsRs;
import bf.com.misys.ib.types.TrnsfDbtsElgDeal;
import bf.com.misys.ib.types.TrnsfDbtsElgDealsList;

public class TDRequestScreenEventHandler extends AbstractCE_IB_TDScreenEvntHandler{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7913511478191395510L;

	public TDRequestScreenEventHandler()
	{
		super();
	}

	public TDRequestScreenEventHandler(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();
		switch(context)
		{
		case "ADD" :
			addToSelectedDealList();
			break;
		case "REMOVE" :
			removeFromSelectedDealList();
			break;
		case "ALL_SUBPRODUCT_LIST" :
			getAllSubproductsList();
			break;
		case "GEN_REQ_ID" :
			generateTDReqID();
			break;
		default :
			break;
		}
	}

	private void generateTDReqID() {
		setF_OUT_tdRequestID(TransferOfDebtsUtil.getTDRequestID());
	}

	private void getAllSubproductsList() {
		ListGenericCodeRs allSubproductList = new ListGenericCodeRs();
		ListGenericCodeRs productList = getF_IN_listGenericCodeRs();
		for(GcCodeDetail eachProductItem : productList.getGcCodeDetails())
		{
			String productID = eachProductItem.getCodeReference();
			HashMap<String, Object> inputs = new HashMap<String, Object>();
			inputs.put("abstractProductID", productID);
			@SuppressWarnings("unchecked")
			HashMap<String, Object> output = MFExecuter.executeMF("IB_CFG_ListSubProductWrapper_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), inputs);
			ListGenericCodeRs subproductList = (ListGenericCodeRs) output.get("listGenericCodeRs_SubProducts");
			for(GcCodeDetail eachSubproductItem : subproductList.getGcCodeDetails())
			{
				allSubproductList.addGcCodeDetails(eachSubproductItem);
			}
		}
		
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(20);
		pagingRequest.setRequestedPage(1);
		pagingRequest.setTotalPages(1);
		pagedQuery.setPagingRequest(pagingRequest );
		allSubproductList.setPagedQuery(pagedQuery );
		RsHeader rsHeader = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setCodes(new SubCode[] {});
		rsHeader.setStatus(status );
		allSubproductList.setRsHeader(rsHeader );
		setF_OUT_listGenericCodeRs(allSubproductList);
		generateTDReqID();
	}

	private void removeFromSelectedDealList() {
		TrnsfDbtsElgDealsList gridDataFromScreen = getF_IN_trnsfDbtsSelectedDealsList();
		if(null != gridDataFromScreen && gridDataFromScreen.getTrnsfDbtsElgDealsCount() >0)
		{
			for(TrnsfDbtsElgDeal eachGridRow : gridDataFromScreen.getTrnsfDbtsElgDeals())
			{
				if(eachGridRow.isSelect())
				{
					gridDataFromScreen.removeTrnsfDbtsElgDeals(eachGridRow);
				}
			}
		}
		setF_OUT_trnsfDbtsSelectedDealsList(gridDataFromScreen);
	}

	private void addToSelectedDealList() {
		Set<String> alreadyAddedDealFrorTD = new HashSet<>();
		TrnsfDbtsElgDealsList selectedDealgrid = getF_IN_trnsfDbtsSelectedDealsList();
		ListTrnsfDbtsElgDealsRs dealSearchGrid = getF_IN_listTrnsfDbtsElgDealsRs();
		if(null != selectedDealgrid && selectedDealgrid.getTrnsfDbtsElgDealsCount() >0)
		{
			for(TrnsfDbtsElgDeal eachGridRow : selectedDealgrid.getTrnsfDbtsElgDeals())
			{
				alreadyAddedDealFrorTD.add(eachGridRow.getDealID());
			}
		}
		else
		{
			selectedDealgrid = new TrnsfDbtsElgDealsList();
		}
		
		if(null != dealSearchGrid && null != dealSearchGrid.getTrnsfDbtsElgDeals() && dealSearchGrid.getTrnsfDbtsElgDealsCount() > 0 )
		{
			for(TrnsfDbtsElgDeal eachSearchGridRow : dealSearchGrid.getTrnsfDbtsElgDeals())
			{
				if(eachSearchGridRow.isSelect() && !alreadyAddedDealFrorTD.contains(eachSearchGridRow.getDealID()))
				{
					alreadyAddedDealFrorTD.add(eachSearchGridRow.getDealID());
					eachSearchGridRow.setSelect(false);
					selectedDealgrid.addTrnsfDbtsElgDeals(eachSearchGridRow);
				}
			}
		}
		setF_OUT_trnsfDbtsSelectedDealsList(selectedDealgrid);
	}
}

