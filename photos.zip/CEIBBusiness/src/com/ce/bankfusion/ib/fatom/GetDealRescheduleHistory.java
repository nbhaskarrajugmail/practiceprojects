package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleHistoryDetails;
import bf.com.misys.dealreschedule.dtls.ib.types.RescheduleHistory;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHFEE;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealRescheduleHistory;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;

public class GetDealRescheduleHistory extends AbstractCE_IB_GetDealRescheduleHistory {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public GetDealRescheduleHistory() {
        super();
    }

    public GetDealRescheduleHistory(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        String dealRescheduleQuery = " WHERE " + IBOCE_IB_DealReschedule.IBDEALID + "=? " + " AND "
            + IBOCE_IB_DealReschedule.IBRESCHEDULESTATUS + " = ? ORDER BY " + IBOCE_IB_DealReschedule.IBRECLASTMODIFIEDDATE + " DESC ";
        RescheduleHistory rescheduleHistoryDetails = new RescheduleHistory();
        if (!IBCommonUtils.isNullOrEmpty(getF_IN_dealId())) {
            String currencyCode = IBCommonUtils.getDealDetails(getF_IN_dealId()).getF_IsoCurrencyCode();
            ArrayList<Object> params = new ArrayList<>();
            params.add(getF_IN_dealId());
            params.add(RescheduleConstants.STATUS_COMPLETED);

            List<IBOCE_IB_DealReschedule> dealRescheduleDtls = BankFusionThreadLocal.getPersistanceFactory()
                .findByQuery(IBOCE_IB_DealReschedule.BONAME, dealRescheduleQuery, params, null, false);
            if (!dealRescheduleDtls.isEmpty()) {

                for (IBOCE_IB_DealReschedule dealReschedule : dealRescheduleDtls) {
                    CeRescheduleHistoryDetails rescheduleHistory = new CeRescheduleHistoryDetails();
                    rescheduleHistory.setRescheduleDate(new Date(dealReschedule.getF_IBRECLASTMODIFIEDDATE().getTime()));
                    rescheduleHistory.setRequestId(dealReschedule.getBoID());
                    rescheduleHistory.setRescheduleProfitAmount(
                        IBCommonUtils.getBFCurrencyAmount(dealReschedule.getF_IBRESCHEDULEPROFIT(), currencyCode));
                    rescheduleHistory
                        .setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(dealReschedule.getF_IBSCHEDULEFEES(), currencyCode));
                    rescheduleHistory.setFeesAmount(IBCommonUtils.getBFCurrencyAmount(
                        dealReschedule.getF_IBRESCHEDULEPROFIT().subtract(dealReschedule.getF_IBSCHEDULEFEES()), currencyCode));
                    rescheduleHistory
                        .setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(dealReschedule.getF_IBSUBSIDYAMOUNT(), currencyCode));
                    // will revisit this in Reschedule Profit User Story
                    // rescheduleHistory.setRescheduleProfitStatus(dealReschedule.getF_IBRESCHEDULESTATUS());
                    rescheduleHistoryDetails.addRescheduleHistoryDetails(rescheduleHistory);
                }
                rescheduleHistoryDetails.setDealId(getF_IN_dealId());
                String refundQuery = " WHERE " + IBOCE_IB_REFUNDRESCHFEE.IBDEALID + "=? ";
                params.clear();
                params.add(getF_IN_dealId());
                List<IBOCE_IB_REFUNDRESCHFEE> dealReschRefundDtls = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_REFUNDRESCHFEE.BONAME, refundQuery, params,
                        null, false);
                if (null != dealReschRefundDtls && !dealReschRefundDtls.isEmpty()) {
        			String scheduledDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
        					CeConstants.REFUND_STATUS_SCHEDULED);
        			String rescheduleDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
        					CeConstants.REFUND_STATUS_REFUNDED);
        			for (IBOCE_IB_REFUNDRESCHFEE dealReschRefundDtl : dealReschRefundDtls) {
        				for (CeRescheduleHistoryDetails rescheduleHistoryDtls : rescheduleHistoryDetails
        						.getRescheduleHistoryDetails()) {
        					if (dealReschRefundDtl.getBoID().equals(rescheduleHistoryDtls.getRequestId())) {
        						if (dealReschRefundDtl.getF_IBSYSTEMSTATUS().equals(CeConstants.REFUND_STATUS_SCHEDULED))
        							rescheduleHistoryDtls.setRescheduleProfitStatus(scheduledDesc);
        						else if (dealReschRefundDtl.getF_IBSYSTEMSTATUS().equals(CeConstants.REFUND_STATUS_REFUNDED))
        							rescheduleHistoryDtls.setRescheduleProfitStatus(rescheduleDesc);
        						break;
        					}
        				}
        			}
                }
                setF_OUT_rescheduleHistory(rescheduleHistoryDetails);
            }
        }
    }
}
