package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetGCDTLNOtherDtlsForAstCatID;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AssetThirdPartyAttributePanelVisibility;
import bf.com.misys.ib.types.AttrVisibiltyFlags;
import bf.com.misys.ib.types.InputFieldsDtls;
import bf.com.misys.ib.types.OutputFieldsDtls;
import bf.com.misys.ib.types.PricingEngineConf;

public class GetGCDTLNOtherDtlsForAstCatID extends AbstractCE_IB_GetGCDTLNOtherDtlsForAstCatID{
	
	public GetGCDTLNOtherDtlsForAstCatID()
	{
		super();
	}
	
	public GetGCDTLNOtherDtlsForAstCatID(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String assetCategoryID = getF_IN_assetCategoryID();
		GetAssetAttributeNames assetAttributeNames = new GetAssetAttributeNames(env);
		assetAttributeNames.setF_IN_categoryID(assetCategoryID);
		assetAttributeNames.setF_IN_onlyAttributeMode(false);
		assetAttributeNames.setF_IN_dealID("Dummy");
		assetAttributeNames.process(env);
		setF_OUT_groupCD(assetAttributeNames.getF_OUT_GROUPCD());
		setF_OUT_toolNo(assetAttributeNames.getF_OUT_TOOLNO());
		IBOIB_AST_AssetCategory assteCategoryDtls = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(
				IBOIB_AST_AssetCategory.BONAME, assetCategoryID, true);
		if(null != assteCategoryDtls)
		{
		  try {
		      Integer listser =  Integer.parseInt(assteCategoryDtls.getF_CATEGORYNAME());
		      setF_OUT_listSer(listser);
		  }catch (Exception e){
		      e.printStackTrace();
		      setF_OUT_listSer(0);
		  }
		    
			
		}
		PricingEngineConf pricingEngineConf = new PricingEngineConf();
		InputFieldsDtls inputFields = new InputFieldsDtls();
		inputFields.setAttr1Label(assetAttributeNames.getF_OUT_attribute1Label());
		inputFields.setAttr2Label(assetAttributeNames.getF_OUT_attribute2Label());
		inputFields.setAttr3Label(assetAttributeNames.getF_OUT_attribute3Label());
		inputFields.setAttr4Label(assetAttributeNames.getF_OUT_attribute4Label());
		inputFields.setAttr5Label(assetAttributeNames.getF_OUT_attribute5Label());
		pricingEngineConf.setInputFieldsDtls(inputFields);
		OutputFieldsDtls outputFields = new OutputFieldsDtls();
		outputFields.setAttr6Label(assetAttributeNames.getF_OUT_attribute6Label());
		outputFields.setAttr7Label(assetAttributeNames.getF_OUT_attribute7Label());
		outputFields.setAttr8Label(assetAttributeNames.getF_OUT_attribute8Label());
		outputFields.setAttr9Label(assetAttributeNames.getF_OUT_attribute9Label());
		pricingEngineConf.setOutputFieldsDtls(outputFields);
		setF_OUT_pricingEngineConf(pricingEngineConf);
		
		AttrVisibiltyFlags attrVisibilityFlags = new AttrVisibiltyFlags();
		AssetThirdPartyAttributePanelVisibility attributeVisibility  = assetAttributeNames.getF_OUT_assetThirdPartyAttributePanelVisibility();
		attrVisibilityFlags.setShowAttr1(attributeVisibility.getPanelVisibilityAttribute1());
		attrVisibilityFlags.setShowAttr2(attributeVisibility.getPanelVisibilityAttribute2());
		attrVisibilityFlags.setShowAttr3(attributeVisibility.getPanelVisibilityAttribute3());
		attrVisibilityFlags.setShowAttr4(attributeVisibility.getPanelVisibilityAttribute4());
		attrVisibilityFlags.setShowAttr5(attributeVisibility.getPanelVisibilityAttribute5());
		attrVisibilityFlags.setShowAttr6(attributeVisibility.getPanelVisibilityAttribute6());
		attrVisibilityFlags.setShowAttr7(attributeVisibility.getPanelVisibilityAttribute7());
		attrVisibilityFlags.setShowAttr8(attributeVisibility.getPanelVisibilityAttribute8());
		attrVisibilityFlags.setShowAttr9(attributeVisibility.getPanelVisibilityAttribute9());
		setF_OUT_attrVisibilityFlags(attrVisibilityFlags);
		
		
	}
}
