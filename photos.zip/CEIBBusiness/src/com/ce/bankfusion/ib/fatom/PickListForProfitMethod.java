package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PickListForProfitMethod;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.PickList;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class PickListForProfitMethod extends AbstractCE_IB_PickListForProfitMethod {

	public PickListForProfitMethod(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		ListGenericCodeRs profitMethodGCList = IBCommonUtils.getGCList(CeConstants.PROFITMETHOD);

		if (profitMethodGCList != null && profitMethodGCList.getGcCodeDetailsCount() > 0) {
			for (GcCodeDetail gcCodeDetail : profitMethodGCList.getGcCodeDetails()) {
				if (gcCodeDetail.getCodeReference().equals(CeConstants.FLATRATE)) {
					PickList pickListItem = CeUtils.getPisckListObject();
					pickListItem.setDescription(gcCodeDetail.getCodeDescription());
					pickListItem.setValues(gcCodeDetail.getCodeReference());
					getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
				}
			}
		}
	}
}
