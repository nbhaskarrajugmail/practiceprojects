package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_SearchFileDetails;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.runtime.toolkit.expression.function.ConvertToTimestamp;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class SearchFileDetails extends AbstractCE_ADF_SearchFileDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(SearchFileDetails.class.getName());

	ArrayList<Object> params = new ArrayList();
	String query = "";
	int pageNo;
	int totalPages;
	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
	
	public SearchFileDetails(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		getQuery();

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		IPagingData pagingData = null;

		if (getF_IN_PagingQuery() != null && getF_IN_PagingQuery().getPagingRequest() != null) {
			pageSize = getF_IN_PagingQuery().getPagingRequest().getNumberOfRows();
			pageNo = getF_IN_PagingQuery().getPagingRequest().getRequestedPage();
		}

		if (pageSize == 0)
			pageSize = PAGE_SIZE;
		if (pageNo == 0)
			pageNo = PAGE_NO;

		pagingData = new PagingData(pageNo, pageSize);
		pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
		VectorTable resultGrid = this.runQuery(query, pagingData);
	}

	private VectorTable runQuery(String dynamicQuery, IPagingData pagingData) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Query used to fetch the data :" + dynamicQuery);
			LOGGER.info("Parameter Values for Query : " + params);
			LOGGER.info("Result Page Number : " + pagingData.getCurrentPageNumber());
		}
		List<SimplePersistentObject> resultSet = null;

		if (query.length() > 7) {
			resultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BATCHFILEDETAIL.BONAME, query,
					params, pagingData, true);
		} else {
			resultSet = BankFusionThreadLocal.getPersistanceFactory().findAll(IBOCE_BATCHFILEDETAIL.BONAME, pagingData);
		}

		VectorTable newResultVector = getVectorTableFromList(resultSet, pagingData.getCurrentPageNumber());
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		// pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		newResultVector.setPagingData(pageData);

		// setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
		setF_OUT_result(newResultVector);
		setF_OUT_PaginatedData(newResultVector);
		totalPages = pagingData.getTotalPages();
		pagingData.getCurrentPageNumber();
		return newResultVector;
	}

	private VectorTable getVectorTableFromList(List<SimplePersistentObject> list, int pageNumber) {
		//List<GcDetails> listGcYnN = GenericCodes.getInstance().getGenricCodes("BOOLEANVALUES", 1);
		VectorTable vectorTable = new VectorTable();
		if (list != null && !list.isEmpty()) {
			Iterator var7 = list.iterator();
			//int idx = (pageNumber - 1) * 10 + 1;
			while (var7.hasNext()) {
				IBOCE_BATCHFILEDETAIL batchtxndetail = (IBOCE_BATCHFILEDETAIL) var7.next();
				Map<String, Object> attribute = new HashMap<>();
				attribute.put("BOID", batchtxndetail.getBoID());
				attribute.put("AMNTTOPROCESS", batchtxndetail.getF_AMNTTOPROCESS());
				attribute.put("BANKID", batchtxndetail.getF_BANKID());
				//attribute.put("SRNO", batchtxndetail.getF_);
				attribute.put("SELECT", false);
				attribute.put("BATCHREF", batchtxndetail.getF_BATCHREF());
				attribute.put("FILENAME", batchtxndetail.getF_FILENAME());
				attribute.put("INTERNALACC", batchtxndetail.getF_INTERNALACC());
				attribute.put("STATUS", batchtxndetail.getF_STATUS());
				attribute.put("TXNTYPE", batchtxndetail.getF_TXNTYPE());
				attribute.put("RECCREATEDON", batchtxndetail.getF_RECCREATEDON());
				attribute.put("RECCREATEDBY", batchtxndetail.getF_RECCREATEDBY());

				vectorTable.addAll(new VectorTable(attribute));
			}
		}
		return vectorTable;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		Map supportedData = pagingState.getPagingHelper().getPagingModel();
		supportedData.put("PAGING_QUERY", query);
		supportedData.put("PAGING_PARAMS", params);
		return pagingState;
	}

	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map map) {

		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		query = (String) pagingModel.get("PAGING_QUERY");
		params = (ArrayList<Object>) pagingModel.get("PAGING_PARAMS");

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (map.containsKey("PAGENO")) {
			pageNo = (Integer) map.get("PAGENO");
		}
		if (map.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) map.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			resultVector = runQuery(query, pagingData);

		}
		return resultVector;
	}

	private void getQuery() {
		StringBuffer QUERY = new StringBuffer();
		String fileName = getF_IN_fileName();
		BigDecimal amountToProcess = getF_IN_amountToProcess();
		String status = getF_IN_status();
		
		params.clear();
		if (!fileName.isEmpty()) {
			QUERY.append(" WHERE " + IBOCE_BATCHFILEDETAIL.FILENAME + " like '%" + fileName + "%'");
		} else {
			QUERY.append(" WHERE ");
		}
		// params.add(fileName);
		if (amountToProcess.compareTo(BigDecimal.ZERO) > CommonConstants.INTEGER_ZERO) {
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_BATCHFILEDETAIL.AMNTTOPROCESS + " = ? ");
			} else {
				QUERY.append(IBOCE_BATCHFILEDETAIL.AMNTTOPROCESS + " = ? ");
			}
			params.add(amountToProcess);
		}
		if (getF_IN_fromDate() != null) {
			Timestamp fromDate = ConvertToTimestamp.run(getF_IN_fromDate());
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_BATCHFILEDETAIL.RECCREATEDON + " >= ? ");
			} else {
				QUERY.append(IBOCE_BATCHFILEDETAIL.RECCREATEDON + " >= ? ");
			}
			params.add(fromDate);
		}
		if (getF_IN_toDate() != null) {
			Timestamp toDate = ConvertToTimestamp.run(getF_IN_toDate());
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_BATCHFILEDETAIL.RECCREATEDON + " <= ? ");
			} else {
				QUERY.append(IBOCE_BATCHFILEDETAIL.RECCREATEDON + " <= ? ");
			}
			params.add(toDate);
		}
		if (!status.isEmpty()) {
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_BATCHFILEDETAIL.STATUS + " = ? ");
			} else {
				QUERY.append(IBOCE_BATCHFILEDETAIL.STATUS + " = ? ");
			}
			params.add(status);
		}if(!getF_IN_txnNarrative().isEmpty()) {
			String INNER_CLAUSE = "SELECT DISTINCT " + IBOCE_BATCHTXNDETAIL.BATCHREF + " FROM "
					+ IBOCE_BATCHTXNDETAIL.BONAME + " WHERE " + IBOCE_BATCHTXNDETAIL.NARRATIVE + " LIKE '%" + getF_IN_txnNarrative() + "%'";
			if (QUERY.length() > 7) {
				QUERY.append(" AND " + IBOCE_BATCHFILEDETAIL.BATCHREF + " IN ("+INNER_CLAUSE+")");
			} else {
				QUERY.append(IBOCE_BATCHFILEDETAIL.BATCHREF + " IN ("+INNER_CLAUSE+")");
			}
		}
		query = QUERY.toString();
	}
	
}
