package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedSearch;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.common.functions.CB_CMN_GetBankFusionMessage;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class TitleDeedSearch extends AbstractCE_IB_TitleDeedSearch{
    
    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    private ArrayList<Object> params = new ArrayList<Object>();
    
    @SuppressWarnings("deprecation")
    public TitleDeedSearch(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) {
        VectorTable newResultVector = new VectorTable();
        String message = CommonConstants.EMPTY_STRING;

        List<SimplePersistentObject> resultSet = factory.findAll(IBOCE_PARENTTITLEDEEDDTLS.BONAME, null, true);
        if (resultSet.size() < 1) {
            message = CB_CMN_GetBankFusionMessage.run(30500010);
        } else {
            /**
             * setting the result set in a vector table.
             */
            //newResultVector = getVectorTableFromList(resultSet);
        }
    }
}
