package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PickListForPaymentFrequency;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.ScheduleUtils;
import com.ce.ib.cfg.dto.SubproductFrequencyDtl;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.PickList;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class PickListForPaymentFrequency extends AbstractCE_IB_PickListForPaymentFrequency {

	private static final Log LOGGER = LogFactory.getLog(PickListForPaymentFrequency.class);

	public PickListForPaymentFrequency(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		String subproductId = CeUtils.getSubproductIdForPickList(getF_IN_inputPayLoad());
		String productId = CeUtils.getProductIdForPickList(getF_IN_inputPayLoad());
		if (IBCommonUtils.isNullOrEmpty(productId) && IBCommonUtils.isNullOrEmpty(subproductId)) {
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_dealId());
			if (dealDetails != null) {
				subproductId = dealDetails.getF_ProductContextCode();
				productId = dealDetails.getF_ProductCode();
			}
		}

		String parentReference = ScheduleUtils.getParentReference(subproductId, productId);

		ListGenericCodeRs paymentFreqGCList = IBCommonUtils.getGCList(parentReference);

		SubproductFrequencyDtl frequencyDtl = ScheduleUtils.getFrequenciesConfiguredAtSubproduct(subproductId);

		if (paymentFreqGCList != null && paymentFreqGCList.getGcCodeDetailsCount() > 0) {
			for (GcCodeDetail gcCodeDetail : paymentFreqGCList.getGcCodeDetails()) {
				if (frequencyDtl != null) {
					if ((gcCodeDetail.getCodeReference().equals("MONTHLY")
							&& frequencyDtl.getMonthlyFrequency().equals("true"))
							|| (gcCodeDetail.getCodeReference().equals("QUARTERLY")
									&& frequencyDtl.getQuarterlyFrequency().equals("true"))
							|| (gcCodeDetail.getCodeReference().equals("HALF-YEARLY")
									&& frequencyDtl.getHalfyearlyFrequency().equals("true"))
							|| (gcCodeDetail.getCodeReference().equals("YEARLY")
									&& frequencyDtl.getYearlyFrequency().equals("true"))) {
						PickList pickListItem = CeUtils.getPisckListObject();
						pickListItem.setDescription(gcCodeDetail.getCodeDescription());
						pickListItem.setValues(gcCodeDetail.getCodeReference());
						getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
						getF_OUT_listGenericCodeRs().addGcCodeDetails(gcCodeDetail);
					}
				} else {
					if (gcCodeDetail.getCodeReference().equals("MONTHLY")
							|| gcCodeDetail.getCodeReference().equals("QUARTERLY")
							|| gcCodeDetail.getCodeReference().equals("HALF-YEARLY")
							|| gcCodeDetail.getCodeReference().equals("YEARLY")) {
						PickList pickListItem = CeUtils.getPisckListObject();
						pickListItem.setDescription(gcCodeDetail.getCodeDescription());
						pickListItem.setValues(gcCodeDetail.getCodeReference());
						getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
						getF_OUT_listGenericCodeRs().addGcCodeDetails(gcCodeDetail);
					}
				}
			}
		}
	}
}
