package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ManageDealRelationshipAgents;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.DealRelationshipDetails;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipAgents;

public class ManageDealRelationshipAgents extends AbstractCE_IB_ManageDealRelationshipAgents {

	public ManageDealRelationshipAgents(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		DealRelationshipDetails masterAgents = getF_IN_dealRelationshipDetails();
		DealRelationshipDetails selectedRelationshipAgents = getF_IN_selectedDealRelationship();// main grid
		if (isF_IN_isValidate()) {
			
			if (getF_IN_relationshipDtl() != null
					&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDtl().getRelationshipDtlId())
					&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipDtl().getPartyId())
					&& getF_IN_relationshipAgent() != null
					&& !IBCommonUtils.isNullOrEmpty(getF_IN_relationshipAgent().getPartyId())) {
				
				// validating party added in Agents panel cannot be same as relationship party
				if(getF_IN_relationshipAgent().getPartyId().equals(getF_IN_relationshipDtl().getPartyId())) 
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_CANNOT_BE_SAME_AS_AGENT_IB);
				
				
				if(!IBCommonUtils.isNullOrEmpty(getF_IN_relationshipAgent().getAgencySource())
						&& selectedRelationshipAgents != null && selectedRelationshipAgents.getRelationshipAgentsCount() > 0) {
					for(RelationshipAgents addedAgent : selectedRelationshipAgents.getRelationshipAgents()) {
						if(addedAgent.getAgencySource().equals(getF_IN_relationshipAgent().getAgencySource())
								&& addedAgent.getPartyId().equals(getF_IN_relationshipAgent().getPartyId())) {
							String agentSource = IBCommonUtils
									.getGCFromCode("IBAGENTSOURCE", getF_IN_relationshipAgent().getAgencySource())
									.getReadCodeValueDetails().getGcCodeDetails().getCodeDescription();
							String[] arguments = new String[2];
							arguments[0] = getF_IN_relationshipAgent().getPartyId();
							arguments[1] = agentSource;
							IBCommonUtils.raiseParametrizedEvent(CeConstants.E_PARTY_WITH_SAME_AGENT_SOURCE_CANNOT_BE_ADDED_IB, arguments);
						}	
					}
				}
			}

		} else {
			for (RelationshipAgents agent : masterAgents.getRelationshipAgents()) {
				if (agent.getRelationshipDtlId().equals(getF_IN_relationshipDtl().getRelationshipDtlId()))
					masterAgents.removeRelationshipAgents(agent);
			}

			for (RelationshipAgents agent : selectedRelationshipAgents.getRelationshipAgents()) {
				masterAgents.addRelationshipAgents(agent);
			}
		}
		setF_OUT_dealRelationshipAgents(masterAgents);
	}

}
