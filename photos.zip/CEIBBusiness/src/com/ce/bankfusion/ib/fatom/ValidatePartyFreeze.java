package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ADFCallSadadAPI;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidatePartyFreeze;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.sadad.invoice.BillInvoice;
import com.ce.sadad.invoice.FeeInvoiceData;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOUDFEXTPT_PFN_PartyHostExtn;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.InvokeSyncWebServiceImpl;

import bf.com.misys.bankfusion.attributes.BFHeader;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.bankfusion.attributes.WebService;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ReschedulingFee;
import bf.com.misys.msgs.party.v12.PartyDetailsRq;
import bf.com.misys.msgs.party.v12.PartyFetchPayloadRq;
import bf.com.misys.party.ws.ReadPartyWSRq;
import bf.com.misys.party.ws.ReadPartyWSRs;
import bf.com.trapedza.bankfusion.webservices.Authentication;
import bf.com.trapedza.bankfusion.webservices.Bfgenericsoapheader;

public class ValidatePartyFreeze extends AbstractCE_IB_ValidatePartyFreeze {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(ValidatePartyFreeze.class);

	public ValidatePartyFreeze(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		
		IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(ibObject.getDealID());
		
		if(null != dealCustomerDetail) {
					
					try {
						// set the factory connection
						IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
						// Filter Query
						String whereClause = " WHERE PTINTERNALPARTYID = ?";
						// Add Parameters
						ArrayList<String> queryParams = new ArrayList<String>();
						queryParams.add(dealCustomerDetail.getF_CUSTOMERID());

						List<IBOUDFEXTPT_PFN_PartyHostExtn> partyHostExtnDetailsUD = factory
								.findByQuery(IBOUDFEXTPT_PFN_PartyHostExtn.BONAME, whereClause, queryParams, null, true);
						String freezeStatus = StringUtils.EMPTY;
						String validate_DEALINIT = StringUtils.EMPTY;
						String validate_REQACTIVATE = StringUtils.EMPTY;
						String validate_INITTECHANALYSIS = StringUtils.EMPTY;
						String validate_STUDY = StringUtils.EMPTY;
						String validate_GRANTAPPROVAL = StringUtils.EMPTY;
						String validate_SIGNCONTRACT = StringUtils.EMPTY;
						String validate_ASSETPROGRESS = StringUtils.EMPTY;
						
						String freezeStatus_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STATUS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeDealInit_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_DEALINIT, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeReqActivate_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_REQACTIVATE, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeInitTechAnalysis_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_INITTECHANALYSIS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeStudy_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_STUDY, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeGrantApproval_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_GRANTAPPROVAL, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeSignContract_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_SIGNCONTRACT, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeAssetProgress_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_ASSETPROGRESS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeRelationInfo_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_BB_RELATIONINFO, "", CeConstants.ADFIBCONFIGLOCATION);
						// process the results
						for (IBOUDFEXTPT_PFN_PartyHostExtn partyHostExtnDlsUD : partyHostExtnDetailsUD) {
							UserDefinedFields userDefinedFields = partyHostExtnDlsUD.getUserDefinedFields();
							if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
								for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
									
									if (userDefinedFld.getFieldName().equals(freezeStatus_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										freezeStatus = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeDealInit_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_DEALINIT = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeReqActivate_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_REQACTIVATE = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeInitTechAnalysis_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_INITTECHANALYSIS = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeStudy_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_STUDY = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeGrantApproval_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_GRANTAPPROVAL = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeSignContract_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_SIGNCONTRACT =userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeAssetProgress_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_ASSETPROGRESS = userDefinedFld.getFieldValue().toString();
									}
																	
								}
							}
						}
						
						if(freezeStatus.equalsIgnoreCase("Yes")) {
							
							if(validate_DEALINIT.equalsIgnoreCase("true") && 
									ibObject.getStepID().equalsIgnoreCase("DEALINIT"))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_REQACTIVATE.equalsIgnoreCase("true") && 
									ibObject.getStepID().equalsIgnoreCase("REQACTIVATE"))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_INITTECHANALYSIS.equalsIgnoreCase("true") && 
									(ibObject.getStepID().equalsIgnoreCase("TECHNICALANALYSIS") || 
											ibObject.getStepID().equalsIgnoreCase("INITIALTECHNICALANALYSIS")))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_STUDY.equalsIgnoreCase("true") && 
									(ibObject.getStepID().equalsIgnoreCase("STUDY")||
											ibObject.getStepID().equalsIgnoreCase("BRNCHSTUDY")))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_GRANTAPPROVAL.equalsIgnoreCase("true") && 
									(ibObject.getStepID().equalsIgnoreCase("BRNCHAPPROVE2")||
											ibObject.getStepID().equalsIgnoreCase("COMMITTEEAPPROVE")))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_SIGNCONTRACT.equalsIgnoreCase("true") && 
									ibObject.getStepID().equalsIgnoreCase("SIGNCONTRACT"))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
							if(validate_ASSETPROGRESS.equalsIgnoreCase("true") && 
									(ibObject.getStepID().equalsIgnoreCase("PROGRESSREPORT")||
											ibObject.getStepID().equalsIgnoreCase("ISSUEPAYMENTORDER")||
											ibObject.getStepID().equalsIgnoreCase("APPROVALANDDISB")))
								IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_FREEZE_IB);
						}
						
					} catch (Exception se) {
						throw se;
					}
			
		}
				
	}
	
}