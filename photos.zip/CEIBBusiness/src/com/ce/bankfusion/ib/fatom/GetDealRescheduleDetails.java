package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ASSETPROFILE;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RESCHEDULEDISTDETAILS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateDealReschedule;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.fatom.PopulateIBBuildingBlock;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.types.Currency;
import bf.com.misys.dealreschedule.dtls.ib.types.CeDistributePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CePostPonePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleRequestDetails;
import bf.com.misys.dealreschedule.dtls.ib.types.DealRescheduleDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.AssetProfileDetails;
import bf.com.misys.schedule.dtls.ib.types.CeAssetProfile;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class GetDealRescheduleDetails extends AbstractCE_IB_PopulateDealReschedule {

	private static BigDecimal hundred = new BigDecimal(100);
	private static String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
	private static String assetProfileQuery = " WHERE " + IBOCE_IB_ASSETPROFILE.IBRESCHEDULEID + " = ? ";
	private static String distributeScheduleQuery = " WHERE " + IBOCE_IB_RESCHEDULEDISTDETAILS.IBRESCHEDULEID + " = ? order by "+IBOCE_IB_RESCHEDULEDISTDETAILS.IBBILLOLDDATE+" asc";

	private IBOIB_DLI_DealDetails dealDetails;
	private ReadLoanDetailsRs readLoanDetails;
	private boolean activeRescheduleReqExists;
	private BigDecimal outstandingFee;
	private static final Log LOGGER = LogFactory.getLog(GetDealRescheduleDetails.class);

	public GetDealRescheduleDetails() {
	}

	public GetDealRescheduleDetails(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		outstandingFee = BigDecimal.ZERO;
		try {
			dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
			readLoanDetails = IBCommonUtils.getLoanDetails(getF_IN_islamicBankingObject().getDealID());
		} catch (Exception e) {
			LOGGER.info("Dealdetails/ReadLoandetails doesnot exist for DealId " + getF_IN_islamicBankingObject().getDealID());
			throw e;
		}

		DealRescheduleDetails dealRescheduleDetails = new DealRescheduleDetails();
		AssetProfileDetails assetProfileDetails = new AssetProfileDetails();
		dealRescheduleDetails.setAssetProfileDetails(assetProfileDetails);
		getCurrentSchedule(dealRescheduleDetails);
		getRescheduleRequestDetails(dealRescheduleDetails);
		getNewScheduleAndAssetProfile(dealRescheduleDetails);
		if(dealRescheduleDetails.getPostPonePaymentSchedule() != null) {
			dealRescheduleDetails.removeAllPostPonePaymentSchedule();
		}
		if(dealRescheduleDetails.getDistributePaymentSchedule() != null) {
			dealRescheduleDetails.removeAllDistributePaymentSchedule();
		}
		setDistributePaymentSchedule(dealRescheduleDetails);
		setPostponePaymentSchedule(dealRescheduleDetails);
		// Getting surplus amount from readloan details
        Currency surplusAmt = RescheduleUtils.getSurplusAmount(dealDetails.getF_DealAccountId());
        if (null != surplusAmt)
            dealRescheduleDetails.getRescheduleRequestDetails()
                    .setSurplusAmount(IBCommonUtils.getBFCurrencyAmount(surplusAmt.getAmount(), surplusAmt.getIsoCurrencyCode()));
		setF_OUT_dealRescheduleDetails(dealRescheduleDetails);
	}

	private void setDistributePaymentSchedule(DealRescheduleDetails dealRescheduleDetails) {
		if(activeRescheduleReqExists && null != dealRescheduleDetails.getRescheduleRequestDetails().getIsDistribute() && dealRescheduleDetails.getRescheduleRequestDetails().getIsDistribute()) {
			ArrayList params = new ArrayList();
			params.add(dealRescheduleDetails.getRescheduleRequestDetails().getRescheduleRequestId());
			List<IBOCE_IB_RESCHEDULEDISTDETAILS> distributeDtls = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME, distributeScheduleQuery, params, null, false);
			int i=1;
			for(IBOCE_IB_RESCHEDULEDISTDETAILS distributeDtl : distributeDtls) {
				CeDistributePaymentSchedule distributeSchedule = new CeDistributePaymentSchedule();
				distributeSchedule.setFeesAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSCHEDULEFEEAMT(), dealDetails.getF_IsoCurrencyCode()));
				distributeSchedule.setIsIncludeSubsidy(BigDecimal.ZERO.compareTo(distributeDtl.getF_IBSUBSIDYAMNT())==-1?true:false);
				distributeSchedule.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBPRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode()));
				distributeSchedule.setProfitAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
				distributeSchedule.setRepaymentNo(i++);
				distributeSchedule.setStatus(distributeDtl.getF_IBSTATUS());
				distributeSchedule.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSUBSIDYAMNT(), dealDetails.getF_IsoCurrencyCode()));
				distributeSchedule.setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSCHEDULEFEEAMT().add(distributeDtl.getF_IBPRINCIPALAMT()).add(distributeDtl.getF_IBPROFITAMT()), dealDetails.getF_IsoCurrencyCode()));
				distributeSchedule.setSelect(false);
				distributeSchedule.setRepaymentDate(distributeDtl.getF_IBBILLDATE());
				distributeSchedule.setIsDistribute(distributeDtl.isF_IBDISTRIBUTE());
				distributeSchedule.setIsSkipRepayment(distributeDtl.isF_IBSELECT());
				dealRescheduleDetails.addDistributePaymentSchedule(distributeSchedule);
			}
		}
		if(dealRescheduleDetails.getDistributePaymentScheduleCount()==0) {
			for(CePaymentSchedule paymentSchedule : dealRescheduleDetails.getCurrentSchedule()) {
				CeDistributePaymentSchedule distributeSchedule = new CeDistributePaymentSchedule();
				distributeSchedule.setFeesAmount(paymentSchedule.getFeesAmount());
				distributeSchedule.setIsIncludeSubsidy(BigDecimal.ZERO.compareTo(paymentSchedule.getSubsidyAmount().getCurrencyAmount())==-1?true:false);
				distributeSchedule.setPrincipalAmount(paymentSchedule.getPrincipalAmount());
				distributeSchedule.setProfitAmount(paymentSchedule.getProfitAmount());
				distributeSchedule.setRepaymentNo(paymentSchedule.getRepaymentNo());
				distributeSchedule.setStatus(paymentSchedule.getStatus());
				distributeSchedule.setSubsidyAmount(paymentSchedule.getSubsidyAmount());
				distributeSchedule.setTotalRepaymentAmount(paymentSchedule.getTotalRepaymentAmount());
				distributeSchedule.setSelect(false);
				distributeSchedule.setRepaymentDate(paymentSchedule.getRepaymentDate());
				distributeSchedule.setIsDistribute(false);
				distributeSchedule.setIsSkipRepayment(false);
				dealRescheduleDetails.addDistributePaymentSchedule(distributeSchedule);
			}
		}
	}

	private void setPostponePaymentSchedule(DealRescheduleDetails dealRescheduleDetails) {
		if(activeRescheduleReqExists && null != dealRescheduleDetails.getRescheduleRequestDetails().getIsPostpone() && dealRescheduleDetails.getRescheduleRequestDetails().getIsPostpone()) {
			ArrayList params = new ArrayList();
			params.add(dealRescheduleDetails.getRescheduleRequestDetails().getRescheduleRequestId());
			List<IBOCE_IB_RESCHEDULEDISTDETAILS> distributeDtls = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME, distributeScheduleQuery, params, null, false);
			int i=1;
			for(IBOCE_IB_RESCHEDULEDISTDETAILS distributeDtl : distributeDtls) {
				CePostPonePaymentSchedule postponeSchedule = new CePostPonePaymentSchedule();
				postponeSchedule.setFeesAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSCHEDULEFEEAMT(), dealDetails.getF_IsoCurrencyCode()));
				postponeSchedule.setIsIncludeSubsidy(BigDecimal.ZERO.compareTo(distributeDtl.getF_IBSUBSIDYAMNT())==-1?true:false);
				postponeSchedule.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBPRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode()));
				postponeSchedule.setProfitAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
				postponeSchedule.setRepaymentOldDate(distributeDtl.getF_IBBILLOLDDATE());
				postponeSchedule.setRepaymentNewDate(distributeDtl.getF_IBBILLDATE());
				postponeSchedule.setRepaymentNo(i++);
				postponeSchedule.setStatus(distributeDtl.getF_IBSTATUS());
				postponeSchedule.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSUBSIDYAMNT(), dealDetails.getF_IsoCurrencyCode()));
				postponeSchedule.setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(distributeDtl.getF_IBSCHEDULEFEEAMT().add(distributeDtl.getF_IBPRINCIPALAMT()).add(distributeDtl.getF_IBPROFITAMT()), dealDetails.getF_IsoCurrencyCode()));
				postponeSchedule.setSelect(distributeDtl.isF_IBSELECT());
				dealRescheduleDetails.addPostPonePaymentSchedule(postponeSchedule);
			}
		}
		if(dealRescheduleDetails.getPostPonePaymentScheduleCount()==0) {
			for(CePaymentSchedule paymentSchedule : dealRescheduleDetails.getCurrentSchedule()) {
				CePostPonePaymentSchedule postponeSchedule = new CePostPonePaymentSchedule();
				postponeSchedule.setFeesAmount(paymentSchedule.getFeesAmount());
				postponeSchedule.setIsIncludeSubsidy(BigDecimal.ZERO.compareTo(paymentSchedule.getSubsidyAmount().getCurrencyAmount())==-1?true:false);
				postponeSchedule.setPrincipalAmount(paymentSchedule.getPrincipalAmount());
				postponeSchedule.setProfitAmount(paymentSchedule.getProfitAmount());
				postponeSchedule.setRepaymentOldDate(paymentSchedule.getRepaymentDate());
				postponeSchedule.setRepaymentNo(paymentSchedule.getRepaymentNo());
				postponeSchedule.setStatus(paymentSchedule.getStatus());
				postponeSchedule.setSubsidyAmount(paymentSchedule.getSubsidyAmount());
				postponeSchedule.setTotalRepaymentAmount(paymentSchedule.getTotalRepaymentAmount());
				postponeSchedule.setSelect(false);
				dealRescheduleDetails.addPostPonePaymentSchedule(postponeSchedule);
			}
		}
		
	}

	private void getNewScheduleAndAssetProfile(DealRescheduleDetails dealRescheduleDetails) {
		if (activeRescheduleReqExists) {
			LOGGER.info("An active deal reschedule request exist, fetching new schedule and profile");
			dealRescheduleDetails.setNewSchedule(RescheduleUtils.getNewSchedule(getF_IN_islamicBankingObject().getDealID(),
					getF_IN_islamicBankingObject().getTransactionID(), dealDetails.getF_IsoCurrencyCode()));
			getAssetProfileDetails(dealRescheduleDetails);
			setF_OUT_displayNewSchedule(true);
			
			PopulateIBBuildingBlock popBBDetails = new PopulateIBBuildingBlock(IBCommonUtils.getBankFusionEnvironment());
	        popBBDetails.setF_IN_buildingBlockID(getF_IN_islamicBankingObject().getPhaseID());
	        popBBDetails.setF_IN_TransactionID(getF_IN_islamicBankingObject().getTransactionID());
	        popBBDetails.setF_IN_TransactionName(getF_IN_islamicBankingObject().getTransactionName());
	        popBBDetails.setF_IN_isDealEnquiry(false);
	        popBBDetails.setF_IN_processConfigID(getF_IN_islamicBankingObject().getProcessConfigID());
	        popBBDetails.setF_IN_productCode(getF_IN_islamicBankingObject().getProductID());
	        popBBDetails.setF_IN_productType(getF_IN_islamicBankingObject().getSubProductID());
	        popBBDetails.setF_IN_stepID(getF_IN_islamicBankingObject().getStepID());
	        popBBDetails.process(IBCommonUtils.getBankFusionEnvironment());
	        if(!IBCommonUtils.isNullOrEmpty(popBBDetails.getF_OUT_editMode()) && popBBDetails.getF_OUT_editMode().equals("F")) {
	        	setF_OUT_displayInstScalars(true);
	        }
		}
	}

	private void getAssetProfileDetails(DealRescheduleDetails dealRescheduleDetails) {
		getAssetProfile(dealRescheduleDetails);
		getAssetBasedPaymentSchedule(dealRescheduleDetails);
	}

	private void getAssetProfile(DealRescheduleDetails dealRescheduleDetails) {
		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getTransactionID());

		List<IBOCE_IB_ASSETPROFILE> assetProfileDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_ASSETPROFILE.BONAME, assetProfileQuery, params, null, false);
		if (!assetProfileDtls.isEmpty()) {
			for (IBOCE_IB_ASSETPROFILE assetprofile : assetProfileDtls) {
				CeAssetProfile ceAssetProfile = new CeAssetProfile();
				ceAssetProfile.setAssetId(assetprofile.getF_IBASSETID());
				ceAssetProfile.setAssetRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBASSETREPAYMENTAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setFeesPercentageOfTotalScheduleFees(assetprofile.getF_IBFEESPERCOFREPAMNT());
				ceAssetProfile.setPrincipalPercentageOfTotalPrincipal(assetprofile.getF_IBPRINCPERCOFREPAMNT());
				ceAssetProfile.setProfitPercentageOfTotalProfit(assetprofile.getF_IBPROFITPERCOFREPAMNT());
				ceAssetProfile.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBSCHEDULEFEESAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setScheduleFeesAmountPaid(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBSCHEDULEFEESAMOUNTPAID(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBTOTALPRINCIPALAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalPrincipalAmountPaid(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalProfitAmount(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBTOTALPROFITAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalProfitAmountPaid(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(
						assetprofile.getF_IBTOTALSUBSIDYAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				ceAssetProfile.setTotalSubsidyAmountPaid(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				dealRescheduleDetails.getAssetProfileDetails().addAssetProfileList(ceAssetProfile);
			}
		}
	}

	private void getAssetBasedPaymentSchedule(DealRescheduleDetails dealRescheduleDetails) {
		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		params.add(getF_IN_islamicBankingObject().getTransactionID());

		List<IBOCE_IB_PaymentScheduleHistory> schHistory = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentScheduleHistory.BONAME, RescheduleUtils.schHisQuery, params, null, false);
		BigDecimal totalRepaymentAmount = BigDecimal.ZERO;
		if (schHistory != null && !schHistory.isEmpty()) {
			for (IBOCE_IB_PaymentScheduleHistory paymentScheduleHistory : schHistory) {
				AssetBasedPaymentSchedule assetBasedPaymentSchedule = new AssetBasedPaymentSchedule();
				assetBasedPaymentSchedule.setAssetId(paymentScheduleHistory.getF_IBASSETID());
				assetBasedPaymentSchedule.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleHistory.getF_IBPRINCIPALAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				assetBasedPaymentSchedule.setProfitAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleHistory.getF_IBPROFITAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				assetBasedPaymentSchedule.setRepaymentDate(paymentScheduleHistory.getF_IBREPAYMENTDATE());
				assetBasedPaymentSchedule.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleHistory.getF_IBSCHEDULEFEESAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				assetBasedPaymentSchedule.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleHistory.getF_IBSUBSIDYAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
				totalRepaymentAmount = paymentScheduleHistory.getF_IBPRINCIPALAMOUNT()
						.add(paymentScheduleHistory.getF_IBPROFITAMOUNT())
						.add(paymentScheduleHistory.getF_IBSCHEDULEFEESAMOUNT())
						.add(paymentScheduleHistory.getF_IBSUBSIDYAMOUNT());
				assetBasedPaymentSchedule.setTotalRepaymentAmount(
						IBCommonUtils.getBFCurrencyAmount(totalRepaymentAmount, dealDetails.getF_IsoCurrencyCode()));
				dealRescheduleDetails.getAssetProfileDetails().addAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
			}
		}
	}

	private void getRescheduleRequestDetails(DealRescheduleDetails dealRescheduleDetails) {
		CeRescheduleRequestDetails rescheduleRequestDetails = new CeRescheduleRequestDetails();
		IBOCE_IB_DealReschedule reschObj = (IBOCE_IB_DealReschedule) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, getF_IN_islamicBankingObject().getTransactionID(), true);
		rescheduleRequestDetails.setIsGenerate(true);
		if (reschObj != null) {
			LOGGER.info("Getting reschedule request details from existing object");
			// an active deal reschedule request already exist
			activeRescheduleReqExists = true;
			getRescheduleReqDtlsFromExistingObj(rescheduleRequestDetails, reschObj);
			if(reschObj.getF_IBRESCHEDULETYPE() == null || reschObj.getF_IBRESCHEDULETYPE().equals("") || reschObj.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_GENERATE)) {
				rescheduleRequestDetails.setIsGenerate(true);
			}else if(reschObj.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_POSTPONE)) {
				rescheduleRequestDetails.setIsPostpone(true);
				rescheduleRequestDetails.setIsGenerate(false);
			}else {
				rescheduleRequestDetails.setIsDistribute(true);
				rescheduleRequestDetails.setIsGenerate(false);
			}
		}

		if (!activeRescheduleReqExists && readLoanDetails != null) {
			LOGGER.info("Getting reschedule request details from ReadLoan service");
			getRescheduleReqDtlsFromHost(rescheduleRequestDetails);

		}
		dealRescheduleDetails.setDealId(getF_IN_islamicBankingObject().getDealID());
		rescheduleRequestDetails.setRescheduleRequestId(getF_IN_islamicBankingObject().getTransactionID());
		rescheduleRequestDetails.setTotalRescheduleProfit(IBCommonUtils.getBFCurrencyAmount(
				RescheduleUtils.getTotalRescheduleProfit(getF_IN_islamicBankingObject().getDealID()), dealDetails.getF_IsoCurrencyCode()));

		dealRescheduleDetails.setRescheduleRequestDetails(rescheduleRequestDetails);
	}

	private void getRescheduleReqDtlsFromHost(CeRescheduleRequestDetails rescheduleRequestDetails) {
		BigDecimal previousPaidProfitAmnt = BigDecimal.ZERO;
        BigDecimal previousPaidPrincipalAmnt = BigDecimal.ZERO;
        BigDecimal currentRescheduleProfit = BigDecimal.ZERO;
        BigDecimal scheduleFeePercentage = BigDecimal.ZERO;
		for (LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
			previousPaidPrincipalAmnt = previousPaidPrincipalAmnt
					.add(loanPayments.getPrincipalAmtPaid());
			previousPaidProfitAmnt = previousPaidProfitAmnt.add(loanPayments.getProfitAmtPaid());
		}
		BigDecimal rescheduleFeeAmtCap = new BigDecimal((IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeeAmtCap").getValue()));
		BigDecimal outstandingPrincipal = readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt();
		if(outstandingPrincipal.compareTo(rescheduleFeeAmtCap)>=CommonConstants.INTEGER_ZERO) {
            int rescheduleFeePercentage = Integer.parseInt(IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeePercentage").getValue());
            currentRescheduleProfit = outstandingPrincipal.multiply(new BigDecimal(rescheduleFeePercentage)).divide(new BigDecimal(100));
            scheduleFeePercentage = new BigDecimal(100);
		}
        rescheduleRequestDetails.setCurrentRescheduleProfit(IBCommonUtils.getBFCurrencyAmount(currentRescheduleProfit, dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setFeesAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setFeesPercentage(BigDecimal.ZERO);
		rescheduleRequestDetails.setIncludeSubsidy(false);
		rescheduleRequestDetails.setNewRemainingInstallments(0);
		rescheduleRequestDetails.setOutstandingNoOfInstallments(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getRemainingNoOfPayments());
		rescheduleRequestDetails.setOutstandinPrincipal(
				IBCommonUtils.getBFCurrencyAmount(outstandingPrincipal, dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setOutstandinProfit(IBCommonUtils.getBFCurrencyAmount(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getProfitAmt().subtract(previousPaidProfitAmnt).subtract(outstandingFee), 
				dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setOutstandingFees(IBCommonUtils.getBFCurrencyAmount(outstandingFee,
				dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setReschedulePaymentDate(RescheduleUtils.getRescheduleMinPaymentDate());
		rescheduleRequestDetails.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(currentRescheduleProfit, dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setScheduleFeesPercentage(scheduleFeePercentage);
		rescheduleRequestDetails.setSurplusAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setTotalNoOfInstallments(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalNoOfPayments());
		rescheduleRequestDetails.setFeesCollectionMethod("SADAD");
		rescheduleRequestDetails.setRescheduleFrequency("YEARLY");
	}

	private void getRescheduleReqDtlsFromExistingObj(CeRescheduleRequestDetails rescheduleRequestDetails,
			IBOCE_IB_DealReschedule reschObj) {
		System.err.println();
        BigDecimal previousPaidProfitAmnt = BigDecimal.ZERO;
        BigDecimal previousPaidPrincipalAmnt = BigDecimal.ZERO;
        
        for(LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
        	previousPaidPrincipalAmnt = previousPaidPrincipalAmnt
					.add(loanPayments.getPrincipalAmtPaid());
			previousPaidProfitAmnt = previousPaidProfitAmnt.add(loanPayments.getProfitAmtPaid());
        }
        
        rescheduleRequestDetails.setCurrentRescheduleProfit(IBCommonUtils
				.getBFCurrencyAmount(reschObj.getF_IBRESCHEDULEPROFIT(), dealDetails.getF_IsoCurrencyCode()));
		BigDecimal feesAmount = reschObj.getF_IBRESCHEDULEPROFIT().subtract(reschObj.getF_IBSCHEDULEFEES());
		rescheduleRequestDetails
				.setFeesAmount(IBCommonUtils.getBFCurrencyAmount(feesAmount, dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setFeesCollectionMethod(reschObj.getF_IBRESCHEDULECOLLMETHOD());
		if (reschObj.getF_IBRESCHEDULEPROFIT().compareTo(BigDecimal.ZERO) > 0)
			rescheduleRequestDetails.setFeesPercentage(hundred.subtract(reschObj.getF_IBSCHEDULEFEESPER()));
		else
			rescheduleRequestDetails.setFeesPercentage(BigDecimal.ZERO);
		rescheduleRequestDetails.setIncludeSubsidy(reschObj.isF_IBINCLUDESUBSIDY());
		rescheduleRequestDetails.setNewRemainingInstallments(reschObj.getF_IBRESCHINSTALLMENTS());
		rescheduleRequestDetails.setOutstandingNoOfInstallments(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getRemainingNoOfPayments());
		rescheduleRequestDetails.setOutstandinPrincipal(IBCommonUtils.getBFCurrencyAmount(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt(),
				dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setOutstandinProfit(IBCommonUtils.getBFCurrencyAmount(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getProfitAmt().subtract(previousPaidProfitAmnt).subtract(outstandingFee), 
				dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setOutstandingFees(IBCommonUtils.getBFCurrencyAmount(outstandingFee,
				dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setRescheduleFrequency(reschObj.getF_IBRESCHEDULEFREQ());
		rescheduleRequestDetails.setReschedulePaymentDate(reschObj.getF_IBRESCHEDULEPAYMENTDT());
		rescheduleRequestDetails.setScheduleFeesAmount(
				IBCommonUtils.getBFCurrencyAmount(reschObj.getF_IBSCHEDULEFEES(), dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setScheduleFeesPercentage(reschObj.getF_IBSCHEDULEFEESPER());
		rescheduleRequestDetails.setSurplusAmount(
				IBCommonUtils.getBFCurrencyAmount(reschObj.getF_IBSURPLUSAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
		rescheduleRequestDetails.setTotalNoOfInstallments(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalNoOfPayments());
		if(reschObj.getF_IBRESCHEDULETYPE() == null || reschObj.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_GENERATE)) {
        	rescheduleRequestDetails.setIsGenerate(true);
        }else if(reschObj.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_POSTPONE)) {
        	rescheduleRequestDetails.setIsPostpone(true);
        }else if(reschObj.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_DISTRIBUTE)) {
        	rescheduleRequestDetails.setIsDistribute(true);
        }
	}

	private void getCurrentSchedule(DealRescheduleDetails dealRescheduleDetails) {
		BigDecimal totalScheduleFeesAmount = BigDecimal.ZERO;
		BigDecimal totalScheduleFeesPaidAmount = BigDecimal.ZERO;
		LOGGER.info("Fetching current schedule from ReadLoan details");
		if (readLoanDetails != null && readLoanDetails.getDealDetails().getPaymentScheduleCount() > 0) {
			for (LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
				CePaymentSchedule currentSchedule = new CePaymentSchedule();
				currentSchedule.setRepaymentDate(loanPayments.getRepaymentDate());
				currentSchedule.setRepaymentNo(loanPayments.getRepaymentNo());
				currentSchedule.setStatus(
						IBCommonUtils.getGCChildDesc("IBINSTALLMENTSTATUS", loanPayments.getRepaymentStatus()));
				currentSchedule.setPrincipalAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setProfitAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setFeesAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setSubsidyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setTotalRepaymentAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				dealRescheduleDetails.addCurrentSchedule(currentSchedule);
			}
		}

		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());

		// ReadLoan gives fees amount also as profit amount, hence looping through
		// breakup table and fetching amounts
		List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);
		if (breakupDtls != null && !breakupDtls.isEmpty()) {
		    String arrearStatus = IBCommonUtils.getGCChildDesc("IBINSTALLMENTSTATUS", "ARREAR");
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : breakupDtls) {
				for (CePaymentSchedule scheduleDetails : dealRescheduleDetails.getCurrentSchedule()) {
					if (CalendarUtil.IsDate1EqualsToDate2(scheduleDetails.getRepaymentDate(),
							paymentSchBreakup.getF_IBBILLDATE())) {
						scheduleDetails.getPrincipalAmount().setCurrencyAmount(scheduleDetails.getPrincipalAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBPRINCIPALAMT()));
						scheduleDetails.getProfitAmount().setCurrencyAmount(scheduleDetails.getProfitAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBPROFITAMT()));
						scheduleDetails.getFeesAmount().setCurrencyAmount(scheduleDetails.getFeesAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
						scheduleDetails.getSubsidyAmount().setCurrencyAmount(scheduleDetails.getSubsidyAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBSUBSIDYAMNT()));
						scheduleDetails.getTotalRepaymentAmount()
								.setCurrencyAmount(scheduleDetails.getPrincipalAmount().getCurrencyAmount()
										.add(scheduleDetails.getProfitAmount().getCurrencyAmount())
										.add(scheduleDetails.getFeesAmount().getCurrencyAmount()));
						totalScheduleFeesAmount = totalScheduleFeesAmount.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						totalScheduleFeesPaidAmount = totalScheduleFeesPaidAmount.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
					}
				}
			}
		}
		outstandingFee = totalScheduleFeesAmount.subtract(totalScheduleFeesPaidAmount);
	}
}
