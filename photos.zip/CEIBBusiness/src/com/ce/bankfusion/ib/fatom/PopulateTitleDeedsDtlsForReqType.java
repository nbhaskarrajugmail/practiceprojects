package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;

public class PopulateTitleDeedsDtlsForReqType {

	public TitleDeedDetailsList getTitleDeedsDtlsList(String requestID, TitleDeedDetailsList hiddenTitleDeedDtlsList) {

		TitleDeedDetailsList titleDeedDtlsList = new TitleDeedDetailsList();

		for (TitleDeedDetails eachHiddenTitleDeed : hiddenTitleDeedDtlsList.getTitleDeedDetailsList()) {
			TitleDeedDetails eachTitleDeedUI = new TitleDeedDetails();

			if (requestID.equals(eachHiddenTitleDeed.getRequestID())) {
				eachTitleDeedUI = eachHiddenTitleDeed;
				
				//eachTitleDeedUI.getAgricultureDetails().setStatusDesc("");
				eachTitleDeedUI.getAgricultureDetails().setSelect(false);
				//eachTitleDeedUI.setTitleDeedVersionNum(0);
				eachTitleDeedUI.getResidentialDetails().getPricePerBuildSqM().setCurrencyCode("");
				titleDeedDtlsList.addTitleDeedDetailsList(eachTitleDeedUI);
			}

		}
		if(titleDeedDtlsList.getTitleDeedDetailsListCount()>0) {
		    titleDeedDtlsList.getTitleDeedDetailsList(0).setSelect(true); 
		}
		
		return titleDeedDtlsList;

	}

	public WellDetailsList populateWellDtlsList(WellDetailsList hiddenWellDetailsList, TitleDeedDetails deedDetails) {
		WellDetailsList wellDetailsList = new WellDetailsList();

    BigDecimal setTotalPrice= BigDecimal.ZERO;
    BFCurrencyAmount totalPrice = new BFCurrencyAmount();
		for (WellDetails eachWellDtl : hiddenWellDetailsList.getWellDetailsList()) {
			WellDetails eachWellDtlUI = new WellDetails();
			if (deedDetails.getEvaluationId().equals(eachWellDtl.getEvaluationId())
					&& deedDetails.getTitleDeedIDPK().equals(eachWellDtl.getTitleDeedIDPK())) {
				eachWellDtlUI = eachWellDtl;
				setTotalPrice = setTotalPrice.add(eachWellDtl.getPrice().getCurrencyAmount());
				totalPrice.setCurrencyCode(eachWellDtl.getPrice().getCurrencyCode());
				wellDetailsList.addWellDetailsList(eachWellDtlUI);
			}
		}

		totalPrice.setCurrencyAmount(setTotalPrice);
		wellDetailsList.setTotalPrice(totalPrice );
		
		return wellDetailsList;
	}

	public BuildingsDetailsList populateBuildingDtlsList(BuildingsDetailsList hiddenBuildingDetailsList,
			TitleDeedDetails deedDetails) {
		BuildingsDetailsList buildingDetailsList = new BuildingsDetailsList();

		BigDecimal setTotalPrice= BigDecimal.ZERO;
    BFCurrencyAmount totalPrice = new BFCurrencyAmount();
		for (BuildingDetails eachBuildingDtl : hiddenBuildingDetailsList.getBuildingsDetailsList()) {
			BuildingDetails eachBuildingDetailUI = new BuildingDetails();
			if (deedDetails.getEvaluationId().equals(eachBuildingDtl.getEvaluationId())
					&& deedDetails.getTitleDeedIDPK().equals(eachBuildingDtl.getTitleDeedIDPK())) {
				eachBuildingDetailUI = eachBuildingDtl;
				setTotalPrice = setTotalPrice.add(eachBuildingDtl.getCost().getCurrencyAmount());
        totalPrice.setCurrencyCode(eachBuildingDtl.getCost().getCurrencyCode());
				buildingDetailsList.addBuildingsDetailsList(eachBuildingDetailUI);
			}
		}
		totalPrice.setCurrencyAmount(setTotalPrice);
		buildingDetailsList.setTotalPrice(totalPrice );
		return buildingDetailsList;
	}

	public TreesDetailsList populateTreeDtlsList(TreesDetailsList hiddenTreesDtlsList, TitleDeedDetails deedDetails) {
		TreesDetailsList treeDetailsGrid = new TreesDetailsList();

		BigDecimal setTotalPrice= BigDecimal.ZERO;
    BFCurrencyAmount totalPrice = new BFCurrencyAmount();
		for (TreeDetails eachTreeDtl : hiddenTreesDtlsList.getTreesDetailsList()) {
			TreeDetails eachTreeDetailsUI = new TreeDetails();
			if (deedDetails.getEvaluationId().equals(eachTreeDtl.getEvaluationId())
					&& deedDetails.getTitleDeedIDPK().equals(eachTreeDtl.getTitleDeedIDPK())) {
				eachTreeDetailsUI = eachTreeDtl;
				setTotalPrice = setTotalPrice.add(eachTreeDtl.getCost().getCurrencyAmount());
        totalPrice.setCurrencyCode(eachTreeDtl.getCost().getCurrencyCode());
				treeDetailsGrid.addTreesDetailsList(eachTreeDetailsUI);
			}
		}
    totalPrice.setCurrencyAmount(setTotalPrice);
    treeDetailsGrid.setTotalPrice(totalPrice );
		return treeDetailsGrid;
	}
	

}
