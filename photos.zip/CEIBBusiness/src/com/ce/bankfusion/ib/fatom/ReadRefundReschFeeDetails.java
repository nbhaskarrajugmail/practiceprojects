package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadRefundReschFeeDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_ReadRefundReschFeeDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleHistoryDetails;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class ReadRefundReschFeeDetails extends AbstractCE_IB_ReadRefundReschFeeDetails implements ICE_IB_ReadRefundReschFeeDetails {
    
    private static final Log LOGGER = LogFactory.getLog(ReadRefundReschFeeDetails.class);
    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public ReadRefundReschFeeDetails() {
        // TODO Auto-generated constructor stub
    }

    public ReadRefundReschFeeDetails(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method Deal ID -->" + getF_IN_ibObject().getDealID());
        IBOCE_IB_REFUNDRESCHDTLS RefundReschProfitActiveReq = RescheduleUtils.getRefundReschProfitActiveReq(getF_IN_ibObject().getDealID());
        if (null != RefundReschProfitActiveReq && !RefundReschProfitActiveReq.getBoID().equals(getF_IN_ibObject().getTransactionID())) {
            IBCommonUtils
                    .raiseUnparameterizedEvent(CeConstants.E_REFUND_RESCH_REQ_EXISTS_CEIB);
        }
        IBOCE_IB_DealReschedule completedRescheduleRequest = RescheduleUtils.getReschReqExistingObjStatusNotCompleted(getF_IN_ibObject().getDealID());
        if (null != completedRescheduleRequest && !completedRescheduleRequest.getBoID().equals(getF_IN_ibObject().getTransactionID())) {
            IBCommonUtils
                    .raiseUnparameterizedEvent(CeConstants.E_CLEAR_RESCHEDULE_TO_PROCEED);
        }
        GetDealRescheduleDetails getRescheduleDetails = new GetDealRescheduleDetails();
        getRescheduleDetails.setF_IN_islamicBankingObject(getF_IN_ibObject());
        getRescheduleDetails.process(env);
        getF_OUT_reschRefundFeeDetails()
                .setCurrentSchedule(getRescheduleDetails.getF_OUT_dealRescheduleDetails().getCurrentSchedule());
        getF_OUT_reschRefundFeeDetails().removeAllNewSchedule();
        List<Date> paidScheduleDates = new ArrayList<Date>();
        boolean isSchedulestartdateSet = false;
        for (CePaymentSchedule paymentSchedule : getRescheduleDetails.getF_OUT_dealRescheduleDetails().getCurrentSchedule()) {
			if ((paymentSchedule.getStatus()
					.equalsIgnoreCase(IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE,
							CeConstants.PAYMENT_STATUS_FULLY_PAID))
					|| paymentSchedule.getStatus()
							.equalsIgnoreCase(IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE,
									CeConstants.PAYMENT_STATUS_PARTIAL_PAID)))
					&& getRescheduleDetails.getF_OUT_dealRescheduleDetails().getNewScheduleCount() > 0) {
				CePaymentSchedule paidPaymentSchedule = new CePaymentSchedule();
				paidPaymentSchedule.setFeesAmount(paymentSchedule.getFeesAmount());
				paidPaymentSchedule.setPrincipalAmount(paymentSchedule.getPrincipalAmount());
				paidPaymentSchedule.setProfitAmount(paymentSchedule.getProfitAmount());
				paidPaymentSchedule.setRepaymentDate(paymentSchedule.getRepaymentDate());
				paidPaymentSchedule.setRepaymentNo(paymentSchedule.getRepaymentNo());
				paidPaymentSchedule.setSelect(false);
				paidPaymentSchedule.setSubsidyAmount(paymentSchedule.getSubsidyAmount());
				paidPaymentSchedule.setTotalRepaymentAmount(paymentSchedule.getTotalRepaymentAmount());
				paidPaymentSchedule.setStatus(paymentSchedule.getStatus());
				getF_OUT_reschRefundFeeDetails().addNewSchedule(paidPaymentSchedule);
				paidScheduleDates.add(paymentSchedule.getRepaymentDate());
			}
			if (!paymentSchedule.getStatus()
					.equalsIgnoreCase(IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE,
							CeConstants.PAYMENT_STATUS_FULLY_PAID))
					&& getRescheduleDetails.getF_OUT_dealRescheduleDetails().getNewScheduleCount() == 0
					&& !isSchedulestartdateSet) {
				getRescheduleDetails.getF_OUT_dealRescheduleDetails().getRescheduleRequestDetails()
						.setReschedulePaymentDate(paymentSchedule.getRepaymentDate());
				isSchedulestartdateSet = true;
			}
        }
            
        for(CePaymentSchedule paymentSchedule : getRescheduleDetails.getF_OUT_dealRescheduleDetails().getNewSchedule())
        {
        	if(!paidScheduleDates.contains(paymentSchedule.getRepaymentDate()))
			{
				paymentSchedule.setRepaymentNo(getF_OUT_reschRefundFeeDetails().getNewScheduleCount() + 1);
				getF_OUT_reschRefundFeeDetails().addNewSchedule(paymentSchedule);
			}
        }
        getF_OUT_reschRefundFeeDetails().getAssetProfileDetails().removeAllAssetBasedPaymentSchedule();
        getF_OUT_reschRefundFeeDetails()
                .setAssetProfileDetails(getRescheduleDetails.getF_OUT_dealRescheduleDetails().getAssetProfileDetails());
        getF_OUT_reschRefundFeeDetails()
                .setRescheduleRequestDetails(getRescheduleDetails.getF_OUT_dealRescheduleDetails().getRescheduleRequestDetails());
        GetDealRescheduleHistory getDealRescheduleHistory = new GetDealRescheduleHistory();
        getDealRescheduleHistory.setF_IN_dealId(getF_IN_ibObject().getDealID());
        getDealRescheduleHistory.process(env);
        for(CeRescheduleHistoryDetails rescheduleHistoryDetails :getDealRescheduleHistory.getF_OUT_rescheduleHistory().getRescheduleHistoryDetails())
        {
        	if(IBCommonUtils.isEmpty(rescheduleHistoryDetails.getRequestId()))
        		getDealRescheduleHistory.getF_OUT_rescheduleHistory().removeRescheduleHistoryDetails(rescheduleHistoryDetails);
        	else
        		rescheduleHistoryDetails.setSelect(false);
        }
        getF_OUT_reschRefundFeeDetails()
                .setRescheduleHistoryDetails(getDealRescheduleHistory.getF_OUT_rescheduleHistory().getRescheduleHistoryDetails());
        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_ibObject().getDealID());
        setRefundDetails(dealDetails);
        getPaymentScheduleFromBreakup(dealDetails);
        getF_OUT_reschRefundFeeDetails().setDealPartyId(IBCommonUtils.getDealPrimaryPartyDetails(getF_IN_ibObject().getDealID()).getF_CUSTOMERID());
        if(getF_OUT_reschRefundFeeDetails().getNewScheduleCount()>0)
            setF_OUT_newScheduleVisibility(true);
        LOGGER.info("Exiting from process method Deal ID -->" + getF_IN_ibObject().getDealID());
    }

    private void getPaymentScheduleFromBreakup(IBOIB_DLI_DealDetails dealDetails) {
        getF_OUT_reschRefundFeeDtls_BKP().getAssetProfileDetails().removeAllAssetBasedPaymentSchedule();
        String schHisQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ORDER BY "
                + IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " ASC ";
        ArrayList<Object> params = new ArrayList<>();
        params.add(getF_IN_ibObject().getDealID());

        List<IBOCE_IB_PaymentSchBreakup> paymentSchedules = BankFusionThreadLocal.getPersistanceFactory()
                .findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, schHisQuery, params, null, false);
        BigDecimal totalRepaymentAmount = BigDecimal.ZERO;
        if (paymentSchedules != null && !paymentSchedules.isEmpty()) {
            for (IBOCE_IB_PaymentSchBreakup paymentScheduleHistory : paymentSchedules) {
                AssetBasedPaymentSchedule assetBasedPaymentSchedule = new AssetBasedPaymentSchedule();
                assetBasedPaymentSchedule.setSelect(false);
                assetBasedPaymentSchedule.setAssetId(paymentScheduleHistory.getF_IBASSETID());
                assetBasedPaymentSchedule.setPrincipalAmount(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBPRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setPrincipalAmountPaid(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBPRINCIPALAMTPAID(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setProfitAmount(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setProfitAmountPaid(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBPROFITAMTPAID(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setRepaymentDate(paymentScheduleHistory.getF_IBBILLDATE());
                assetBasedPaymentSchedule.setScheduleFeesAmount(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBSCHEDULEFEEAMT(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setScheduleFeesAmountPaid(IBCommonUtils.getBFCurrencyAmount(
                        paymentScheduleHistory.getF_IBSCHEDULEFEESAMTPAID(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setSubsidyAmount(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBSUBSIDYAMNT(), dealDetails.getF_IsoCurrencyCode()));
                assetBasedPaymentSchedule.setSubsidyAmountPaid(IBCommonUtils
                        .getBFCurrencyAmount(paymentScheduleHistory.getF_IBSUBSIDYAMTPAID(), dealDetails.getF_IsoCurrencyCode()));
                totalRepaymentAmount = paymentScheduleHistory.getF_IBPRINCIPALAMT().add(paymentScheduleHistory.getF_IBPROFITAMT())
                        .add(paymentScheduleHistory.getF_IBSCHEDULEFEEAMT()).add(paymentScheduleHistory.getF_IBSUBSIDYAMNT());
                assetBasedPaymentSchedule.setTotalRepaymentAmount(
                        IBCommonUtils.getBFCurrencyAmount(totalRepaymentAmount, dealDetails.getF_IsoCurrencyCode()));
                if (getF_OUT_reschRefundFeeDetails().getAssetProfileDetails().getAssetBasedPaymentScheduleCount() == 0) {
                    getF_OUT_reschRefundFeeDetails().getAssetProfileDetails()
                            .addAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
                }
                getF_OUT_reschRefundFeeDtls_BKP().getAssetProfileDetails().addAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
				if (!CalendarUtil.IsDate1GreaterThanDate2(
						getF_OUT_reschRefundFeeDetails().getRescheduleRequestDetails().getReschedulePaymentDate(),
						paymentScheduleHistory.getF_IBBILLDATE())) {
					if(null != paymentScheduleHistory.getF_IBPROFITAMTPAID())
							getF_OUT_reschRefundFeeDetails().getRescheduleRequestDetails().getOutstandinProfit()
							.setCurrencyAmount(
									getF_OUT_reschRefundFeeDetails().getRescheduleRequestDetails().getOutstandinProfit()
											.getCurrencyAmount().add(paymentScheduleHistory.getF_IBPROFITAMTPAID()));
					if(null != paymentScheduleHistory.getF_IBSCHEDULEFEESAMTPAID())
					getF_OUT_reschRefundFeeDetails().getRescheduleRequestDetails().getOutstandingFees()
							.setCurrencyAmount(getF_OUT_reschRefundFeeDetails().getRescheduleRequestDetails()
									.getOutstandingFees().getCurrencyAmount()
									.add(paymentScheduleHistory.getF_IBSCHEDULEFEESAMTPAID()));
				}
            }
        }
    }

    private void setRefundDetails(IBOIB_DLI_DealDetails dealDetails) {
        LOGGER.info("Entering into setRefundDetails method Deal ID -->" + getF_IN_ibObject().getDealID());
        IBOCE_IB_REFUNDRESCHDTLS refundReschDtls = (IBOCE_IB_REFUNDRESCHDTLS) factory
                .findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, getF_IN_ibObject().getTransactionID(), true);
        if (null != refundReschDtls) {
            getF_OUT_reschRefundFeeDetails().setPaymentMode(refundReschDtls.getF_IBPAYMENTMODE());
			getF_OUT_reschRefundFeeDetails()
					.setOtherBankAccount((CeConstants.NOACCOUNT.equals(refundReschDtls.getF_IBCUSTOMERACCOUNT())
							|| CeConstants.PAYMENT_MODE_TOSURPLUS.equals(refundReschDtls.getF_IBPAYMENTMODE()))
									? IBConstants.EMPTY_STRING
									: refundReschDtls.getF_IBCUSTOMERACCOUNT());
			 getF_OUT_reschRefundFeeDetails().setRefundableFeeAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
            getF_OUT_reschRefundFeeDetails().getRefundableFeeAmount().setCurrencyAmount(refundReschDtls.getF_IBPIADSCHEDULEFEEAMT());
        }
        /*String refundQuery = " WHERE " + IBOCE_IB_REFUNDRESCHFEE.IBDEALID + "=? ";
        ArrayList<Object> params = new ArrayList<>();
        params.add(getF_IN_ibObject().getDealID());
        List<IBOCE_IB_REFUNDRESCHFEE> dealReschRefundDtls = factory.findByQuery(IBOCE_IB_REFUNDRESCHFEE.BONAME, refundQuery, params,
                null, false);
        if (null != dealReschRefundDtls && !dealReschRefundDtls.isEmpty()) {
			String scheduledDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
					CeConstants.REFUND_STATUS_SCHEDULED);
			String rescheduleDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
					CeConstants.REFUND_STATUS_REFUNDED);
			for (IBOCE_IB_REFUNDRESCHFEE dealReschRefundDtl : dealReschRefundDtls) {
				for (CeRescheduleHistoryDetails rescheduleHistoryDtls : getF_OUT_reschRefundFeeDetails()
						.getRescheduleHistoryDetails()) {
					if (dealReschRefundDtl.getBoID().equals(rescheduleHistoryDtls.getRequestId())) {
						if (dealReschRefundDtl.getF_IBSYSTEMSTATUS().equals(CeConstants.REFUND_STATUS_SCHEDULED))
							rescheduleHistoryDtls.setRescheduleProfitStatus(scheduledDesc);
						else if (dealReschRefundDtl.getF_IBSYSTEMSTATUS().equals(CeConstants.REFUND_STATUS_REFUNDED))
							rescheduleHistoryDtls.setRescheduleProfitStatus(rescheduleDesc);
						break;
					}
				}
			}
        }*/
        LOGGER.info("Exiting from setRefundDetails method Deal ID -->" + getF_IN_ibObject().getDealID());
    }
}
