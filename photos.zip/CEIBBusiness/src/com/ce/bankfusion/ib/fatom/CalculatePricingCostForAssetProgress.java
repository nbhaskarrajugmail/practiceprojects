/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineConfigID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineConfig;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculatePricingCostForAssetProgress;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.expression.builder.functions.AddMonthsToDate;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.IslamicBankingObject;

/**
 * @author Aklesh
 *
 */
public class CalculatePricingCostForAssetProgress extends AbstractCE_IB_CalculatePricingCostForAssetProgress {

	private static final long serialVersionUID = 7137308733675905581L;
	private boolean oneDone;
	private boolean twoDone;
	private boolean threeDone;
	private boolean fourDone;
	private boolean fiveDone;
	
	private static Integer E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE = 44000352;

	public CalculatePricingCostForAssetProgress(BankFusionEnvironment env) {
		super(env);

	}

	public CalculatePricingCostForAssetProgress() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		Integer GROUPCD = getF_IN_GROUPCD();
		Integer TOOLNO = getF_IN_TOOLNO();
		Integer ListSer = getF_IN_LISTSER();
		String assetID = getF_IN_assetID();
		BigDecimal attribute7 = getF_IN_attribute7();
		BigDecimal attribute8 = getF_IN_attribute8();
		BigDecimal attribute9 = getF_IN_attribute9();
		IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();

		AssetThirdPartyDetails assetThirdPartyDetails = new AssetThirdPartyDetails();
		AsstCategory assetCategory = getF_IN_assetCategory();
		assetThirdPartyDetails.setAssetCategory(assetCategory);
		assetThirdPartyDetails.setGroupCD(GROUPCD);
		assetThirdPartyDetails.setToolNO(TOOLNO);

		CE_IB_PricingEngineConfigID pricingEngineConfigID = new CE_IB_PricingEngineConfigID();
		pricingEngineConfigID.setF_GRP_CD(GROUPCD);
		pricingEngineConfigID.setF_TOOLNO(TOOLNO);
		IBOIB_AST_AssetCategory assetCategorydtl= (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, assetThirdPartyDetails.getAssetCategory().getCategory(), true);
		ListSer = assetCategorydtl.getF_CATEGORYNAME()!=null?Integer.parseInt(assetCategorydtl.getF_CATEGORYNAME()):0;
		pricingEngineConfigID.setF_LISTSER(ListSer);
		IBOCE_IB_PricingEngineConfig pricingEngineConfig = (IBOCE_IB_PricingEngineConfig) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_PricingEngineConfig.BONAME, pricingEngineConfigID, true);
		if (pricingEngineConfig != null) {
			Integer res2 = pricingEngineConfig.getF_RES2_CD();
			Integer res3 = pricingEngineConfig.getF_RES3_CD();
			Integer res4 = pricingEngineConfig.getF_RES4_CD();

			Integer attr1 = pricingEngineConfig.getF_LBL1_CD();
			Integer attr2 = pricingEngineConfig.getF_LBL2_CD();
			Integer attr3 = pricingEngineConfig.getF_LBL3_CD();
			Integer attr4 = pricingEngineConfig.getF_LBL4_CD();
			Integer attr5 = pricingEngineConfig.getF_LBL5_CD();
			if (res2!=null && res2.equals(attr1)) {
				assetThirdPartyDetails.setAttribute1(attribute7);
				oneDone = true;
			}
			if (res2!=null && res2.equals(attr2)) {
				assetThirdPartyDetails.setAttribute2(attribute7);
				twoDone = true;
			}
			if (res2!=null && res2.equals(attr3)) {
				assetThirdPartyDetails.setAttribute3(attribute7);
				threeDone = true;
			}
			if (res2!=null && res2.equals(attr4)) {
				assetThirdPartyDetails.setAttribute4(attribute7);
				fourDone = true;
			}
			if (res2!=null && res2.equals(attr5)) {
				assetThirdPartyDetails.setAttribute5(attribute7);
				fiveDone = true;
			}

			if (res3!=null && res3.equals(attr1)) {
				assetThirdPartyDetails.setAttribute1(attribute8);
				oneDone = true;
			}
			if (res3!=null && res3.equals(attr2)) {
				assetThirdPartyDetails.setAttribute2(attribute8);
				twoDone = true;
			}
			if (res3!=null && res3.equals(attr3)) {
				assetThirdPartyDetails.setAttribute3(attribute8);
				threeDone = true;
			}
			if (res3!=null && res3.equals(attr4)) {
				assetThirdPartyDetails.setAttribute4(attribute8);
				fourDone = true;
			}
			if (res3!=null && res3.equals(attr5)) {
				assetThirdPartyDetails.setAttribute5(attribute8);
				fiveDone = true;
			}

			if (res4!=null && res4.equals(attr1)) {
				assetThirdPartyDetails.setAttribute1(attribute9);
				oneDone = true;
			}
			if (res4!=null && res4.equals(attr2)) {
				assetThirdPartyDetails.setAttribute2(attribute9);
				twoDone = true;
			}
			if (res4!=null && res4.equals(attr3)) {
				assetThirdPartyDetails.setAttribute3(attribute9);
				threeDone = true;
			}
			if (res4!=null && res4.equals(attr4)) {
				assetThirdPartyDetails.setAttribute4(attribute9);
				fourDone = true;
			}
			if (res4!=null && res4.equals(attr5)) {
				assetThirdPartyDetails.setAttribute5(attribute9);
				fiveDone = true;
			}
		}
		AssetInfoAndStudyFatom assetAndStudyFatom = new AssetInfoAndStudyFatom(env);
		assetAndStudyFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetAndStudyFatom.setF_IN_mode("READ");
		assetAndStudyFatom.process(env);
		AssetThirdPartyDetails[] assetTPDetails = assetAndStudyFatom.getF_OUT_assetThirdPartyDetailsList()
				.getAssetThirdPartyDetails();
		
		for (AssetThirdPartyDetails assetThirdPartyDetail : assetTPDetails) {
			if (assetThirdPartyDetail.getAssetSerial().equals(assetID)) {
				AssetProgressUtil.getValidateStudyValues(getF_IN_assetProgressReportDetails(), assetID,attribute7,attribute8,attribute9,assetThirdPartyDetail.getAttribute7(),assetThirdPartyDetail.getAttribute8(),assetThirdPartyDetail.getAttribute9());
				if (!oneDone) {
					assetThirdPartyDetails.setAttribute1(assetThirdPartyDetail.getAttribute1()!=null?assetThirdPartyDetail.getAttribute1():new BigDecimal(0));
				}
				if (!twoDone) {
					assetThirdPartyDetails.setAttribute2(assetThirdPartyDetail.getAttribute2()!=null?assetThirdPartyDetail.getAttribute2():new BigDecimal(0));
				}
				if (!threeDone) {
					assetThirdPartyDetails.setAttribute3(assetThirdPartyDetail.getAttribute3()!=null?assetThirdPartyDetail.getAttribute3():new BigDecimal(0));
				}
				if (!fourDone) {
					assetThirdPartyDetails.setAttribute4(assetThirdPartyDetail.getAttribute4()!=null?assetThirdPartyDetail.getAttribute4():new BigDecimal(0));
				}
				if (!fiveDone) {
					assetThirdPartyDetails.setAttribute5(assetThirdPartyDetail.getAttribute5()!=null?assetThirdPartyDetail.getAttribute5():new BigDecimal(0));
				}
			}
		}

		CalculateRatesFromPricingEngine calculateRatesFromPricingEngine = new CalculateRatesFromPricingEngine(env);
		calculateRatesFromPricingEngine.setF_IN_islamicBankingObject(islamicBankingObject);
		calculateRatesFromPricingEngine.setF_IN_assetThirdPartyDetails(assetThirdPartyDetails);
		calculateRatesFromPricingEngine.setF_IN_studyAchFlag(2);
		calculateRatesFromPricingEngine.process(env);
		BigDecimal calculatedCost = calculateRatesFromPricingEngine.getF_OUT_assetThirdPartyDetails().getAttribute6();
		if(calculatedCost.compareTo(getF_IN_originalStudyCost())>0) {
			/*String[] parms = new String[2];
			parms[0] = calculatedCost.toString();
			parms[1] = getF_IN_originalFinalCost().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE, parms);*/
			calculatedCost = getF_IN_originalStudyCost();
		}
		//islamicBankingObject.getProfitAmount()--Invoice amount is passed in this object
		if(islamicBankingObject.getProfitAmount()!=null && ((islamicBankingObject.getProfitAmount().compareTo(BigDecimal.ZERO)>CommonConstants.INTEGER_ZERO)&&(islamicBankingObject.getProfitAmount().compareTo(calculatedCost)<CommonConstants.INTEGER_ZERO))) {
			calculatedCost = islamicBankingObject.getProfitAmount();
		}
		BigDecimal percentage = CalculateStudyGrantApproval.calculateParticipationPercentage(getF_IN_originalStudyCost(), getF_IN_originalFinalCost());
		setF_OUT_assetCost(calculatedCost);
		BigDecimal finalCalculatedCost = calculatedCost.multiply(percentage).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
		setF_OUT_finalCalculatedCost(finalCalculatedCost);
		BigDecimal progressPercent = getF_OUT_finalCalculatedCost().multiply(new BigDecimal(100)).divide(getF_IN_originalFinalCost(), 2, RoundingMode.HALF_UP);
		setF_OUT_progressPercent(progressPercent);
		Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(getF_IN_assetProgressReportDetails().getAssetProgressReportList(), getF_IN_assetID());;
		BigDecimal previousReportsCost = costMap.get("CALCULATEDCOST");
		BigDecimal previousReportsFinalCost = costMap.get("FINALCOST");
		BigDecimal previousReportsAllowedFinalCost = costMap.get("ALLOWEDFINALCOST");
		BigDecimal netCost = calculatedCost.subtract(previousReportsCost);
		BigDecimal netFinalCost = getF_OUT_finalCalculatedCost().subtract(previousReportsFinalCost);
		setF_OUT_netCost(netCost);
		setF_OUT_netFinalCost(netFinalCost);
		setF_OUT_previousCost(previousReportsCost);
		setF_OUT_previousFinalCost(previousReportsFinalCost);
		
		
		getF_OUT_actualFinalCost().setCurrencyAmount(netFinalCost);
		getF_OUT_allowedFinalCost().setCurrencyAmount(netFinalCost);
		getF_OUT_finalCostAfterDeduction().setCurrencyAmount(netFinalCost);
		getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
		setF_OUT_actualCostReadOnly(true);
		boolean isFirstReport = previousReportsCost.compareTo(BigDecimal.ZERO)==CommonConstants.INTEGER_ZERO?true:false;
		applyRules(isFirstReport,netCost,netFinalCost,previousReportsFinalCost,previousReportsAllowedFinalCost);
	}

	private void applyRules(boolean isFirstReport,BigDecimal calculatedCost,BigDecimal finalCalculatedCost,BigDecimal previousReportsFinalCost,BigDecimal previousReportsAllowedFinalCost) {
		
		/*Cattle contracts (How to identify-11201DEFAULTSAR): 
		 if its first report 50% of progress report amount can be disbursed, 
		 remaining amount can be disbursed in second disbursement after 3 months of first report of the rest of the amount*/
		List<String> cattleContractProductsList = new ArrayList<>();
		String cattleContractProducts = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.CATTLE_CONTRACT_PRODUCTS, "",CeConstants.ADFIBCONFIGLOCATION);

		if (cattleContractProducts != null && !cattleContractProducts.isEmpty()) {
			cattleContractProductsList = IBCommonUtils.isNotEmpty(cattleContractProducts)? Arrays.asList(cattleContractProducts.split(",")): new ArrayList<String>();
		}
		if(cattleContractProductsList.contains(getF_IN_islamicBankingObject().getSubProductID())) {
			if(isFirstReport) {
				BigDecimal finalCost= finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				
			}else {
				for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
					if(assetProgressReport.getDisbursementNumber()==1) {
						int cattleContractTerm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
								CeConstants.CATTLE_CONTRACT_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
						Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), cattleContractTerm, "Yes");
						if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
							IBCommonUtils.raiseUnparameterizedEvent(44000431);
						}
					}
				}
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
			}
			setF_OUT_actualCostReadOnly(true);
			return;
		}
		 /*	a.)	For asset 905 if its first progress report we can disburse only 50% of what has been implemented.
		       If we want to disburse more than 50 % then exception 28 needs to be raised.
			b.)	For asset 905 if this is the second disbursement, we can disburse all the remaining amount of what has been implemented
			    provided that the second disbursement is after 3 months.
			c.)	Any other assets under this contract will be disbursed on implementation %.
		 */
		List<String> ordinaryAlBanTreesList = new ArrayList<>();
		String ordinaryAlBanTrees = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.AL_BAN_TRESS_TOOLS, "",CeConstants.ADFIBCONFIGLOCATION);

		if (ordinaryAlBanTrees != null && !ordinaryAlBanTrees.isEmpty()) {
			ordinaryAlBanTreesList = IBCommonUtils.isNotEmpty(ordinaryAlBanTrees)? Arrays.asList(ordinaryAlBanTrees.split(",")): new ArrayList<String>();
		}
		if(ordinaryAlBanTreesList.contains(getF_IN_TOOLNO().toString())) {

			if(isFirstReport) {
				BigDecimal finalCost= finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				
			}else {
				for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
					if(assetProgressReport.getDisbursementNumber()==1) {
						int alBanTreesTerm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
								CeConstants.AL_BAN_TRESS_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
						Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), alBanTreesTerm, "Yes");
						if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
							IBCommonUtils.raiseUnparameterizedEvent(44000431);
						}
					}
				}
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
			}
			setF_OUT_actualCostReadOnly(false);
			return;
		}
		/*Normal protected house Contracts: for tools 88,253,320,272,90,823 in Normal Loans only 
			a.)	For first progress report of that asset mentioned above value of 50% of progress report amount can be disbursed 
			 	if its more than 50% then exception No 3 needs to be raised.
			b.)	If there is previous disbursement, then rest of the progress report amount can be 
				 disbursed from the previous report only if the period is more than 6 months. And its less than 6 months then 
				 exception 2 needs to be raised.
			c.)	Any other tools then 88,253,320,272,90,823 this under Normal protected house can be disbursed based on the implementation.
		 */
		List<String> normalProtectedHouseList = new ArrayList<>();
		String normalProtectedHouse = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_PROTECTED_HOUSE, "",CeConstants.ADFIBCONFIGLOCATION);

		if (normalProtectedHouse != null && !normalProtectedHouse.isEmpty()) {
			normalProtectedHouseList = IBCommonUtils.isNotEmpty(normalProtectedHouse)? Arrays.asList(normalProtectedHouse.split(",")): new ArrayList<String>();
		}
		if(normalProtectedHouseList.contains(getF_IN_TOOLNO().toString())) {

			if(isFirstReport) {
				BigDecimal finalCost= finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				
			}else {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				
				BigDecimal finalCost= finalCalculatedCost;
				for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
					if(assetProgressReport.getDisbursementNumber()==1) {
						int normalHouseterm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
								CeConstants.NORMAL_PROTECTED_HOUSE_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
						Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), normalHouseterm, "Yes");
						if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
							finalCost= finalCalculatedCost.add(BigDecimal.ZERO);
						}else {
							finalCost= finalCalculatedCost.add(previousPendingAmount);
						}
					}
				}
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
			}
			setF_OUT_actualCostReadOnly(false);
			return;
		}
		
		/*
		 * 8. Normal Loans that can be divided (currently mobile bees only- Currently
		  11102DEFAULTSAR should be in property file): 
		  a.) if its first progress report we can disburse only 50% of what has been implemented. 
		  b.) If there is disbursement before 3 months, then whatever has been implemented and
		  remaining disbursement from previous report can be disbursed.
		 */
		List<String> mobileBeesProductsList = new ArrayList<>();
		String mobileBeesProducts = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.MOBILE_BEES_PRODUCTS, "",CeConstants.ADFIBCONFIGLOCATION);

		if (mobileBeesProducts != null && !mobileBeesProducts.isEmpty()) {
			mobileBeesProductsList = IBCommonUtils.isNotEmpty(mobileBeesProducts)? Arrays.asList(mobileBeesProducts.split(",")): new ArrayList<String>();
		}
		if(mobileBeesProductsList.contains(getF_IN_islamicBankingObject().getSubProductID())) {
			if(isFirstReport) {
				BigDecimal finalCost= finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				
			}else {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				
				BigDecimal finalCost= finalCalculatedCost;
				for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
					if(assetProgressReport.getDisbursementNumber()==1) {
						int mobileBeesTerm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
								CeConstants.MOBILE_BEES_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
						Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), mobileBeesTerm, "Yes");
						if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
							finalCost= finalCalculatedCost.add(BigDecimal.ZERO);
						}else {
							finalCost= finalCalculatedCost.add(previousPendingAmount);
						}
					}
				}
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
			}
			setF_OUT_actualCostReadOnly(true);
			return;
		}
		
		/*
		 3. Normal fishing contracts containing a boat (tool 186): For Normal loans Only
		  a.) if the boat is fully implemented and no disbursement is done against
		  the boat then we can disburse 50% of all assets under the deal, if I need to
		  disburse more than 50% of all the assets under the deal then exception 18
		  needs to be raised. 
		  b.) In case the boat is fully implemented and any
		  previous disbursement have been done against the boat then we can disburse
		  all the remaining amount for all the other assets under the deal provided
		  that time between last disbursement is more than 3 months, if its less than 3
		  months then exception 15 needs to be raised. 
		  c.) If the boat is not fully
		  implemented, we can not disburse any amount for any assets under the deal
		  regardless of what has been implemented for those assets.
		 */
		String boatToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.BOAT_TOOL_ID, "",CeConstants.ADFIBCONFIGLOCATION);
		boolean normalFishingContract = false;
		BigDecimal boatProgress = BigDecimal.ZERO;
		BigDecimal boatDisbursedAmount = BigDecimal.ZERO;
		for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
			if (assetProgressDetails.getToolNO().toString().equals(boatToolID)) {
				normalFishingContract = true;
				boatProgress = assetProgressDetails.getInvoiceCompletionPercentage();
				boatDisbursedAmount = assetProgressDetails.getPrevouslyDisbursedAmount().getCurrencyAmount();
			}
		}
		if (normalFishingContract) {
			if(getF_IN_TOOLNO()==Integer.parseInt(boatToolID)) {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
				
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
				setF_OUT_actualCostReadOnly(false);
				return;
			}
			if (boatProgress.compareTo(new BigDecimal(100)) == CommonConstants.INTEGER_ZERO) {
				if (boatDisbursedAmount.compareTo(BigDecimal.ZERO) == CommonConstants.INTEGER_ZERO) {
					BigDecimal finalCost= finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
					setF_OUT_actualCostReadOnly(false);
					return;
				}else {
					BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
					BigDecimal finalCost= finalCalculatedCost;
					for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
						if(assetProgressReport.getDisbursementNumber()==1) {
							int mobileBeesTerm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
									CeConstants.BOAT_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
							Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), mobileBeesTerm, "Yes");
							if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
								finalCost= finalCalculatedCost.add(BigDecimal.ZERO);
							}else {
								finalCost= finalCalculatedCost.add(previousPendingAmount);
							}
						}
					}
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
					setF_OUT_actualCostReadOnly(false);
					return;
				}
			}else {
				BigDecimal finalCost= BigDecimal.ZERO;
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(finalCost);
				setF_OUT_actualCostReadOnly(true);
				return;
			}
		}
		
		/*5.	Normal Loans contracts containing well and fold (6 and 51): 
			a.)	if its first report and no disbursement before than implementation % will be calculated which equals the cost of what has been implemented 
				if well cost in study is 10,000 and the cost of what has been implemented is 3000 then the % of implementation will be 
					3000/10000% which will equal 30%.
				If That implementation % id equal or more than 50 % then 50% of what has been implemented will be disbursed (1500).
			b.)	if the user checks the flag whatever has been implemented is enough then in that case we can disburse 
			 	whatever has been implemented and no further disbursement will be allowed even if the user increases the completion %
			c.)	If completion % is less than 50% then whatever has been implemented in the well will be disbursed and no further 
				disbursement will be done for this assets exception no 14 needs to be raised.
			d.)	For 6 and 51 if there is a previous disbursement then we can disburse remaining amount that has been implemented.
			e.)	Any other assets under this contract other than 6 and 51 we can disburse what has been implemented.
			f.)	We cannot disburse 51 without fully disbursing 6 if we need to disburse overriding this condition then exception 12 needs to be raised.
		 */
		String wellToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.WELL_TOOL_ID, "",CeConstants.ADFIBCONFIGLOCATION);
		String foldToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.FOLD_TOOL_ID, "",CeConstants.ADFIBCONFIGLOCATION);
		boolean normalWellFoldContract = false;
		BigDecimal wellProgressPercent = BigDecimal.ZERO;
		for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
			if (assetProgressDetails.getToolNO().toString().equals(wellToolID)) {
				normalWellFoldContract = true;
				wellProgressPercent = assetProgressDetails.getInvoiceCompletionPercentage();
				if(getF_IN_TOOLNO().toString().equals(wellToolID))
					wellProgressPercent = getF_OUT_progressPercent();
			}
		}
		if(normalWellFoldContract && (getF_IN_TOOLNO().toString().equals(foldToolID)||getF_IN_TOOLNO().toString().equals(wellToolID))) {
			setF_OUT_actualCostReadOnly(true);
			if (isFirstReport) {
				//TODO -need to get isInvoicerequired from UI
				boolean isEnough = isF_IN_isEnough();
				BigDecimal progressPercent = getF_OUT_progressPercent();
				if(isEnough) {
					BigDecimal finalCost = finalCalculatedCost;
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				}
				else if (progressPercent.compareTo(new BigDecimal(50)) >= CommonConstants.INTEGER_ZERO) {
					BigDecimal finalCost = finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100),
							2, RoundingMode.HALF_UP);
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				}else {
					//Exception 14 needs to be raised for this
					BigDecimal finalCost = finalCalculatedCost;
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				}
				if(wellProgressPercent.compareTo(new BigDecimal(100))<0 && getF_IN_TOOLNO().toString().equals(foldToolID)) {
					if(isEnough) {
						BigDecimal finalCost = finalCalculatedCost;
						getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
						getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
						getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
						getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
					}
					else if (progressPercent.compareTo(new BigDecimal(50)) >= CommonConstants.INTEGER_ZERO) {
						BigDecimal finalCost = finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100),
								2, RoundingMode.HALF_UP);
						getF_OUT_actualFinalCost().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_allowedFinalCost().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_finalCostAfterDeduction().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
						setF_OUT_actualCostReadOnly(false);
						//Exception 12 needs to be raised for this
					}else {
						//Exception 14 needs to be raised for this
						BigDecimal finalCost = finalCalculatedCost;
						getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
						getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
						getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
						getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
					}
				}
			}else {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				
				BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
				setF_OUT_actualCostReadOnly(true);
			}
		}
		/*1.	Palm Contracts: if the deal contains toolno 98 its palm contract
			a.)	For Palm fluids (tool no 98) and palm irrigation network (37): (Need to check what is palm index):
			b.)	Case 1: if tool 98 and 37 with palm index activated and this is the first progress report for the fluids 
			if the number of the palm fluids implemented is less than 100 then the disbursement % will be 100 % for fluids 98 and the network 37.
			if the number of implemented fluids is more than 100 then disbursement percentage will be 50 % for 98 and 37.
			c.)	Case 2: if tool 98 and 37 with palm index activated (What is activation in system) and it�s
			 not the first progress report
			If an amount is disbursed before for 98 and 37 then we can disburse the remaining amount for 98 and 37 provided 
			that a year has been passed from the last disbursement, this can be overridden with exception No 1.
			d.)	Case 3: We can not disburse any amount on the fluids 98 unless implementation is completed on the network 37.
			e.)	Case 4: In case of fruits (Need to know tool no) and its network 37 with fruits indicator is active 
			then we can disburse whatever has been implemented in the fruits provided that the network 37 can not be disbursed 
			without implementing its fruits (788,120,121,789).
		 */
		String palmIrrigationNetwrk = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.PALM_IRRIG_NET_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		String palmFluits = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.PALM_FLUITS_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		boolean palmContract = false;
		BigDecimal palmFluitsImplemented = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal palmNetworkProgress = CommonConstants.BIGDECIMAL_ZERO;
		for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails()
				.getAssetProgressDetailsList()) {
			if (assetProgressDetails.getToolNO().toString().equals(palmFluits)
					|| assetProgressDetails.getToolNO().toString().equals(palmIrrigationNetwrk)) {
				palmContract = true;
				palmFluitsImplemented = getF_IN_attribute7();
				if (assetProgressDetails.getToolNO().toString().equals(palmIrrigationNetwrk)) {
					palmNetworkProgress = assetProgressDetails.getInvoiceCompletionPercentage();
					if(getF_IN_TOOLNO().toString().equals(palmIrrigationNetwrk))
						palmNetworkProgress = getF_OUT_progressPercent();
				}
			}
		}
		if (palmContract
				&& (getF_IN_TOOLNO().toString().equals(palmFluits) || getF_IN_TOOLNO().toString().equals(palmIrrigationNetwrk))) {
			setF_OUT_actualCostReadOnly(true);
			
			if (isFirstReport) {
				if (getF_IN_TOOLNO().toString().equals(palmIrrigationNetwrk)) {
					List<String> palmFruitsList = new ArrayList<>();
					String palmFruits = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
							CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.PALM_FRUITS_TOOL_ID, "",
							CeConstants.ADFIBCONFIGLOCATION);
					if (palmFruits != null && !palmFruits.isEmpty()) {
						palmFruitsList = IBCommonUtils.isNotEmpty(palmFruits) ? Arrays.asList(palmFruits.split(","))
								: new ArrayList<String>();
					}
					for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails()
							.getAssetProgressDetailsList()) {
						if (palmFruitsList.contains(assetProgressDetails.getToolNO().toString())) {
							if (assetProgressDetails.getInvoiceCompletionPercentage()
									.compareTo(new BigDecimal(100)) != CommonConstants.INTEGER_ZERO) {
								getF_OUT_actualFinalCost().setCurrencyAmount(BigDecimal.ZERO);
								getF_OUT_allowedFinalCost().setCurrencyAmount(BigDecimal.ZERO);
								getF_OUT_finalCostAfterDeduction().setCurrencyAmount(BigDecimal.ZERO);
								getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
								return;
							}
						}
					}
				}
				if (getF_IN_TOOLNO().toString().equals(palmFluits)) {
					if(palmNetworkProgress.compareTo(new BigDecimal(100))!=CommonConstants.INTEGER_ZERO) {
						getF_OUT_actualFinalCost().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_allowedFinalCost().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_finalCostAfterDeduction().setCurrencyAmount(BigDecimal.ZERO);
						getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
						return;
					}
				}
				if(palmFluitsImplemented.compareTo(new BigDecimal(100))<CommonConstants.INTEGER_ZERO) {
					BigDecimal finalCost = finalCalculatedCost;
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				}else {
					BigDecimal finalCost = finalCalculatedCost.multiply(new BigDecimal(50)).divide(new BigDecimal(100),
							2, RoundingMode.HALF_UP);
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				}
			}else {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				BigDecimal finalCost= finalCalculatedCost;
				for(AssetProgressReport assetProgressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
					if(assetProgressReport.getDisbursementNumber()==1) {
						int palmTerm = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
								CeConstants.PALM_TERM, "", CeConstants.ADFIBCONFIGLOCATION));
						Date newDisbursementDate= AddMonthsToDate.run(assetProgressReport.getProgressVisitDateG(), palmTerm, "Yes");
						if(SystemInformationManager.getInstance().getBFBusinessDate().compareTo(newDisbursementDate)<0) {
							finalCost= finalCalculatedCost.add(BigDecimal.ZERO);
							setF_OUT_actualCostReadOnly(false);
						}else {
							finalCost= finalCalculatedCost.add(previousPendingAmount);
						}
					}
				}
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
				
				return;
			}
		}
		
		/*1.	In case that a deal has a tractor (tool no 7) and you have any of the following tool id (10,11,12,15,628,17,21,26,203,478,629,9) 
			then you cannot progress any of them unless the tool 7 is fully progressed. If we are progressing any of them 
			and tool no 7 is not fully progressed, then exception no 16 must be raised.*/
		String tractorToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.TRACTOR_TOOL_ID, "",CeConstants.ADFIBCONFIGLOCATION);
		boolean tractorContract = false;
		BigDecimal tractorProgress = BigDecimal.ZERO;
		for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
			if (assetProgressDetails.getToolNO().toString().equals(tractorToolID)) {
				tractorContract = true;
				tractorProgress = assetProgressDetails.getInvoiceCompletionPercentage();
			}
		}
		if (tractorContract) {
			if(getF_IN_TOOLNO()==Integer.parseInt(tractorToolID)) {
				BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
				BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
				
				getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
				setF_OUT_actualCostReadOnly(true);
				return;
			}
			List<String> tractorAccessoriesList = new ArrayList<>();
			String tractorAccessories = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.TRACTOR_ASS_TOOL_ID, "",CeConstants.ADFIBCONFIGLOCATION);

			if (tractorAccessories != null && !tractorAccessories.isEmpty()) {
				tractorAccessoriesList = IBCommonUtils.isNotEmpty(tractorAccessories)? Arrays.asList(tractorAccessories.split(",")): new ArrayList<String>();
			}
			if(tractorAccessoriesList.contains(getF_IN_TOOLNO().toString())) {
				if (tractorProgress.compareTo(new BigDecimal(100)) == CommonConstants.INTEGER_ZERO) {
					BigDecimal previousPendingAmount = previousReportsFinalCost.subtract(previousReportsAllowedFinalCost);
					BigDecimal finalCost= finalCalculatedCost.add(previousPendingAmount);
					
					getF_OUT_actualFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_allowedFinalCost().setCurrencyAmount(finalCost);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(finalCost);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(previousPendingAmount);
					setF_OUT_actualCostReadOnly(true);
					return;
				}else {
					getF_OUT_actualFinalCost().setCurrencyAmount(BigDecimal.ZERO);
					getF_OUT_allowedFinalCost().setCurrencyAmount(BigDecimal.ZERO);
					getF_OUT_finalCostAfterDeduction().setCurrencyAmount(BigDecimal.ZERO);
					getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
					setF_OUT_actualCostReadOnly(false);
					return;
				}
			}
		}
		/*3.	For it has registered with a waste tank (182) then we cannot disburse more than 50% unless 
			we do full implementation of waste tank 182 and with exception 33 we can disburse more than 50%.
		*/
		String wasteTankToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.WASTE_TANK_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		if (getF_IN_TOOLNO().toString().equals(wasteTankToolID)) {
			BigDecimal progressPercent = getF_OUT_progressPercent();
			if (progressPercent.compareTo(new BigDecimal(50)) > CommonConstants.INTEGER_ZERO
					&& progressPercent.compareTo(new BigDecimal(100)) < CommonConstants.INTEGER_ZERO) {
				getF_OUT_actualFinalCost().setCurrencyAmount(BigDecimal.ZERO);
				getF_OUT_allowedFinalCost().setCurrencyAmount(BigDecimal.ZERO);
				getF_OUT_finalCostAfterDeduction().setCurrencyAmount(BigDecimal.ZERO);
				getF_OUT_prevouslyUnDisbursedAmount().setCurrencyAmount(BigDecimal.ZERO);
				setF_OUT_actualCostReadOnly(false);
				return;
			}
		}
	}

}
