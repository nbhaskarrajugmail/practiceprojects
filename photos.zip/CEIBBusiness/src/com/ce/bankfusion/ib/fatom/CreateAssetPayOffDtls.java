package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetPayoffMetadata;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CreateAssetPayOffDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.EarlyAssetPayoffCollDtls;
import bf.com.misys.ib.types.EarlyAssetPayoffCollection;

public class CreateAssetPayOffDtls extends AbstractCE_IB_CreateAssetPayOffDtls {
	private static final Log LOGGER = LogFactory.getLog(CreateAssetPayOffDtls.class);

	public CreateAssetPayOffDtls(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("Creating Asset Payoff details for DealId " + getF_IN_islamicBankingObject().getDealID());
		EarlyAssetPayoffCollDtls assetPayoffCollDtls = getF_IN_earlyAssetPayoffDtls().getEarlyAssetPayoffCollDtls();
		EarlyAssetPayoffUtils.validateAssetSelectCount(getF_IN_earlyAssetPayoffDtls(),
				getF_IN_islamicBankingObject().getDealID(), isF_IN_isAssetpayoffProcess(), getF_IN_BBMode());
		if (assetPayoffCollDtls.getPaymentMethod() != null
				&& assetPayoffCollDtls.getPaymentMethod().equals(IBConstants.PAYMENTMETHOD_CSH)) {
			assetPayoffCollDtls.setInternalAccountNum(IBCommonUtils.getPseudoCashAccount());
		}
		persistAssetPayoffDtls(assetPayoffCollDtls);
	}

	private void persistAssetPayoffDtls(EarlyAssetPayoffCollDtls assetPayoffCollDtls) {
		bulkDeleteEarlyAssetPayoff();

		if (getF_IN_earlyAssetPayoffDtls() != null
				&& getF_IN_earlyAssetPayoffDtls().getEarlyAssetPayoffCollection() != null) {
			StringBuffer assetIds = new StringBuffer();

			for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : getF_IN_earlyAssetPayoffDtls()
					.getEarlyAssetPayoffCollection()) {
				if (earlyAssetPayoffCollection.isSelect()) {
					assetIds.append(earlyAssetPayoffCollection.getAssetId());
					assetIds.append("|");
					persistAssetPayoffMetadata(earlyAssetPayoffCollection);
				}
			}
			assetIds = new StringBuffer(assetIds.substring(0, assetIds.lastIndexOf("|")));

			IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtls = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
					.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_EarlyAssetPayoffDtls.BONAME);
			assetPayoffDtls.setBoID(getF_IN_islamicBankingObject().getTransactionID());
			assetPayoffDtls.setF_IBACCOUNTNUMBER(assetPayoffCollDtls.getInternalAccountNum());
			assetPayoffDtls.setF_IBASSETIDS(assetIds.toString());
			assetPayoffDtls.setF_IBDEALID(getF_IN_islamicBankingObject().getDealID());
			assetPayoffDtls.setF_IBNARRATIVE(assetPayoffCollDtls.getNarrative());
			assetPayoffDtls.setF_IBPAYMENTMETHOD(assetPayoffCollDtls.getPaymentMethod());
			assetPayoffDtls.setF_IBRECCREATEDBY(IBCommonUtils.getUserId());
			assetPayoffDtls.setF_IBRECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
			assetPayoffDtls.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
			assetPayoffDtls.setF_IBREVSUBSIDYPAID(assetPayoffCollDtls.isReverseSubsidyPaid());
			assetPayoffDtls.setF_IBSTATUS(CeConstants.ASSET_PAYOFF_STATUS_NEW);
			assetPayoffDtls.setF_IBTOTALREMAMOUNT(assetPayoffCollDtls.getTotalRemainingAmount().getCurrencyAmount());
			assetPayoffDtls.setF_IBTOTALSUBSIDYAMOUNT(assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount());
			if (EarlyAssetPayoffUtils.isAssetPayOffProcess(getF_IN_islamicBankingObject().getSearchPageID()))
				assetPayoffDtls.setF_IBISRECALLACTION(false);
			else
				assetPayoffDtls.setF_IBISRECALLACTION(true);
			IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_EarlyAssetPayoffDtls.BONAME, assetPayoffDtls);

		}
	}

	private void persistAssetPayoffMetadata(EarlyAssetPayoffCollection earlyAssetPayoffCollection) {
		IBOCE_IB_AssetPayoffMetadata assetPayoffDtls = (IBOCE_IB_AssetPayoffMetadata) IBCommonUtils
				.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_AssetPayoffMetadata.BONAME);
		assetPayoffDtls.setBoID(IBCommonUtils.getNewGUID());
		assetPayoffDtls.setF_IBASSETCOST(earlyAssetPayoffCollection.getTotalAssetCost().getCurrencyAmount());
		assetPayoffDtls.setF_IBASSETPAYOFFID(getF_IN_islamicBankingObject().getTransactionID());
		assetPayoffDtls.setF_IBASSETPROFITAMNT(earlyAssetPayoffCollection.getTotalProfitAmount().getCurrencyAmount());
		assetPayoffDtls.setF_IBASSETID(earlyAssetPayoffCollection.getAssetId());
		assetPayoffDtls.setF_IBREMASSETCOSTCOLLECTED(
				earlyAssetPayoffCollection.getRemainingAssetCostToBeCollected().getCurrencyAmount());
		assetPayoffDtls.setF_IBREMFEESCOLLECTED(
				earlyAssetPayoffCollection.getRemainingFeesAmntToBeCollected().getCurrencyAmount());
		assetPayoffDtls.setF_IBREMPROFITCOLLECTED(
				earlyAssetPayoffCollection.getRemainingProfitAmntToBeCollected().getCurrencyAmount());
		assetPayoffDtls
				.setF_IBSCHEDULEFEESAMNT(earlyAssetPayoffCollection.getTotalScheduleFeesAmount().getCurrencyAmount());
		IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_AssetPayoffMetadata.BONAME, assetPayoffDtls);
	}

	private void bulkDeleteEarlyAssetPayoff() {
		String whereClauseForPayoffDtl = " WHERE " + IBOCE_IB_EarlyAssetPayoffDtls.IBEARLYASSETPAYOFFDTLSID + " = ? ";
		String whereClauseForPayoffMetadata = " WHERE " + IBOCE_IB_AssetPayoffMetadata.IBASSETPAYOFFID + " = ? ";

		ArrayList params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getTransactionID());

		IBCommonUtils.getPersistanceFactory().bulkDelete(IBOCE_IB_EarlyAssetPayoffDtls.BONAME, whereClauseForPayoffDtl,
				params);
		IBCommonUtils.getPersistanceFactory().bulkDelete(IBOCE_IB_AssetPayoffMetadata.BONAME,
				whereClauseForPayoffMetadata, params);

		IBCommonUtils.getPersistanceFactory().commitTransaction();
	}

}
