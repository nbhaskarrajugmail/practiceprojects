package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_EnableDisableScalars;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ce.ib.types.RequestEvaluationDtlsEditableTags;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;

public class EnableDisableScalars extends AbstractCE_IB_EnableDisableScalars {
	
	public EnableDisableScalars() {
		super();
	}

	public EnableDisableScalars(BankFusionEnvironment env) {
        super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		String categoryType = getF_IN_categoryType();
    	RequestEvaluationDtlsEditableTags reqEvalEditableTags = getF_IN_requestEvaluationEditableTags();
    	TitleDeedDetailsList titleDeedDtlsAgriculture = getF_IN_titleDeedDtlsAgriculture();
        WellDetailsList hiddenWellDetailsList = getF_IN_hidden_wellDetailsList();
        TreesDetailsList hiddenTreesDtlsList = getF_IN_hidden_treesDetailsList();
        BuildingsDetailsList hiddenBuildingDtlsList = getF_IN_hidden_buildingsDetailsList();
        
        int wellFlag=0, treeFlag=0, buildingFlag=0;
        boolean visibilty = reqEvalEditableTags.getTitleDeed();
        boolean readOnlyTags = reqEvalEditableTags.getViewOnly();
        
        //edit mode
    	if(visibilty && !readOnlyTags && titleDeedDtlsAgriculture !=null) {
    		for(TitleDeedDetails titleDeedDtls: titleDeedDtlsAgriculture.getTitleDeedDetailsList()) {
        		if(titleDeedDtls.getSelect()) {
    				if(hiddenWellDetailsList.getWellDetailsListCount()>0){
    					for(WellDetails wellDtls: hiddenWellDetailsList.getWellDetailsList()) {
    						if(wellDtls.getEvaluationId().equals(titleDeedDtls.getEvaluationId())) {
    							wellFlag=1;
    							setF_OUT_readOnlyWells(false);
    						}
    					}
    				}
    				if(hiddenTreesDtlsList.getTreesDetailsListCount()>0 ){
    					for(TreeDetails treeDtls: hiddenTreesDtlsList.getTreesDetailsList()) {
    						if(treeDtls.getEvaluationId().equals(titleDeedDtls.getEvaluationId())) {
    							treeFlag=1;
    							setF_OUT_readOnlyTrees(false);
    						}
    					}
    				}
    				if(hiddenBuildingDtlsList.getBuildingsDetailsListCount()>0 ){
    					for(BuildingDetails buildingDtls: hiddenBuildingDtlsList.getBuildingsDetailsList()) {
    						if(buildingDtls.getEvaluationId().equals(titleDeedDtls.getEvaluationId())) {
    							buildingFlag=1;
    							setF_OUT_readOnlyBuilding(false);
    						}
    					}
    				}
				}
        	}
    		if(hiddenWellDetailsList.getWellDetailsListCount()==0 || wellFlag==0) {
    			setF_OUT_readOnlyWells(true);
    		}
            if(hiddenTreesDtlsList.getTreesDetailsListCount()==0 || treeFlag==0) {
    			setF_OUT_readOnlyTrees(true);
    		}
    		if(hiddenBuildingDtlsList.getBuildingsDetailsListCount()==0 || buildingFlag==0) {
    			setF_OUT_readOnlyBuilding(true);
    		}
        }       
        //view mode
      if(visibilty && readOnlyTags && categoryType.equals("Agricultural")) {
				setF_OUT_readOnlyWells(true);
				setF_OUT_readOnlyTrees(true);
				setF_OUT_readOnlyBuilding(true);
		}
	}
}
					



