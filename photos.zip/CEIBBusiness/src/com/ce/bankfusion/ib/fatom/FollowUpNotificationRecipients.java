package com.ce.bankfusion.ib.fatom;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.tasks.ITask;
import com.trapedza.bankfusion.tasks.messaging.ITaskMessage;
import com.trapedza.bankfusion.tasks.messaging.ITaskMessageRecipient;
import com.trapedza.bankfusion.tasks.messaging.TaskMessageRecipient;
import com.trapedza.bankfusion.tasks.messaging.providers.IRecipientsProvider;

public class FollowUpNotificationRecipients implements IRecipientsProvider {

	private static final long serialVersionUID = 1L;

	private static final transient Log logger = LogFactory.getLog(FollowUpNotificationRecipients.class.getName());

	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void initialise(ITask task, ITaskMessage taskMessage) {
		Map<String, Serializable> taskDetails = new HashMap<String, Serializable>();
		taskDetails = task.getDetails();
		setUserId((String) taskDetails.get("UserName"));
	}

	@Override
	public ITaskMessageRecipient getRecipient(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<ITaskMessageRecipient> getRecipients(IPersistenceObjectsFactory arg0) {

		Collection<ITaskMessageRecipient> recipients = new ArrayList<ITaskMessageRecipient>();
		ITaskMessageRecipient taskMessageRecipient = null;
		taskMessageRecipient = new TaskMessageRecipient();
		taskMessageRecipient.setName(userId);
		recipients.add(taskMessageRecipient);
		return recipients;
	}

	@Override
	public int getRecipientsProviderId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean passesFilter(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		return false;
	}
}
