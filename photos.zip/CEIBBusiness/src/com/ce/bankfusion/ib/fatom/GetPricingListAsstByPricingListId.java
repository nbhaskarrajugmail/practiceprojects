package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetPricingListAsstByPricingListId;
import com.ce.ib.cfg.bo.PriceList;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class GetPricingListAsstByPricingListId extends AbstractCE_IB_GetPricingListAsstByPricingListId {

	private static final long serialVersionUID = -43751525110295463L;

	public GetPricingListAsstByPricingListId(BankFusionEnvironment env) {
		super(env);
	}

	public GetPricingListAsstByPricingListId() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		PriceList price = new PriceList();
		setF_OUT_pricingList(price.getPriceListAssetbyPriceListId(getF_IN_pricingListID()).getPricingList());
	}
}
