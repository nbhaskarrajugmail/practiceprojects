package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDFEES;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ExecuteRefundFees;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.RefundFeesDtls;

public class ExecuteRefundFees extends AbstractCE_IB_ExecuteRefundFees{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public ExecuteRefundFees()
	{
		super();
	}
	
	public ExecuteRefundFees(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealFeesClause = "WHERE "+ IBOIB_DLI_DealAssetChargesdtls.DealAssetChargesdtlsIdPk+"=?";
		String dealScheduledFeesClause = "WHERE "+ IBOCE_IB_REFUNDFEES.IBDEALID+"=?" +" AND "+ IBOCE_IB_REFUNDFEES.IBREFUNDSTATUS+"=?";
		
		ArrayList params = new ArrayList<>();
		params.add(ibObject.getDealID());
		params.add("SCHEDULED");
		List<IBOCE_IB_REFUNDFEES> dealRefundedFeesList = factory.findByQuery(IBOCE_IB_REFUNDFEES.BONAME, dealScheduledFeesClause, params, null, false);
		
		for(IBOCE_IB_REFUNDFEES refundFee : dealRefundedFeesList) {
			refundFee.setF_IBREFUNDAMT(refundFee.getF_IBPAIDAMT());
			refundFee.setF_IBREFUNDSTATUS("REFUNDED");
			
			IBOIB_DLI_DealAssetChargesdtls dealassetchargeDetail = (IBOIB_DLI_DealAssetChargesdtls) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, refundFee.getF_IBDEALASSETCHARGEDTLID(), true);
			
			IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, refundFee.getBoID(), true);
			if(null != payRecDetail)
				payRecDetail.setF_TRANSACTIONSTATUS("REFUNDED");
			
			dealassetchargeDetail.setF_UNPAIDCHARGEAMOUNT(dealassetchargeDetail.getF_UNPAIDCHARGEAMOUNT().add(refundFee.getF_IBPAIDAMT()));
			
			if(dealassetchargeDetail.getF_OriginalChgAmount().compareTo(dealassetchargeDetail.getF_UNPAIDCHARGEAMOUNT()) == 0) {
				dealassetchargeDetail.setF_CHARGEPAYMENTSTATUS("UNPAID");
			}else {
				dealassetchargeDetail.setF_CHARGEPAYMENTSTATUS("PARTIALLYPAID");
			}
			
		}
		
	}

}
