/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SurplusTransfer;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_TransferToBank;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_TransferToBankDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOPayDetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_MaintainTransferToBank;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.TransferToBank;

/**
 * @author Aklesh
 *
 */
public class MaintainTransferToBank extends AbstractCE_ADF_MaintainTransferToBank {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String where_clause = "WHERE " + IBOCE_ADF_TransferToBankDetails.TRANSACTIONID + "=?";
	private static final String PO_PAY_UPDATE_WHERE_CLAUSE = "WHERE " + IBOCE_IB_IssuePOPayDetail.IBISSUEPOPAYDETAILID
			+ " IN(" + "SELECT " + IBOCE_ADF_TransferToBankDetails.ISSUEPOPAYDTLSID + " FROM "
			+ IBOCE_ADF_TransferToBankDetails.BONAME + " WHERE " + IBOCE_ADF_TransferToBankDetails.TRANSACTIONID
			+ "=? AND "+IBOCE_ADF_TransferToBankDetails.EXCLUDE+ "=?)";
	private static final String PO_UPDATE_WHERE_CLAUSE = "WHERE " + IBOCE_IB_IssuePODetail.IBPURCHASEORDERID
			+ " IN(SELECT " + IBOCE_IB_IssuePOPayDetail.IBPURCHASEORDERID + " FROM " + IBOCE_IB_IssuePOPayDetail.BONAME
			+ " WHERE " + IBOCE_IB_IssuePOPayDetail.IBISSUEPOPAYDETAILID + " IN(" + "SELECT "
			+ IBOCE_ADF_TransferToBankDetails.ISSUEPOPAYDTLSID + " FROM " + IBOCE_ADF_TransferToBankDetails.BONAME
			+ " WHERE " + IBOCE_ADF_TransferToBankDetails.TRANSACTIONID + "=? AND "
			+ IBOCE_ADF_TransferToBankDetails.EXCLUDE + "=?))";
	private static final String SURPLUS_UPDATE_WHERE_CLAUSE = "WHERE " + IBOCE_ADF_SurplusTransfer.TRANSACTIONID
			+ " IN(" + "SELECT " + IBOCE_ADF_TransferToBankDetails.ISSUEPOPAYDTLSID + " FROM "
			+ IBOCE_ADF_TransferToBankDetails.BONAME + " WHERE " + IBOCE_ADF_TransferToBankDetails.TRANSACTIONID
			+ "=? AND "+IBOCE_ADF_TransferToBankDetails.EXCLUDE+ "=?)";

	public MaintainTransferToBank(BankFusionEnvironment env) {
		super(env);

	}

	public MaintainTransferToBank() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String editMode = getF_IN_editMode();
		String mode  = getF_IN_mode();
		
		String transactionID = getF_IN_transferToBankDetails().getTransferHeaderDetails().getTransactionID();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_ADF_TransferToBank transferToBank = (IBOCE_ADF_TransferToBank) factory.findByPrimaryKey(IBOCE_ADF_TransferToBank.BONAME, transactionID, true);
		
		if("PERSIST".equals(mode)) {
			if (transferToBank == null) {
				transferToBank = (IBOCE_ADF_TransferToBank) factory.getStatelessNewInstance(IBOCE_ADF_TransferToBank.BONAME);
				transferToBank.setBoID(transactionID);
				transferToBank.setF_BANKID(getF_IN_transferToBankDetails().getTransferHeaderDetails().getBankID());
				transferToBank.setF_CURRENCY(getF_IN_transferToBankDetails().getTransferHeaderDetails().getCurrency());
				transferToBank.setF_POFROMDATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getPoDateFrom());
				transferToBank.setF_POTODATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getPoDateTo());
				transferToBank.setF_PROCESSDATE(null);
				transferToBank.setF_PROCESSREFERENCE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getProcessReference());
				transferToBank.setF_VALUEDATE(null);
				transferToBank.setF_NOTES(getF_IN_transferToBankDetails().getTransferHeaderDetails().getNotes());
				factory.create(IBOCE_ADF_TransferToBank.BONAME, transferToBank);
			} else {
				transferToBank.setF_BANKID(getF_IN_transferToBankDetails().getTransferHeaderDetails().getBankID());
				transferToBank.setF_CURRENCY(getF_IN_transferToBankDetails().getTransferHeaderDetails().getCurrency());
				transferToBank.setF_POFROMDATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getPoDateFrom());
				transferToBank.setF_POTODATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getPoDateTo());
				transferToBank.setF_PROCESSDATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getProcessDate().equals(new Date(0))?null:getF_IN_transferToBankDetails().getTransferHeaderDetails().getProcessDate());
				transferToBank.setF_PROCESSREFERENCE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getProcessReference());
				transferToBank.setF_VALUEDATE(getF_IN_transferToBankDetails().getTransferHeaderDetails().getValueDate());
				transferToBank.setF_NOTES(getF_IN_transferToBankDetails().getTransferHeaderDetails().getNotes());
			}
			
			ArrayList<String> params = new ArrayList<>();
			params.add(transactionID);
			factory.bulkDelete(IBOCE_ADF_TransferToBankDetails.BONAME, where_clause, params);
			for (TransferToBank transferToBankDtls : getF_IN_transferToBankDetails().getTransferToBankList()) {
				IBOCE_ADF_TransferToBankDetails transferToBankDtl = (IBOCE_ADF_TransferToBankDetails) factory
						.getStatelessNewInstance(IBOCE_ADF_TransferToBankDetails.BONAME);
				transferToBankDtl.setF_AMOUNT(transferToBankDtls.getAmount());
				transferToBankDtl.setF_BENEFICIARYADDRESS(transferToBankDtls.getBeneficiaryAddress());
				transferToBankDtl.setF_BENEFICIARYBANK(transferToBankDtls.getBeneficiaryBank());
				transferToBankDtl.setF_BENEFICIARYIBAN(transferToBankDtls.getBeneficiaryIBAN());
				transferToBankDtl.setF_BENEFICIARYNAME(transferToBankDtls.getBeneficiaryName());
				transferToBankDtl.setF_CURRENCY(transferToBankDtls.getCurrency());
				transferToBankDtl.setF_EXCLUDE(transferToBankDtls.getExclude());
				transferToBankDtl.setF_ISSUEPOPAYDTLSID(transferToBankDtls.getIssuePOPayDtlsID());
				transferToBankDtl.setF_LOANACCOUNTID(transferToBankDtls.getLoanAccountID());
				transferToBankDtl.setF_TRANSACTIONID(transactionID);
				transferToBankDtl.setF_VALUEDATE(transferToBankDtls.getValueDate());
				factory.create(IBOCE_ADF_TransferToBankDetails.BONAME, transferToBankDtl);
			}
			
		}else if("UPDATEPO".equals(mode) && "G".equals(editMode)) {
			String processReference = transferToBank.getF_PROCESSREFERENCE();
			Date processedDate = transferToBank.getF_PROCESSDATE();
			ArrayList params = new ArrayList<>();
			params.add(transactionID);
			params.add(false);
			List columnList = new ArrayList<>();
			columnList.add(IBOCE_IB_IssuePOPayDetail.IBTRANSFERID);
			columnList.add(IBOCE_IB_IssuePOPayDetail.IBTRANSFERDATE);
			List values = new ArrayList<>();
			values.add(processReference);
			values.add(processedDate);
			int recordsUpdate = factory.bulkUpdate(IBOCE_IB_IssuePOPayDetail.BONAME, PO_PAY_UPDATE_WHERE_CLAUSE, params , columnList , values);
			System.out.println(recordsUpdate);
			
			List poColumnList = new ArrayList<>();
			poColumnList.add(IBOCE_IB_IssuePODetail.IBSTATUS);
			List poValues = new ArrayList<>();
			poValues.add("Completed");
			int  records= factory.bulkUpdate(IBOCE_IB_IssuePODetail.BONAME, PO_UPDATE_WHERE_CLAUSE, params , poColumnList , poValues);
			System.out.println(records);
			updateSurplusPosting(transactionID);
		}
	}

	private void updateSurplusPosting(String transactionID) {
		ArrayList params = new ArrayList<>();
		params.add(transactionID);
		params.add(false);
		List columnList = new ArrayList<>();
		columnList.add(IBOCE_ADF_SurplusTransfer.STATUS);
		List values = new ArrayList<>();
		values.add(true);
		int recordsUpdate = BankFusionThreadLocal.getPersistanceFactory().bulkUpdate(IBOCE_ADF_SurplusTransfer.BONAME,
				SURPLUS_UPDATE_WHERE_CLAUSE, params, columnList, values);
		System.out.println(recordsUpdate);

	}
}