/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_GovtSubsidy;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_PartyLoanDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_ManageSubsidyHandler;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.PartyLoanDetails;

/**
 * @author Aklesh
 *
 */
public class ManageSubsidyHandler extends AbstractCE_ADF_ManageSubsidyHandler {
	private transient final static Log logger = LogFactory.getLog(ManageSubsidyHandler.class.getName());
	private static final long serialVersionUID = 7137308733675905581L;
	private static final String NATIONALID = "NationalID";
	private static final String PARTYNAME = "PARTYNAME";
	private static final String UPLOADEDAMT = "UploadedAmount";
	private static final String SNo = "SrNO";
	private static final String Where_Clause = "WHERE " + IBOCE_ADF_GovtSubsidy.IBPROCESSINGYEAR + "=? AND "
			+ IBOCE_ADF_GovtSubsidy.IBSTATUS + "=? ";
	private static final String GEN_FILE_WHERE_CLAUSE = "WHERE " + IBOCE_ADF_GovtSubsidy.IBPROCESSINGYEAR + "=? AND "
			+ IBOCE_ADF_GovtSubsidy.IBPROCESSREF + " IS NOT NULL AND " + IBOCE_ADF_GovtSubsidy.IBPROCESSREF + "=? AND (("
			+ IBOCE_ADF_GovtSubsidy.IBHASZERO + "=? AND " +IBOCE_ADF_GovtSubsidy.IBHASRESCHEDULE+"=? AND "+ IBOCE_ADF_GovtSubsidy.IBUNHOLD + "=?) OR "
			+ IBOCE_ADF_GovtSubsidy.IBMANUALEXCLUDE + "=?)";
	private static final String viewQuery = " WHERE " + IBOCE_ADF_PartyLoanDetails.CEPARTYID + " =? AND "
			+ IBOCE_ADF_PartyLoanDetails.CETYPE + " =?";
	ArrayList<Object> params = new ArrayList();
	String query = "";
	int pageNo;
	int totalPages;
	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
	private static final String MOBILENUMBER = "MOBILENUMBER";
	private static final String CURRENTDUE = "CURRENTDUE";

	public ManageSubsidyHandler(BankFusionEnvironment env) {
		super(env);

	}

	public ManageSubsidyHandler() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String mode = getF_IN_mode();
		System.err.println();
		PartyLoanDetails partyLoanDetails = getF_IN_partyLoanDetails();
		if (mode.equals("Save")) {
			for (PartyLoanDetails partyLoanDetail : getF_IN_subsidyHoldUnhold().getPartyLoanDetails()) {
				if (partyLoanDetail.getSelect()) {
					// PartyLoanDetails partyLoanDetails = getF_IN_partyLoanDetails();
					IBOCE_ADF_GovtSubsidy govtSubsidy = (IBOCE_ADF_GovtSubsidy) BankFusionThreadLocal
							.getPersistanceFactory()
							.findByPrimaryKey(IBOCE_ADF_GovtSubsidy.BONAME, partyLoanDetail.getRecordID(), true);
					//govtSubsidy.setF_IBCURRENTDUEAMOUNT(partyLoanDetails.getCurrentDueAmount());
					//govtSubsidy.setF_IBHASRESCHEDULE(partyLoanDetails.getIsRescheduleDone());
					//govtSubsidy.setF_IBHASZERO(partyLoanDetails.getHasZeroDues());
					govtSubsidy.setF_IBMANUALEXCLUDE(partyLoanDetails.getManualExclude());
					govtSubsidy.setF_IBPROCESSEDDATE(SystemInformationManager.getInstance().getBFBusinessDate());
					govtSubsidy.setF_IBPROCESSREF(getF_IN_processedBatchReference());
					govtSubsidy.setF_IBREASON(partyLoanDetails.getReason());
					govtSubsidy.setF_IBUNHOLD(partyLoanDetails.getIsUnhold());
				}
			}
		}
		if (mode.equals("Generate")) {
			getQuery();
			int pageSize = PAGE_SIZE;
			int pageNo = PAGE_NO;

			IPagingData pagingData = null;

			if (getF_IN_PagedQuery() != null && getF_IN_PagedQuery().getPagingRequest() != null) {
				pageSize = getF_IN_PagedQuery().getPagingRequest().getNumberOfRows();
				pageNo = getF_IN_PagedQuery().getPagingRequest().getRequestedPage();
			}

			if (pageSize == 0)
				pageSize = PAGE_SIZE;
			if (pageNo == 0)
				pageNo = PAGE_NO;

			pagingData = new PagingData(pageNo, pageSize);
			pagingData.setRequiresTotalPages(true);
			this.runQuery(query, pagingData);

		}
		if (mode.equals("Update")) {
			updateUnprocessedRecords();
		}
	}

	private void updateUnprocessedRecords() {
		/*
		 * select vw.CEPARTYID,sum(vw.CETOTALDUE) totalDue from
		 * customextn.CE_IBTB_GOVTSUBSIDY govs, customextn.CEVW_PARTYLOANDETAILS vw
		 * where vw.CEPARTYID=govs.CEIBPARTYID AND govs.CEIBPROCESSINGYEAR='2021' group
		 * by vw.CEPARTYID
		 */
		Map<String,BigDecimal> partyAmounts = new HashMap<>();
		Map<String,String> partyHasResch = new HashMap<>();
		ArrayList params = new ArrayList<>();
		params.add(getF_IN_year());
		params.add("N");
		params.add("Party");
		String where = "SELECT vw." + IBOCE_ADF_PartyLoanDetails.CEPARTYID + " AS PartyID,vw."
				+ IBOCE_ADF_PartyLoanDetails.CETOTALDUE + " AS TotalDue,vw."
				+ IBOCE_ADF_PartyLoanDetails.CEHASRESCHEDULE + " AS HashResch " + " FROM " + IBOCE_ADF_GovtSubsidy.BONAME
				+ " govs," + IBOCE_ADF_PartyLoanDetails.BONAME + " vw WHERE vw." + IBOCE_ADF_PartyLoanDetails.CEPARTYID
				+ "=govs." + IBOCE_ADF_GovtSubsidy.IBPARTYID + " AND govs." + IBOCE_ADF_GovtSubsidy.IBPROCESSINGYEAR
				+ "=? AND govs." + IBOCE_ADF_GovtSubsidy.IBSTATUS + "=? AND vw." + IBOCE_ADF_PartyLoanDetails.CETYPE
				+ "=?";
		Iterator iterator = BankFusionThreadLocal.getPersistanceFactory()
				.executeGenericQuery(where, params, null, false).iterator();
		while (iterator.hasNext()) {
			SimplePersistentObject simplePersistentObj = (SimplePersistentObject) iterator.next();
			String partyID = (String) simplePersistentObj.getDataMap().get("PartyID");
			BigDecimal dueAmount =(BigDecimal)simplePersistentObj.getDataMap().get("TotalDue");
			String hashResch = (String) simplePersistentObj.getDataMap().get("HashResch");
			if(partyAmounts.get(partyID)!=null) {
				partyAmounts.put(partyID, partyAmounts.get(partyID).add(dueAmount));
			}else {
				partyAmounts.put(partyID, dueAmount);
			}
			if("1".equals(hashResch)) {
				partyHasResch.put(partyID, "1");
			}
			
		}
		params.clear();
		params.add(getF_IN_year());
		params.add("N");
		List<IBOCE_ADF_GovtSubsidy> subsidylist = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_ADF_GovtSubsidy.BONAME, Where_Clause, params, null, true);
		for (IBOCE_ADF_GovtSubsidy subsidy : subsidylist) {
			boolean hasReschedule = false;
			boolean zeroDues = true;
			BigDecimal dueAmount = BigDecimal.ZERO;
			if (partyAmounts.get(subsidy.getF_IBPARTYID()) != null) {
				zeroDues = partyAmounts.get(subsidy.getF_IBPARTYID())
						.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO ? false : true;
				dueAmount = partyAmounts.get(subsidy.getF_IBPARTYID());
			}
			if (partyHasResch.get(subsidy.getF_IBPARTYID()) != null) {
				hasReschedule = true;
			}
			subsidy.setF_IBCURRENTDUEAMOUNT(dueAmount);
			subsidy.setF_IBHASZERO(zeroDues);
			subsidy.setF_IBHASRESCHEDULE(hasReschedule);
			subsidy.setF_IBPROCESSEDDATE(SystemInformationManager.getInstance().getBFBusinessDate());
			subsidy.setF_IBPROCESSREF(getF_IN_uploadedBatchReference());
		}
	}

	

	private VectorTable generateExcelFile(List<IBOCE_ADF_GovtSubsidy> subsidylist, int pageNumber) {
		VectorTable vectorTable = new VectorTable();
		int srNo = (pageNumber - 1) * 10 + 1;
		for (IBOCE_ADF_GovtSubsidy subsidy : subsidylist) {
			Map<String, Object> attribute = new HashMap<>();
			attribute.put(SNo, srNo++);
			attribute.put(NATIONALID, subsidy.getF_IBNATIONALID());
			attribute.put(PARTYNAME, subsidy.getF_IBPARTYNAME());
			attribute.put(MOBILENUMBER, subsidy.getF_IBCONTACTNUM());
			attribute.put(UPLOADEDAMT, subsidy.getF_IBUPLOADAMOUNT());
			attribute.put(CURRENTDUE, subsidy.getF_IBCURRENTDUEAMOUNT());
			subsidy.setF_IBSTATUS("Y");
			vectorTable.addAll(new VectorTable(attribute));
		}
		return vectorTable;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		Map supportedData = pagingState.getPagingHelper().getPagingModel();
		supportedData.put("PAGING_QUERY", query);
		supportedData.put("PAGING_PARAMS", params);

		return pagingState;
	}

	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map supportData) {

		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		query = (String) pagingModel.get("PAGING_QUERY");
		params = (ArrayList<Object>) pagingModel.get("PAGING_PARAMS");
		String exportAllPages = supportData.containsKey("getAllRows") ? (String) supportData.get("getAllRows") : "";

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (supportData.containsKey("PAGENO")) {
			pageNo = (Integer) supportData.get("PAGENO");
		}
		if (supportData.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) supportData.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) supportData.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			if ("y".equals(exportAllPages)) {
				short numberOfRowsPerPage = Short.parseShort((String) supportData.get("NR"));
				int totalPageCount = (Integer) supportData.get("TOTALPAGES");
				pageSize = numberOfRowsPerPage * totalPageCount;
				pagingData.setPageSize(pageSize);
				pagingData.setCurrentPageNumber(Integer.valueOf(1));
			}
			resultVector = runQuery(query, pagingData);

		}
		return resultVector;
	}

	private void getQuery() {
		query = GEN_FILE_WHERE_CLAUSE;
		
		params.add(getF_IN_year());
		params.add(getF_IN_uploadedBatchReference());
		params.add(true);
		params.add(false);
		params.add(false);
		params.add(true);

	}

	private VectorTable runQuery(String dynamicQuery, IPagingData pagingData) {
		List<IBOCE_ADF_GovtSubsidy> resultSet = null;
		if (query.length() > 7) {
			resultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_ADF_GovtSubsidy.BONAME, query,
					params, pagingData, true);
		}
		VectorTable newResultVector = generateExcelFile(resultSet, pagingData.getCurrentPageNumber());
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		// pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		newResultVector.setPagingData(pageData);

		// setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
		setF_OUT_PaginatedData(newResultVector);
		totalPages = pagingData.getTotalPages();
		pagingData.getCurrentPageNumber();
		return newResultVector;
	}
}