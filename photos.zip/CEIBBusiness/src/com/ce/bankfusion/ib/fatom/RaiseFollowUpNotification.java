/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.misys.bankfusion.subsystem.task.ITaskService;
import com.misys.bankfusion.subsystem.task.mbean.impl.TaskService;
import com.trapedza.bankfusion.tasks.ITask;

@SuppressWarnings("serial")
public class RaiseFollowUpNotification {

 
    public void raiseNotification(String user,String loanAccountID) {
        ITaskService taskService = TaskService.getInstance();
        ITask task = taskService.createTask("business.followUpNotification");
        Map<String, Serializable> taskDetails = new HashMap<String, Serializable>();
        taskDetails.put("UserName", user);
       /* taskDetails.put(LOConstants.CP_ACTION_NAME, getF_IN_actionId());
        taskDetails.put(LOConstants.CP_APPLICATIONID, getF_IN_applicationId());
        taskDetails.put(LOConstants.CP_NOTIFY_ID, getF_IN_notifyId());*/
        taskDetails.put("NotificationMessage", "Follow Up is assgined to you for Loan Number:"+loanAccountID);
        task.setDetails(taskDetails);
        task.setComment("Follow Up is assgined to you for Loan Number:"+loanAccountID);
       // task.setCustomTaskViewMFName("FO_CMN_ReplayApplicationTask_SRV");
      //  task.setPayLoad(getF_IN_applicationId());
        task.setTaskDescription("Follow Up is assgined to you for Loan Number:"+loanAccountID);
        taskService.raiseTask(task);

    }

}
