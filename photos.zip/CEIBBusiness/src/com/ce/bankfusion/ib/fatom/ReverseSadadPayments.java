package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReverseSadadPayments;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ReverseSadadPayments extends AbstractCE_IB_ReverseSadadPayments{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6771654678446717029L;

	public ReverseSadadPayments()
	{
		
	}
	
	public ReverseSadadPayments(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String status_in_string = "'"+CeConstants.SADAD_PYMT_ON_SADAD+"','"
				+CeConstants.SADAD_PYMT_CANCELLED+"'";
		String whereClause = "WHERE "+IBOCE_IB_SadadPayments.IBDEALID + " = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTEPID + " = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTATUS + " IN ("
				+ status_in_string + ")";

		ArrayList<String> params = new ArrayList();
		params.add(ibObj.getDealID());
		params.add(ibObj.getStepID());
		List<IBOCE_IB_SadadPayments> paymentsToBeReversed = factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, whereClause, params , null, false);
		String nationalID = CommonConstants.EMPTY_STRING;
		if(null != paymentsToBeReversed && !paymentsToBeReversed.isEmpty())
		{
			String partyID = CommonConstants.EMPTY_STRING;
			try {
				partyID = ADFTechGrantAssetUtils.getDealCustomer(ibObj.getDealID());
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			nationalID = SadadPaymentUtils.getNationalId(partyID);
		}

		for(IBOCE_IB_SadadPayments paymentToBeReversed : paymentsToBeReversed)
		{
			//if cancelled, a new invoice has to be created.
			if(CeConstants.SADAD_PYMT_CANCELLED.equals(paymentToBeReversed.getF_IBSTATUS()))
			{
				//creating a new invoice - start
				String invoiceId = CommonConstants.EMPTY_STRING;
				String chargeDtlsID = paymentToBeReversed.getF_IBDEALCHARGEDTLID();
				BigDecimal taxAmount =  CommonConstants.BIGDECIMAL_ZERO;
				BigDecimal chargeAmount = CommonConstants.BIGDECIMAL_ZERO;
				//can be read from FeePaymentStatus table as well
				IBOIB_DLI_DealAssetChargesdtls chargeDtl = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, chargeDtlsID, false);
				if("STEP".equalsIgnoreCase(chargeDtl.getF_CHARGETYPE()))
				{
					taxAmount = chargeDtl.getF_TaxAmount();
					chargeAmount = chargeDtl.getF_ChargeAmount().add(chargeDtl.getF_TaxAmount());
				}
				else
				{
					taxAmount = chargeDtl.getF_UNPAIDTAXAMOUNT();
					chargeAmount = chargeDtl.getF_UNPAIDCHARGEAMOUNT().add(chargeDtl.getF_UNPAIDTAXAMOUNT());
				}
				invoiceId = SadadPaymentUtils.createSadadInvoice(nationalID, ibObj.getDealID(), chargeAmount, taxAmount, chargeDtl.getF_FEESCONFIGID());
				//creating a new invoice - end
				//creating a reversed entry
				SadadPaymentUtils.createReverseEntry(paymentToBeReversed);
				//updating the status and invoiceID
				paymentToBeReversed.setF_IBSTATUS(CeConstants.SADAD_PYMT_CANCEL);
				paymentToBeReversed.setF_IBINVOICEID(invoiceId);
			}
			else if(CeConstants.SADAD_PYMT_ON_SADAD.equals(paymentToBeReversed.getF_IBSTATUS()))
			{
				if(StringUtils.isBlank(paymentToBeReversed.getF_IBORIGINVOICEID()))
				{
					//previously scheduled - hence just canceling
					//canceling the invoice
					SadadPaymentUtils.cancelInvoice(paymentToBeReversed.getF_IBINVOICEID(),paymentToBeReversed.getF_IBDEALCHARGEDTLID());
					//creating a reversed entry
					SadadPaymentUtils.createReverseEntry(paymentToBeReversed);
					//updating the status
					paymentToBeReversed.setF_IBSTATUS(CeConstants.SADAD_PYMT_SCHEDULED);
					paymentToBeReversed.setF_IBINVOICEID(CommonConstants.EMPTY_STRING);

				}
				else if(StringUtils.isNotBlank(paymentToBeReversed.getF_IBORIGINVOICEID()))
				{
					//previously updateInvoice - hence just canceling new and scheduling the original
					String invoiceID = CommonConstants.EMPTY_STRING;
					//canceling the new invoice
					String newInvoiceID = paymentToBeReversed.getF_IBINVOICEID();
					SadadPaymentUtils.cancelInvoice(newInvoiceID,paymentToBeReversed.getF_IBDEALCHARGEDTLID());
					//creating a new invoice with the details of original invoice- start
					String originalInvoiceId = paymentToBeReversed.getF_IBORIGINVOICEID();
					IBOCE_IB_FeesPaymentStatus feePaymentDtls = (IBOCE_IB_FeesPaymentStatus) factory.findByPrimaryKey(IBOCE_IB_FeesPaymentStatus.BONAME, originalInvoiceId, false);
					BigDecimal taxAmount =  CommonConstants.BIGDECIMAL_ZERO; //TODO - need to understand how to derive this value
					BigDecimal chargeAmount = feePaymentDtls.getF_IBFEESPAYMENTFAMNT();
					invoiceID = SadadPaymentUtils.createSadadInvoice(nationalID, ibObj.getDealID(), chargeAmount, taxAmount, feePaymentDtls.getF_IBFEESPAYMENTFEESID());
					//creating a new invoice - end
					//creating a reversed entry
					SadadPaymentUtils.createReverseEntry(paymentToBeReversed);
					//updating the status and invoiceID
					paymentToBeReversed.setF_IBINVOICEID(invoiceID);
					paymentToBeReversed.setF_IBSTATUS(CeConstants.SADAD_PYMT_UPDATE);
					//updating the originalInvoiceID
					paymentToBeReversed.setF_IBORIGINVOICEID(CommonConstants.EMPTY_STRING);

				}
			}
		}
	}

}
