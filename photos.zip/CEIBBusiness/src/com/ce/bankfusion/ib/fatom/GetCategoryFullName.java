/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetCategoryFullName;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AsstCategory;

/**
 * @author Aklesh
 *
 */
public class GetCategoryFullName extends AbstractCE_IB_GetCategoryFullName {

	private static final long serialVersionUID = 7137308733675905581L;

	public GetCategoryFullName(BankFusionEnvironment env) {
		super(env);

	}

	public GetCategoryFullName() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		//IBOIB_AST_AssetDetails assetDetails= (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory().findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, getF_IN_categoryID(), true);
		
		AsstCategory assetCategory = new AsstCategory();
        assetCategory.setCategory(getF_IN_categoryID());
        String categoryHirachyName = AssetCategoryUtil.getCategoryQualifiedName(getF_IN_categoryID(), BankFusionThreadLocal.getPersistanceFactory(), null);
        categoryHirachyName = categoryHirachyName.replace(">", ">>");
        categoryHirachyName = (String) categoryHirachyName.subSequence(0, categoryHirachyName.lastIndexOf(">>"));
        assetCategory.setCategorization(categoryHirachyName);
        setF_OUT_assetCategory(assetCategory);
	}

}
