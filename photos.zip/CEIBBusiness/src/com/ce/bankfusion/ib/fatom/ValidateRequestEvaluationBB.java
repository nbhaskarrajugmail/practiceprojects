package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ExistingRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.NoEvalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;

public class ValidateRequestEvaluationBB {
	
	public static void validateRequestID(String dealID, CollateralRequestDetailsList collateralReqGridDtls) {
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + " = ? AND " + IBOCE_IB_DealCollateralDtls.IBREQUESTID + " = ? ";
		
		for(CollateralRequestDetails collateralReqDtls: collateralReqGridDtls.getCollateralRequestDetailsList()) {
			if(collateralReqDtls.getSelect()) {
			    
			if(null != collateralReqDtls.getStatus() && collateralReqDtls.getStatus().equals("DELETED")) {
			    IBCommonUtils.raiseUnparameterizedEvent(44000288);  //This request cannot be modified
			}
			String requestID = collateralReqDtls.getRequestID();
			
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(dealID);
			queryParams.add(requestID);
			List<IBOCE_IB_DealCollateralDtls> collateralDtls = factory.findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClause, queryParams, null, true);
			
			if(collateralDtls!=null && !collateralDtls.isEmpty()) { 
				IBCommonUtils.raiseUnparameterizedEvent(44000288);  //This request cannot be modified
			}
		 }
			
	   }
	}
	
	public static void validateCoverValueExistingType(ExistingRequestdtls existingDtls) {
		BigDecimal coverValue = existingDtls.getUtilizeAmount().getCurrencyAmount();
			if(coverValue.compareTo(BigDecimal.ZERO)==0 || coverValue==null) {  
				IBCommonUtils.raiseUnparameterizedEvent(44000285);
			}   				
	}
	
	public static void validateCollateralIdExistingType(ExistingRequestdtls existingDtls) {
		String collateralID = existingDtls.getCollateralID();
			if(collateralID==null || collateralID.isEmpty()) {  
				IBCommonUtils.raiseUnparameterizedEvent(44000291);
			}   				
		
	}
	
	public static void validateCoverValueNoEvaluation(NoEvalRequestdtls noEvaluationDtls) {
		BigDecimal coverValue = noEvaluationDtls.getCoverValue().getCurrencyAmount();
			if(coverValue.compareTo(BigDecimal.ZERO)==0 || coverValue==null) {
				IBCommonUtils.raiseUnparameterizedEvent(44000285);
			}
	}

	public static void validateCoverValuePersonal(PersonalRequestdtls personalDtls) {
		
		BigDecimal coverValue = personalDtls.getCoverValue().getCurrencyAmount();
		BigDecimal availableBalance = personalDtls.getAvailableBalance().getCurrencyAmount();
			if(coverValue.compareTo(BigDecimal.ZERO)==0 || coverValue==null) {
				IBCommonUtils.raiseUnparameterizedEvent(44000285);  
			}
			
           /* if(coverValue.compareTo(availableBalance)==1) {
            	IBCommonUtils.raiseUnparameterizedEvent(44000284);  
            	// cover value should not be greater than available balance        
            }
            	//this validation is handled in Validation Exception Framework - For personal Guarantee if the amount is going beyond 250k then it should go for Approval to grp 2	
          */	
	}
	
	public static void validateCustomerIdPersonal(String customerId) {
		 String[] msgArgs = new String[1];
	        msgArgs[0] = customerId;
	        if(customerId==null || ( null!= customerId && customerId.isEmpty())) { //check for value not null
				IBCommonUtils.raiseParametrizedEvent(20020032, msgArgs);  //validate customerId on click of save
			}
	}
	
	public static void validatePersonalTypeCount(CollateralRequestDetailsList collateralReqGridDtls, CollateralRequestDetails collateralReqDtls) {
		
		int count=0;
		
		String allowedCount = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.PERSONAL_REQUEST_CONF_FILE,
	            CeConstants.ALLLOWED_NUMBER_OF_PERSONAL_TYPES, "", CeConstants.ADFIBCONFIGLOCATION);
		int personalCount = Integer.parseInt(allowedCount);
		
			if(collateralReqGridDtls.getCollateralRequestDetailsListCount()>0) {
	            CollateralRequestDetails[] collateralList = collateralReqGridDtls.getCollateralRequestDetailsList();
	            for(CollateralRequestDetails collateralDtls : collateralList) {
	            	if("Personal".equals(collateralDtls.getRequestType())) {
	            		count++;
	            	}
	            }
	            if("Personal".equals(collateralReqDtls.getRequestType()) && collateralReqDtls.getStatus().equals("")) {
	            	count++;
	            }
	            if(count>personalCount) {
	            	IBCommonUtils.raiseUnparameterizedEvent(44000289);
	            	//should contain only max 3 entries for personalType per deal.
	            }
		 	}	
		 
	}
	public static void validateTitleDeedNumResidential(TitleDeedDetails titleDeedDetails) {
		
		if((titleDeedDetails.getTitleDeedNum()==null || titleDeedDetails.getTitleDeedNum().isEmpty()) 
    				&& (titleDeedDetails.getTitleDeedIDPK()==null ||titleDeedDetails.getTitleDeedIDPK().isEmpty())) {
		IBCommonUtils.raiseUnparameterizedEvent(44000287);   				//titleDeedNumber is mandatory 
    			
    		
		}
        
    }
	
	public static void validatetitleDeedDtlsNonPersonal(TitleDeedDetailsList titleDeedList) {
 		
		if(titleDeedList.getTitleDeedDetailsListCount() == 0) {
    				IBCommonUtils.raiseUnparameterizedEvent(44000290);  
    				//user can't save the data to main grid if title deed details are not present
		}
	}
	
	public static void validateEvaluatorResidential(TitleDeedDetailsList titleDeedDtlsList, TitleDeedDetails deedDetails) {
		int count=0;
		String newEvaluator = deedDetails.getResidentialDetails().getEvaluator();
		String newEvaluationID = deedDetails.getEvaluationId();
		for(TitleDeedDetails titleDeedDtls: titleDeedDtlsList.getTitleDeedDetailsList()) {
			String evaluationID = titleDeedDtls.getEvaluationId();
			String evaluator = titleDeedDtls.getResidentialDetails().getEvaluator();
			if(!evaluator.isEmpty()) {
				if(newEvaluator.equals(evaluator) && !(evaluationID.equals(newEvaluationID))) {
					count++;
				}
			}
			if(count==1) {	
				IBCommonUtils.raiseUnparameterizedEvent(44000286);  
				//each evaluatorType should occur only once in the grid 
			}
		}
	}
	public static void validateEvaluatorAgriculture(TitleDeedDetailsList titleDeedDtlsList, TitleDeedDetails deedDetails) {
		
		String newEvaluator = deedDetails.getAgricultureDetails().getEvaluator();
		String newEvaluationID = deedDetails.getEvaluationId();
		int count=0;
		for(TitleDeedDetails titleDeedDtls: titleDeedDtlsList.getTitleDeedDetailsList()) {
			String evaluator = titleDeedDtls.getAgricultureDetails().getEvaluator();
			String evaluationID = titleDeedDtls.getEvaluationId();
			if(!evaluator.isEmpty() && !(evaluationID.equals(newEvaluationID))) {
				if(newEvaluator.equals(evaluator)) {
					count++;
				}
			}
			if(count==1) {	
				IBCommonUtils.raiseUnparameterizedEvent(44000286);  
				//each evaluatorType should occur only once in the grid 
			}
		}
	}
	
	public static void validatePersonalPartyIdExist(CollateralRequestDetails collateralReqDtls,CollateralRequestDetailsList newRow)
	{
		if (newRow.getCollateralRequestDetailsListCount() > 0) {
			CollateralRequestDetails[] collateralList = newRow.getCollateralRequestDetailsList();
			for (CollateralRequestDetails collateralDtlsEach : collateralList) {
				if (!collateralDtlsEach.isSelect()) {

					if (collateralDtlsEach.getRequestType().equalsIgnoreCase("Personal")) {

						if (collateralDtlsEach.getPersonalRequest().getCustomerId().equalsIgnoreCase(
								collateralReqDtls.getPersonalRequest().getCustomerId())) {
							IBCommonUtils.raiseUnparameterizedEvent(44000422);
						}
					}
				}
			}
		}

	}
}
