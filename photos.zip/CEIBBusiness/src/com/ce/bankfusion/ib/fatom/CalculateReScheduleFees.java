package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateReScheduleFees;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealreschedule.dtls.ib.types.CeDistributePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CePostPonePaymentSchedule;

public class CalculateReScheduleFees extends AbstractCE_IB_CalculateReScheduleFees{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CalculateReScheduleFees() {
        super();
      }

      @SuppressWarnings("deprecation")
      public CalculateReScheduleFees(BankFusionEnvironment env) {
        super(env);
      }

      @Override
      public void process(BankFusionEnvironment env) throws BankFusionException {
    	  boolean isDistribute = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsDistribute();
    	  boolean isPostpone = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsPostpone();
    	  
    	  BigDecimal totalAmountProcessed = BigDecimal.ZERO;
    	  BigDecimal currentRescheduleProfit = BigDecimal.ZERO;
    	  BigDecimal scheduleFeePercentage = BigDecimal.ZERO;
    	  String dealCurrency = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinPrincipal().getCurrencyCode();
    	  if(isPostpone) {
    		 for(CePostPonePaymentSchedule cePostPonePaymentSchedule: getF_IN_dealRescheduleDetails().getPostPonePaymentSchedule()) {
    			 if(!cePostPonePaymentSchedule.isSelect()&&cePostPonePaymentSchedule.getRepaymentNewDate()!=null) {
    				 totalAmountProcessed = totalAmountProcessed.add(cePostPonePaymentSchedule.getTotalRepaymentAmount().getCurrencyAmount());
    			 }
    			 if(cePostPonePaymentSchedule.isSelect()) {
    				 totalAmountProcessed = totalAmountProcessed.add(cePostPonePaymentSchedule.getTotalRepaymentAmount().getCurrencyAmount());
    			 }
    		 }
    	  }
    	  if(isDistribute) {
    		  for(CeDistributePaymentSchedule ceDistributePaymentSchedule: getF_IN_dealRescheduleDetails().getDistributePaymentSchedule()) {
    			  if(ceDistributePaymentSchedule.isIsSkipRepayment()) {
    				  totalAmountProcessed = totalAmountProcessed.add(ceDistributePaymentSchedule.getTotalRepaymentAmount().getCurrencyAmount());
    			  }
    		  }
    	  }
    	  BigDecimal rescheduleFeeAmtCap = new BigDecimal((IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeeAmtCap").getValue()));
          BigDecimal outstandingPrincipal = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinPrincipal().getCurrencyAmount();
          if(outstandingPrincipal.compareTo(rescheduleFeeAmtCap)>=CommonConstants.INTEGER_ZERO) {
              int rescheduleFeePercentage = Integer.parseInt(IBCommonUtils.getModuleConfigurationValue("IB", "RescheduleFeePercentage").getValue());
              currentRescheduleProfit = totalAmountProcessed.multiply(new BigDecimal(rescheduleFeePercentage)).divide(new BigDecimal(100));
              scheduleFeePercentage  =new BigDecimal(100);
          }
    	  
          setF_OUT_rescheduleProfitAmount(IBCommonUtils.getBFCurrencyAmount(currentRescheduleProfit,dealCurrency));
          setF_OUT_scheduleFeeAmount(IBCommonUtils.getBFCurrencyAmount(currentRescheduleProfit,dealCurrency));
          setF_OUT_scheduleFeePercentage(scheduleFeePercentage);
      }
}
