package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistSadadPayments;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.SadadPaymentDtlsList;
import bf.com.misys.ib.types.SadadPayments;

public class PersistSadadPayments extends AbstractCE_IB_PersistSadadPayments{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public PersistSadadPayments()
	{
		super();
	}
	
	public PersistSadadPayments(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		SadadPaymentDtlsList sadadPaymentsList = getF_IN_sadadPaymentsList();
		String wherClause = "WHERE "+IBOCE_IB_SadadPayments.IBDEALID+" = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTEPID+" = ? AND "
				+ IBOCE_IB_SadadPayments.IBSTATUS+" NOT IN ('"
				+ CeConstants.SADAD_PYMT_CANCELLED+"','"
				+ CeConstants.SADAD_PYMT_REVERSED+"')";
		StringBuilder inClause = new StringBuilder();
		inClause.append(" AND " + IBOCE_IB_SadadPayments.IBPAYMENTSID+ " NOT IN (");
		for(SadadPayments sadadPayment : sadadPaymentsList.getSadadPaymentDtls())
		{
			String paymentID = SadadPaymentUtils.createSadadPayment(sadadPayment, getF_IN_islamicBankingObject().getDealID());
			inClause.append("'"+paymentID+"',");
		}
		inClause.deleteCharAt(inClause.length()-1);
		inClause.append(")");
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<String>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		params.add(getF_IN_islamicBankingObject().getStepID());
		String finalWhereClause = wherClause;
		if(sadadPaymentsList.getSadadPaymentDtlsCount() > 0)
		{
			finalWhereClause = finalWhereClause+inClause;
		}
		//deleting the entries for previously scheduled but later waived/deleted fees
		factory.bulkDelete(IBOCE_IB_SadadPayments.BONAME, finalWhereClause, params );
	}

}
