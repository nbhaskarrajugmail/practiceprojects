package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ADFCallSadadAPI;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.ce.sadad.invoice.BillInvoice;
import com.ce.sadad.invoice.FeeInvoiceData;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.InvokeSyncWebServiceImpl;

import bf.com.misys.bankfusion.attributes.BFHeader;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.bankfusion.attributes.WebService;
import bf.com.misys.ib.types.ReschedulingFee;
import bf.com.misys.msgs.party.v12.PartyDetailsRq;
import bf.com.misys.msgs.party.v12.PartyFetchPayloadRq;
import bf.com.misys.party.ws.ReadPartyWSRq;
import bf.com.misys.party.ws.ReadPartyWSRs;
import bf.com.trapedza.bankfusion.webservices.Authentication;
import bf.com.trapedza.bankfusion.webservices.Bfgenericsoapheader;

public class ADFCallSadadAPI extends AbstractCE_IB_ADFCallSadadAPI {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(ADFCallSadadAPI.class);

	public ADFCallSadadAPI(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("Creating Asset Payoff details for DealId " + getF_IN_InputValue());
		ReschedulingFee ReschedulingFees[] = getF_IN_reschedulingFeesList().getReschedulingFee();
		String dealId = getF_IN_InputValue();
		String nationalId = StringUtils.EMPTY;
		String partyID = CommonConstants.EMPTY_STRING;
		try {
			partyID = ADFTechGrantAssetUtils.getDealCustomer(dealId);
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		nationalId = getNationalId(partyID);
		String upfrontProfitCollection = StringUtils.EMPTY;
		try {
			upfrontProfitCollection = queryDealAditionalDtlsUDCheckSADAD(queryDealAditionalDtls(dealId));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		/*
		 * Check id UDF_ADF00000050, the Upfront Profit Collection is equal to SADAD for
		 * this deal Id
		 */
		if (upfrontProfitCollection.equals("SADAD")) {
			for (ReschedulingFee reschedulingFee : ReschedulingFees) {
				if(!reschedulingFee.getChargePaymentStatus().equalsIgnoreCase("WAIVED")) {
					ArrayList params = new ArrayList<>();
					params.add(getF_IN_InputValue());
					params.add(reschedulingFee.getFeesConfId());
					IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
					String sadadInvoiceFee = "WHERE "+ IBOCE_IB_FeesPaymentStatus.IBDEALID+"=?" +" AND "+ IBOCE_IB_FeesPaymentStatus.IBFEESPAYMENTFEESID+"=?";
					List<IBOCE_IB_FeesPaymentStatus> feePayments=factory.findByQuery(IBOCE_IB_FeesPaymentStatus.BONAME, sadadInvoiceFee, params, null, false);
					boolean invoiceToBeRaised = true;
					if(feePayments.size()>0)
						invoiceToBeRaised=false;
					
				if(invoiceToBeRaised) {
				FeeInvoiceData feeInvoiceData = new FeeInvoiceData();
				try {
					feeInvoiceData.setBillAccount(nationalId);
					feeInvoiceData.setBillAmount(reschedulingFee.getAmountInDeal().getAmountEdited());
					// [Question]: Due date ?
					feeInvoiceData.setDueDate(SystemInformationManager.getInstance().getBFBusinessDate());
					// [Question]: what should be the expiry ?
					feeInvoiceData.setExpiryDate(SystemInformationManager.getInstance().getBFBusinessDate());
					feeInvoiceData.setVatAmount(reschedulingFee.getChargeDetails().getTaxAmount());
				} catch (Exception e) {
					e.printStackTrace();
				}
				String invoiceID = generateBillInvoiceforFee(feeInvoiceData);
				persistFeeInvoiceDetails(feeInvoiceData, invoiceID, reschedulingFee.getFeesConfId());
				}
			  }
			}

		}
	}

	private void persistFeeInvoiceDetails(FeeInvoiceData feeInvoiceData, String invoiceID, String feesID) {

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_FeesPaymentStatus feesPaymentStatus = (IBOCE_IB_FeesPaymentStatus) factory
				.getStatelessNewInstance(IBOCE_IB_FeesPaymentStatus.BONAME);
		feesPaymentStatus.setBoID(invoiceID);
		feesPaymentStatus.setF_IBDEALID(getF_IN_InputValue());
		feesPaymentStatus.setF_IBFEESPAYMENTAMNTPAID(CommonConstants.BIGDECIMAL_ZERO);
		feesPaymentStatus.setF_IBFEESPAYMENTFAMNT(feeInvoiceData.getBillAmount());
		// [Question]: Fees ID, from where to get it ?
		feesPaymentStatus.setF_IBFEESPAYMENTFEESID(feesID);
		feesPaymentStatus.setF_IBFEESPAYMENTISCANCEL(false);
		feesPaymentStatus.setF_IBFEESPAYMENTNATIONALID(feeInvoiceData.getBillAccount());
		factory.create(IBOCE_IB_FeesPaymentStatus.BONAME, feesPaymentStatus);
	}

	public ReadPartyWSRs readParty(ReadPartyWSRq rq, BankFusionEnvironment env) {
		String partyURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
				"IB_PARTY_WS_URL", "false");
		ReadPartyWSRs rs = new ReadPartyWSRs();
		InvokeSyncWebServiceImpl invokeWS = new InvokeSyncWebServiceImpl(env);
		WebService param = new WebService();
		BFHeader bfHeader = new BFHeader();
		bfHeader.setCorrelationID(GUIDGen.getNewGUID());
		bfHeader.setZone(env.getUserSession().getZone());
		param.setBfHeader(bfHeader);
		param.setOperationName("PT_PFN_ReadPartyWS_SRV");
		param.setRequestPayload(rq);
		param.setResponsePayload(rs);
		param.setServiceName(partyURL + "/bfweb/services/ReadPartyWS?wsdl");
		param.setTimeOut(30000);
		param.setSecurityCheckRequired(false);
		Bfgenericsoapheader soap = new Bfgenericsoapheader();
		Authentication authentication = new Authentication();
		String authProvider = getServerAuthProvider();
		if (authProvider.equalsIgnoreCase("CAS")) {
			authentication.setUserLocator(env.getUserLocn().getStringRepresentation());
		} else {
			authentication.setUserName("system");
			authentication.setPassword("system");
		}
		soap.setAuthentication(authentication);
		soap.setBFHeader(bfHeader);
		param.setCustomHeader(soap);
		invokeWS.setF_IN_WebService(param);
		invokeWS.process(env);
		rs = (ReadPartyWSRs) invokeWS.getF_OUT_Response();
		return rs;
	}

	private String getServerAuthProvider() {
		return BankFusionPropertySupport.getServerProperty("AuthenticationProvider");
	}

	private String getNationalId(String partyId) {
		try {
			ReadPartyWSRq partyWSRq = new ReadPartyWSRq();
			partyWSRq.setPartyID(partyId);
			ReadPartyWSRs partyWSRs = readParty(partyWSRq, BankFusionThreadLocal.getBankFusionEnvironment());
			String partyType = partyWSRs.getPartyBasicDetails().getPartyType().getCode();

			PartyFetchPayloadRq fetchPayloadRq = new PartyFetchPayloadRq();
			fetchPayloadRq.setPartyId(partyId);
			fetchPayloadRq.setPartyType(partyType);
			HashMap<String, PartyFetchPayloadRq> partyPayload = new HashMap<String, PartyFetchPayloadRq>();
			partyPayload.put("partyFetchPayloadRq", fetchPayloadRq);
			HashMap loanOutput = MFExecuter.executeMF("CE_IB_GetPartyDetails_SRV", partyPayload,
					BankFusionThreadLocal.getUserLocator().getStringRepresentation());
			PartyDetailsRq readLoanDtlsRs = (PartyDetailsRq) loanOutput.get("PartyDetailsRq");
			if (partyType.equals("1062")) {
				return readLoanDtlsRs.getPartyDetails().getPartyTaxDtl().getGstRegistration().getIdReference();
			} else {
				return readLoanDtlsRs.getPartyDetails().getEntPtyBasicDtls().getRegNumber();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	private String queryDealAditionalDtls(String DealNum) throws Exception {
		try {
			String idpk = StringUtils.EMPTY;

			// set the factory connection
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

			// Filter Query
			String whereClause = " WHERE IBDEALNO = ?";
			// Add Parameters
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(DealNum);

			List<IBOIB_DLI_DealAditionalDtls> dealAddtionalDetails = factory
					.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, queryParams, null, true);

			// process the results
			for (IBOIB_DLI_DealAditionalDtls dealAdditionalDetails : dealAddtionalDetails) {
				idpk = dealAdditionalDetails.getBoID();
			}
			return idpk;
		} catch (Exception se) {
			throw se;
		}

	}

	private String queryDealAditionalDtlsUDCheckSADAD(String idpk) throws Exception {
		try {
			// set the factory connection
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			// Filter Query
			String whereClause = " WHERE IBDEALADDITIONALDTLSIDPK = ?";
			// Add Parameters
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(idpk);

			List<IBOUDFEXTIB_DLI_DealAditionalDtls> dealAddtionalDetailsUD = factory
					.findByQuery(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, whereClause, queryParams, null, true);
			String upfrontProfitCollection = StringUtils.EMPTY;
			String upfrontProfitCollectionMethod = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.UDFPROPERTY, CeConstants.UPFRONT_PROFIT_COLLECTION_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
			// process the results
			for (IBOUDFEXTIB_DLI_DealAditionalDtls dealAdditionalDetailsUD : dealAddtionalDetailsUD) {
				UserDefinedFields userDefinedFields = dealAdditionalDetailsUD.getUserDefinedFields();
				if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
					for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
						/* Upfront Profit Collection */
						if (userDefinedFld.getFieldName().equals(upfrontProfitCollectionMethod)) {
							upfrontProfitCollection = (String) userDefinedFld.getFieldValue();
						}
					}
				}
			}
			return upfrontProfitCollection;
		} catch (Exception se) {
			throw se;
		}
	}

	private String generateBillInvoiceforFee(FeeInvoiceData feeData) {
		String invoiceID = StringUtils.EMPTY;
		Map<String, Object> result = new HashMap<String, Object>();
		if (feeData != null) {
			LOGGER.info("Generating Invoice for the initial study, for Account " + feeData.getBillAccount());
			LOGGER.info("Payment Amount: " + feeData.getBillAmount()+" Bill account: "+feeData.getBillAccount()+" Due Date And Expiry date:"+feeData.getDueDate());
			BillInvoice billInvoice = new BillInvoice();
			try {
				result  = billInvoice.genBillInvoiceforFee(feeData);
			} catch (Exception exception) {
				LOGGER.error("Sadad invoice creation failed : " + exception.getLocalizedMessage());
				IBCommonUtils.raiseUnparameterizedEvent(SadadPaymentUtils.E_SADAD_INVOICE_CREATION_FAILED);
			}
			Object status = (String) result.get("status");
			if(null != status && "Success".equalsIgnoreCase(status.toString()))
			{
				invoiceID = (String) result.get("invoiceId");
			}
			else
			{
				Object statusCode = result.get("statusCode");
				LOGGER.error("Sadad invoice creation failed with statusCode : " + (null != statusCode?statusCode:null));
				IBCommonUtils.raiseUnparameterizedEvent(SadadPaymentUtils.E_SADAD_INVOICE_CREATION_FAILED);
			}
			LOGGER.info("The Result of sending invoice to SADAD is : " + result);
		}
		return invoiceID;
	}
}