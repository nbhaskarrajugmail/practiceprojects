/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressEditableTags;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * @author Aklesh
 *
 */
public class AssetProgressEditableTags extends AbstractCE_IB_AssetProgressEditableTags {

	private static final long serialVersionUID = 7137308733675905581L;

	public AssetProgressEditableTags(BankFusionEnvironment env) {
		super(env);

	}

	public AssetProgressEditableTags() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String progressStatus = getF_IN_progressStatus();
		if(isF_IN_viewMode()) {
			setF_OUT_newRowViewMode(true);
			setF_OUT_saveRemoveViewMode(true);
			setF_OUT_scallersViewMode(true);
		}else {
			if((!"New".equalsIgnoreCase(progressStatus)&& !"".equalsIgnoreCase(progressStatus))) {
				setF_OUT_saveRemoveViewMode(true);
				setF_OUT_scallersViewMode(true);
			}
		}
	}

}
