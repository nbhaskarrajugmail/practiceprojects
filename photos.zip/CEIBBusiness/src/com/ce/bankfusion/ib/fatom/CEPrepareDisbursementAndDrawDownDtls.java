package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOAssetDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentScheduleDetails;
import com.misys.bankfusion.ib.fatom.ReadSchedules;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_IDI_PrepareDisbursementAndDrawDownDtls;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.msgs.v1r0.MaintainDisbursementDetails;
import bf.com.misys.ib.schedule.payments.DrawdownDetails;
import bf.com.misys.ib.schedule.types.DrawDownAndDownPaymentDetails;
import bf.com.misys.ib.types.DisbursementInfo;
import bf.com.misys.ib.types.DownPaymentDetails;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ProductConfiguration;

public class CEPrepareDisbursementAndDrawDownDtls extends AbstractIB_IDI_PrepareDisbursementAndDrawDownDtls {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public CEPrepareDisbursementAndDrawDownDtls(BankFusionEnvironment env) {
        super(env);
    }

    public CEPrepareDisbursementAndDrawDownDtls() {
        super();
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        Date constructionEndDate = null;
        DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails = new DrawDownAndDownPaymentDetails();

        ReadSchedules readSchedules = new ReadSchedules();

        if (!IBCommonUtils.isNullOrEmpty(getF_IN_dealID())) {

            DownPaymentDetails downPaymentDetails = getF_IN_downPaymentDetail();
            /**
             * The down payment should be passed in case of on the fly disbursement and down payment schedule.
             */
            if (downPaymentDetails != null
                && !ScheduleUtils.isBigDecimaNullOrZero(downPaymentDetails.getDownPaymentAmount().getCurrencyAmount())) {

                /**
                 * Set deal start date as downpayment date if the downpayment date is not set but downpayment amount is set..
                 */
                if (CalendarUtil.isDateNullOrDefaultDate(downPaymentDetails.getDownPaymentDate())) {

                    downPaymentDetails.setDownPaymentDate(IBCommonUtils.getDealDetails(getF_IN_dealID()).getF_DealStartDate());
                }

                readSchedules.setF_IN_downPaymentDetailsInput(downPaymentDetails);
            }

            ProductConfiguration prodConfiguration = IBCommonUtils.loadProductConfiguration(getF_IN_dealID());
            /**
             * Apply down payments should be true only if the deal has a construction profile.
             */
            readSchedules.setF_IN_isApplyDownpayments(prodConfiguration.getGeneralParameters().isIsGestationPeriod());
            readSchedules.setF_IN_dealId(getF_IN_dealID());
            readSchedules.process(env);

            MaintainDisbursementDetails disbursementDetails = readSchedules.getF_OUT_maintainDisbursementDetails();

            if (disbursementDetails.getIsMutipleDisbursementAllowed() && disbursementDetails.getDisbursementInfoCount() == 0) {
                
                String whereClause1 =
                    "WHERE " + IBOCE_IB_IssuePODetail.IBSTATUS+ " = ? AND " + IBOCE_IB_IssuePODetail.IBDEALID+ " = ?";
                ArrayList<String> params = new ArrayList<String>();
                params.clear();
                params.add("Processed");
                params.add( readSchedules.getF_IN_dealId());
                IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                List<IBOCE_IB_IssuePODetail> issuePO = (List<IBOCE_IB_IssuePODetail>) factory
                    .findByQuery(IBOCE_IB_IssuePODetail.BONAME, whereClause1, params, null, true);
                
                for(IBOCE_IB_IssuePODetail ip : issuePO) {
                  String issuePOID = ip.getF_IBPURCHASEORDERID();
                
                String whereClause2 =
                    "WHERE " + IBOCE_IB_IssuePOAssetDetail.IBPURCHASEORDERID+ " = ? ";
                params.clear();
                params.add(issuePOID);

                List<IBOCE_IB_IssuePOAssetDetail> issuePOAssetDtls = (List<IBOCE_IB_IssuePOAssetDetail>) factory
                    .findByQuery(IBOCE_IB_IssuePOAssetDetail.BONAME, whereClause2, params, null, true);
                Map<String,BigDecimal> ids = new HashMap();
                for(IBOCE_IB_IssuePOAssetDetail asset : issuePOAssetDtls) {
                    
                    
                    if(ids.containsKey(asset.getF_IBASSETID())) {
                        BigDecimal Value=ids.get(asset.getF_IBASSETID());
                        ids.replace(asset.getF_IBASSETID(), Value.add(asset.getF_IBDISBURSEDAMOUNT()));
                    }else {
                        ids.put(asset.getF_IBASSETID(), asset.getF_IBDISBURSEDAMOUNT());
                    }
                    
                }
                    for (Map.Entry mapElement : ids.entrySet()) {
                        String whereClause3 =  "WHERE " + IBOIB_IDI_ThirdPartyPaymentDetails.ASSETDETAILID+ " = ? ";
                        params.clear();
                        params.add((String) mapElement.getKey());
                    
                    List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartySch = (List<IBOIB_IDI_ThirdPartyPaymentDetails>) factory
                        .findByQuery(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, whereClause3, params, null, true);
                    int disbursementNo = 0;
                    for(IBOIB_IDI_ThirdPartyPaymentDetails thirdParty : thirdPartySch) {
                        
                        String whereClause = " WHERE "
                            + IBOIB_IDI_ThirdPartyPaymentScheduleDetails.THIRDPTYPAYMMENTDTLSID + "=?";
                        ArrayList<String> params1 = new ArrayList<String>();
                        params1.clear();
                        params1.add(thirdParty.getBoID());
                        List<IBOIB_IDI_ThirdPartyPaymentScheduleDetails> tPPayScheDtls = (List<IBOIB_IDI_ThirdPartyPaymentScheduleDetails>) factory
                            .findByQuery(IBOIB_IDI_ThirdPartyPaymentScheduleDetails.BONAME, whereClause, params1,
                                null, false);
                    
                        for(IBOIB_IDI_ThirdPartyPaymentScheduleDetails tpSch: tPPayScheDtls) {
                        
                   
                    DisbursementInfo disbursementRuntimeInfo = new DisbursementInfo();
                    disbursementRuntimeInfo.removeAllDisbursemetCreditDetails();
                    disbursementRuntimeInfo.setDisbursementAccount(readSchedules.getF_OUT_maintainDisbursementDetails().getDefaultDisbursementAccount());
                    disbursementRuntimeInfo.setDisbursementAccountType(readSchedules.getF_OUT_maintainDisbursementDetails().getDefaultDisbursementAccountType());
                    BFCurrencyAmount amt = new BFCurrencyAmount();
                    amt.setCurrencyAmount(ids.get(mapElement.getValue()));
                    amt.setCurrencyCode(IBCommonUtils.getDealDetails( readSchedules.getF_IN_dealId()).getF_IsoCurrencyCode());
                    disbursementRuntimeInfo.setDisbursementAmount(amt);
                    disbursementRuntimeInfo.setDisbursementDate(tpSch.getF_PAYMENTDT());
                    disbursementRuntimeInfo.setDisbursementNo(++disbursementNo);
                    disbursementRuntimeInfo.setIsDisbursed(false);
                    disbursementRuntimeInfo.setThirdPartyId(IBConstants.EMPTY_STRING);
                    disbursementRuntimeInfo.setDisbursementStatus(IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT);
                    disbursementDetails.addDisbursementInfo(disbursementRuntimeInfo);
                    }}
                }
                
                }
                if(disbursementDetails.getDisbursementInfoCount() == 0) {
                    IBCommonUtils.raiseUnparameterizedEvent(35100448);
                }
            }

            DisbursementInfo[] disbursementInfo = readSchedules.getF_OUT_maintainDisbursementDetails().getDisbursementInfo();
            constructionEndDate = readSchedules.getF_OUT_maintainDisbursementDetails().getConstructEndDate();

            List<DrawdownDetails> drawdownDetails = new ArrayList<>();

            for (int i = 0; i < disbursementInfo.length; i++) {
                DrawdownDetails drawDtls = new DrawdownDetails();
                drawDtls.setDrawdownAmount(disbursementInfo[i].getDisbursementAmount().getCurrencyAmount());
                drawDtls.setDrawdownDate(disbursementInfo[i].getDisbursementDate());
                drawdownDetails.add(drawDtls);
                drawDownAndDownPaymentDetails.addDrawdownDetails(drawDtls);

            }
            drawDownAndDownPaymentDetails
                .setDownPaymentDetails(readSchedules.getF_OUT_maintainDisbursementDetails().getDownPaymentDetails());
        }
        setF_OUT_drawDownAndDownPaymentDtls(drawDownAndDownPaymentDetails);
        setF_OUT_constructionEndDate(constructionEndDate);
        if (null != readSchedules.isF_OUT_isAllDsibursedAssetReceived()) {
            boolean isAllDisbursedAssetReceived = readSchedules.isF_OUT_isAllDsibursedAssetReceived();
            setF_OUT_isAllDsibursedAssetReceived(isAllDisbursedAssetReceived);
        }
    }
}