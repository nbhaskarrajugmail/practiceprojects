package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AgricultureRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_BuildingDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ResidentialRquestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TitleDeedDtlsForEvaluation;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TreeDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_WellDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedEvaluation;
import com.ce.bankfusion.ib.util.CalculationRequestEvaluationUtils;
import com.ce.ib.buildingblock.RequestEvaluationHBuildingBlock;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealClosureDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TPT_ThirdPartyOfficeDetails;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.fatoms.CustomAutoNumFatom;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.AgricultureDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CoOrdinateDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.OwnersDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ResidentialDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class TitleDeedEvaluation extends AbstractCE_IB_TitleDeedEvaluation {

    private static final long serialVersionUID = 1L;
    
    private static Boolean NewExistDataWell = false;
    private static Boolean NewExistDataTree = false;
    private static Boolean NewExistDataBuilding = false;

    public TitleDeedEvaluation() {
        super();
    }

    public TitleDeedEvaluation(BankFusionEnvironment env) {

    }

    public void process(BankFusionEnvironment env) throws BankFusionException {
        String category = getF_IN_category();

        String mode = getF_IN_mode();

        switch (mode) {
        case "SCALAR_NEW":
            addNewRow(env);
            break;
        case "SCALAR_NEW_WELLS":
            addNewRowofWells(env);
            break;
        case "SCALAR_NEW_BUILDINGS":
            addNewRowofBuildings(env);
            break;
        case "SCALAR_NEW_TREES":
            addNewRowofTrees(env);
            break;
        case "SCALAR_SAVE":
            saveRowofTitleDeed(env);
            break;
        case "SCALAR_SAVE_WELLS":
            saveRowofWells(env);
            break;
        case "SCALAR_SAVE_BUILDINGS":
            saveRowofBuildings(env);
            break;
        case "SCALAR_SAVE_TREES":
            saveRowofTrees(env);
            break;
        case "SCALAR_REMOVE":
            removeRowofTitleDeedList(env);
            break;
        case "SCALAR_REMOVE_WELLS":
            removeRowOfWellDetails(env);
            break;
        case "SCALAR_REMOVE_TREES":
            removeRowOfTreeDetails(env);
            break;
        case "SCALAR_REMOVE_BUILDINGS":
            removeRowOfBuildingDetails(env);
            break;
        case "POPULATE":
            populateDataOnCheckBoxEvent(category, env);
            break;
        default:
            break;

        }

    }

    private void populateDataOnCheckBoxEvent(String category, BankFusionEnvironment env) {

        TitleDeedDetailsList titleDeedDtlsList = getF_IN_titleDeedDtlsList();

        WellDetailsList hiddenWellDetailsList = getF_IN_hidden_wellDtlsList();
        WellDetailsList wellDetailsList = new WellDetailsList();

        TreesDetailsList hiddenTreesDtlsList = getF_IN_hidden_treesDtlsList();// getf_in
        TreesDetailsList treeDetailsGrid = new TreesDetailsList();

        BuildingsDetailsList hiddenBuildingDtlsList = getF_IN_hidden_buildingDtlsList();// getf_in
        BuildingsDetailsList buildingDetailsGrid = new BuildingsDetailsList();

        PopulateTitleDeedsDtlsForReqType populateTitleDeedsDtlsForReqType = new PopulateTitleDeedsDtlsForReqType();

        CoOrdinateDetailsList coOrdinateDtlsList = new CoOrdinateDetailsList();
        OwnersDetailsList ownersDtlsList = new OwnersDetailsList();

        for (TitleDeedDetails deedDetails : titleDeedDtlsList.getTitleDeedDetailsList()) {
            if (deedDetails.getSelect()) {
                String titleDeedIdpk = deedDetails.getTitleDeedIDPK();
                int titledeedVersion = deedDetails.getTitleDeedVersionNum();

                HashMap mapData = PopulateTitleDeedDtls.populateCoOrdinateAndOwnerDtls(titleDeedIdpk, titledeedVersion, env);
                coOrdinateDtlsList = (CoOrdinateDetailsList) mapData.get("CoOrdinateDtlsList");
                ownersDtlsList = (OwnersDetailsList) mapData.get("OwnersDtlsList");
                
                if (category.equals("Agricultural")) {
                    wellDetailsList = populateTitleDeedsDtlsForReqType.populateWellDtlsList(hiddenWellDetailsList, deedDetails);
                    treeDetailsGrid = populateTitleDeedsDtlsForReqType.populateTreeDtlsList(hiddenTreesDtlsList, deedDetails);
                    buildingDetailsGrid = populateTitleDeedsDtlsForReqType.populateBuildingDtlsList(hiddenBuildingDtlsList, deedDetails);
                    setF_OUT_coOrdinateDtlsList(coOrdinateDtlsList);
                    // setF_out(wellDetailsList);// not hidden , only main UI;
                    setF_OUT_wellDetailsList(wellDetailsList);
                    // setF_out(treeDetailsGrid);// not hidden , only main UI;
                    setF_OUT_treeDetailsList(treeDetailsGrid);
                    // setF_out(buildingDetailsGrid);// not hidden , only main UI;
                    setF_OUT_buildingDetailsList(buildingDetailsGrid);
                    
                } else if (category.equals("Residential") || category.equals("Commercial")) {
                    
                    // owners and coordinates
                    setF_OUT_coOrdinateDtlsList(coOrdinateDtlsList);
                    setF_OUT_ownersDtlsList(ownersDtlsList);
                }

            }

        }
    }

    private void addNewRowofTrees(BankFusionEnvironment env) {
        // TreeDetails eachTreeDetails = getF_IN_treeDetails();
        TreesDetailsList treeDetailsGrid = getF_IN_treeDetailsList();
        int sno = 1;
        if (treeDetailsGrid.getTreesDetailsListCount() > 0) {
            for (TreeDetails treeDtls : treeDetailsGrid.getTreesDetailsList()) {
                treeDtls.setSelect(false);
                sno++;
            }
        }
        TreeDetails addRow = new TreeDetails();
        BFCurrencyAmount cost = null;
        BigDecimal treeAge = null;
        BFCurrencyAmount price = null;
        Integer noOfTrees = null;

        addRow.setCost(cost);
        addRow.setNoOfTrees(noOfTrees);
        addRow.setNotes(CommonConstants.EMPTY_STRING);
        addRow.setPricePerTree(price);
        addRow.setSno(sno);
        addRow.setTreeAge(treeAge);
        addRow.setTreeDetailsID(CommonConstants.EMPTY_STRING); // set ID
        addRow.setTreeType(CommonConstants.EMPTY_STRING);
        addRow.setTreeTypeDesc(CommonConstants.EMPTY_STRING);
        addRow.setSelect(true);
        treeDetailsGrid.addTreesDetailsList(addRow);
        setF_OUT_treeDetailsList(treeDetailsGrid);
        setF_OUT_showBtn(false);
        setF_OUT_readOnlyNewTree(true);
        
    }

    private void addNewRowofBuildings(BankFusionEnvironment env) {
        // BuildingDetails eachTreeDetails = getF_IN_buildingDetails();
        BuildingsDetailsList buildingsDetailsGrid = getF_IN_buildingDetailsList();
        Integer sno = 1;
        if (buildingsDetailsGrid.getBuildingsDetailsListCount() > 0) {
            for (BuildingDetails buildingDtls : buildingsDetailsGrid.getBuildingsDetailsList()) {
                buildingDtls.setSelect(false);
                sno++;
            }
        }
        BuildingDetails addRow = new BuildingDetails();
        BigDecimal buildingAge = null;
        BFCurrencyAmount cost = null;
        BigDecimal buildingSize = null;
        BFCurrencyAmount pricePerSqM = null;
        addRow.setBuildingAge(buildingAge);
        addRow.setBuildingDetailsID(CommonConstants.EMPTY_STRING);
        addRow.setBuildingsize(buildingSize);
        addRow.setBuildingType(CommonConstants.EMPTY_STRING);
        addRow.setBuildingTypeDesc(CommonConstants.EMPTY_STRING);
        addRow.setCost(cost);
        addRow.setNotes(CommonConstants.EMPTY_STRING);
        addRow.setPricePerSqM(pricePerSqM);
        addRow.setSelect(true);

        addRow.setSno(sno);
        buildingsDetailsGrid.addBuildingsDetailsList(addRow);
        setF_OUT_buildingDetailsList(buildingsDetailsGrid);
        setF_OUT_showBtn(false);
        setF_OUT_readOnlyNewBuilding(true);
    }

    private void addNewRowofWells(BankFusionEnvironment env) {
        // WellDetails eachWellDetails = getF_IN_wellDetails();
        WellDetailsList wellsDetailsGrid = getF_IN_wellDetailsList();// getf_in
       
        Integer sno = 1;
        if (wellsDetailsGrid.getWellDetailsListCount() > 0) {
            for (WellDetails wellDtls : wellsDetailsGrid.getWellDetailsList()) {
                wellDtls.setSelect(false);
                sno++;
            }
        }
        WellDetails addRow = new WellDetails();
        BigDecimal airDepth = null;
        BigDecimal depth = null;
        BigDecimal wellDiameter = null;
        BFCurrencyAmount price = null;

        addRow.setAirDepth(airDepth);
        addRow.setDepth(depth);
        addRow.setNotes(CommonConstants.EMPTY_STRING);
        addRow.setPrice(price);
        addRow.setSno(sno);
        addRow.setWellDetailsID(CommonConstants.EMPTY_STRING);
        addRow.setWellDiameter(wellDiameter);
        addRow.setWellType(CommonConstants.EMPTY_STRING);
        addRow.setWellTypeDesc(CommonConstants.EMPTY_STRING);
        addRow.setSelect(true);
        wellsDetailsGrid.addWellDetailsList(addRow);
        setF_OUT_wellDetailsList(wellsDetailsGrid);
        setF_OUT_showBtn(false);
        setF_OUT_readOnlyNewWell(true);
    }

    private void addNewRow(BankFusionEnvironment env) {

        String CategoryType = getF_IN_category();// getf_in
        TitleDeedDetailsList titleDeedDtslList = getF_IN_titleDeedDtlsList();
        ValidateRequestEvaluationBB.validateTitleDeedNumResidential(getF_IN_titleDeedDtls());

        TitleDeedDetails singleTitleDeed = getF_IN_titleDeedDtls();
        TitleDeedDetails newTitleDeed = new TitleDeedDetails();
        ResidentialDetails residentialDetails = new ResidentialDetails();
        AgricultureDetails agricultureDetails = new AgricultureDetails();
        if (titleDeedDtslList.getTitleDeedDetailsListCount() > 0) {
           for(TitleDeedDetails DeedDtls : titleDeedDtslList.getTitleDeedDetailsList()) {
           // for (int i = 0; i < titleDeedDtslList.getTitleDeedDetailsListCount(); i++) {
                //if (titleDeedDtslList.getTitleDeedDetailsList(i).isSelect()) {
               if(DeedDtls.isSelect()) {  
                    //newTitleDeed = titleDeedDtslList.getTitleDeedDetailsList(i);
                    
                    if (CategoryType.equals("Agricultural")) {

                        agricultureDetails.setEvaluator("");
                        agricultureDetails.setStatus("");
                        agricultureDetails.setStatusDesc("");
                        agricultureDetails.setDescription(DeedDtls.getAgricultureDetails().getDescription());
                        agricultureDetails.setDistanceToMainRoad(DeedDtls.getAgricultureDetails().getDistanceToMainRoad());
                        agricultureDetails.setDunumPrice(DeedDtls.getAgricultureDetails().getDunumPrice());
                        agricultureDetails.setElectricityAvailable(DeedDtls.getAgricultureDetails().getElectricityAvailable());
                        agricultureDetails.setEligibleToFarm(DeedDtls.getAgricultureDetails().getEligibleToFarm());
                        agricultureDetails.setEvaluationDate(DeedDtls.getAgricultureDetails().getEvaluationDate());
                        agricultureDetails.setInsideFarmRoadType(DeedDtls.getAgricultureDetails().getInsideFarmRoadType());
                        agricultureDetails.setIsLocationMatching(DeedDtls.getAgricultureDetails().getIsLocationMatching());
                        agricultureDetails.setIsPlanMatching(DeedDtls.getAgricultureDetails().getIsPlanMatching());
                        agricultureDetails.setIsPrevMortgageAmt(DeedDtls.getAgricultureDetails().getIsPrevMortgageAmt());
                        agricultureDetails.setSelect(DeedDtls.getAgricultureDetails().getSelect());
                        agricultureDetails.setLandNetValue(DeedDtls.getAgricultureDetails().getLandNetValue());
                        //agricultureDetails.setLandTotalValue(DeedDtls.getAgricultureDetails());
                        agricultureDetails.setLastModifiedDate(DeedDtls.getAgricultureDetails().getLastModifiedDate());
                        agricultureDetails.setMortgageAmt(DeedDtls.getAgricultureDetails().getMortgageAmt());
                        agricultureDetails.setNearestCityName(DeedDtls.getAgricultureDetails().getNearestCityName());
                        agricultureDetails.setFarmSizeInDunum(DeedDtls.getAgricultureDetails().getFarmSizeInDunum()); 
                        agricultureDetails.setNearestCityDistance(DeedDtls.getAgricultureDetails().getNearestCityDistance());
                        //agricultureDetails.setNetCoverValue(netCoverValue);
                        agricultureDetails.setOthers(DeedDtls.getAgricultureDetails().getOthers());
                        agricultureDetails.setPhoneAvailable(DeedDtls.getAgricultureDetails().getPhoneAvailable());
                        //agricultureDetails.setTotalCoverValue(totalCoverValue);
                        agricultureDetails.setTypeOfRoad(DeedDtls.getAgricultureDetails().getTypeOfRoad());
                        agricultureDetails.setWaterAvailability(DeedDtls.getAgricultureDetails().getWaterAvailability());
                        agricultureDetails.setWateringMethod(DeedDtls.getAgricultureDetails().getWateringMethod());
                        agricultureDetails.setWaterInNeighbourArea(DeedDtls.getAgricultureDetails().getWaterInNeighbourArea());
                        
                        IBCommonUtils.intializeDefaultvalues(residentialDetails);
                        setF_OUT_hiddenBuildingDtlsList(getF_IN_hidden_buildingDtlsList());
                        setF_OUT_hidden_wellDtlsList(getF_IN_hidden_wellDtlsList());
                        setF_OUT_hidden_treesDtlsList(getF_IN_hidden_treesDtlsList());

                    } else if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {
                        residentialDetails.setEvaluator("");
                        residentialDetails.setStatus("");
                        residentialDetails.setStatusDesc("");
                        
                        residentialDetails.setBuildingAge(DeedDtls.getResidentialDetails().getBuildingAge());
                        residentialDetails.setBuiltArea(DeedDtls.getResidentialDetails().getBuiltArea());
                        residentialDetails.setCompoundWallHeight(DeedDtls.getResidentialDetails().getCompoundWallHeight());
                        residentialDetails.setConstructionLevel(DeedDtls.getResidentialDetails().getConstructionLevel());
                        residentialDetails.setDescription(DeedDtls.getResidentialDetails().getDescription());
                        residentialDetails.setEvaluationDate(DeedDtls.getResidentialDetails().getEvaluationDate());
                        residentialDetails.setHouseNo(DeedDtls.getResidentialDetails().getHouseNo());
                        residentialDetails.setIsBuilding(DeedDtls.getResidentialDetails().getIsBuilding());
                        residentialDetails.setIsLocationMatching(DeedDtls.getResidentialDetails().getIsLocationMatching());
                        residentialDetails.setIsPlanMatching(DeedDtls.getResidentialDetails().getIsPlanMatching());
                        residentialDetails.setIsPrevMortgageAmt(DeedDtls.getResidentialDetails().getIsPrevMortgageAmt());
                        residentialDetails.setLandArea(DeedDtls.getResidentialDetails().getLandArea());
                        residentialDetails.setLastModifiedDate(DeedDtls.getResidentialDetails().getLastModifiedDate());
                        //residentialDetails.setNetEvaluationValue(DeedDtls.getResidentialDetails().getNetEvaluationValue());
                        residentialDetails.setMortgageAmt(DeedDtls.getResidentialDetails().getMortgageAmt());
                        residentialDetails.setNoOfFloors(DeedDtls.getResidentialDetails().getNoOfFloors());
                        residentialDetails.setPricePerBuildSqM(DeedDtls.getResidentialDetails().getPricePerBuildSqM());
                        residentialDetails.setPricePerSqM(DeedDtls.getResidentialDetails().getPricePerSqM());
                        residentialDetails.setPropertySize(DeedDtls.getResidentialDetails().getPropertySize());
                        residentialDetails.setQuality(DeedDtls.getResidentialDetails().getQuality());
                        residentialDetails.setResidentialDetailsID(DeedDtls.getResidentialDetails().getResidentialDetailsID());
                        residentialDetails.setSelect(false);
                        residentialDetails.setShadowPrice(DeedDtls.getResidentialDetails().getShadowPrice());
                        residentialDetails.setShadowSize(DeedDtls.getResidentialDetails().getShadowSize());
                        residentialDetails.setStreetName1(DeedDtls.getResidentialDetails().getStreetName1());
                        residentialDetails.setStreetName2(DeedDtls.getResidentialDetails().getStreetName2());
                        residentialDetails.setStreetName3(DeedDtls.getResidentialDetails().getStreetName3());
                        residentialDetails.setStreetName4(DeedDtls.getResidentialDetails().getStreetName4());
                        residentialDetails.setStreetsTypes(DeedDtls.getResidentialDetails().getStreetsTypes());
                        //residentialDetails.setTotalEvaluationValue(DeedDtls.getResidentialDetails().getTotalEvaluationValue());
                        residentialDetails.setUtilityAreaSize(DeedDtls.getResidentialDetails().getUtilityAreaSize());
                        residentialDetails.setUtilityPrice(DeedDtls.getResidentialDetails().getUtilityPrice());
                        residentialDetails.setWallPrice(DeedDtls.getResidentialDetails().getWallPrice());
                        
                        IBCommonUtils.intializeDefaultvalues(agricultureDetails);
                        

                    }

                    DeedDtls.setSelect(false);

                    CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom();
                    customAutoNumFatom.setF_IN_BONAME("TITLEDEEDEVALUATION");
                    customAutoNumFatom.setF_IN_IsRightPad(false);
                    customAutoNumFatom.setF_IN_Prefix("TD");
                    customAutoNumFatom.setF_IN_Suffix("");
                    customAutoNumFatom.setF_IN_TotalLength(0);
                    customAutoNumFatom.process(env);
                    String Id = customAutoNumFatom.getF_OUT_PrimKey();
                    newTitleDeed.setEvaluationId(Id);
                   
                    
                    newTitleDeed.setAgricultureDetails(agricultureDetails);
                    newTitleDeed.setResidentialDetails(residentialDetails );
                    newTitleDeed.setLandPlotNum(DeedDtls.getLandPlotNum());
                    newTitleDeed.setPlan(DeedDtls.getPlan());
                    newTitleDeed.setRequestID(DeedDtls.getRequestID());
                    newTitleDeed.setSelect(true);
                    newTitleDeed.setSource(DeedDtls.getSource());
                    newTitleDeed.setTitleDeedIDPK(DeedDtls.getTitleDeedIDPK());
                    newTitleDeed.setTitleDeedNum(DeedDtls.getTitleDeedNum());
                    newTitleDeed.setTitleDeedVersionNum(DeedDtls.getTitleDeedVersionNum());
                    newTitleDeed.setType(DeedDtls.getType());
                    newTitleDeed.setYear(DeedDtls.getYear());
                    /*newTitleDeed.setSelect(true);*/
                    
                }
                
                
                
            
            }
           titleDeedDtslList.addTitleDeedDetailsList(newTitleDeed);
            //titleDeedDtslList.getTitleDeedDetailsList(titleDeedDtslList.getTitleDeedDetailsListCount()-1).setSelect(true);
        } else {
            if (CategoryType.equals("Agricultural")) {

                singleTitleDeed.getAgricultureDetails().setDescription(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setDistanceToMainRoad(CommonConstants.EMPTY_STRING);
                BFCurrencyAmount dunumPrice = new BFCurrencyAmount();
                dunumPrice.setCurrencyAmount(BigDecimal.ZERO);
                dunumPrice.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setDunumPrice(dunumPrice);
                singleTitleDeed.getAgricultureDetails().setElectricityAvailable(false);
                singleTitleDeed.getAgricultureDetails().setEligibleToFarm(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setEvaluationDate(IBCommonUtils.getBFBusinessDate());
                singleTitleDeed.getAgricultureDetails().setEvaluator(CommonConstants.EMPTY_STRING);
                //BigDecimal farmSizeInDunum = null;
                singleTitleDeed.getAgricultureDetails().setFarmSizeInDunum(BigDecimal.ZERO);
                singleTitleDeed.getAgricultureDetails().setInsideFarmRoadType(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setIsLocationMatching(false);
                singleTitleDeed.getAgricultureDetails().setIsPlanMatching(false);
                singleTitleDeed.getAgricultureDetails().setIsPrevMortgageAmt(false);
                singleTitleDeed.getAgricultureDetails().setSelect(false);
                BFCurrencyAmount landNetVal = new BFCurrencyAmount();
                landNetVal.setCurrencyAmount(BigDecimal.ZERO);
                landNetVal.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setLandNetValue(landNetVal);
                BFCurrencyAmount landTotalVal = new BFCurrencyAmount();
                landTotalVal.setCurrencyAmount(BigDecimal.ZERO);
                landTotalVal.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setLandTotalValue(landTotalVal);
                Timestamp lastModDate = null;
                singleTitleDeed.getAgricultureDetails().setLastModifiedDate(lastModDate);
                BFCurrencyAmount mortgageAmt = new BFCurrencyAmount();
                mortgageAmt.setCurrencyAmount(BigDecimal.ZERO);
                mortgageAmt.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setMortgageAmt(mortgageAmt);
                BigDecimal nearestCityDis = null;
                singleTitleDeed.getAgricultureDetails().setNearestCityDistance(nearestCityDis);
                BFCurrencyAmount netCoverValue = new BFCurrencyAmount();
                netCoverValue.setCurrencyAmount(BigDecimal.ZERO);
                netCoverValue.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setNetCoverValue(netCoverValue);
                singleTitleDeed.getAgricultureDetails().setOthers(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setPhoneAvailable(false);
                singleTitleDeed.getAgricultureDetails().setStatus(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setStatusDesc(CommonConstants.EMPTY_STRING);
                BFCurrencyAmount totalCoverValue = new BFCurrencyAmount();
                totalCoverValue.setCurrencyAmount(BigDecimal.ZERO);
                totalCoverValue.setCurrencyCode("");
                singleTitleDeed.getAgricultureDetails().setTotalCoverValue(totalCoverValue);
                singleTitleDeed.getAgricultureDetails().setTypeOfRoad(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setWaterAvailability(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setWateringMethod(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getAgricultureDetails().setWaterInNeighbourArea(CommonConstants.EMPTY_STRING);
                setF_OUT_hiddenBuildingDtlsList(getF_IN_hidden_buildingDtlsList());
                setF_OUT_hidden_wellDtlsList(getF_IN_hidden_wellDtlsList());
                setF_OUT_hidden_treesDtlsList(getF_IN_hidden_treesDtlsList());
            }

            if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {

                BigDecimal buildingAge = null;
                singleTitleDeed.getResidentialDetails().setBuildingAge(buildingAge);
                //BigDecimal builtArea = null;
                singleTitleDeed.getResidentialDetails().setBuiltArea(BigDecimal.ZERO);
                //BigDecimal compundWallHeight = null;
                singleTitleDeed.getResidentialDetails().setCompoundWallHeight(BigDecimal.ZERO);
                singleTitleDeed.getResidentialDetails().setConstructionLevel(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setDescription(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setSelect(false);
                singleTitleDeed.getResidentialDetails().setEvaluationDate(IBCommonUtils.getBFBusinessDate());
                singleTitleDeed.getResidentialDetails().setEvaluator(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setHouseNo(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setIsBuilding(false);
                singleTitleDeed.getResidentialDetails().setIsLocationMatching(false);
                singleTitleDeed.getResidentialDetails().setIsPlanMatching(false);
                singleTitleDeed.getResidentialDetails().setIsPrevMortgageAmt(false);
                BFCurrencyAmount newEvalValue = new BFCurrencyAmount();
                newEvalValue.setCurrencyAmount(BigDecimal.ZERO);
                newEvalValue.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setNetEvaluationValue(newEvalValue);
                Integer noOfFloors = null;
                singleTitleDeed.getResidentialDetails().setNoOfFloors(noOfFloors);
                BFCurrencyAmount pricePerBuildSqM = new BFCurrencyAmount();
                pricePerBuildSqM.setCurrencyAmount(BigDecimal.ZERO);
                pricePerBuildSqM.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setPricePerBuildSqM(pricePerBuildSqM);
                BFCurrencyAmount pricePerSqM = new BFCurrencyAmount();
                pricePerSqM.setCurrencyAmount(BigDecimal.ZERO);
                pricePerSqM.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setPricePerSqM(pricePerSqM);
                BigDecimal propertySize = BigDecimal.ZERO;
                singleTitleDeed.getResidentialDetails().setPropertySize(propertySize);
                singleTitleDeed.getResidentialDetails().setQuality(CommonConstants.EMPTY_STRING);
                BFCurrencyAmount shadowPrice = new BFCurrencyAmount();
                shadowPrice.setCurrencyAmount(BigDecimal.ZERO);
                shadowPrice.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setShadowPrice(shadowPrice);
                //BigDecimal shadowSize = null;
                singleTitleDeed.getResidentialDetails().setShadowSize(BigDecimal.ZERO);
                singleTitleDeed.getResidentialDetails().setStatus(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStatusDesc(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStreetName1(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStreetName2(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStreetName3(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStreetName4(CommonConstants.EMPTY_STRING);
                singleTitleDeed.getResidentialDetails().setStreetsTypes(CommonConstants.EMPTY_STRING);
                BFCurrencyAmount totalEvaluationValue = new BFCurrencyAmount();
                totalEvaluationValue.setCurrencyAmount(BigDecimal.ZERO);
                totalEvaluationValue.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setTotalEvaluationValue(totalEvaluationValue);
                //BigDecimal utilityAreaSize = null;
                singleTitleDeed.getResidentialDetails().setUtilityAreaSize(BigDecimal.ZERO);
                BFCurrencyAmount utilityPrice = new BFCurrencyAmount();
                utilityPrice.setCurrencyAmount(BigDecimal.ZERO);
                utilityPrice.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setUtilityPrice(utilityPrice);
                BFCurrencyAmount wallPrice = new BFCurrencyAmount();
                wallPrice.setCurrencyAmount(BigDecimal.ZERO);
                wallPrice.setCurrencyCode("");
                singleTitleDeed.getResidentialDetails().setWallPrice(wallPrice);
            }

            singleTitleDeed.setSelect(true);
            CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom();

            customAutoNumFatom.setF_IN_BONAME("TITLEDEEDEVALUATION");
            customAutoNumFatom.setF_IN_IsRightPad(false);
            customAutoNumFatom.setF_IN_Prefix("TD");
            customAutoNumFatom.setF_IN_Suffix("");
            customAutoNumFatom.setF_IN_TotalLength(0);
            customAutoNumFatom.process(env);
            String Id = customAutoNumFatom.getF_OUT_PrimKey();

            singleTitleDeed.setEvaluationId(Id);
            
            if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {
                 String titleDeedNum = singleTitleDeed.getTitleDeedNum();
                 String whereClause = " WHERE " + IBOCE_IB_ResidentialRquestDetails.IBTITLEDEEDNUM + " = ? AND " + IBOCE_IB_ResidentialRquestDetails.IBSTATUS + " = ? ";
                 ArrayList params = new ArrayList<>();
                 params.add(titleDeedNum);
                 params.add("Selected");
                 List<IBOCE_IB_ResidentialRquestDetails> resi =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_ResidentialRquestDetails.BONAME, whereClause , params ,null, false);
                 if(resi.size()>0) {
                     IBOCE_IB_ResidentialRquestDetails resiObj = resi.get(0);
                     //IBCommonUtils.intializeDefaultvalues(resiObj);
                     
                     String whereClauseDeal = " WHERE " + IBOCE_IB_DealCollateralDtls.IBTITLEDEEDNUM + " = ? ";
                     ArrayList parameter = new ArrayList<>();
                     parameter.add(resiObj.getF_IBTITLEDEEDNUM());
                     List<IBOCE_IB_DealCollateralDtls> DealCollateral = null ;
                     if(BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClauseDeal, parameter ,null, false)!=null) {
                         DealCollateral =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClauseDeal, parameter ,null, false);
                     }
                     
                     
                     if(DealCollateral!=null ||!DealCollateral.isEmpty()) {
                     
                         CustomAutoNumFatom customAutoNumFatom1 = new CustomAutoNumFatom();

                         customAutoNumFatom1.setF_IN_BONAME("TITLEDEEDEVALUATION");
                         customAutoNumFatom1.setF_IN_IsRightPad(false);
                         customAutoNumFatom1.setF_IN_Prefix("TD");
                         customAutoNumFatom1.setF_IN_Suffix("");
                         customAutoNumFatom1.setF_IN_TotalLength(0);
                         customAutoNumFatom1.process(env);
                         String NewId = customAutoNumFatom1.getF_OUT_PrimKey();
                         singleTitleDeed.setEvaluationId(NewId);
                         singleTitleDeed.getResidentialDetails().getTotalEvaluationValue().setCurrencyAmount(resiObj.getF_IBTOTALEVALUATIONVALUE());
                     singleTitleDeed.getResidentialDetails().getNetEvaluationValue().setCurrencyAmount(resiObj.getF_IBNETEVALUATIONVALUE());
                     
                     singleTitleDeed.getResidentialDetails().setEvaluationDate(resiObj.getF_IBEVALUATIONDATE());
                     singleTitleDeed.getResidentialDetails().setPropertySize(resiObj.getF_IBPROPERTYSIZE());
                     singleTitleDeed.getResidentialDetails().setHouseNo(resiObj.getF_IBHOUSENUMBER());
                     IslamicBankingObject ibo = getF_IN_islamicBankingObject();
                     BFCurrencyAmount mortgageAmount = new BFCurrencyAmount();
                     BFCurrencyAmount s = CalculationRequestEvaluationUtils.getMortgageAmtForResidential(resiObj.getF_IBTITLEDEEDNUM(), ibo);
                     IBCommonUtils.intializeDefaultvalues(mortgageAmount);
                     //mortgageAmount.setCurrencyAmount(BigDecimal.TEN);
                     if(s!=null && s.getCurrencyAmount().compareTo(BigDecimal.ZERO)>0) {
                         singleTitleDeed.getResidentialDetails().setIsPrevMortgageAmt(true);
                         singleTitleDeed.getResidentialDetails().getMortgageAmt().setCurrencyAmount(s.getCurrencyAmount());
                     }else {
                         mortgageAmount.setCurrencyAmount(BigDecimal.ZERO);
                         singleTitleDeed.getResidentialDetails().setIsPrevMortgageAmt(false);
                         singleTitleDeed.getResidentialDetails().setMortgageAmt(mortgageAmount);
                     }
                     
                     
                     //singleTitleDeed.getResidentialDetails().setIsPrevMortgageAmt(true);
                     //singleTitleDeed.getResidentialDetails().getMortgageAmt().setCurrencyAmount(resiObj.getF_IBMORTGAGEAMT());
                     singleTitleDeed.getResidentialDetails().setIsPlanMatching(resiObj.isF_IBISPLANMATCHING());
                     singleTitleDeed.getResidentialDetails().setIsLocationMatching(resiObj.isF_IBISLOCATIONMATCHING());
                     singleTitleDeed.getResidentialDetails().setStreetsTypes(resiObj.getF_IBSTREETTYPES());
                     singleTitleDeed.getResidentialDetails().setStreetName1(resiObj.getF_IBSTREETNAME1());
                     singleTitleDeed.getResidentialDetails().setStreetName2(resiObj.getF_IBSTREETNAME2());
                     singleTitleDeed.getResidentialDetails().setStreetName3(resiObj.getF_IBSTREETNAME3());
                     singleTitleDeed.getResidentialDetails().setStreetName4(resiObj.getF_IBSTREETNAME4());
                     singleTitleDeed.getResidentialDetails().setIsBuilding(resiObj.isF_IBISBUILDING());
                     singleTitleDeed.getResidentialDetails().setConstructionLevel(resiObj.getF_IBCONSTRUCTIONLEVEL());
                     singleTitleDeed.getResidentialDetails().setQuality(resiObj.getF_IBQUALITY());
                     singleTitleDeed.getResidentialDetails().setBuildingAge(resiObj.getF_IBBUILDINGAGE());
                     singleTitleDeed.getResidentialDetails().setNoOfFloors(resiObj.getF_IBNUMBEROFFLOORS());
                     singleTitleDeed.getResidentialDetails().setLandArea(resiObj.getF_IBLANDAREA());
                     singleTitleDeed.getResidentialDetails().getPricePerBuildSqM().setCurrencyAmount(resiObj.getF_IBPRICEPERBUILDINGSQM());
                     singleTitleDeed.getResidentialDetails().setBuiltArea(resiObj.getF_IBBUILTAREA());
                     singleTitleDeed.getResidentialDetails().getPricePerSqM().setCurrencyAmount(resiObj.getF_IBPRICEPERSQM());
                     singleTitleDeed.getResidentialDetails().setShadowSize(resiObj.getF_IBSHADOWSIZE());
                     singleTitleDeed.getResidentialDetails().getShadowPrice().setCurrencyAmount(resiObj.getF_IBSHADOWPRICE());
                     singleTitleDeed.getResidentialDetails().setCompoundWallHeight(resiObj.getF_IBCOMPUNDWALLHEIGHT());
                     singleTitleDeed.getResidentialDetails().getWallPrice().setCurrencyAmount(resiObj.getF_IBWALLPRICE());
                     singleTitleDeed.getResidentialDetails().setUtilityAreaSize(resiObj.getF_IBUTILITYAREASIZE());
                     singleTitleDeed.getResidentialDetails().getUtilityPrice().setCurrencyAmount(resiObj.getF_IBUTILITYPRICE());
                     singleTitleDeed.getResidentialDetails().setDescription(resiObj.getF_IBDESCRIPTION());
                     
                 }
                 }
            }
            if(CategoryType.equals("Agricultural")) {
               String titleDeedNum = singleTitleDeed.getTitleDeedNum();
               String whereClause = " WHERE " + IBOCE_IB_AgricultureRequestDetails.IBTITLEDEEDNUM + " = ? AND " + IBOCE_IB_AgricultureRequestDetails.IBSTATUS + " = ? ";
            ArrayList params = new ArrayList<>();
            params.add(titleDeedNum);
            params.add("Selected");
            List<IBOCE_IB_AgricultureRequestDetails> agri =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_AgricultureRequestDetails.BONAME, whereClause , params ,null, false);
            if(agri.size()>0) {
            IBOCE_IB_AgricultureRequestDetails agriObj = agri.get(0);
            String requestIDAgri =  agriObj.getF_IBREQUESTID();
            String whereClauseDeal = " WHERE " + IBOCE_IB_DealCollateralDtls.IBTITLEDEEDNUM + " = ? ";
            ArrayList parameter = new ArrayList<>();
            parameter.add(agriObj.getF_IBTITLEDEEDNUM());
            List<IBOCE_IB_DealCollateralDtls> DealCollateral=  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClauseDeal  , parameter  ,null, false);
            
            if(!DealCollateral.isEmpty()) {
                CustomAutoNumFatom customAutoNumFatom1 = new CustomAutoNumFatom();

                customAutoNumFatom1.setF_IN_BONAME("TITLEDEEDEVALUATION");
                customAutoNumFatom1.setF_IN_IsRightPad(false);
                customAutoNumFatom1.setF_IN_Prefix("TD");
                customAutoNumFatom1.setF_IN_Suffix("");
                customAutoNumFatom1.setF_IN_TotalLength(0);
                customAutoNumFatom1.process(env);
                String NewId = customAutoNumFatom1.getF_OUT_PrimKey();
                singleTitleDeed.setEvaluationId(NewId);
            singleTitleDeed.getAgricultureDetails().getTotalCoverValue().setCurrencyAmount(agriObj.getF_IBTOTALCOVERVALUE());
            singleTitleDeed.getAgricultureDetails().getNetCoverValue().setCurrencyAmount(agriObj.getF_IBNETCOVERVALUE());
            singleTitleDeed.getAgricultureDetails().setEvaluationDate(agriObj.getF_IBEVALUATIONDATE());
             BFCurrencyAmount mortgageAmount = new BFCurrencyAmount();
             BFCurrencyAmount s = CalculationRequestEvaluationUtils.getMortgageAmtForAgriculture(agriObj.getF_IBTITLEDEEDNUM(), getF_IN_islamicBankingObject());
             IBCommonUtils.intializeDefaultvalues(mortgageAmount);
             //mortgageAmount.setCurrencyAmount(BigDecimal.TEN);
             if(s!=null || s.getCurrencyAmount().compareTo(BigDecimal.ZERO)>0) {
                 
                 singleTitleDeed.getAgricultureDetails().setIsPrevMortgageAmt(true);
                 singleTitleDeed.getAgricultureDetails().getMortgageAmt().setCurrencyAmount(s.getCurrencyAmount());
                 
             }else {
                 mortgageAmount.setCurrencyAmount(BigDecimal.ZERO);
                 singleTitleDeed.getAgricultureDetails().setIsPrevMortgageAmt(false);
                 singleTitleDeed.getAgricultureDetails().setMortgageAmt(mortgageAmount);
                 
             }
             
             
            singleTitleDeed.getAgricultureDetails().setIsPlanMatching(agriObj.isF_IBISPLANMATCHING());
            singleTitleDeed.getAgricultureDetails().setIsLocationMatching(agriObj.isF_IBISLOCATIONMATCHING());
            singleTitleDeed.getAgricultureDetails().setNearestCityDistance(agriObj.getF_IBNEARESTCITYDISTANCE());
            singleTitleDeed.getAgricultureDetails().setNearestCityName(agriObj.getF_IBNEARESTCITYNAME());
            singleTitleDeed.getAgricultureDetails().setDistanceToMainRoad(agriObj.getF_IBDISTANCETOMAINROAD());
            singleTitleDeed.getAgricultureDetails().setWaterAvailability(agriObj.getF_IBWATERAVAILABILITY());
            singleTitleDeed.getAgricultureDetails().setWaterInNeighbourArea(agriObj.getF_IBWATREINNEIGHBOURSAREA());
            singleTitleDeed.getAgricultureDetails().setTypeOfRoad(agriObj.getF_IBTYPEOFROAD());
            singleTitleDeed.getAgricultureDetails().setEligibleToFarm(agriObj.getF_IBELIGIBLETOFARM());
            singleTitleDeed.getAgricultureDetails().setWateringMethod(agriObj.getF_IBWATERINGMETHOD());
            singleTitleDeed.getAgricultureDetails().setInsideFarmRoadType(agriObj.getF_IBINSIDEFARMROADTYPE());
            singleTitleDeed.getAgricultureDetails().setFarmSizeInDunum(agriObj.getF_IBFARMSIZEINDUNUM());
            singleTitleDeed.getAgricultureDetails().setOthers(agriObj.getF_IBOTHERS());
            singleTitleDeed.getAgricultureDetails().setElectricityAvailable(agriObj.isF_IBELECTIRCITYAVAILABLE());
            singleTitleDeed.getAgricultureDetails().setPhoneAvailable(agriObj.isF_IBPHONEAVAILABLE());
            singleTitleDeed.getAgricultureDetails().getLandTotalValue().setCurrencyAmount(agriObj.getF_IBLANDTOTALVALUE());
            singleTitleDeed.getAgricultureDetails().getLandNetValue().setCurrencyAmount(agriObj.getF_IBLANDNETVALUE());        singleTitleDeed.getAgricultureDetails().getDunumPrice().setCurrencyAmount(agriObj.getF_IBDUNUMPRICE());
            
            //set Trees if available

            String treeClause = " WHERE " + IBOCE_IB_TreeDetails.IBEVALUATIONID + " = ? ";
            ArrayList treeParam = new ArrayList<>();
            treeParam.add(agriObj.getF_IBEVALUATIONID());
            List<IBOCE_IB_TreeDetails> trees =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_TreeDetails.BONAME, treeClause   , treeParam   ,null, false);
            
            TreesDetailsList TDList = getF_IN_hidden_treesDtlsList();
            if(trees.size()>0) {

                for(IBOCE_IB_TreeDetails eachTree : trees) {
                    if(eachTree.getF_IBREQUESTID().equals(requestIDAgri)){
                    TreeDetails tree = new TreeDetails();
                    tree.setAgricultureDetailsID(eachTree.getF_IBAGREECULTUREDTLSID());
                    tree.setCost(IBCommonUtils.getBFCurrencyAmount(eachTree.getF_IBCOST(), getF_IN_islamicBankingObject().getCurrency()));
                    tree.setEvaluationId(NewId);
                    tree.setNoOfTrees(eachTree.getF_IBNOOFTREES());
                    tree.setNotes(eachTree.getF_IBNOTES());
                    tree.setPricePerTree(IBCommonUtils.getBFCurrencyAmount(eachTree.getF_IBPRICEPERTREE(), getF_IN_islamicBankingObject().getCurrency()));

                    tree.setSno(eachTree.getF_IBSNO());
                    tree.setTitleDeedIDPK(eachTree.getF_IBTITLEDEEDID());
                    tree.setTitleDeedNum(eachTree.getF_IBTITLEDEEDNUM());
                    tree.setTreeAge(eachTree.getF_IBTREEAGE());
                    tree.setTreeDetailsID(eachTree.getBoID());
                    tree.setTreeType(eachTree.getF_IBTREETYPE());
                    
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("TREE_GRP_TYP");
                    String Desc = "";

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                      if (eachTree.getF_IBTREETYPE().equals(gcCode.getCodeReference())) {
                        Desc = gcCode.getCodeDescription();
                        break;
                      }
                    }
                    tree.setTreeTypeDesc(Desc);
                    TDList.addTreesDetailsList(tree);
                }
                }
             
            }
            setF_OUT_hidden_treesDtlsList(TDList);

            //set wells if available
            String wellClause = " WHERE " + IBOCE_IB_WellDetails.IBEVALUATIONID + " = ? ";
            ArrayList wellParam = new ArrayList<>();
            wellParam.add(agriObj.getF_IBEVALUATIONID());
            List<IBOCE_IB_WellDetails> wells =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_WellDetails.BONAME, wellClause, wellParam,null, false);
            WellDetailsList WLList = getF_IN_hidden_wellDtlsList();
            if(wells.size()>0) {

                for(IBOCE_IB_WellDetails eachWell : wells) {
                    if(eachWell.getF_IBREQUESTID().equals(requestIDAgri)){
                    WellDetails eachWellDtl = new WellDetails();
                    eachWellDtl.setAgricultureDetailsID(eachWell.getF_IBAGRICULTUREDTLSID());
                    eachWellDtl.setAirDepth(eachWell.getF_IBAIRDEPTH());
                    eachWellDtl.setDepth(eachWell.getF_IBDEPTH());
                    eachWellDtl.setEvaluationId(NewId);
                    eachWellDtl.setNotes(eachWell.getF_IBNOTES());
                    eachWellDtl.setPrice(IBCommonUtils.getBFCurrencyAmount(eachWell.getF_IBPRICE(), getF_IN_islamicBankingObject().getCurrency()));
                    
                    eachWellDtl.setSno(eachWell.getF_IBSNO());
                    eachWellDtl.setTitleDeedIDPK(eachWell.getF_IBTITLEDEEDID());
                    eachWellDtl.setTitleDeedNum(eachWell.getF_IBTITLEDEEDNUM());
                    eachWellDtl.setWellDetailsID(eachWell.getBoID());
                    eachWellDtl.setWellDiameter(eachWell.getF_IBWELLDIAMETER());
                    eachWellDtl.setWellType(eachWell.getF_IBWELLTYPE());
                    
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("WELL_TYP");
                    String Desc = "";

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                      if (eachWell.getF_IBWELLTYPE().equals(gcCode.getCodeReference())) {
                        Desc = gcCode.getCodeDescription();
                        break;
                      }
                    }
                    eachWellDtl.setWellTypeDesc(Desc);
                    WLList.addWellDetailsList(eachWellDtl);
                }

                }
               
            }
                
                setF_OUT_hidden_wellDtlsList(WLList);
            
            
            
            //set buildings if available
            String buildingClause = " WHERE " + IBOCE_IB_BuildingDetails.IBEVALUATIONID + " = ? ";
            ArrayList buildingParam = new ArrayList<>();
            buildingParam.add(agriObj.getF_IBEVALUATIONID());
            List<IBOCE_IB_BuildingDetails> buildings =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_BuildingDetails.BONAME, buildingClause, buildingParam, null, false);
            
            BuildingsDetailsList BLDList = getF_IN_hidden_buildingDtlsList();
            if(wells.size()>0) {

                for(IBOCE_IB_BuildingDetails buildingDetail: buildings) {
                    if(buildingDetail.getF_IBREQUESTID().equals(requestIDAgri)){
                    BuildingDetails build = new BuildingDetails();
                    build.setAgricultureDetailsID(buildingDetail.getF_IBAGREECULTUREDTLSID());
                    build.setBuildingAge(buildingDetail.getF_IBBUILDINGAGE());
                    build.setBuildingDetailsID(buildingDetail.getBoID());
                    build.setBuildingsize(buildingDetail.getF_IBBUILDINGSIZE());
                    build.setBuildingType(buildingDetail.getF_IBBUILDINGTYPE());
                    build.setEvaluationId(NewId);
                    build.setCost(IBCommonUtils.getBFCurrencyAmount(buildingDetail.getF_IBCOST(), getF_IN_islamicBankingObject().getCurrency()));
                    build.setNotes(buildingDetail.getF_IBNOTES());
                    build.setPricePerSqM(IBCommonUtils.getBFCurrencyAmount(buildingDetail.getF_IBPRICEPERSQM(), getF_IN_islamicBankingObject().getCurrency()));
                    build.setSno(buildingDetail.getF_IBSNO());
                    build.setTitleDeedIDPK(buildingDetail.getF_IBTITLEDEEDID());
                    build.setTitleDeedNum(buildingDetail.getF_IBTITLEDEEDNUM());
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("BLD_GRP_TYP");
                    String statusDesc = null;

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                        if (buildingDetail.getF_IBBUILDINGTYPE().equals(gcCode.getCodeReference())) {
                            statusDesc = gcCode.getCodeDescription();

                            break;
                        }
                    }

                    build.setBuildingTypeDesc(statusDesc);
                    BLDList.addBuildingsDetailsList(build);
                }
                }
               
            }
                setF_OUT_hiddenBuildingDtlsList(BLDList);
            
            
            }
            } 
            }
            titleDeedDtslList.addTitleDeedDetailsList(singleTitleDeed);
        }
        
        
        setF_OUT_readOnlyNewResidential(true);
        setF_OUT_readOnlyNewAgriculture(true);
        setF_OUT_titleDeedDtlsList(titleDeedDtslList);
        // }
        setF_OUT_showBtn(false);

    }

    private void saveRowofTrees(BankFusionEnvironment env) {

        TreeDetails eachTreeDetails = getF_IN_treeDetails();
        TreesDetailsList treeDetailsGrid = getF_IN_treeDetailsList();
        Boolean flag = true;
        if(eachTreeDetails.getTreeType().isEmpty() || eachTreeDetails.getTreeAge()==null ||
                eachTreeDetails.getNoOfTrees()==null || eachTreeDetails.getPricePerTree()==null || eachTreeDetails.getCost()==null) {
            IBCommonUtils.raiseUnparameterizedEvent(35100145);
            flag = false;
        }

        if(flag) {
        if (treeDetailsGrid.getTreesDetailsListCount() > 0) {
            for (TreeDetails eachTreeDetailFromGrid : treeDetailsGrid.getTreesDetailsList()) {
                if (eachTreeDetailFromGrid.isSelect()) {

                    String evaluationID = null;
                    for (TitleDeedDetails TD : getF_IN_titleDeedDtlsList().getTitleDeedDetailsList()) {
                        if(TD.isSelect()) {
                            evaluationID = TD.getEvaluationId();
                        }
                    }
                    eachTreeDetailFromGrid.setEvaluationId(evaluationID);
                    eachTreeDetailFromGrid.setCost(eachTreeDetails.getCost());
                    eachTreeDetailFromGrid.setNoOfTrees(eachTreeDetails.getNoOfTrees());
                    eachTreeDetailFromGrid.setNotes(eachTreeDetails.getNotes());
                    eachTreeDetailFromGrid.setPricePerTree(eachTreeDetails.getPricePerTree());
                    eachTreeDetailFromGrid.setSno(eachTreeDetails.getSno());
                    eachTreeDetailFromGrid.setTreeAge(eachTreeDetails.getTreeAge());
                    eachTreeDetailFromGrid.setTreeDetailsID(eachTreeDetails.getTreeDetailsID());
                    
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("TREE_GRP_TYP");
                    String statusDesc = null;

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                        if (eachTreeDetails.getTreeType().equals(gcCode.getCodeReference())) {
                            statusDesc = gcCode.getCodeDescription();

                            break;
                        }
                    }

                    eachTreeDetailFromGrid.setTreeType(eachTreeDetails.getTreeType());
                    eachTreeDetailFromGrid.setTreeTypeDesc(statusDesc);

                }

            }
        }
        }
        setF_OUT_treeDetailsList(treeDetailsGrid);
        setF_OUT_readOnlyNewTree(false);
    }

    private void saveRowofBuildings(BankFusionEnvironment env) {

        BuildingDetails buildingDetail = getF_IN_buildingDetails();
        BuildingsDetailsList buildingDetailsGrid = getF_IN_buildingDetailsList();
        
        Boolean flag = true;
        if(buildingDetail.getBuildingType()==null || buildingDetail.getBuildingType().isEmpty() || buildingDetail.getBuildingAge()==null || buildingDetail.getBuildingsize()==null || buildingDetail.getPricePerSqM()==null) {
            IBCommonUtils.raiseUnparameterizedEvent(35100145);
            flag = false;
        }
        
        if(flag) {

        if (buildingDetailsGrid.getBuildingsDetailsListCount() > 0) {
            for (BuildingDetails eachBuildingDetailFromGrid : buildingDetailsGrid.getBuildingsDetailsList()) {
                if (eachBuildingDetailFromGrid.isSelect()) {

                    eachBuildingDetailFromGrid.setBuildingAge(buildingDetail.getBuildingAge());
                    eachBuildingDetailFromGrid.setBuildingDetailsID(buildingDetail.getBuildingDetailsID());
                    eachBuildingDetailFromGrid.setBuildingsize(buildingDetail.getBuildingsize());
                    eachBuildingDetailFromGrid.setBuildingType(buildingDetail.getBuildingType());

                    String evaluationID = null;
                    for (TitleDeedDetails TD : getF_IN_titleDeedDtlsList().getTitleDeedDetailsList()) {
                        if(TD.isSelect()) {
                            evaluationID = TD.getEvaluationId();
                        }
                    }
                    eachBuildingDetailFromGrid.setEvaluationId(evaluationID);
                    
                    eachBuildingDetailFromGrid.setCost(buildingDetail.getCost());
                    eachBuildingDetailFromGrid.setNotes(buildingDetail.getNotes());
                    eachBuildingDetailFromGrid.setPricePerSqM(buildingDetail.getPricePerSqM());
                    eachBuildingDetailFromGrid.setSno(buildingDetail.getSno());
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("BLD_GRP_TYP");
                    String statusDesc = null;

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                        if (buildingDetail.getBuildingType().equals(gcCode.getCodeReference())) {
                            statusDesc = gcCode.getCodeDescription();

                            break;
                        }
                    }

                    eachBuildingDetailFromGrid.setBuildingTypeDesc(statusDesc);

                }

            }
        }
        }
        setF_OUT_buildingDetailsList(buildingDetailsGrid);
        setF_OUT_readOnlyNewBuilding(false);
       
    }

    private void saveRowofWells(BankFusionEnvironment env) {

        WellDetails eachWellDetails = getF_IN_wellDetails();
        WellDetailsList wellDetailsGrid = getF_IN_wellDetailsList();
        
        Boolean flag = true;
        if(eachWellDetails.getWellType().isEmpty() || eachWellDetails.getDepth()==null || eachWellDetails.getAirDepth()==null ||
                eachWellDetails.getWellDiameter()==null || eachWellDetails.getPrice()==null) {
            IBCommonUtils.raiseUnparameterizedEvent(35100145);
            flag = false;
        }

        if(flag) {
        if (wellDetailsGrid.getWellDetailsListCount() > 0) {
            for (WellDetails eachWellDetailFromGrid : wellDetailsGrid.getWellDetailsList()) {
                if (eachWellDetailFromGrid.isSelect()) {

                    eachWellDetailFromGrid.setAirDepth(eachWellDetails.getAirDepth());
                    eachWellDetailFromGrid.setDepth(eachWellDetails.getDepth());
                    eachWellDetailFromGrid.setNotes(eachWellDetails.getNotes());
                    eachWellDetailFromGrid.setPrice(eachWellDetails.getPrice());
                    eachWellDetailFromGrid.setSno(eachWellDetails.getSno());
                    eachWellDetailFromGrid.setWellDetailsID(eachWellDetails.getWellDetailsID());
                    eachWellDetailFromGrid.setWellDiameter(eachWellDetails.getWellDiameter());
                    eachWellDetailFromGrid.setWellType(eachWellDetails.getWellType());
                    String evaluationID = null;
                   for (TitleDeedDetails TD : getF_IN_titleDeedDtlsList().getTitleDeedDetailsList()) {
                       if(TD.isSelect()) {
                           evaluationID = TD.getEvaluationId();
                       }
                   }
                   eachWellDetailFromGrid.setEvaluationId(evaluationID);
                    ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("WELL_TYP");
                    String statusDesc = null;

                    for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                        if (eachWellDetailFromGrid.getWellType().equals(gcCode.getCodeReference())) {
                            statusDesc = gcCode.getCodeDescription();

                            break;
                        }
                    }

                    eachWellDetailFromGrid.setWellTypeDesc(statusDesc);

                }

            }
        }
        }
        setF_OUT_wellDetailsList(wellDetailsGrid);
        setF_OUT_readOnlyNewWell(false);
    }

    private void saveRowofTitleDeed(BankFusionEnvironment env) {

        TitleDeedDetails deedDetails = getF_IN_titleDeedDtls();
        String CategoryType = getF_IN_category();// getf_in
        TitleDeedDetailsList deedDetailsList = getF_IN_titleDeedDtlsList();
        WellDetailsList wellDtlsMainHidden = new WellDetailsList();
        BuildingsDetailsList buildingDtlsMainHidden = new BuildingsDetailsList();
        TreesDetailsList treeDtlsMainHidden = new TreesDetailsList();
        
        Boolean flag = true;
        if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {
            if(deedDetails.getResidentialDetails().getEvaluationDate().equals("")||
                deedDetails.getResidentialDetails().getPropertySize().equals("")||
                deedDetails.getResidentialDetails().getHouseNo().isEmpty()||
                deedDetails.getResidentialDetails().getMortgageAmt().getCurrencyAmount().equals("")||
                deedDetails.getResidentialDetails().getEvaluator().isEmpty()||
                deedDetails.getResidentialDetails().getStreetsTypes().isEmpty()||
                deedDetails.getResidentialDetails().getStreetName1().isEmpty()||
                deedDetails.getResidentialDetails().getStreetName2().isEmpty()||
                deedDetails.getResidentialDetails().getStreetName3().isEmpty()||
                deedDetails.getResidentialDetails().getStreetName4().isEmpty()||
                deedDetails.getResidentialDetails().getStatus().isEmpty()) {
                IBCommonUtils.raiseUnparameterizedEvent(35100145);
                flag = false;
            }
        }
        if (CategoryType.equals("Agricultural")) {
            if(deedDetails.getAgricultureDetails().getEvaluationDate().equals("")||
                deedDetails.getAgricultureDetails().getMortgageAmt().getCurrencyAmount().equals("")||
                deedDetails.getAgricultureDetails().getNearestCityDistance().equals("")||
                deedDetails.getAgricultureDetails().getNearestCityName().isEmpty()||
                deedDetails.getAgricultureDetails().getDistanceToMainRoad().isEmpty()||
                deedDetails.getAgricultureDetails().getEvaluator().isEmpty()||
                deedDetails.getAgricultureDetails().getWaterAvailability().isEmpty()||
                deedDetails.getAgricultureDetails().getWaterInNeighbourArea().isEmpty()||
                deedDetails.getAgricultureDetails().getTypeOfRoad().isEmpty()||
                deedDetails.getAgricultureDetails().getEligibleToFarm().isEmpty()||
                deedDetails.getAgricultureDetails().getWateringMethod().isEmpty()||
                deedDetails.getAgricultureDetails().getInsideFarmRoadType().isEmpty()||
                deedDetails.getAgricultureDetails().getOthers().isEmpty()||
                deedDetails.getAgricultureDetails().getFarmSizeInDunum().equals("")||
                deedDetails.getAgricultureDetails().getDunumPrice().getCurrencyAmount().equals("")||
                deedDetails.getAgricultureDetails().getStatus().isEmpty()) {
                IBCommonUtils.raiseUnparameterizedEvent(35100145);
                flag = false;
            }
        }
        
        if(flag) {
        if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {
            ValidateRequestEvaluationBB.validateEvaluatorResidential(deedDetailsList, deedDetails);
             // validate evaluator
        } else if (CategoryType.equals("Agricultural")) {
            ValidateRequestEvaluationBB.validateEvaluatorAgriculture(deedDetailsList, deedDetails);
        }
        if (deedDetailsList.getTitleDeedDetailsListCount() > 0) {
            for (TitleDeedDetails eachTitleDeedFromGrid : deedDetailsList.getTitleDeedDetailsList()) {
              
                //validation for agricultural duplicate selected row
                if(deedDetails.getAgricultureDetails().getStatus().equals("Selected") && eachTitleDeedFromGrid.getAgricultureDetails().getStatus().equals("Selected") && !deedDetails.getEvaluationId().equals(eachTitleDeedFromGrid.getEvaluationId())) {
                    IBCommonUtils.raiseUnparameterizedEvent(44000330); 
                }
                
                //validation for residential duplicate selected row
                if(deedDetails.getResidentialDetails().getStatus().equals("Selected") && eachTitleDeedFromGrid.getResidentialDetails().getStatus().equals("Selected") && !deedDetails.getEvaluationId().equals(eachTitleDeedFromGrid.getEvaluationId())) {
                    IBCommonUtils.raiseUnparameterizedEvent(44000330); 
                }

                if (eachTitleDeedFromGrid.isSelect()) {

                    eachTitleDeedFromGrid.setType(deedDetails.getType());
                    eachTitleDeedFromGrid.setYear(deedDetails.getYear());

                    if (CategoryType.equals("Agricultural")) {
                        AgricultureDetails agricultureDetails = new AgricultureDetails();
                        agricultureDetails.setAgricultureDetailsID(deedDetails.getAgricultureDetails().getAgricultureDetailsID());
                        agricultureDetails.setDescription(deedDetails.getAgricultureDetails().getDescription());
                        agricultureDetails.setDistanceToMainRoad(deedDetails.getAgricultureDetails().getDistanceToMainRoad());
                        agricultureDetails.setDunumPrice(deedDetails.getAgricultureDetails().getDunumPrice());
                        agricultureDetails.setElectricityAvailable(deedDetails.getAgricultureDetails().getElectricityAvailable());
                        agricultureDetails.setEligibleToFarm(deedDetails.getAgricultureDetails().getEligibleToFarm());
                        agricultureDetails.setEvaluationDate(deedDetails.getAgricultureDetails().getEvaluationDate());
                        agricultureDetails.setEvaluator(deedDetails.getAgricultureDetails().getEvaluator());
                        agricultureDetails.setFarmSizeInDunum(deedDetails.getAgricultureDetails().getFarmSizeInDunum());
                        agricultureDetails.setInsideFarmRoadType(deedDetails.getAgricultureDetails().getInsideFarmRoadType());
                        agricultureDetails.setIsLocationMatching(deedDetails.getAgricultureDetails().isIsLocationMatching());
                        agricultureDetails.setIsPlanMatching(deedDetails.getAgricultureDetails().getIsPlanMatching());
                        agricultureDetails.setIsPrevMortgageAmt(deedDetails.getAgricultureDetails().getIsPrevMortgageAmt());
                        agricultureDetails.setLandNetValue(deedDetails.getAgricultureDetails().getLandNetValue());
                        agricultureDetails.setLandTotalValue(deedDetails.getAgricultureDetails().getLandTotalValue());
                        agricultureDetails.setLastModifiedDate(deedDetails.getAgricultureDetails().getLastModifiedDate());
                        agricultureDetails.setMortgageAmt(deedDetails.getAgricultureDetails().getMortgageAmt());
                        agricultureDetails.setNearestCityDistance(deedDetails.getAgricultureDetails().getNearestCityDistance());
                        agricultureDetails.setNetCoverValue(deedDetails.getAgricultureDetails().getNetCoverValue());
                        agricultureDetails.setOthers(deedDetails.getAgricultureDetails().getOthers());
                        agricultureDetails.setPhoneAvailable(deedDetails.getAgricultureDetails().getPhoneAvailable());

                        ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("EVALUATIONSTATUS");
                        String statusDesc = null;
                        String status = null;
                        for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                            if (deedDetails.getAgricultureDetails().getStatus().equals(gcCode.getCodeReference())) {
                                statusDesc = gcCode.getCodeDescription();
                                status = gcCode.getCodeValue();
                                break;
                            }
                        }

                        
                        agricultureDetails.setStatus(status);
                        agricultureDetails.setStatusDesc(statusDesc);
                        agricultureDetails.setNearestCityName(deedDetails.getAgricultureDetails().getNearestCityName());
                        agricultureDetails.setTotalCoverValue(CalculationRequestEvaluationUtils.getTotalEvaluationValueOfAgriculture(
                            getF_IN_titleDeedDtls().getAgricultureDetails(), getF_IN_titleDeedDtlsList(), getF_IN_wellDetails(),
                            getF_IN_wellDetailsList(), getF_IN_treeDetails(), getF_IN_treeDetailsList(), getF_IN_buildingDetails(),
                            getF_IN_buildingDetailsList()));
                        agricultureDetails.setNetCoverValue(CalculationRequestEvaluationUtils.getNetEvaluationValueOfAgriculture(
                            getF_IN_titleDeedDtls().getAgricultureDetails(), getF_IN_titleDeedDtlsList(), getF_IN_wellDetails(),
                            getF_IN_wellDetailsList(), getF_IN_treeDetails(), getF_IN_treeDetailsList(), getF_IN_buildingDetails(),
                            getF_IN_buildingDetailsList(), getF_IN_titleDeedNum(), getF_IN_islamicBankingObject()));
                        agricultureDetails.setTypeOfRoad(deedDetails.getAgricultureDetails().getTypeOfRoad());
                        agricultureDetails.setWaterAvailability(deedDetails.getAgricultureDetails().getWaterAvailability());
                        agricultureDetails.setWateringMethod(deedDetails.getAgricultureDetails().getWateringMethod());
                        agricultureDetails.setWaterInNeighbourArea(deedDetails.getAgricultureDetails().getWaterInNeighbourArea());

                        eachTitleDeedFromGrid.setAgricultureDetails(agricultureDetails);
                        setF_OUT_readOnlyNewAgriculture(false);

                    } else if (CategoryType.equals("Residential") || CategoryType.equals("Commercial")) {
                        ResidentialDetails residentialDetails = new ResidentialDetails();
                        residentialDetails.setBuildingAge(deedDetails.getResidentialDetails().getBuildingAge());
                        residentialDetails.setBuiltArea(deedDetails.getResidentialDetails().getBuiltArea());
                        residentialDetails.setCompoundWallHeight(deedDetails.getResidentialDetails().getCompoundWallHeight());
                        residentialDetails.setConstructionLevel(deedDetails.getResidentialDetails().getConstructionLevel());
                        residentialDetails.setDescription(deedDetails.getResidentialDetails().getDescription());
                        residentialDetails.setEvaluationDate(deedDetails.getResidentialDetails().getEvaluationDate());
                        residentialDetails.setEvaluator(deedDetails.getResidentialDetails().getEvaluator());
                        residentialDetails.setHouseNo(deedDetails.getResidentialDetails().getHouseNo());
                        residentialDetails.setIsBuilding(deedDetails.getResidentialDetails().getIsBuilding());
                        residentialDetails.setIsLocationMatching(deedDetails.getResidentialDetails().getIsLocationMatching());
                        residentialDetails.setIsPlanMatching(deedDetails.getResidentialDetails().getIsPlanMatching());
                        residentialDetails.setIsPrevMortgageAmt(deedDetails.getResidentialDetails().getIsPrevMortgageAmt());
                        residentialDetails.setMortgageAmt(deedDetails.getResidentialDetails().getMortgageAmt());
                        residentialDetails.setNetEvaluationValue(deedDetails.getResidentialDetails().getNetEvaluationValue());
                        residentialDetails.setNoOfFloors(deedDetails.getResidentialDetails().getNoOfFloors());
                        residentialDetails.setPricePerBuildSqM(deedDetails.getResidentialDetails().getPricePerBuildSqM());
                        residentialDetails.setPricePerSqM(deedDetails.getResidentialDetails().getPricePerSqM());
                        residentialDetails.setPropertySize(deedDetails.getResidentialDetails().getPropertySize());
                        residentialDetails.setQuality(deedDetails.getResidentialDetails().getQuality());
                        residentialDetails.setResidentialDetailsID(deedDetails.getResidentialDetails().getResidentialDetailsID());
                        residentialDetails.setShadowPrice(deedDetails.getResidentialDetails().getShadowPrice());
                        residentialDetails.setShadowSize(deedDetails.getResidentialDetails().getShadowSize());

                        ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("EVALUATIONSTATUS");
                        String statusDesc = null;
                        String status = null;

                        for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                            if (deedDetails.getResidentialDetails().getStatus().equals(gcCode.getCodeReference())) {
                                statusDesc = gcCode.getCodeDescription();
                                status = gcCode.getCodeValue();
                                break;
                            }
                        }

                        residentialDetails.setStatus(status);
                        residentialDetails.setStatusDesc(statusDesc);

                        residentialDetails.setStreetName1(deedDetails.getResidentialDetails().getStreetName1());
                        residentialDetails.setStreetName2(deedDetails.getResidentialDetails().getStreetName2());
                        residentialDetails.setStreetName3(deedDetails.getResidentialDetails().getStreetName3());
                        residentialDetails.setStreetName4(deedDetails.getResidentialDetails().getStreetName4());
                        residentialDetails.setStreetsTypes(deedDetails.getResidentialDetails().getStreetsTypes());
                        residentialDetails.setTotalEvaluationValue(deedDetails.getResidentialDetails().getTotalEvaluationValue());
                        residentialDetails.setUtilityAreaSize(deedDetails.getResidentialDetails().getUtilityAreaSize());
                        residentialDetails.setUtilityPrice(deedDetails.getResidentialDetails().getUtilityPrice());
                        residentialDetails.setWallPrice(deedDetails.getResidentialDetails().getWallPrice());
                        residentialDetails.setLandArea(deedDetails.getResidentialDetails().getLandArea());
                        eachTitleDeedFromGrid.setResidentialDetails(residentialDetails);
                        setF_OUT_readOnlyNewResidential(false);
                    }
                    WellDetailsList wellList = new WellDetailsList();
                    wellList = saveWellHiddenGridWhileSavingTitleDeed(deedDetails);
                    for(WellDetails well : wellList.getWellDetailsList()) {
                        wellDtlsMainHidden.addWellDetailsList(well);
                    }
                    
                    BuildingsDetailsList buildingList = new BuildingsDetailsList();
                    buildingList = saveBuildingHiddenGridWhileSavingTitleDeed(deedDetails);
                    for(BuildingDetails building : buildingList.getBuildingsDetailsList()) {
                        buildingDtlsMainHidden.addBuildingsDetailsList(building);
                    }
                    
                    TreesDetailsList treeList = new TreesDetailsList();
                    treeList = saveTreeHiddenGridWhileSavingTitleDeed(deedDetails);
                    for(TreeDetails tree : treeList.getTreesDetailsList()) {
                        treeDtlsMainHidden.addTreesDetailsList(tree);
                    }
                    
                }

                
            }

        }
    }
        setF_OUT_hidden_wellDtlsList(wellDtlsMainHidden);
        setF_OUT_hiddenBuildingDtlsList(buildingDtlsMainHidden);
        setF_OUT_hidden_treesDtlsList(treeDtlsMainHidden);
        setF_OUT_titleDeedDtlsList(deedDetailsList);
    }

    private TreesDetailsList saveTreeHiddenGridWhileSavingTitleDeed(TitleDeedDetails deedDetails) {

        TreesDetailsList treeDetailsList = getF_IN_treeDetailsList();
        TreesDetailsList hiddenTreeDetailsList = getF_IN_hidden_treesDtlsList();

        if(null != hiddenTreeDetailsList && hiddenTreeDetailsList.getTreesDetailsListCount()>0 && hiddenTreeDetailsList.getTreesDetailsList(0).getTreeType().isEmpty()) {
            hiddenTreeDetailsList.removeTreesDetailsListAt(0);
        }
        for (TreeDetails eachHiddenTreeDtl : hiddenTreeDetailsList.getTreesDetailsList()) {
            if(eachHiddenTreeDtl.getRequestID()!=null) {
            if (eachHiddenTreeDtl.getEvaluationId().equals(deedDetails.getEvaluationId())
                && (eachHiddenTreeDtl.getRequestID().equals(deedDetails.getRequestID()))) {
                hiddenTreeDetailsList.removeTreesDetailsList(eachHiddenTreeDtl);
            }
            }
        }
        
        for (TreeDetails eachHiddenTreeDtl : hiddenTreeDetailsList.getTreesDetailsList()) {
            if(eachHiddenTreeDtl.getRequestID()==null) {
            if (eachHiddenTreeDtl.getEvaluationId().equals(deedDetails.getEvaluationId())) {
                hiddenTreeDetailsList.removeTreesDetailsList(eachHiddenTreeDtl);
            }
            }
        }
        
        
        if (treeDetailsList.getTreesDetailsList().length > 0) {
            for (int j = 0; j < treeDetailsList.getTreesDetailsListCount(); j++) {
                if ((!StringUtils.isEmpty(treeDetailsList.getTreesDetailsList(j).getEvaluationId()))
                    && !deedDetails.getEvaluationId().equals(treeDetailsList.getTreesDetailsList(j).getEvaluationId())) {
                    TreeDetails eachHiddenTreeDtl = new TreeDetails();
                    //eachHiddenTreeDtl.setAgricultureDetailsID(treeDetailsList.getTreesDetailsList(j).getAgricultureDetailsID());
                    eachHiddenTreeDtl.setCost(treeDetailsList.getTreesDetailsList(j).getCost());
                    eachHiddenTreeDtl.setNoOfTrees(treeDetailsList.getTreesDetailsList(j).getNoOfTrees());
                    eachHiddenTreeDtl.setNotes(treeDetailsList.getTreesDetailsList(j).getNotes());
                    eachHiddenTreeDtl.setPricePerTree(treeDetailsList.getTreesDetailsList(j).getPricePerTree());
                    eachHiddenTreeDtl.setSno(treeDetailsList.getTreesDetailsList(j).getSno());
                    eachHiddenTreeDtl.setTreeAge(treeDetailsList.getTreesDetailsList(j).getTreeAge());
                    eachHiddenTreeDtl.setTreeDetailsID(treeDetailsList.getTreesDetailsList(j).getTreeDetailsID());
                    eachHiddenTreeDtl.setTreeType(treeDetailsList.getTreesDetailsList(j).getTreeType());
                    eachHiddenTreeDtl.setTreeTypeDesc(treeDetailsList.getTreesDetailsList(j).getTreeTypeDesc());
                    hiddenTreeDetailsList.addTreesDetailsList(eachHiddenTreeDtl);

                } else {
                    if (StringUtils.isEmpty(treeDetailsList.getTreesDetailsList(j).getEvaluationId())) {
                        treeDetailsList.getTreesDetailsList(j).setEvaluationId(deedDetails.getEvaluationId());
                        treeDetailsList.getTreesDetailsList(j)
                            .setAgricultureDetailsID(deedDetails.getAgricultureDetails().getAgricultureDetailsID());
                        treeDetailsList.getTreesDetailsList(j).setRequestID(deedDetails.getRequestID());
                        treeDetailsList.getTreesDetailsList(j).setTitleDeedIDPK(deedDetails.getTitleDeedIDPK());
                        treeDetailsList.getTreesDetailsList(j).setTitleDeedNum(deedDetails.getTitleDeedNum());
                        hiddenTreeDetailsList.addTreesDetailsList(j, treeDetailsList.getTreesDetailsList(j));
                    } else {
                        hiddenTreeDetailsList.addTreesDetailsList(treeDetailsList.getTreesDetailsList(j));
                    }
                }

            }

        }

        return hiddenTreeDetailsList;
    }

    private BuildingsDetailsList saveBuildingHiddenGridWhileSavingTitleDeed(TitleDeedDetails deedDetails) {

        BuildingsDetailsList buildingDetailsList = getF_IN_buildingDetailsList();// getf_in
        BuildingsDetailsList hiddenBuildingDetailsList = getF_IN_hidden_buildingDtlsList();// getf_in

        if(null != hiddenBuildingDetailsList && hiddenBuildingDetailsList.getBuildingsDetailsListCount()>0 && hiddenBuildingDetailsList.getBuildingsDetailsList(0).getBuildingType().isEmpty()) {
            hiddenBuildingDetailsList.removeBuildingsDetailsListAt(0);
        }
        
        for (BuildingDetails eachHiddenBuildingDtl : hiddenBuildingDetailsList.getBuildingsDetailsList()) {
            if(eachHiddenBuildingDtl.getRequestID()!=null) {
            if (eachHiddenBuildingDtl.getEvaluationId().equals(deedDetails.getEvaluationId())
                && (eachHiddenBuildingDtl.getRequestID().equals(deedDetails.getRequestID()))) {
                hiddenBuildingDetailsList.removeBuildingsDetailsList(eachHiddenBuildingDtl);
            }
        }
        }
        for (BuildingDetails eachHiddenBuildingDtl : hiddenBuildingDetailsList.getBuildingsDetailsList()) {
        if(eachHiddenBuildingDtl.getRequestID()==null) {
            if (eachHiddenBuildingDtl.getEvaluationId().equals(deedDetails.getEvaluationId())){
                hiddenBuildingDetailsList.removeBuildingsDetailsList(eachHiddenBuildingDtl);
            }
        }
        }
        
        if (buildingDetailsList.getBuildingsDetailsList().length > 0) {
            for (int j = 0; j < buildingDetailsList.getBuildingsDetailsListCount(); j++) {
                if ((!StringUtils.isEmpty(buildingDetailsList.getBuildingsDetailsList(j).getEvaluationId()))
                    && !deedDetails.getEvaluationId().equals(buildingDetailsList.getBuildingsDetailsList(j).getEvaluationId())) {
                    BuildingDetails eachHiddenBuildingDtl = new BuildingDetails();
                   // eachHiddenBuildingDtl.setAgricultureDetailsID(buildingDetailsList.getBuildingsDetailsList(j).getAgricultureDetailsID());
                    eachHiddenBuildingDtl.setBuildingAge(buildingDetailsList.getBuildingsDetailsList(j).getBuildingAge());
                    eachHiddenBuildingDtl.setBuildingDetailsID(buildingDetailsList.getBuildingsDetailsList(j).getBuildingDetailsID());
                    eachHiddenBuildingDtl.setBuildingsize(buildingDetailsList.getBuildingsDetailsList(j).getBuildingsize());
                    eachHiddenBuildingDtl.setBuildingType(buildingDetailsList.getBuildingsDetailsList(j).getBuildingType());
                    eachHiddenBuildingDtl.setBuildingTypeDesc(buildingDetailsList.getBuildingsDetailsList(j).getBuildingTypeDesc());
                    eachHiddenBuildingDtl.setCost(buildingDetailsList.getBuildingsDetailsList(j).getCost());
                    eachHiddenBuildingDtl.setNotes(buildingDetailsList.getBuildingsDetailsList(j).getNotes());
                    eachHiddenBuildingDtl.setPricePerSqM(buildingDetailsList.getBuildingsDetailsList(j).getPricePerSqM());
                    eachHiddenBuildingDtl.setSno(buildingDetailsList.getBuildingsDetailsList(j).getSno());
                    hiddenBuildingDetailsList.addBuildingsDetailsList(eachHiddenBuildingDtl);

                } else {
                    if (StringUtils.isEmpty(buildingDetailsList.getBuildingsDetailsList(j).getEvaluationId())) {
                        buildingDetailsList.getBuildingsDetailsList(j).setEvaluationId(deedDetails.getEvaluationId());
                        buildingDetailsList.getBuildingsDetailsList(j)
                            .setAgricultureDetailsID(deedDetails.getAgricultureDetails().getAgricultureDetailsID());
                        buildingDetailsList.getBuildingsDetailsList(j).setRequestID(deedDetails.getRequestID());
                        buildingDetailsList.getBuildingsDetailsList(j).setTitleDeedIDPK(deedDetails.getTitleDeedIDPK());
                        buildingDetailsList.getBuildingsDetailsList(j).setTitleDeedNum(deedDetails.getTitleDeedNum());
                        hiddenBuildingDetailsList.addBuildingsDetailsList(j, buildingDetailsList.getBuildingsDetailsList(j));
                    } else {
                        hiddenBuildingDetailsList.addBuildingsDetailsList(buildingDetailsList.getBuildingsDetailsList(j));
                    }
                }

            }

        }

        return hiddenBuildingDetailsList;
    }

    private WellDetailsList saveWellHiddenGridWhileSavingTitleDeed(TitleDeedDetails deedDetails) {

        WellDetailsList wellDetailsList = getF_IN_wellDetailsList();// getf_in
        WellDetailsList hiddenWellDetailsList = getF_IN_hidden_wellDtlsList();// getf_in
        if(null != hiddenWellDetailsList && hiddenWellDetailsList.getWellDetailsListCount()>0 && hiddenWellDetailsList.getWellDetailsList(0).getWellType().isEmpty()) {
            hiddenWellDetailsList.removeWellDetailsListAt(0);
        }
        
        for (WellDetails eachHiddenwellDtl : hiddenWellDetailsList.getWellDetailsList()) {
            if(eachHiddenwellDtl.getRequestID()!=null) {
              if (eachHiddenwellDtl.getEvaluationId().equals(deedDetails.getEvaluationId())
                  && (eachHiddenwellDtl.getRequestID().equals(deedDetails.getRequestID()))) {
                  hiddenWellDetailsList.removeWellDetailsList(eachHiddenwellDtl);
              }
            }
        }
        
        for (WellDetails eachHiddenwellDtl : hiddenWellDetailsList.getWellDetailsList()) {
            if(eachHiddenwellDtl.getRequestID()==null) {
              if (eachHiddenwellDtl.getEvaluationId().equals(deedDetails.getEvaluationId())) {
                  hiddenWellDetailsList.removeWellDetailsList(eachHiddenwellDtl);
              }
            }
        }
        

        if (wellDetailsList.getWellDetailsList().length > 0) {
            for (int j = 0; j < wellDetailsList.getWellDetailsListCount(); j++) {
                if ((!StringUtils.isEmpty(wellDetailsList.getWellDetailsList(j).getEvaluationId()))
                    && !deedDetails.getEvaluationId().equals(wellDetailsList.getWellDetailsList(j).getEvaluationId())) {
                    WellDetails eachHiddenwellDtl = new WellDetails();
                   // eachHiddenwellDtl.setAgricultureDetailsID(wellDetailsList.getWellDetailsList(j).getAgricultureDetailsID());
                    eachHiddenwellDtl.setAirDepth(wellDetailsList.getWellDetailsList(j).getAirDepth());
                    eachHiddenwellDtl.setDepth(wellDetailsList.getWellDetailsList(j).getDepth());
                    eachHiddenwellDtl.setNotes(wellDetailsList.getWellDetailsList(j).getNotes());
                    eachHiddenwellDtl.setPrice(wellDetailsList.getWellDetailsList(j).getPrice());
                    eachHiddenwellDtl.setSno(wellDetailsList.getWellDetailsList(j).getSno());
                    eachHiddenwellDtl.setWellDetailsID(wellDetailsList.getWellDetailsList(j).getWellDetailsID());
                    eachHiddenwellDtl.setWellDiameter(wellDetailsList.getWellDetailsList(j).getWellDiameter());
                    eachHiddenwellDtl.setWellType(wellDetailsList.getWellDetailsList(j).getWellType());
                    eachHiddenwellDtl.setWellTypeDesc(wellDetailsList.getWellDetailsList(j).getWellTypeDesc());
                    hiddenWellDetailsList.addWellDetailsList(eachHiddenwellDtl);

                } else {
                    if (StringUtils.isEmpty(wellDetailsList.getWellDetailsList(j).getEvaluationId())) {
                        wellDetailsList.getWellDetailsList(j).setEvaluationId(deedDetails.getEvaluationId());
                        wellDetailsList.getWellDetailsList(j)
                            .setAgricultureDetailsID(deedDetails.getAgricultureDetails().getAgricultureDetailsID());
                        wellDetailsList.getWellDetailsList(j).setRequestID(deedDetails.getRequestID());
                        wellDetailsList.getWellDetailsList(j).setTitleDeedIDPK(deedDetails.getTitleDeedIDPK());
                        wellDetailsList.getWellDetailsList(j).setTitleDeedNum(deedDetails.getTitleDeedNum());
                        hiddenWellDetailsList.addWellDetailsList(j, wellDetailsList.getWellDetailsList(j));
                    } else {
                        hiddenWellDetailsList.addWellDetailsList(wellDetailsList.getWellDetailsList(j));
                    }
                }

            }

        }

        return hiddenWellDetailsList;
    }

    private void removeRowofTitleDeedList(BankFusionEnvironment env) {

        TitleDeedDetailsList titleDeedDtlsList = getF_IN_titleDeedDtlsList();
        TitleDeedDetailsList hiddenTitleDeedDtslList = getF_IN_hidden_titleDeedDtlsList();

        WellDetailsList wellDtlsListUI = getF_IN_wellDetailsList();// getf_in
        BuildingsDetailsList buildingListUI = getF_IN_buildingDetailsList();// getf_in
        TreesDetailsList treesListUI = new TreesDetailsList();

        WellDetailsList hiddenWellDtlsList = getF_IN_hidden_wellDtlsList();// getf_in
        BuildingsDetailsList hiddenBuildingList = getF_IN_hidden_buildingDtlsList();// getf_in
        TreesDetailsList hiddenTreesList = new TreesDetailsList();

        if (titleDeedDtlsList.getTitleDeedDetailsListCount() > 0) {
            for (TitleDeedDetails titleDeeddtl : titleDeedDtlsList.getTitleDeedDetailsList()) {
                if (titleDeeddtl.getSelect()) {
                    for (TitleDeedDetails hiddenTitleDeeddtl : hiddenTitleDeedDtslList.getTitleDeedDetailsList()) {
                        if (!StringUtils.isEmpty(hiddenTitleDeeddtl.getEvaluationId())
                            && hiddenTitleDeeddtl.getEvaluationId().equals(titleDeeddtl.getEvaluationId())) {
                            hiddenTitleDeedDtslList.removeTitleDeedDetailsList(hiddenTitleDeeddtl);
                        }
                    }
                    for (WellDetails wellDtl : hiddenWellDtlsList.getWellDetailsList()) {
                        if (!StringUtils.isEmpty(titleDeeddtl.getEvaluationId())
                            && titleDeeddtl.getEvaluationId().equals(wellDtl.getEvaluationId())) {

                            hiddenWellDtlsList.removeWellDetailsList(wellDtl);
                            wellDtlsListUI.removeWellDetailsList(wellDtl);
                        }
                    }
                    for (BuildingDetails buildingDtl : hiddenBuildingList.getBuildingsDetailsList()) {
                        if (!StringUtils.isEmpty(titleDeeddtl.getEvaluationId())
                            && titleDeeddtl.getEvaluationId().equals(buildingDtl.getEvaluationId())) {
                            hiddenBuildingList.removeBuildingsDetailsList(buildingDtl);
                            buildingListUI.removeBuildingsDetailsList(buildingDtl);
                        }
                    }
                    for (TreeDetails treeDtl : hiddenTreesList.getTreesDetailsList()) {
                        if (!StringUtils.isEmpty(titleDeeddtl.getEvaluationId())
                            && titleDeeddtl.getEvaluationId().equals(treeDtl.getEvaluationId())) {
                            hiddenTreesList.removeTreesDetailsList(treeDtl);
                            treesListUI.removeTreesDetailsList(treeDtl);
                        }
                    }
                    titleDeedDtlsList.removeTitleDeedDetailsList(titleDeeddtl);
                }
            }
            if (titleDeedDtlsList.getTitleDeedDetailsList().length > 0) {
                int sizeOfList = (titleDeedDtlsList.getTitleDeedDetailsListCount());
                titleDeedDtlsList.getTitleDeedDetailsList(sizeOfList - 1).setSelect(true);

            }

            
            
            setF_OUT_hidden_titleDeedDtlsList(hiddenTitleDeedDtslList);
            // both hidden and main setf_out_building
            setF_OUT_hiddenBuildingDtlsList(hiddenBuildingList);
            setF_OUT_buildingDetailsList(buildingListUI);
            // both hidden and main tree
            setF_OUT_hidden_treesDtlsList(hiddenTreesList);
            setF_OUT_treeDetailsList(treesListUI);
            // both hidden and main wells
            setF_OUT_wellDetailsList(wellDtlsListUI);
            setF_OUT_hidden_wellDtlsList(hiddenWellDtlsList);
            setF_OUT_readOnlyNewResidential(false);
            setF_OUT_readOnlyNewAgriculture(false);

        }
        setF_OUT_titleDeedDtlsList(titleDeedDtlsList);
    }

    private void removeRowOfWellDetails(BankFusionEnvironment env) {

        WellDetailsList wellDtlsList = getF_IN_wellDetailsList();
        WellDetailsList hiddenWellDtlsList = getF_IN_hidden_wellDtlsList();
        if (wellDtlsList.getWellDetailsListCount() > 0) {
            for (WellDetails eachWellDtl : wellDtlsList.getWellDetailsList()) {
                if (eachWellDtl.isSelect()) {
                    for (WellDetails hiddenEachWellDtl : hiddenWellDtlsList.getWellDetailsList()) {
                        hiddenWellDtlsList.removeWellDetailsList(hiddenEachWellDtl);
                    }
                    wellDtlsList.removeWellDetailsList(eachWellDtl);

                }
            }
            
            
            if (wellDtlsList.getWellDetailsList().length > 0) {
                int sizeOfList = wellDtlsList.getWellDetailsListCount();
                wellDtlsList.getWellDetailsList(sizeOfList - 1).setSelect(true);

            }

            // setf_out hidden wells
            setF_OUT_hidden_wellDtlsList(hiddenWellDtlsList);
            // setf_main UI well
            
            setF_OUT_readOnlyNewWell(false);
        }
        BFCurrencyAmount totalValue = new BFCurrencyAmount();

        totalValue.setCurrencyAmount(BigDecimal.ZERO);
        for(WellDetails well : wellDtlsList.getWellDetailsList()) {
            
           totalValue.setCurrencyAmount(totalValue.getCurrencyAmount().add(well.getPrice().getCurrencyAmount()));
            totalValue.setCurrencyCode(well.getPrice().getCurrencyCode());
        }
        wellDtlsList.setTotalPrice(totalValue);
        setF_OUT_wellDetailsList(wellDtlsList);
        if(wellDtlsList.getWellDetailsListCount()==0) {
            setF_OUT_showBtn(true);
        }

    }

    private void removeRowOfBuildingDetails(BankFusionEnvironment env) {

        BuildingsDetailsList buildingDtlsList = getF_IN_buildingDetailsList();
        BuildingsDetailsList hiddenBuildingDtlsList = getF_IN_hidden_buildingDtlsList();
        if (buildingDtlsList.getBuildingsDetailsListCount() > 0) {
            for (BuildingDetails eachBuildingDtl : buildingDtlsList.getBuildingsDetailsList()) {
                if (eachBuildingDtl.isSelect()) {
                    for (BuildingDetails hiddenEachBuildingDtl : buildingDtlsList.getBuildingsDetailsList()) {
                        hiddenBuildingDtlsList.removeBuildingsDetailsList(hiddenEachBuildingDtl);
                    }
                    buildingDtlsList.removeBuildingsDetailsList(eachBuildingDtl);

                }
            }
            if (buildingDtlsList.getBuildingsDetailsList().length > 0) {
                int sizeOfList = buildingDtlsList.getBuildingsDetailsListCount();
                buildingDtlsList.getBuildingsDetailsList(sizeOfList - 1).setSelect(true);

            }

            // setf_out hidden building
            setF_OUT_hiddenBuildingDtlsList(hiddenBuildingDtlsList);
            // setf_main UI building
            
            setF_OUT_readOnlyNewBuilding(false);
        }
        
        BFCurrencyAmount totalValue = new BFCurrencyAmount();

        totalValue.setCurrencyAmount(BigDecimal.ZERO);
        for(BuildingDetails build : buildingDtlsList.getBuildingsDetailsList()) {
            
           totalValue.setCurrencyAmount(totalValue.getCurrencyAmount().add(build.getCost().getCurrencyAmount()));
            totalValue.setCurrencyCode(build.getCost().getCurrencyCode());
        }
        buildingDtlsList.setTotalPrice(totalValue);
        setF_OUT_buildingDetailsList(buildingDtlsList);
        if(buildingDtlsList.getBuildingsDetailsListCount()==0) {
            setF_OUT_showBtn(true);
        }
        

    }

    private void removeRowOfTreeDetails(BankFusionEnvironment env) {

        TreesDetailsList treeDtlsList = getF_IN_treeDetailsList();
        TreesDetailsList hiddenTreeDtlsList = new TreesDetailsList();
        if (treeDtlsList.getTreesDetailsListCount() > 0) {
            for (TreeDetails eachTreeDtl : treeDtlsList.getTreesDetailsList()) {
                if (eachTreeDtl.isSelect()) {
                    for (TreeDetails hiddenEachTreeDtl : treeDtlsList.getTreesDetailsList()) {
                        hiddenTreeDtlsList.removeTreesDetailsList(hiddenEachTreeDtl);
                    }
                    treeDtlsList.removeTreesDetailsList(eachTreeDtl);

                }
            }
            if (treeDtlsList.getTreesDetailsList().length > 0) {
                int sizeOfList = treeDtlsList.getTreesDetailsListCount();
                treeDtlsList.getTreesDetailsList(sizeOfList - 1).setSelect(true);

            }

            
            // setf_out hidden trees
            setF_OUT_hidden_treesDtlsList(hiddenTreeDtlsList);
            // setf_main UI trees
            
            setF_OUT_readOnlyNewTree(false);
        }
        
        BFCurrencyAmount totalValue = new BFCurrencyAmount();

        totalValue.setCurrencyAmount(BigDecimal.ZERO);
        for(TreeDetails tree : treeDtlsList.getTreesDetailsList()) {
            
           totalValue.setCurrencyAmount(totalValue.getCurrencyAmount().add(tree.getCost().getCurrencyAmount()));
            totalValue.setCurrencyCode(tree.getCost().getCurrencyCode());
        }
        treeDtlsList.setTotalPrice(totalValue);
        setF_OUT_treeDetailsList(treeDtlsList);
        if(treeDtlsList.getTreesDetailsListCount()==0) {
            setF_OUT_showBtn(true);
        }
        

    }

}