package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SavePriceListConfig;
import com.ce.ib.cfg.bo.PriceList;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TPT_ThirdPartyDetails;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.ib.types.PricingCfgSearchRs;
import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListAssetCfg;
import bf.com.misys.ib.types.PricingListCfg;
import bf.com.misys.ib.types.RegistryCfgSearchRs;
import bf.com.misys.ib.types.RegistryListCfg;

public class SavePriceListConfig extends AbstractCE_IB_SavePriceListConfig {

	private static final long serialVersionUID = -3796173908675904903L;
	private static final transient Log LOGGER = LogFactory.getLog(SavePriceListConfig.class.getName());

	public SavePriceListConfig(BankFusionEnvironment env) {
		super(env);

	}

	public SavePriceListConfig() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
	    String mode = getF_IN_mode();
	    if(mode.equals("NEW")) {
	        PricingCfgSearchRs pricingSearchRqIN = getF_IN_pricingSearchRsIN();
	        PricingListCfg[] pricing = pricingSearchRqIN.getRegCfgSearch().getPricingListDtls();
	        Boolean newRow = false;
	        for(PricingListCfg item : pricing) {
	            if(item.getSelect()==true) {
	                item.setSelect(Boolean.FALSE);
	            }
	            if(IBCommonUtils.isNullOrEmpty(item.getDocumentNumber()) || item.getDocumentNumber().equalsIgnoreCase("") ) {
	                newRow = true;
	            }
	        }
	        
	        if(!newRow) {
	            int entries = pricingSearchRqIN.getPagedQuery().getPagingRequest().getNumberOfRows();
	           Date dt = new Date(IBCommonUtils.getBFBusinessDateTime().getYear(),IBCommonUtils.getBFBusinessDateTime().getMonth(),IBCommonUtils.getBFBusinessDateTime().getDate());
	           CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom(env);
	           customAutoNumFatom.setF_IN_BONAME("CE_IB_PricingListCfg");
	           customAutoNumFatom.setF_IN_isRightPad(false);
	           customAutoNumFatom.setF_IN_Prefix("Price_");
	           customAutoNumFatom.setF_IN_Suffix("");
	           customAutoNumFatom.setF_IN_TotalLength(0);
	           customAutoNumFatom.process(env);

	           String reqId = customAutoNumFatom.getF_OUT_PrimKey(); 
	           
	           PricingListCfg vPricingListDtls = new PricingListCfg();
	           vPricingListDtls.setDocumentDate(dt);
	           vPricingListDtls.setDocumentNumber("");
	           vPricingListDtls.setReferenceNumber("");
	           vPricingListDtls.setPriceListYear(0);
	           vPricingListDtls.setPricingListId(reqId);
	           vPricingListDtls.setVendorId("");
	           vPricingListDtls.setVendorName("");
	           vPricingListDtls.setVendorType("");
	           vPricingListDtls.setPricingListDate(dt);
	           vPricingListDtls.setSelect(Boolean.TRUE);
	            
	            pricingSearchRqIN.getRegCfgSearch().addPricingListDtls(vPricingListDtls);
	            
	            pricingSearchRqIN.getPagedQuery().getPagingRequest().setNumberOfRows(entries+1);
	            }
	            setF_OUT_pricingSearchRs(pricingSearchRqIN);
	        
	    } else {
	        PricingList pricingList = getF_IN_pricingSearchRsIN().getRegCfgSearch();
	        PricingListAssetCfg priceListAsstCfg = getF_IN_priceListAssetCfg();
	        PricingListCfg priceListCfg = getF_IN_pricingListCfg();
	        if (pricingList.getPricingListAssetDtls().length > 0) {
	          IBOIB_TPT_ThirdPartyDetails details= (IBOIB_TPT_ThirdPartyDetails) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_TPT_ThirdPartyDetails.BONAME, priceListCfg.getVendorId(), true);
	          if(details==null) {
	            IBCommonUtils.raiseUnparameterizedEvent(35100069);
	          }
	          try {
	            PriceList priceList = new PriceList();
	            priceList.savePricingList(priceListCfg);
	            priceListAsstCfg.setPricingListId(priceListCfg.getPricingListId());
	            
	            PricingListAssetCfg[] assetList = pricingList.getPricingListAssetDtls();
	            Date dt = new Date(IBCommonUtils.getBFBusinessDateTime().getYear(),IBCommonUtils.getBFBusinessDateTime().getMonth(),IBCommonUtils.getBFBusinessDateTime().getDate());
	            for(PricingListAssetCfg asset : assetList) {
	                asset.setAttribute1(null==asset.getAttribute1()?0:asset.getAttribute1());
	                asset.setAttribute2(null==asset.getAttribute2()?0:asset.getAttribute2());
	                asset.setAttribute3(null==asset.getAttribute3()?0:asset.getAttribute3());
	                asset.setNewPLDate1(null==asset.getNewPLDate1()?dt:asset.getNewPLDate1());
	                asset.setNewPLDate2(null==asset.getNewPLDate2()?dt:asset.getNewPLDate2());
	                asset.setHorsePower(null==asset.getHorsePower()?BigDecimal.ZERO:asset.getHorsePower());
	                //asset.setModel(IBCommonUtils.isNullOrEmpty(asset.getModel())?"Model":asset.getModel());
	        }
	            
	            priceList.savePricingAssetList(priceListCfg.getPricingListId(), assetList);
	            BusinessEventSupport.getInstance().raiseBusinessInfoEvent(44000207,
	                new Object[] {}, LOGGER,
	                IBCommonUtils.getBankFusionEnvironment());
	            
	            PricingCfgSearchRs pricingSearchIN = getF_IN_pricingSearchRsIN();
	            for(PricingListCfg pri : pricingSearchIN.getRegCfgSearch().getPricingListDtls()) {
	                if(pri.isSelect()) {
	                    pri.setDocumentNumber(priceListCfg.getDocumentNumber());
	                    pri.setPriceListYear(priceListCfg.getPriceListYear());
	                    pri.setReferenceNumber(priceListCfg.getReferenceNumber());
	                    pri.setVendorId(priceListCfg.getVendorId());
	                    pri.setVendorName(priceListCfg.getVendorName());
	                    pri.setVendorType(priceListCfg.getVendorType());
	                }
	            }
	            setF_OUT_pricingSearchRs(pricingSearchIN);
	          } catch (Exception e) {
	            LOGGER.error(e);
	            BusinessEventSupport.getInstance().raiseBusinessErrorEvent(44000204,
	                new Object[] {}, LOGGER,
	                IBCommonUtils.getBankFusionEnvironment());
	          }
	        } else {
	          BusinessEventSupport.getInstance().raiseBusinessErrorEvent(11400229, new Object[] { "Asset Details" },
	              LOGGER, IBCommonUtils.getBankFusionEnvironment());
	        }
	    }
		
	}
}
