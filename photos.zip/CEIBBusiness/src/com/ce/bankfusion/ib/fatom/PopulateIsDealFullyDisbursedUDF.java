package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateIsDealFullyDisbursedUDF;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class PopulateIsDealFullyDisbursedUDF extends AbstractCE_IB_PopulateIsDealFullyDisbursedUDF{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 696889188340716281L;
	
	private static final Log LOGGER = LogFactory.getLog(PopulateIsDealFullyDisbursedUDF.class);

	public PopulateIsDealFullyDisbursedUDF()
	{
		super();
	}

	public PopulateIsDealFullyDisbursedUDF(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		String whereClause = "WHERE " + IBOIB_DLI_DealDetails.DealAccountId + " IS NOT NULL";
		ArrayList<String> params = new ArrayList<>();
		List<IBOIB_DLI_DealDetails> deals = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOIB_DLI_DealDetails.BONAME, whereClause , params, null, false);
		if(null != deals && !deals.isEmpty())
		{
			for(IBOIB_DLI_DealDetails deal : deals)
			{
				try 
				{
					CeUtils.updateIsDealFullyDisbursed(deal.getBoID());
				}
				catch(Exception e)
				{
					LOGGER.info("The IsDealFullyDisbursed UDF update failed for dealID " + deal.getBoID()
					+ "with the error : " + e.getLocalizedMessage());
				}
			}
		}
		
	}
}
