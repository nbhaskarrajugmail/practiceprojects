package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_IsSpecialProjectAndTool206;
import com.ce.bankfusion.ib.util.CeConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class IsSpecialProjectAndTool206 extends AbstractCE_IB_IsSpecialProjectAndTool206 {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public IsSpecialProjectAndTool206() {
        super();
        // TODO Auto-generated constructor stub
    }

    public IsSpecialProjectAndTool206(BankFusionEnvironment env) {
        super(env);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        setF_OUT_assetStudyCostReadOnly(true);
        if (!isF_IN_isDealEnquiry() && !getF_IN_mode().equals("VIEW") && getF_IN_editMode().equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE)
            && isF_IN_isSpecialProject()) {
                 setF_OUT_assetStudyCostReadOnly(false);
        }
    }

}
