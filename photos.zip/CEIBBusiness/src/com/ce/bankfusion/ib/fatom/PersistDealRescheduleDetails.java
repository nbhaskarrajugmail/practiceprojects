package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ASSETPROFILE;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RESCHEDULEDISTDETAILS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistDealRescheduleDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_PersistDealRescheduleDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealreschedule.dtls.ib.types.CeDistributePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CePostPonePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleRequestDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.CeAssetProfile;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class PersistDealRescheduleDetails extends AbstractCE_IB_PersistDealRescheduleDetails
        implements ICE_IB_PersistDealRescheduleDetails {

    public PersistDealRescheduleDetails() {
        // TODO Auto-generated constructor stub
    }

    private static final transient Log LOGGER = LogFactory.getLog(PersistCollateralDetails.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    private static String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
    private boolean isDealReschedule = true;

    public PersistDealRescheduleDetails(BankFusionEnvironment env) {
        super(env);

    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method");
        Date lastRepaymentDate = null;
		BigDecimal subsidyAmount = BigDecimal.ZERO;
        if(getF_IN_dealRescheduleDetails().getNewScheduleCount() == 0)
        {
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_SCHEDULE_GENERATION_MANDATORY_CEIB);
        }
        else if(getF_IN_dealRescheduleDetails().getNewScheduleCount() > 0)
        {
	        BigDecimal totalPrincipalAmt = BigDecimal.ZERO;
	        BigDecimal totalProfitAmt = BigDecimal.ZERO;
	        BigDecimal totalFeeAmt = BigDecimal.ZERO;
	        for (CePaymentSchedule paymentSchedule : getF_IN_dealRescheduleDetails().getNewSchedule()) {
	            totalPrincipalAmt = totalPrincipalAmt.add(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
	            totalProfitAmt = totalProfitAmt.add(paymentSchedule.getProfitAmount().getCurrencyAmount());
	            totalFeeAmt = totalFeeAmt.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
	            subsidyAmount = subsidyAmount.add(paymentSchedule.getSubsidyAmount().getCurrencyAmount());
				lastRepaymentDate = paymentSchedule.getRepaymentDate();
	        }
	        BigDecimal previousPaidPrincipalAmnt = BigDecimal.ZERO;
	        ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(getF_IN_dealRescheduleDetails().getDealId());
			for (LoanPayments loanPayments : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
				previousPaidPrincipalAmnt = previousPaidPrincipalAmnt
						.add(loanPayments.getPrincipalAmtPaid());
			}
	        IBOCE_IB_REFUNDRESCHDTLS refundRescheduleDetails = (IBOCE_IB_REFUNDRESCHDTLS) factory
	                .findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId(), true);
	        if(null != refundRescheduleDetails) {
	        	isDealReschedule = false;
	        }
	        int amountChangeEventCode = null == refundRescheduleDetails? 44000313 :CeConstants.E_REFUND_HOST_AMOUNTS_CHANGE_CEIB;
	        BigDecimal disbursedOutstandingPrincipal = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount().subtract(previousPaidPrincipalAmnt);
			if (disbursedOutstandingPrincipal.compareTo(totalPrincipalAmt) != 0) {
	        	BigDecimal remainingPrincipal = disbursedOutstandingPrincipal.subtract(totalPrincipalAmt);
	        	if(remainingPrincipal.compareTo(BigDecimal.ZERO) > 0) {
	        		String[] msgArgs = { remainingPrincipal.toString(),
	                        getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinPrincipal().getCurrencyCode() };
	                IBCommonUtils.raiseParametrizedEvent(CeConstants.E_UNSCHEDULE_PRINCIPAL_AMOUNT_CEIB, msgArgs);
	        	}
	        	else {
	        		IBCommonUtils.raiseUnparameterizedEvent(amountChangeEventCode);
	        	}
	        }
	        if (getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinProfit().getCurrencyAmount().compareTo(totalProfitAmt) != 0) {
	        	BigDecimal remainingProfit = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinProfit().getCurrencyAmount().subtract(totalProfitAmt);
	        	if(remainingProfit.compareTo(BigDecimal.ZERO) > 0) {
	                String[] msgArgs = { remainingProfit.toString(),
	                        getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandinProfit().getCurrencyCode() };
	                IBCommonUtils.raiseParametrizedEvent(CeConstants.E_UNSCHEDULE_PROFIT_AMOUNT_CEIB, msgArgs);
	        	}
	        	else {
	        		IBCommonUtils.raiseUnparameterizedEvent(amountChangeEventCode);
	        	}
	        }
	        BigDecimal totalFeesAmount = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandingFees().getCurrencyAmount().add(getF_IN_dealRescheduleDetails()
					.getRescheduleRequestDetails().getScheduleFeesAmount().getCurrencyAmount());
	        BigDecimal deltaAmount =totalFeesAmount.subtract(totalFeeAmt);
			if (deltaAmount.compareTo(BigDecimal.ONE) > 0) {
				if (getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandingFees()	.getCurrencyAmount().add(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails()
								.getScheduleFeesAmount().getCurrencyAmount()).compareTo(totalFeeAmt) != 0) {
					BigDecimal remainingFees = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getOutstandingFees().getCurrencyAmount().add(getF_IN_dealRescheduleDetails()
									.getRescheduleRequestDetails().getScheduleFeesAmount().getCurrencyAmount())	.subtract(totalFeeAmt);
					if (remainingFees.compareTo(BigDecimal.ZERO) > 0) {
						String[] msgArgs = { remainingFees.toString(), getF_IN_dealRescheduleDetails()
								.getRescheduleRequestDetails().getScheduleFeesAmount().getCurrencyCode() };
						IBCommonUtils.raiseParametrizedEvent(CeConstants.E_UNSCHEDULE_FEES_AMOUNT_CEIB, msgArgs);
					} else {
						IBCommonUtils.raiseUnparameterizedEvent(amountChangeEventCode);
					}
				}
			}
        }
            
        if (!isF_IN_isViewOnlyMode())
            persistDetails(env, lastRepaymentDate, subsidyAmount);
        LOGGER.info("Exiting from process method");
    }

    private void persistDetails(BankFusionEnvironment env, Date lastRepaymentDate, BigDecimal subsidyAmount) {
        persistDealRescheduleDetails(env, lastRepaymentDate, subsidyAmount);
        persistAssetProfileDetails();
        persistPaymentBreakUpDetails();
        persistPostponeAndDistributeDetails();
    }

    private void persistAssetProfileDetails() {
        removeExistingAssetProfileDetails();
        if (getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetProfileListCount() > 0) {
            for (CeAssetProfile assetProfile : getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetProfileList()) {
                IBOCE_IB_ASSETPROFILE newAssetProfile = (IBOCE_IB_ASSETPROFILE) factory
                        .getStatelessNewInstance(IBOCE_IB_ASSETPROFILE.BONAME);
                newAssetProfile.setF_IBASSETID(assetProfile.getAssetId());
                newAssetProfile.setF_IBASSETREPAYMENTAMOUNT(assetProfile.getAssetRepaymentAmount().getCurrencyAmount());
                newAssetProfile.setF_IBDEALID(getF_IN_dealRescheduleDetails().getDealId());
                newAssetProfile.setF_IBFEESPERCOFREPAMNT(assetProfile.getFeesPercentageOfTotalScheduleFees());
                newAssetProfile.setF_IBPRINCPERCOFREPAMNT(assetProfile.getPrincipalPercentageOfTotalPrincipal());
                newAssetProfile.setF_IBPROFITPERCOFREPAMNT(assetProfile.getProfitPercentageOfTotalProfit());
                newAssetProfile.setF_IBRESCHEDULEID(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
                newAssetProfile.setF_IBSCHEDULEFEESAMOUNT(assetProfile.getScheduleFeesAmount().getCurrencyAmount());
                newAssetProfile.setF_IBSCHEDULEFEESAMOUNTPAID(assetProfile.getScheduleFeesAmountPaid().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALPRINCIPALAMOUNT(assetProfile.getTotalPrincipalAmount().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALPRINCIPALAMOUNTPAID(assetProfile.getTotalPrincipalAmountPaid().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALPROFITAMOUNT(assetProfile.getTotalProfitAmount().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALPROFITAMOUNTPAID(assetProfile.getTotalProfitAmountPaid().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALSUBSIDYAMOUNT(assetProfile.getTotalSubsidyAmount().getCurrencyAmount());
                newAssetProfile.setF_IBTOTALSUBSIDYAMOUNTPAID(assetProfile.getTotalSubsidyAmountPaid().getCurrencyAmount());
                factory.create(IBOCE_IB_ASSETPROFILE.BONAME, newAssetProfile);
            }
        }
    }

    private void removeExistingAssetProfileDetails() {
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_ASSETPROFILE.IBRESCHEDULEID + "= ? AND "
                + IBOCE_IB_ASSETPROFILE.IBDEALID + "= ? ");
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
        params.add(getF_IN_dealRescheduleDetails().getDealId());
        factory.bulkDelete(IBOCE_IB_ASSETPROFILE.BONAME, queryCondition.toString(), params);
    }

    private void persistPaymentBreakUpDetails() {
        String rescheduleRequestId = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId();
        String dealId = getF_IN_dealRescheduleDetails().getDealId();
        removeExistingPaymentsSchedule(rescheduleRequestId, dealId);
        
        if (getF_IN_dealRescheduleDetails().getAssetProfileDetails().getAssetBasedPaymentScheduleCount() > 0) {
            for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_dealRescheduleDetails().getAssetProfileDetails()
                    .getAssetBasedPaymentSchedule()) {
                IBOCE_IB_PaymentScheduleHistory newPaymentSchedule = (IBOCE_IB_PaymentScheduleHistory) factory
                        .getStatelessNewInstance(IBOCE_IB_PaymentScheduleHistory.BONAME);
                newPaymentSchedule.setF_IBASSETID(assetBasedPaymentSchedule.getAssetId());
                newPaymentSchedule.setF_IBDEALID(dealId);
                newPaymentSchedule.setF_IBPRINCIPALAMOUNT(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount());
                newPaymentSchedule.setF_IBPROFITAMOUNT(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount());
                newPaymentSchedule.setF_IBREPAYMENTDATE(assetBasedPaymentSchedule.getRepaymentDate());
                newPaymentSchedule.setF_IBRESCHEDULEID(
                        rescheduleRequestId);
                newPaymentSchedule.setF_IBSCHEDULEFEESAMOUNT(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount());
                newPaymentSchedule.setF_IBSUBSIDYAMOUNT(assetBasedPaymentSchedule.getSubsidyAmount().getCurrencyAmount());
                newPaymentSchedule.setF_IBREPAYMENTSTATUS(IBConstants.REPAYMENT_STATUS_UNPAID);
                factory.create(IBOCE_IB_PaymentScheduleHistory.BONAME, newPaymentSchedule);
            }
            persistPreviousPaidInstallments();
        }

    }
    
    private void persistPreviousPaidInstallments() {
    	/*Map<Date, String> dateAndStatusMap = new HashMap<>();
    	ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(getF_IN_dealRescheduleDetails().getDealId());*/
    	ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_dealRescheduleDetails().getDealId());
		/*if(readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getPaymentScheduleCount() > 0) {
			for(LoanPayments loanPayments : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
				if(CalendarUtil.IsDate1GreaterThanDate2(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getReschedulePaymentDate(), 
						loanPayments.getRepaymentDate())) {
					dateAndStatusMap.put(loanPayments.getRepaymentDate(), loanPayments.getRepaymentStatus());
				}
			}
		}*/

		List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);
		if (breakupDtls != null && !breakupDtls.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : breakupDtls) {

				boolean isPartiallyOrFullyPaid = ((null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) < 0)
						|| (null != paymentSchBreakup.getF_IBPRINCIPALAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) < 0)
						|| (null != paymentSchBreakup.getF_IBPROFITAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) < 0)
						|| (null != paymentSchBreakup.getF_IBSUBSIDYAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) < 0)) ? true
										: false;
				if(CalendarUtil.IsDate1GreaterThanDate2(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getReschedulePaymentDate(), 
						paymentSchBreakup.getF_IBBILLDATE()) && isPartiallyOrFullyPaid) {
					IBOCE_IB_PaymentScheduleHistory newPaymentSchedule = (IBOCE_IB_PaymentScheduleHistory) factory
	                        .getStatelessNewInstance(IBOCE_IB_PaymentScheduleHistory.BONAME);
	                newPaymentSchedule.setF_IBASSETID(paymentSchBreakup.getF_IBASSETID());
	                newPaymentSchedule.setF_IBDEALID(paymentSchBreakup.getF_IBDEALID());
	                newPaymentSchedule.setF_IBPRINCIPALAMOUNT(paymentSchBreakup.getF_IBPRINCIPALAMTPAID());
	                newPaymentSchedule.setF_IBPROFITAMOUNT(paymentSchBreakup.getF_IBPROFITAMTPAID());
	                newPaymentSchedule.setF_IBREPAYMENTDATE(paymentSchBreakup.getF_IBBILLDATE());
	                newPaymentSchedule.setF_IBRESCHEDULEID(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
	                newPaymentSchedule.setF_IBSCHEDULEFEESAMOUNT(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
	                newPaymentSchedule.setF_IBSUBSIDYAMOUNT(paymentSchBreakup.getF_IBSUBSIDYAMTPAID());
	                /*if(!dateAndStatusMap.isEmpty()
	                		&& dateAndStatusMap.containsKey(paymentSchBreakup.getF_IBBILLDATE()))*/
	                	newPaymentSchedule.setF_IBREPAYMENTSTATUS(CeConstants.PAYMENT_STATUS_FULLY_PAID);
	                /*else
	                	//this should not reach
	                	newPaymentSchedule.setF_IBREPAYMENTSTATUS(IBConstants.REPAYMENT_STATUS_UNPAID);*/
	                factory.create(IBOCE_IB_PaymentScheduleHistory.BONAME, newPaymentSchedule);
				}
			}
		}
		
	}

    private void removeExistingPaymentsSchedule(String rescheduleRequestId, String dealId) {
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID + "= ? AND "
                + IBOCE_IB_PaymentScheduleHistory.IBDEALID + "= ? ");
        ArrayList<String> params = new ArrayList<String>();
        params.add(rescheduleRequestId);
        params.add(dealId);
        factory.bulkDelete(IBOCE_IB_PaymentScheduleHistory.BONAME, queryCondition.toString(), params);
    }

    private void persistDealRescheduleDetails(BankFusionEnvironment env, Date lastRepaymentDate, BigDecimal subsidyAmount) {
        IBOCE_IB_DealReschedule existingDealRescheduleDetails = (IBOCE_IB_DealReschedule) factory.findByPrimaryKey(
                IBOCE_IB_DealReschedule.BONAME,
                getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId(), true);
        if (null != existingDealRescheduleDetails) {
            updateExistingRecord(env, existingDealRescheduleDetails, lastRepaymentDate, subsidyAmount);
        }
        else {
            createNewRecord(env, lastRepaymentDate, subsidyAmount);
        }
    }

    private void createNewRecord(BankFusionEnvironment env, Date lastRepaymentDate, BigDecimal subsidyAmount) {
        IBOCE_IB_DealReschedule newDealRescheduleDetails = (IBOCE_IB_DealReschedule) factory
                .getStatelessNewInstance(IBOCE_IB_DealReschedule.BONAME);
        newDealRescheduleDetails.setBoID(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
        updateExistingRecord(env, newDealRescheduleDetails, lastRepaymentDate, subsidyAmount);
        newDealRescheduleDetails.setF_IBRECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
        newDealRescheduleDetails.setF_IBRECCREATEDBY(env.getUserID());
        factory.create(IBOCE_IB_DealReschedule.BONAME, newDealRescheduleDetails);
    }

    private void updateExistingRecord(BankFusionEnvironment env, IBOCE_IB_DealReschedule existingDealRescheduleDetails,
    		 Date lastRepaymentDate, BigDecimal subsidyAmount) {
        existingDealRescheduleDetails.setF_IBDEALID(getF_IN_dealRescheduleDetails().getDealId());
        CeRescheduleRequestDetails rescheduleRequestDetails = getF_IN_dealRescheduleDetails().getRescheduleRequestDetails();
        existingDealRescheduleDetails.setF_IBINCLUDESUBSIDY(rescheduleRequestDetails.getIncludeSubsidy());
        existingDealRescheduleDetails.setF_IBOUTSTANDINGINSTALLMENTS(rescheduleRequestDetails.getOutstandingNoOfInstallments());
        existingDealRescheduleDetails
                .setF_IBOUTSTANDINGPRINCIPAL(rescheduleRequestDetails.getOutstandinPrincipal().getCurrencyAmount());
        existingDealRescheduleDetails.setF_IBOUTSTANDINGPROFIT(rescheduleRequestDetails.getOutstandinProfit().getCurrencyAmount());
        existingDealRescheduleDetails.setF_IBRECLASTMODIFIEDBY(env.getUserID());
        existingDealRescheduleDetails.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
        existingDealRescheduleDetails.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
        existingDealRescheduleDetails.setF_IBRESCHEDULECOLLMETHOD(rescheduleRequestDetails.getFeesCollectionMethod());
        existingDealRescheduleDetails.setF_IBRESCHEDULEFREQ(rescheduleRequestDetails.getRescheduleFrequency());
        existingDealRescheduleDetails.setF_IBRESCHEDULEPAYMENTDT(rescheduleRequestDetails.getReschedulePaymentDate());
        existingDealRescheduleDetails
                .setF_IBRESCHEDULEPROFIT(rescheduleRequestDetails.getCurrentRescheduleProfit().getCurrencyAmount());
        existingDealRescheduleDetails.setF_IBRESCHEDULESTATUS(IBConstants.NEW);
        existingDealRescheduleDetails.setF_IBRESCHINSTALLMENTS(rescheduleRequestDetails.getNewRemainingInstallments());
        existingDealRescheduleDetails.setF_IBSCHEDULEFEES(rescheduleRequestDetails.getScheduleFeesAmount().getCurrencyAmount());
        existingDealRescheduleDetails.setF_IBSCHEDULEFEESPER(rescheduleRequestDetails.getScheduleFeesPercentage());
        existingDealRescheduleDetails.setF_IBSURPLUSAMOUNT(rescheduleRequestDetails.getSurplusAmount().getCurrencyAmount());
        existingDealRescheduleDetails.setF_IBTOTALINSTBEFRESCH(rescheduleRequestDetails.getTotalNoOfInstallments());
        existingDealRescheduleDetails.setF_IBMATURITYDATE(lastRepaymentDate);
		existingDealRescheduleDetails.setF_IBSUBSIDYAMOUNT(subsidyAmount);
		existingDealRescheduleDetails.setF_IBRESCHFEESAMOUNT(rescheduleRequestDetails.getFeesAmount().getCurrencyAmount());
		existingDealRescheduleDetails.setF_IBOUTSTANDINGFEE(rescheduleRequestDetails.getOutstandingFees().getCurrencyAmount());
		if(null == rescheduleRequestDetails.getIsGenerate() || rescheduleRequestDetails.getIsGenerate()){
			existingDealRescheduleDetails.setF_IBRESCHEDULETYPE(CeConstants.RESCHEDULE_TYPE_GENERATE);
		}else if(rescheduleRequestDetails.getIsDistribute()){
			existingDealRescheduleDetails.setF_IBRESCHEDULETYPE(CeConstants.RESCHEDULE_TYPE_DISTRIBUTE);
		}else if(rescheduleRequestDetails.getIsPostpone()){
			existingDealRescheduleDetails.setF_IBRESCHEDULETYPE(CeConstants.RESCHEDULE_TYPE_POSTPONE);
		}
    }
    private void persistPostponeAndDistributeDetails() {
        removeExistingPAndDDetails();
        if (getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsDistribute()!=null && getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsDistribute() &&
        		getF_IN_dealRescheduleDetails().getDistributePaymentSchedule() != null && getF_IN_dealRescheduleDetails().getDistributePaymentSchedule().length>0) {
            for (CeDistributePaymentSchedule distSchedule : getF_IN_dealRescheduleDetails().getDistributePaymentSchedule()) {
            	IBOCE_IB_RESCHEDULEDISTDETAILS distScheduleDB = (IBOCE_IB_RESCHEDULEDISTDETAILS) factory
                        .getStatelessNewInstance(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME);
            	distScheduleDB.setBoID(GUIDGen.getNewGUID());
            	distScheduleDB.setF_IBRESCHEDULEID(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
            	distScheduleDB.setF_IBDEALID(getF_IN_dealRescheduleDetails().getDealId());
            	distScheduleDB.setF_IBBILLDATE(distSchedule.getRepaymentDate());
            	distScheduleDB.setF_IBBILLOLDDATE(distSchedule.getRepaymentDate());//repaydate
            	distScheduleDB.setF_IBDISTRIBUTE(distSchedule.getIsDistribute());
            	distScheduleDB.setF_IBSELECT(distSchedule.getIsSkipRepayment());
            	distScheduleDB.setF_IBPRINCIPALAMT(distSchedule.getPrincipalAmount().getCurrencyAmount());
            	distScheduleDB.setF_IBPROFITAMT(distSchedule.getProfitAmount().getCurrencyAmount());
            	distScheduleDB.setF_IBSCHEDULEFEEAMT(distSchedule.getFeesAmount().getCurrencyAmount());
            	distScheduleDB.setF_IBSUBSIDYAMNT(distSchedule.getSubsidyAmount().getCurrencyAmount());
            	distScheduleDB.setF_IBSTATUS(distSchedule.getStatus());
                factory.create(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME, distScheduleDB);
            }
        }
        if (getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsPostpone()!=null && getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getIsPostpone() && 
        		getF_IN_dealRescheduleDetails().getPostPonePaymentSchedule() != null && getF_IN_dealRescheduleDetails().getPostPonePaymentSchedule().length>0) {
        	for (CePostPonePaymentSchedule postPoneSchedule : getF_IN_dealRescheduleDetails().getPostPonePaymentSchedule()) {
        		IBOCE_IB_RESCHEDULEDISTDETAILS distScheduleDB = (IBOCE_IB_RESCHEDULEDISTDETAILS) factory
        				.getStatelessNewInstance(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME);
        		distScheduleDB.setBoID(GUIDGen.getNewGUID());
        		distScheduleDB.setF_IBRESCHEDULEID(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
        		distScheduleDB.setF_IBDEALID(getF_IN_dealRescheduleDetails().getDealId());
        		distScheduleDB.setF_IBBILLOLDDATE(postPoneSchedule.getRepaymentOldDate());
        		distScheduleDB.setF_IBBILLDATE(postPoneSchedule.getRepaymentNewDate());
        		distScheduleDB.setF_IBDISTRIBUTE(false);
        		distScheduleDB.setF_IBSELECT(false);
        		distScheduleDB.setF_IBPRINCIPALAMT(postPoneSchedule.getPrincipalAmount().getCurrencyAmount());
        		distScheduleDB.setF_IBPROFITAMT(postPoneSchedule.getProfitAmount().getCurrencyAmount());
        		distScheduleDB.setF_IBSCHEDULEFEEAMT(postPoneSchedule.getFeesAmount().getCurrencyAmount());
        		distScheduleDB.setF_IBSUBSIDYAMNT(postPoneSchedule.getSubsidyAmount().getCurrencyAmount());
        		distScheduleDB.setF_IBSTATUS(postPoneSchedule.getStatus());
        		factory.create(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME, distScheduleDB);
        	}
        }
    }

    private void removeExistingPAndDDetails() {
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_RESCHEDULEDISTDETAILS.IBRESCHEDULEID + "= ?");
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_dealRescheduleDetails().getRescheduleRequestDetails().getRescheduleRequestId());
        factory.bulkDelete(IBOCE_IB_RESCHEDULEDISTDETAILS.BONAME, queryCondition.toString(), params);
    }

}
