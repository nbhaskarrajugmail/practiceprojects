/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateDisbursementFeesAndProfit;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_FeesConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOBanks;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.types.GcCodeDetail;

/**
 * @author Aklesh
 *
 */
public class CalculateDisbursementFeesAndProfit extends AbstractCE_IB_CalculateDisbursementFeesAndProfit {

	private static final long serialVersionUID = 7137308733675905581L;

	public CalculateDisbursementFeesAndProfit(BankFusionEnvironment env) {
		super(env);

	}

	public CalculateDisbursementFeesAndProfit() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		calculateFeesDetails(getF_IN_islamicBankingObject().getDealID());
		calculateProfitDetails(getF_IN_islamicBankingObject().getDealID());
		setF_OUT_listDebitBanks(IBCommonUtils.getGCList("OTHERBANKNAME"));
		/*List<IBOBanks> banks= BankFusionThreadLocal.getPersistanceFactory().findAll(IBOBanks.BONAME, null);
		getF_OUT_listDebitBanks().removeAllGcCodeDetails();
		for (IBOBanks iboBanks : banks) {
			GcCodeDetail codeDetail = new GcCodeDetail();
			codeDetail.setCodeDescription(iboBanks.getF_BANKNAME());
			codeDetail.setCodeReference(iboBanks.getBoID());
			getF_OUT_listDebitBanks().addGcCodeDetails(codeDetail);
		}*/
	}
	
	public void calculateFeesDetails(String dealId) {
      String feeCollectionMethod  = CeUtils.getUDFValueByName(dealId,CeConstants.FEE_COLLECTION_METHOD).toString();       

       /*
          UserDefinedFields userDefinedFields = CeUtils.getUserExtension(dealId);
        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(feeCollectionMethodId)) {
                feeCollectionMethod = (String) list.getFieldValue();
            }
        }*/
        if ("DEDUCT FROM DISBURSEMENT".equals(feeCollectionMethod)) {

            String whereClause = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ? AND " + IBOIB_DLI_DealAssetChargesdtls.ISUPFRONT
                + "='Y' AND " + IBOIB_DLI_DealAssetChargesdtls.ISWAIVED + " = 'N'";
            ArrayList<String> params = new ArrayList<String>();
            params.add(dealId);
            List<IBOIB_DLI_DealAssetChargesdtls> list = new ArrayList<IBOIB_DLI_DealAssetChargesdtls>();
            list = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, whereClause, params, null,
                false);
            String intialFeeId= BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
    	            CeConstants.INITIAL_FEES_FEESID, "", CeConstants.ADFIBCONFIGLOCATION);
    		String adjustmentFeesId= BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
    	            CeConstants.ADJUSTMENT_FEES_FEESID, "", CeConstants.ADFIBCONFIGLOCATION);
			for (IBOIB_DLI_DealAssetChargesdtls iboib_DLI_DealAssetChargesdtls : list) {
				IBOIB_CFG_FeesConfig feeConfig = (IBOIB_CFG_FeesConfig) BankFusionThreadLocal.getPersistanceFactory()
	                    .findByPrimaryKey(IBOIB_CFG_FeesConfig.BONAME, iboib_DLI_DealAssetChargesdtls.getF_FEESCONFIGID(), true);
				if (intialFeeId.equalsIgnoreCase(feeConfig.getF_FEESID())) {
					BigDecimal totalFees = iboib_DLI_DealAssetChargesdtls.getF_OriginalChgAmount();
					BigDecimal unpaidFees =iboib_DLI_DealAssetChargesdtls.getF_UNPAIDCHARGEAMOUNT();
					BigDecimal feesPaid = totalFees.subtract(unpaidFees);
					getF_OUT_issuePayOrderDtls().setTotalFees(totalFees);
					getF_OUT_issuePayOrderDtls().setOutstandingFees(unpaidFees);
					getF_OUT_issuePayOrderDtls().setPaidFees(feesPaid);
				}
				if (adjustmentFeesId.equalsIgnoreCase(feeConfig.getF_FEESID())) {
					BigDecimal totalFees = iboib_DLI_DealAssetChargesdtls.getF_OriginalChgAmount();
					BigDecimal unpaidFees =iboib_DLI_DealAssetChargesdtls.getF_UNPAIDCHARGEAMOUNT();
					BigDecimal feesPaid = totalFees.subtract(unpaidFees);
					getF_OUT_issuePayOrderDtls().setTotalAdjustmentFees(totalFees);
					getF_OUT_issuePayOrderDtls().setOutstandingAdjustmentFees(unpaidFees);
					getF_OUT_issuePayOrderDtls().setPaidAdjustmentFees(feesPaid);
				}
			}
        }else {
        	setF_OUT_isFeesRequired(false);
        }
    }

    public void calculateProfitDetails(String dealId) {
        String upfrontProfitMethod = "";
        BigDecimal upfrontAmount = BigDecimal.ZERO;
        BigDecimal calcUpfrontAmount = BigDecimal.ZERO;
        String upfrontProfitMethodId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.UPFRONT_PROFIT_COLLECTION, "", CeConstants.ADFIBCONFIGLOCATION);
        String upfrontProfitAmountId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.UPFRONT_PROFIT_AMOUNT, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = CeUtils.getUserExtension(dealId);

        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(upfrontProfitMethodId)) {
                upfrontProfitMethod = (String) list.getFieldValue();
            }
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(upfrontProfitAmountId)) {
                upfrontAmount = (BigDecimal) list.getFieldValue();
            }
        }
		if ("DEDUCT FROM DISBURSEMENT".equals(upfrontProfitMethod)) {
			BigDecimal paidProfit = BigDecimal.ZERO;
			String WHERE_CLAUSE_ISSUEPO = "WHERE " + IBOCE_IB_IssuePODetail.IBDEALID + "=? AND "
					+ IBOCE_IB_IssuePODetail.IBSTATUS + "=?";
			ArrayList<String> params = new ArrayList<String>();
			params.add(dealId);
			params.add("Processed");
			List<IBOCE_IB_IssuePODetail> ib_IssuePODetails = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_IssuePODetail.BONAME, WHERE_CLAUSE_ISSUEPO, params, null, false);
			for (IBOCE_IB_IssuePODetail iboce_IB_IssuePODetail : ib_IssuePODetails) {
				paidProfit = paidProfit.add(iboce_IB_IssuePODetail.getF_IBUPFRONTFEE());
			}
			calcUpfrontAmount = upfrontAmount;
			getF_OUT_issuePayOrderDtls().setUpfrontProfitToBePaid(calcUpfrontAmount);
			getF_OUT_issuePayOrderDtls().setOutstandingUpfrontProfit(calcUpfrontAmount.subtract(paidProfit));
			getF_OUT_issuePayOrderDtls().setPaidUpfrontProfit(paidProfit);
		}


    }
}
