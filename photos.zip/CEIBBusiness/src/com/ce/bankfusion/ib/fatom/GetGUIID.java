package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetGUIID;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_GetGUIID;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.utils.GUIDGen;

public class GetGUIID extends AbstractCE_IB_GetGUIID implements ICE_IB_GetGUIID {

    public GetGUIID() {
    }
    public GetGUIID(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        setF_OUT_generatedID(GUIDGen.getNewGUID());
    }

}
