package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SelectTitleDeedRequestEval;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class SelectTitleDeedRequestEval extends AbstractCE_IB_SelectTitleDeedRequestEval{

    public SelectTitleDeedRequestEval() {
        super();
  }
  @SuppressWarnings("deprecation")
    public SelectTitleDeedRequestEval(BankFusionEnvironment env) {
    
    }
  
  @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
    String idpk = null;
    TitleDeedDetailsType titleDeedDtls = new TitleDeedDetailsType();
      SearchTitleDeedDtlsRsType list = getF_IN_listTitleDeed();
      for(TitleDeedDetailsType listTitleDeedDtls : list.getListTitleDeedIdDtls().getTitleDeedDetails()) {
          if(listTitleDeedDtls.isSelect()) {
              idpk = listTitleDeedDtls.getTitleDeedIdpk();
              titleDeedDtls.setAreaSize(listTitleDeedDtls.getAreaSize());
              titleDeedDtls.setTitleDeedIdpk(listTitleDeedDtls.getTitleDeedIdpk());
              titleDeedDtls.setDicissionStatus(listTitleDeedDtls.getDicissionStatus());
              titleDeedDtls.setFarmLocation(listTitleDeedDtls.getFarmLocation());
              titleDeedDtls.setLandPlanNumber(listTitleDeedDtls.getLandPlanNumber());
              titleDeedDtls.setLandPlotNumber(listTitleDeedDtls.getLandPlotNumber());
              titleDeedDtls.setLinkedToCollateral(listTitleDeedDtls.getLinkedToCollateral());
              titleDeedDtls.setNotes(listTitleDeedDtls.getNotes());
              titleDeedDtls.setReasonForChange(listTitleDeedDtls.getReasonForChange());
              titleDeedDtls.setRetailIndex(listTitleDeedDtls.getRetailIndex());
              titleDeedDtls.setSplitIndicator(listTitleDeedDtls.getSplitIndicator());
              titleDeedDtls.setStatus(listTitleDeedDtls.getStatus());
              titleDeedDtls.setTitleDeedNumber(listTitleDeedDtls.getTitleDeedNumber());
              titleDeedDtls.setTitleDeedSource(listTitleDeedDtls.getTitleDeedSource());
              titleDeedDtls.setTitleDeedStatus(listTitleDeedDtls.getTitleDeedStatus());
              titleDeedDtls.setTitleDeedType(listTitleDeedDtls.getTitleDeedType());
              titleDeedDtls.setTitleDeedYear(listTitleDeedDtls.getTitleDeedYear());
              titleDeedDtls.setTransactionDate(listTitleDeedDtls.getTransactionDate());
              titleDeedDtls.setTransactionNotes(listTitleDeedDtls.getTransactionNotes());
              titleDeedDtls.setTransactionType(listTitleDeedDtls.getTransactionType());
              titleDeedDtls.setValidFrom(listTitleDeedDtls.getValidFrom());
              titleDeedDtls.setValidFromHijri(listTitleDeedDtls.getValidFromHijri());
              titleDeedDtls.setValidTo(listTitleDeedDtls.getValidTo());
              titleDeedDtls.setValidToHijri(listTitleDeedDtls.getValidToHijri()); 
              titleDeedDtls.setVersionNumber(listTitleDeedDtls.getVersionNumber());
              
              
              break;
          }
      }

      setF_OUT_idpk(idpk);
      
    setF_OUT_titleDeed(titleDeedDtls);
  }
}
