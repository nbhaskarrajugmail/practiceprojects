package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CustomerLiabilitiesOfIssuePO;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePaymentOrder;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistIssuePayOrderDtls;
import com.misys.bankfusion.common.GUIDGen;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.IssuePayOrderDtls;

public class PersistIssuePayOrderDtls extends AbstractCE_IB_PersistIssuePayOrderDtls {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	private static final transient Log LOG = LogFactory.getLog(PersistIssuePayOrderDtls.class.getName());
	private static final int ISSUE_PAYMENT_ORDER_GREATER_THAN_ZERO = 44000228;

	public PersistIssuePayOrderDtls() {
		super();
	}

	@SuppressWarnings("deprecation")
	public PersistIssuePayOrderDtls(BankFusionEnvironment env) {
		super(env);
	}

	@SuppressWarnings({ "deprecation" })
	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		/*IssuePayOrderDtls issuePayOrderDtls = getF_IN_issuePayOrderDtl();
		persistIssuePayOderDtls(issuePayOrderDtls,env);
		persistCustLiabDtls(issuePayOrderDtls);*/
	}

	/*private void persistIssuePayOderDtls(IssuePayOrderDtls issuePayOrderDtls, BankFusionEnvironment env) {
		CalculateCustomerLiablitiesAmt calculateCustomerLiablitiesAmt= new CalculateCustomerLiablitiesAmt();
		calculateCustomerLiablitiesAmt.validateFeesToBePaidAmt(issuePayOrderDtls, env);
		if(issuePayOrderDtls.getPaymentOrderAmt().compareTo(BigDecimal.ZERO)>0)
		{
		deleteIssueOrderDtls(issuePayOrderDtls);
		IBOCE_IB_IssuePaymentOrder newIssuePaymentOrder = (IBOCE_IB_IssuePaymentOrder) factory
				.getStatelessNewInstance(IBOCE_IB_IssuePaymentOrder.BONAME);
		newIssuePaymentOrder.setF_CUSTLIABDEDUCTED(issuePayOrderDtls.getCustomerLiabilitiesToBeDeducted());
		newIssuePaymentOrder.setF_DEALID(issuePayOrderDtls.getDealId());
		newIssuePaymentOrder.setF_DISBURSEMENTAMOUNT(issuePayOrderDtls.getDisbursementAmt());
		newIssuePaymentOrder.setF_FEESDEDUCTED(issuePayOrderDtls.getFeesToBeDeducted());
		newIssuePaymentOrder.setF_UPAMTDEDUCTED(issuePayOrderDtls.getUpfrontProfitToBeDeducted());
		newIssuePaymentOrder.setF_FEESTOBEPAID(issuePayOrderDtls.getFeesToBePaid());
		newIssuePaymentOrder.setF_UPAMTTOBEPAID(issuePayOrderDtls.getUpfrontProfitToBePaid());
		newIssuePaymentOrder.setF_OUTSTANDINGCUSTLIAB(issuePayOrderDtls.getOutstandingCustomerLiabilities());
		BigDecimal outstandingFees= issuePayOrderDtls.getFeesToBeDeducted().subtract(issuePayOrderDtls.getPaidFees().add(issuePayOrderDtls.getFeesToBePaid()));
		BigDecimal outstandingUpfrontProfit= issuePayOrderDtls.getUpfrontProfitToBeDeducted().subtract(issuePayOrderDtls.getPaidUpfrontProfit().add(issuePayOrderDtls.getUpfrontProfitToBePaid()));
		
		newIssuePaymentOrder.setF_OUTSTANDINGFEES(outstandingFees);
		newIssuePaymentOrder.setF_OUTSTANDINGUPAMT(outstandingUpfrontProfit);
		
		newIssuePaymentOrder.setF_OUTSTANDINGFEESINDISB(issuePayOrderDtls.getOutstandingFeesInDisb());
		newIssuePaymentOrder.setF_OUTSTANDINGUPAMTINDISB(issuePayOrderDtls.getOutstandingUpfrontProfitInDisb());
		newIssuePaymentOrder.setF_PAIDFEES(issuePayOrderDtls.getFeesToBePaid().add(issuePayOrderDtls.getPaidFees()));
		newIssuePaymentOrder.setF_PAIDUPAMT(issuePayOrderDtls.getUpfrontProfitToBePaid().add(issuePayOrderDtls.getPaidUpfrontProfit()));
		newIssuePaymentOrder.setF_PAYMENTORDERAMOUNT(issuePayOrderDtls.getPaymentOrderAmt());
		newIssuePaymentOrder.setBoID(GUIDGen.getNewGUID());
		factory.create(IBOCE_IB_IssuePaymentOrder.BONAME, newIssuePaymentOrder);
		}
		else {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(ISSUE_PAYMENT_ORDER_GREATER_THAN_ZERO, new Object[] {},
					LOG, env);
		}

	}

	private int deleteIssueOrderDtls(IssuePayOrderDtls issuePayOrderDtls) {
		int res = 0;
		if ((StringUtils.isNotEmpty(issuePayOrderDtls.getDealId()))) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(issuePayOrderDtls.getDealId());
			String WHERECLAUSE = "where " + IBOCE_IB_IssuePaymentOrder.DEALID + " = ? ";
			res = factory.bulkDelete(IBOCE_IB_IssuePaymentOrder.BONAME, WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}

	private void persistCustLiabDtls(IssuePayOrderDtls issuePayOrderDtls) {
		CustomerLiabilities[] customerLiabilities = issuePayOrderDtls.getCustomerLiabilitiesDtls();
		deleteCustLiab(issuePayOrderDtls.getDealId());
		for (int i = 0; i < customerLiabilities.length; i++) {

			IBOCE_IB_CustomerLiabilitiesOfIssuePO newCustomerLiabilities = (IBOCE_IB_CustomerLiabilitiesOfIssuePO) factory
					.getStatelessNewInstance(IBOCE_IB_CustomerLiabilitiesOfIssuePO.BONAME);
			newCustomerLiabilities.setF_DEALIDOFCUSTOMER(customerLiabilities[i].getDealId());
			newCustomerLiabilities.setF_DEALIDOFPO(issuePayOrderDtls.getDealId());
			newCustomerLiabilities.setF_OUTSTANDINGAMOUNT((customerLiabilities[i].getOutstandingAmt()));
			newCustomerLiabilities.setF_SELECT(customerLiabilities[i].getSelect());
			newCustomerLiabilities.setF_UESRROLE(customerLiabilities[i].getTransactionType());
			newCustomerLiabilities.setF_TRANSACTIONTYPE("user");
			
			factory.create(IBOCE_IB_CustomerLiabilitiesOfIssuePO.BONAME, newCustomerLiabilities);

		}
	}

	private int deleteCustLiab(String dealId) {
		int res = 0;
		if ((StringUtils.isNotEmpty(dealId))) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(dealId);
			String WHERECLAUSE = "where " + IBOCE_IB_CustomerLiabilitiesOfIssuePO.DEALIDOFPO + " = ? ";
			res = factory.bulkDelete(IBOCE_IB_CustomerLiabilitiesOfIssuePO.BONAME, WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}*/
}
