package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UpdateScheduleRefundStatus;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.RefundFeesDtls;
import bf.com.misys.ib.types.RefundFeesDtlsList;

public class UpdateScheduleRefundStatus extends AbstractCE_IB_UpdateScheduleRefundStatus{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public UpdateScheduleRefundStatus()
	{
		super();
	}
	
	public UpdateScheduleRefundStatus(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		boolean scheduleRefund = isF_IN_scheduleRefund();
		boolean cancelRefund = isF_IN_cancelRefund();
		boolean disableFields = false;
		boolean test=false;
		
		RefundFeesDtlsList refundFeesList = getF_IN_refundFeesDtlsList();
		
		for(RefundFeesDtls refundFee : refundFeesList.getRefundFeesDtls()) {
			if(scheduleRefund && refundFee.isSelect()) {
				refundFee.setRefundStatus("SCHEDULED");
				
				//if(getF_IN_bankAccountId().isEmpty())
					//IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PARTY_OTHER_BANK_ACC_MANDATORY);
				
				refundFee.setBankAccountId(getF_IN_bankAccountId());
				refundFee.setDescription(getF_IN_description());
			} else if(cancelRefund && refundFee.isSelect()){
				refundFee.setRefundStatus("");
			} else if(refundFee.isSelect() && refundFee.getRefundStatus().equalsIgnoreCase("REFUNDED")) {
				disableFields = true;
			}
		}
		
				
		setF_OUT_refundFeesDtlsList(refundFeesList);
		
		//View Mode Or Edit Mode
				IBOIB_CFG_BuildingBlockConfig buildingBlockConfig = IBCommonUtils.getConfiguredBuildingBlock(ibObject.getPhaseID(), ibObject.getProductID(), ibObject.getSubProductID(), ibObject.getStepID(), ibObject.getProcessConfigID());
				
				
				String mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
				
				if(mode.equalsIgnoreCase(IBConstants.VIEWMODE)) {
					disableFields = true;
				}
				
				setF_OUT_disableFields(disableFields);
				
	}

}
