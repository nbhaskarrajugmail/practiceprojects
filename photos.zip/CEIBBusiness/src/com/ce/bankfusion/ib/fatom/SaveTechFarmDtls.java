package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveTechFarmDtls;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;

public class SaveTechFarmDtls extends AbstractCE_IB_SaveTechFarmDtls {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final transient Log LOG = LogFactory.getLog(SaveTechFarmDtls.class.getName());

	public static final int AREA_DETAILS_MANDATORY = 44000215;
	public static final int TOTAL_AREA_TOTAL_TITLE_DEED_AREA = 44000447;
	public static final int AREA_AND_COORDINATES_MANDATORY = 44000216;
	public static final int TOTAL_ALL_DEEDS_TOTAL_CROPS_COMP = 44000234;
	private static final int ALL_COORDINATES_AND_PORT_DETAILS_MANDATARY = 44000239;
	private static final int ALL_GUARD_DATA_DETAILS_MANDATARY = 44000240;
	private static final int ALL_WEALTH_DATA_DETAILS_MANDATARY = 44000241;
	private static final int FARM_DOOR_COORDINATE_MANDATORY_ADF = 44000243;
	public static final int E_MIN_FOUR_COORDINATE_SHOULD_BE_CHECKED_IB = 44000445;

	public SaveTechFarmDtls(BankFusionEnvironment env) {
		super(env);

	}

	public SaveTechFarmDtls() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		TechnicalFarmDtl technicalFarmDtl = getF_IN_technicalFarmDtl();
		TechnicalAnalysisDtls technicalAnalysisDtls = getF_IN_technicalAnalysisDtls();
		TechnicalAnalysisDtls hiddenTechAnalysisDtls = new TechnicalAnalysisDtls();
		TechnicalFarmDtlList hiddenTechFarmDtls = getF_IN_hiddenTechDtls().getTechnicalFarmDtlsList();
		TechnicalAreaDtlList techAreaDtlsInput = technicalAnalysisDtls.getTechnicalAreaDtlsList();
		TechnicalAreaDtlList hiddenTechAreaDtls = getF_IN_hiddenTechDtls().getTechnicalAreaDtlsList();
		AssetUDFsCollection technicalAssetUDF = technicalAnalysisDtls.getTechnicalAssetUDFs();
		//TODO This Part needs to be done
		//getF_IN_hiddenTechDtls().getTechnicalAssetUDFs();
		TechnicalAreaCoordinateDtlList techAreaCoordDtlsInput = technicalAnalysisDtls.getTechnicalAreaCoordinatesList();
		TechnicalAreaCoordinateDtlList hiddenGridOnlyCoordinate = getF_IN_hiddenTechDtls()
				.getTechnicalAreaCoordinatesList();

		TechnicalCropDtlList techCropDtlsInput = technicalAnalysisDtls.getTechnicalCropDtlsList();
		TechnicalCropDtlList hiddenTechCropDtls = getF_IN_hiddenTechDtls().getTechnicalCropDtlsList();

		TechincalAssetDtlsList techAssetDtlsInput = technicalAnalysisDtls.getTechnicalAssetDtlsList();
		TechincalAssetDtlsList hiddenTechAssetDtls = getF_IN_hiddenTechDtls().getTechnicalAssetDtlsList();
		validateAreaAndCropsData(techAreaDtlsInput, techCropDtlsInput, env);
		ValidateDoorOfTheFarmCoordinates(techAreaDtlsInput.getTechnicalAreaDtlListCount(), technicalFarmDtl);
		String referenceNum = saveTechFarmDtl(technicalFarmDtl, hiddenTechFarmDtls, env);
		//validateTechAreaAndCoordinateDtls(technicalAnalysisDtls, env);
		if (isF_IN_titileDeedVisibility()) {
			saveTechAreaDtls(techAreaDtlsInput, hiddenTechAreaDtls, techAreaCoordDtlsInput, hiddenGridOnlyCoordinate,
					referenceNum);
		}
		if(isF_IN_cropsVisibility())
			saveTechCropDtl(techCropDtlsInput, hiddenTechCropDtls, referenceNum);
		
		saveTechAssetDtl(techAssetDtlsInput, hiddenTechAssetDtls, referenceNum);
		TechnicalWellDtlsList techWellDtlsInput = technicalAnalysisDtls.getTechnicalWellDtlsList();
		TechnicalWellDtlsList hiddenTechWellDtls = getF_IN_hiddenTechDtls().getTechnicalWellDtlsList();
		saveTechWellDtl(techWellDtlsInput, hiddenTechWellDtls, referenceNum);
		// saveTechAssetUDFDtl(technicalAssetUDF,hiddenTechAssetUDF,referenceNum);

		hiddenTechAnalysisDtls.setTechnicalAreaCoordinatesList(hiddenGridOnlyCoordinate);
		hiddenTechAnalysisDtls.setTechnicalAreaDtlsList(hiddenTechAreaDtls);
		hiddenTechAnalysisDtls.setTechnicalAssetDtlsList(hiddenTechAssetDtls);
		hiddenTechAnalysisDtls.setTechnicalCropDtlsList(hiddenTechCropDtls);
		hiddenTechAnalysisDtls.setTechnicalFarmDtlsList(hiddenTechFarmDtls);
		hiddenTechAnalysisDtls.setTechnicalAssetUDFs(technicalAssetUDF);
		hiddenTechAnalysisDtls.setTechnicalWellDtlsList(hiddenTechWellDtls);
		setF_OUT_technicalDtlsList(hiddenTechAnalysisDtls);
		setF_OUT_technicalFarmDtlList(hiddenTechFarmDtls);
	}

	private void ValidateDoorOfTheFarmCoordinates(int titleDeedsCount, TechnicalFarmDtl technicalFarmDtl) {
		if (titleDeedsCount > CommonConstants.INTEGER_ZERO) {
			if (((technicalFarmDtl.getEastCoordinate().equals(CommonConstants.EMPTY_STRING))
					|| (technicalFarmDtl.getEastCoordinateO().equals(CommonConstants.EMPTY_STRING))
					|| (technicalFarmDtl.getNorthCoordinate().equals(CommonConstants.EMPTY_STRING))
					|| (technicalFarmDtl.getNorthCoordinateO().equals(CommonConstants.EMPTY_STRING)))) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(FARM_DOOR_COORDINATE_MANDATORY_ADF,
						new Object[] {}, LOG, BankFusionThreadLocal.getBankFusionEnvironment());
			}
		}
	}

	private void validateAreaAndCropsData(TechnicalAreaDtlList techAreaDtlsInput,
			TechnicalCropDtlList techCropDtlsInput, BankFusionEnvironment env) {
		if (techAreaDtlsInput.getTechnicalAreaDtlListCount() > CommonConstants.INTEGER_ZERO
				&& techCropDtlsInput.getTechnicalCropDtlListCount() > CommonConstants.INTEGER_ZERO) {
			BigDecimal totalAreaforAllDeeds = new BigDecimal(
					techAreaDtlsInput.getTechnicalAreaDtlList(0).getTotalAreaForAllDeeds());
			BigDecimal totalAreaForAllCrops = new BigDecimal(
					techCropDtlsInput.getTechnicalCropDtlList(0).getTotalAreaForAlCrop());
			if (totalAreaForAllCrops.compareTo(totalAreaforAllDeeds) > CommonConstants.INTEGER_ZERO) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(TOTAL_ALL_DEEDS_TOTAL_CROPS_COMP,
						new Object[] {}, LOG, env);
			}
		}
	}

	/*
	 * private void saveTechAssetUDFDtl(AssetUDFsCollection technicalAssetUDF,
	 * AssetUDFsCollection hiddenTechAssetUDF, String referenceNum) {
	 * 
	 * for (AssetUDF assetUdfDtl : technicalAssetUDF.getAssetUDFs()) {
	 * 
	 * AssetUDF eachAssetUDF = new AssetUDF();
	 * eachAssetUDF.setAssetid(assetUdfDtl.getAssetid());
	 * eachAssetUDF.setFieldId(assetUdfDtl.getFieldId());
	 * eachAssetUDF.setFieldValue(assetUdfDtl.getFieldValue());
	 * hiddenTechAssetUDF.addAssetUDFs(eachAssetUDF);
	 * 
	 * }
	 * 
	 * }
	 */

	private String saveTechFarmDtl(TechnicalFarmDtl technicalFarmDtl, TechnicalFarmDtlList hiddenTechFarmDtls,
			BankFusionEnvironment env) {
		String referenceNum = new String();
		validateFishermanDetails(technicalFarmDtl, env);
		if (hiddenTechFarmDtls.getTechnicalFarmDtlList().length > 0
				&& !StringUtils.isEmpty(technicalFarmDtl.getReferenceNumber())) {
			for (int i = 0; i < hiddenTechFarmDtls.getTechnicalFarmDtlListCount(); i++) {
				if (hiddenTechFarmDtls.getTechnicalFarmDtlList(i).getReferenceNumber()
						.equals(technicalFarmDtl.getReferenceNumber())) {
					technicalFarmDtl.setFarmTypeRef(technicalFarmDtl.getFarmType());
					technicalFarmDtl.setSoilTypeRef(technicalFarmDtl.getSoilType());
					technicalFarmDtl.setWaterAvailabiltyRef(technicalFarmDtl.getWaterAvailabilty());
					technicalFarmDtl.setPurposeRef(technicalFarmDtl.getPurpose());
					hiddenTechFarmDtls.setTechnicalFarmDtlList(i, technicalFarmDtl);
					referenceNum = technicalFarmDtl.getReferenceNumber();

				}
			}
		} else {

			TechnicalFarmDtl vTechnicalFarmDtl = new TechnicalFarmDtl();
			referenceNum = generateReportTechId(env);
			vTechnicalFarmDtl.setDate(technicalFarmDtl.getDate());
			vTechnicalFarmDtl.setDealId(technicalFarmDtl.getDealId());
			vTechnicalFarmDtl.setEastCoordinate(technicalFarmDtl.getEastCoordinate());
			vTechnicalFarmDtl.setEastCoordinateO(technicalFarmDtl.getEastCoordinateO());
			vTechnicalFarmDtl.setElectricitySrcAvailable(technicalFarmDtl.getElectricitySrcAvailable());
			vTechnicalFarmDtl.setFarmType(technicalFarmDtl.getFarmType());
			vTechnicalFarmDtl.setFarmTypeRef(technicalFarmDtl.getFarmType());
			vTechnicalFarmDtl.setInspectorName(technicalFarmDtl.getInspectorName());
			vTechnicalFarmDtl.setNorthCoordinate(technicalFarmDtl.getNorthCoordinate());
			vTechnicalFarmDtl.setNorthCoordinateO(technicalFarmDtl.getNorthCoordinateO());
			vTechnicalFarmDtl.setNotesAndConditions(technicalFarmDtl.getNotesAndConditions());
			vTechnicalFarmDtl.setNumberOfReceipt(technicalFarmDtl.getNumberOfReceipt());
			vTechnicalFarmDtl.setOtherFindings(technicalFarmDtl.getOtherFindings());
			vTechnicalFarmDtl.setPurpose(technicalFarmDtl.getPurpose());
			vTechnicalFarmDtl.setPurposeRef(technicalFarmDtl.getPurpose());
			vTechnicalFarmDtl.setReferenceNumber(referenceNum);
			vTechnicalFarmDtl.setSignExist(technicalFarmDtl.getSignExist());
			vTechnicalFarmDtl.setSoilType(technicalFarmDtl.getSoilType());
			vTechnicalFarmDtl.setSoilTypeRef(technicalFarmDtl.getSoilType());
			vTechnicalFarmDtl.setWaterAvailabilty(technicalFarmDtl.getWaterAvailabilty());
			vTechnicalFarmDtl.setWaterAvailabiltyRef(technicalFarmDtl.getWaterAvailabilty());

			vTechnicalFarmDtl.setAreaAssignedForSpclPrj(technicalFarmDtl.getAreaAssignedForSpclPrj());
			// For Fisherman Same table needs to be updated
			vTechnicalFarmDtl.setLicenseNumber(technicalFarmDtl.getLicenseNumber());
			vTechnicalFarmDtl.setFishLicenseDate(technicalFarmDtl.getFishLicenseDate());
			vTechnicalFarmDtl.setFishLicenseDateHijri(technicalFarmDtl.getFishLicenseDateHijri());
			vTechnicalFarmDtl.setLicenseType(technicalFarmDtl.getLicenseType());
			vTechnicalFarmDtl.setLicenseSource(technicalFarmDtl.getLicenseSource());
			vTechnicalFarmDtl.setNoOfBoats(technicalFarmDtl.getNoOfBoats());
			vTechnicalFarmDtl.setFishNorthCoordinate(technicalFarmDtl.getFishNorthCoordinate());
			vTechnicalFarmDtl.setFishNorthCoordinateO(technicalFarmDtl.getFishNorthCoordinateO());
			vTechnicalFarmDtl.setFishEastCoordinate(technicalFarmDtl.getFishEastCoordinate());
			vTechnicalFarmDtl.setFishEastCoordinateO(technicalFarmDtl.getFishEastCoordinateO());
			vTechnicalFarmDtl.setFishPort(technicalFarmDtl.getFishPort());
			vTechnicalFarmDtl.setLetterNumber(technicalFarmDtl.getLetterNumber());
			vTechnicalFarmDtl.setLetterDate(technicalFarmDtl.getLetterDate());
			vTechnicalFarmDtl.setLetterDateHijri(technicalFarmDtl.getLetterDateHijri());
			vTechnicalFarmDtl.setLetterSource(technicalFarmDtl.getLetterSource());
			vTechnicalFarmDtl.setWealthLetterNumber(technicalFarmDtl.getWealthLetterNumber());
			vTechnicalFarmDtl.setWealthLetterDate(technicalFarmDtl.getWealthLetterDate());
			vTechnicalFarmDtl.setWealthLetterDateHijri(technicalFarmDtl.getWealthLetterDateHijri());
			vTechnicalFarmDtl.setWealthLetterSource(technicalFarmDtl.getWealthLetterSource());
			hiddenTechFarmDtls.addTechnicalFarmDtlList(vTechnicalFarmDtl);

		}

		return referenceNum;
	}

	private void validateFishermanDetails(TechnicalFarmDtl technicalFarmDtl, BankFusionEnvironment env) {

		if (((technicalFarmDtl.getNoOfBoats() != null) || (technicalFarmDtl.getFishPort() != null)
				|| (technicalFarmDtl.getFishNorthCoordinateO() != null)
				|| (technicalFarmDtl.getFishNorthCoordinate() != null)
				|| (technicalFarmDtl.getFishEastCoordinateO() != null)
				|| (technicalFarmDtl.getFishEastCoordinate() != null))
				&& ((technicalFarmDtl.getNoOfBoats() == null) || (technicalFarmDtl.getFishPort() == null)
						|| (technicalFarmDtl.getFishNorthCoordinateO() == null)
						|| (technicalFarmDtl.getFishNorthCoordinate() == null)
						|| (technicalFarmDtl.getFishEastCoordinateO() == null)
						|| (technicalFarmDtl.getFishEastCoordinate() == null))) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(ALL_COORDINATES_AND_PORT_DETAILS_MANDATARY,
					new Object[] {}, LOG, env);
		}
		if (((technicalFarmDtl.getLetterDate() != null) || (technicalFarmDtl.getLetterNumber() != null)
				|| (technicalFarmDtl.getLetterSource() != null))
				&& ((technicalFarmDtl.getLetterDate() == null) || (technicalFarmDtl.getLetterNumber() == null)
						|| (technicalFarmDtl.getLetterSource() == null))) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(ALL_GUARD_DATA_DETAILS_MANDATARY,
					new Object[] {}, LOG, env);
		}
		if (((technicalFarmDtl.getWealthLetterDate() != null) || (technicalFarmDtl.getWealthLetterNumber() != null)
				|| (technicalFarmDtl.getWealthLetterSource() != null))
				&& ((technicalFarmDtl.getWealthLetterDate() == null)
						|| (technicalFarmDtl.getWealthLetterNumber() == null)
						|| (technicalFarmDtl.getWealthLetterSource() == null))) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(ALL_WEALTH_DATA_DETAILS_MANDATARY,
					new Object[] {}, LOG, env);
		}

	}

	private void saveTechAreaDtls(TechnicalAreaDtlList techAreaDtlsInput, TechnicalAreaDtlList hiddenTechAreaDtls,
			TechnicalAreaCoordinateDtlList techAreaCoordDtlsInput,
			TechnicalAreaCoordinateDtlList hiddenGridOnlyCoordinate, String referenceNum) {

		// take coordinates from hidden as data with different title id is already saved
		// on save area .
		techAreaCoordDtlsInput.removeAllTechnicalAreaCoordinateDtlList();
		int countOfChecked=0;
		for (int i = 0; i < hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlListCount(); i++) {
			if (hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i).getReferenceNumber() == null
					|| hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i).getReferenceNumber()
							.equals(CommonConstants.EMPTY_STRING)) {
				hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i).setReferenceNumber(referenceNum);
				hiddenGridOnlyCoordinate.setTechnicalAreaCoordinateDtlList(i,
						hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i));
			}
		}
		
		for (int i = 0; i < hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlListCount(); i++) {
			if (hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i).getReferenceNumber()
							.equals(referenceNum)) {
				if(hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList(i).getDefaultCoordinates())
					countOfChecked=countOfChecked+1;
			}
		}
		if (!(techAreaDtlsInput.getTechnicalAreaDtlList().length > 0)) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_DETAILS_MANDATORY, new Object[] {}, LOG,
					BankFusionThreadLocal.getBankFusionEnvironment());

		}
		if (countOfChecked < 4) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_MIN_FOUR_COORDINATE_SHOULD_BE_CHECKED_IB, new Object[] {},
					LOG, BankFusionThreadLocal.getBankFusionEnvironment());
		}
		for (TechnicalAreaDtl hiddenTechAreaDtl : hiddenTechAreaDtls.getTechnicalAreaDtlList()) {
			if (hiddenTechAreaDtl.getReferenceNumber().equals(referenceNum)) {
				hiddenTechAreaDtls.removeTechnicalAreaDtlList(hiddenTechAreaDtl);
			}
		}
		
		
		for (TechnicalAreaDtl areaDtl : techAreaDtlsInput.getTechnicalAreaDtlList()) {
			areaDtl.setReferenceNumber(referenceNum);
			hiddenTechAreaDtls.addTechnicalAreaDtlList(areaDtl);
		}
		
	}

	private void saveTechAssetDtl(TechincalAssetDtlsList techAssetDtlsInput, TechincalAssetDtlsList hiddenTechAssetDtls,
			String referenceNum) {
		
		for (TechnicalAssetDtl technicalAssetDtl : hiddenTechAssetDtls.getTechincalAssetDtlsList()) {
			if (technicalAssetDtl.getReferenceNumber().equals(referenceNum)) {
				hiddenTechAssetDtls.removeTechincalAssetDtlsList(technicalAssetDtl);
			}
		}
		
		for (TechnicalAssetDtl assetDtl : techAssetDtlsInput.getTechincalAssetDtlsList()) {
			assetDtl.setReferenceNumber(referenceNum);
			hiddenTechAssetDtls.addTechincalAssetDtlsList(assetDtl);
		}/*

			if (hiddenTechAssetDtls.getTechincalAssetDtlsList().length > 0
					&& !StringUtils.isEmpty(assetDtl.getReferenceNumber())) {
				for (int i = 0; i < hiddenTechAssetDtls.getTechincalAssetDtlsListCount(); i++) {
					if (!StringUtils.isEmpty(assetDtl.getAssetId())
							&& hiddenTechAssetDtls.getTechincalAssetDtlsList(i).getAssetId()
									.equals(assetDtl.getAssetId())
							&& (hiddenTechAssetDtls.getTechincalAssetDtlsList(i).getReferenceNumber()
									.equals(assetDtl.getReferenceNumber()))) {
						// assetDtl.setReferenceNumber(referenceNum);
						hiddenTechAssetDtls.setTechincalAssetDtlsList(i, assetDtl);

					} else {
						assetDtl.setReferenceNumber(referenceNum);

						TechnicalAssetDtl vTechincalAssetDtlsList = new TechnicalAssetDtl();
						vTechincalAssetDtlsList.setAssetCategory(assetDtl.getAssetCategory());
						vTechincalAssetDtlsList.setAssetId(assetDtl.getAssetId());
						vTechincalAssetDtlsList.setAssetName(assetDtl.getAssetName());
						vTechincalAssetDtlsList.setExtensionDetails(assetDtl.getExtensionDetails());
						vTechincalAssetDtlsList.setReferenceNumber(assetDtl.getReferenceNumber());

						hiddenTechAssetDtls.addTechincalAssetDtlsList(vTechincalAssetDtlsList);
					}
				}
			} else {

				assetDtl.setReferenceNumber(referenceNum);

				TechnicalAssetDtl vTechincalAssetDtlsList = new TechnicalAssetDtl();
				vTechincalAssetDtlsList.setAssetCategory(assetDtl.getAssetCategory());
				vTechincalAssetDtlsList.setAssetId(assetDtl.getAssetId());
				vTechincalAssetDtlsList.setAssetName(assetDtl.getAssetName());
				vTechincalAssetDtlsList.setExtensionDetails(assetDtl.getExtensionDetails());
				vTechincalAssetDtlsList.setReferenceNumber(assetDtl.getReferenceNumber());

				hiddenTechAssetDtls.addTechincalAssetDtlsList(vTechincalAssetDtlsList);

			}
		*/
		/*if (techAssetDtlsInput.getTechincalAssetDtlsListCount() == CommonConstants.INTEGER_ZERO) {
			for (TechnicalAssetDtl technicalAssetDtl : hiddenTechAssetDtls.getTechincalAssetDtlsList()) {
				if (technicalAssetDtl.getReferenceNumber().equals(referenceNum)) {
					hiddenTechAssetDtls.removeTechincalAssetDtlsList(technicalAssetDtl);
				}
			}
		}*/
	}

	private void saveTechCropDtl(TechnicalCropDtlList techCropDtlsInput, TechnicalCropDtlList hiddenTechCropDtls,
			String referenceNum) {
		
		for (TechnicalCropDtl technicalCropDtl : hiddenTechCropDtls.getTechnicalCropDtlList()) {
			if (technicalCropDtl.getReferenceNumber().equals(referenceNum)) {
				hiddenTechCropDtls.removeTechnicalCropDtlList(technicalCropDtl);
			}
		}
		int cropArea = CommonConstants.INTEGER_ZERO;
        for (TechnicalCropDtl cropDtl : techCropDtlsInput.getTechnicalCropDtlList()) {
            cropDtl.setReferenceNumber(referenceNum);
            hiddenTechCropDtls.addTechnicalCropDtlList(cropDtl);
            if(cropDtl.getStatus().equals("1")) {
                Double x = Double.valueOf(cropDtl.getArea());
                cropArea = cropArea+(int) Math.round(x);
            }
        }
        
        TechnicalAreaDtl[] technicalAreaDtl= getF_IN_technicalAnalysisDtls().getTechnicalAreaDtlsList().getTechnicalAreaDtlList();
        int areaCanBeUsedForAllDeeds = 0;
        if(technicalAreaDtl.length>0) {
            Double x = Double.valueOf(technicalAreaDtl[0].getAreaUsedForAllDeeds());
            areaCanBeUsedForAllDeeds = (int) Math.round(x);
        }
        //int areaCanBeUsedForAllDeeds= technicalAreaDtl.length>0?Integer.parseInt(technicalAreaDtl[0].getAreaUsedForAllDeeds()):0;
		if(cropArea>areaCanBeUsedForAllDeeds) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(TOTAL_AREA_TOTAL_TITLE_DEED_AREA, new Object[] {}, LOG,
					BankFusionThreadLocal.getBankFusionEnvironment());
		}
	}

	private void validateTechAreaAndCoordinateDtls(TechnicalAnalysisDtls technicalAnalysisDtls,
			BankFusionEnvironment env) {

		TechnicalAreaDtlList techAreaDtlsInput = technicalAnalysisDtls.getTechnicalAreaDtlsList();
		TechnicalAreaCoordinateDtlList techAreaCoordDtlsInput = technicalAnalysisDtls.getTechnicalAreaCoordinatesList();

		if (!(techAreaDtlsInput.getTechnicalAreaDtlList().length > 0)) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_DETAILS_MANDATORY, new Object[] {}, LOG,
					env);

		}
		if (!(techAreaCoordDtlsInput.getTechnicalAreaCoordinateDtlList().length > 0)) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_AND_COORDINATES_MANDATORY, new Object[] {},
					LOG, env);

		}

	}

	private String generateReportTechId(BankFusionEnvironment env) {
		CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom(env);
		customAutoNumFatom.setF_IN_BONAME("IBOCE_IB_TechnicalFarm");// need to set new BO
		// customAutoNumFatom.setF_IN_IsRightPad(false);
		customAutoNumFatom.setF_IN_Prefix("Techrpt_00");
		customAutoNumFatom.setF_IN_Suffix("");
		customAutoNumFatom.setF_IN_TotalLength(0);
		customAutoNumFatom.process(env);

		String reportTechId = customAutoNumFatom.getF_OUT_PrimKey();
		return reportTechId;

	}

	private void saveTechWellDtl(TechnicalWellDtlsList techWellDtlsInput, TechnicalWellDtlsList hiddenTechWellDtls,
			String referenceNum) {
		for (TechnicalWellDtl technicalWellDtl : hiddenTechWellDtls.getTechnicalWellDtlList()) {
			if (technicalWellDtl.getReferenceNumber().equals(referenceNum)) {
				hiddenTechWellDtls.removeTechnicalWellDtlList(technicalWellDtl);
			}

		}
		for (TechnicalWellDtl technicalWellDtl : techWellDtlsInput.getTechnicalWellDtlList()) {
			technicalWellDtl.setReferenceNumber(referenceNum);
			hiddenTechWellDtls.addTechnicalWellDtlList(technicalWellDtl);
		}

		/*for (TechnicalWellDtl technicalWellDtl : techWellDtlsInput.getTechnicalWellDtlList()) {

			if (hiddenTechWellDtls.getTechnicalWellDtlList().length > 0
					&& !StringUtils.isEmpty(technicalWellDtl.getReferenceNumber())) {
				for (int i = 0; i < hiddenTechWellDtls.getTechnicalWellDtlListCount(); i++) {
					if (technicalWellDtl.getSerialNumber() != 0
							&& hiddenTechWellDtls.getTechnicalWellDtlList(i).getSerialNumber()
									.equals(technicalWellDtl.getSerialNumber())
							&& (hiddenTechWellDtls.getTechnicalWellDtlList(i).getReferenceNumber()
									.equals(technicalWellDtl.getReferenceNumber()))) {
						// technicalWellDtl.setReferenceNumber(referenceNum);
						hiddenTechWellDtls.setTechnicalWellDtlList(i, technicalWellDtl);

					} else if (hiddenTechWellDtls.getTechnicalWellDtlList(i).getReferenceNumber()
							.equals(technicalWellDtl.getReferenceNumber())) {
						technicalWellDtl.setReferenceNumber(referenceNum);

						TechnicalWellDtl vTechnicalWellDtlList = new TechnicalWellDtl();
						vTechnicalWellDtlList.setEastCoordinate(technicalWellDtl.getEastCoordinate());
						vTechnicalWellDtlList.setEastCoordinateO(technicalWellDtl.getEastCoordinateO());
						vTechnicalWellDtlList.setIsWellUsed(technicalWellDtl.getIsWellUsed());
						vTechnicalWellDtlList.setLicenseDate(technicalWellDtl.getLicenseDate());
						vTechnicalWellDtlList.setLicenseDateHijri(technicalWellDtl.getLicenseDateHijri());
						vTechnicalWellDtlList.setLicenseNumber(technicalWellDtl.getLicenseNumber());
						vTechnicalWellDtlList.setNorthCoordinate(technicalWellDtl.getNorthCoordinate());
						vTechnicalWellDtlList.setNorthCoordinateO(technicalWellDtl.getNorthCoordinateO());
						vTechnicalWellDtlList.setOldBranchCode(technicalWellDtl.getOldBranchCode());
						vTechnicalWellDtlList.setOldContractID(technicalWellDtl.getOldContractID());
						vTechnicalWellDtlList.setReferenceNumber(referenceNum);
						vTechnicalWellDtlList.setSelect(false);
						vTechnicalWellDtlList.setSerialNumber(technicalWellDtl.getSerialNumber());
						vTechnicalWellDtlList.setTitleDeedId(technicalWellDtl.getTitleDeedId());
						vTechnicalWellDtlList.setTitleDescription(technicalWellDtl.getTitleDescription());
						vTechnicalWellDtlList.setWellAir(technicalWellDtl.getWellAir());
						vTechnicalWellDtlList.setWellArch(technicalWellDtl.getWellArch());
						vTechnicalWellDtlList.setWellDepth(technicalWellDtl.getWellDepth());
						vTechnicalWellDtlList.setWellStatus(technicalWellDtl.getWellStatus());
						vTechnicalWellDtlList.setWellType(technicalWellDtl.getWellType());

						hiddenTechWellDtls.addTechnicalWellDtlList(vTechnicalWellDtlList);
					}
				}
			} else {

				technicalWellDtl.setReferenceNumber(referenceNum);

				TechnicalWellDtl vTechnicalWellDtlList = new TechnicalWellDtl();
				vTechnicalWellDtlList.setEastCoordinate(technicalWellDtl.getEastCoordinate());
				vTechnicalWellDtlList.setEastCoordinateO(technicalWellDtl.getEastCoordinateO());
				vTechnicalWellDtlList.setIsWellUsed(technicalWellDtl.getIsWellUsed());
				vTechnicalWellDtlList.setLicenseDate(technicalWellDtl.getLicenseDate());
				vTechnicalWellDtlList.setLicenseDateHijri(technicalWellDtl.getLicenseDateHijri());
				vTechnicalWellDtlList.setLicenseNumber(technicalWellDtl.getLicenseNumber());
				vTechnicalWellDtlList.setNorthCoordinate(technicalWellDtl.getNorthCoordinate());
				vTechnicalWellDtlList.setNorthCoordinateO(technicalWellDtl.getNorthCoordinateO());
				vTechnicalWellDtlList.setOldBranchCode(technicalWellDtl.getOldBranchCode());
				vTechnicalWellDtlList.setOldContractID(technicalWellDtl.getOldContractID());
				vTechnicalWellDtlList.setReferenceNumber(referenceNum);
				vTechnicalWellDtlList.setSelect(false);
				vTechnicalWellDtlList.setSerialNumber(technicalWellDtl.getSerialNumber());
				vTechnicalWellDtlList.setTitleDeedId(technicalWellDtl.getTitleDeedId());
				vTechnicalWellDtlList.setTitleDescription(technicalWellDtl.getTitleDescription());
				vTechnicalWellDtlList.setWellAir(technicalWellDtl.getWellAir());
				vTechnicalWellDtlList.setWellArch(technicalWellDtl.getWellArch());
				vTechnicalWellDtlList.setWellDepth(technicalWellDtl.getWellDepth());
				vTechnicalWellDtlList.setWellStatus(technicalWellDtl.getWellStatus());
				vTechnicalWellDtlList.setWellType(technicalWellDtl.getWellType());

				hiddenTechWellDtls.addTechnicalWellDtlList(vTechnicalWellDtlList);

			}
		}
		if (techWellDtlsInput.getTechnicalWellDtlListCount() == CommonConstants.INTEGER_ZERO) {
			for (TechnicalWellDtl technicalWellDtl : hiddenTechWellDtls.getTechnicalWellDtlList()) {
				if (technicalWellDtl.getReferenceNumber().equals(referenceNum)) {
					hiddenTechWellDtls.removeTechnicalWellDtlList(technicalWellDtl);
				}

			}
		}*/
	}

}
