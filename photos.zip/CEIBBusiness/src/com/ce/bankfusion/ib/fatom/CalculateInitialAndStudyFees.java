package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateInitialAndStudyFees;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_FeesConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.ib.types.RuleInputData;
import bf.com.misys.ib.types.RuleInputRq;
import bf.com.misys.ib.types.SystemObjectOutputDetail;
import bf.com.misys.ib.types.SystemParam;

public class CalculateInitialAndStudyFees extends AbstractCE_IB_CalculateInitialAndStudyFees {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static final Log LOGGER = LogFactory.getLog(CalculateInitialAndStudyFees.class);

    private static String SELECT_ADJUSTMENTFEESCONFIG = " WHERE " + IBOIB_CFG_FeesConfig.ISACTIVE + " = ? " + " AND "
        + IBOIB_CFG_FeesConfig.PROCESSCONFIGID + " = ? AND " + IBOIB_CFG_FeesConfig.AMOUNTORRULEID + " = ?";

    private static String SELECT_DEALASSETCHARGESDTLS = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.FEESCONFIGID + " = ? " + " AND "
        + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ?" + " AND " + IBOIB_DLI_DealAssetChargesdtls.CHARGEPAYMENTSTATUS + " = ?" + " AND "
        + IBOIB_DLI_DealAssetChargesdtls.CHARGETYPE + " = ?";

    public CalculateInitialAndStudyFees(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        if (!IBCommonUtils.isNullOrEmpty(getF_IN_dealId())) {
            IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_dealId());
            String initialFeeRuleId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.INITIAL_FEE_RULE_FILE,
                CeConstants.INITIAL_FEE_RULE, "", CeConstants.ADFIBCONFIGLOCATION);
            String adjustmentFeeRuleId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.INITIAL_FEE_RULE_FILE,
                CeConstants.ADJUSTMENT_FEE_RULE, "", CeConstants.ADFIBCONFIGLOCATION);
            BigDecimal adjustmentFeesAmount = CommonConstants.BIGDECIMAL_ZERO;
            BigDecimal initialFeeAmount = CommonConstants.BIGDECIMAL_ZERO;
            if (!IBCommonUtils.isNullOrEmpty(initialFeeRuleId) && !IBCommonUtils.isNullOrEmpty(adjustmentFeeRuleId)) {
                initialFeeAmount = executeFeeRule(initialFeeRuleId);
                BigDecimal oldInitialFee = (BigDecimal) CeUtils.getUDFValueByNameFromAdditionalDtls(getF_IN_dealId(), "INITIAL_FEE_AMOUNT");
                if (oldInitialFee.compareTo(BigDecimal.ZERO) > 0) {
                    adjustmentFeesAmount = initialFeeAmount.subtract(oldInitialFee);
                    updateExistingAdjustmentFee(dealDetails, adjustmentFeeRuleId, adjustmentFeesAmount);
                    if (adjustmentFeesAmount.compareTo(BigDecimal.ZERO) > 0) {
                        setF_OUT_adjustmentFeesAmount(
                            IBCommonUtils.getBFCurrencyAmount(adjustmentFeesAmount, dealDetails.getF_IsoCurrencyCode()));
                        persistAdjustmentFeeUDF(adjustmentFeesAmount);
                    }
                    setF_OUT_initialFeesAmount(IBCommonUtils.getBFCurrencyAmount(oldInitialFee, dealDetails.getF_IsoCurrencyCode()));
                } else {
                    setF_OUT_initialFeesAmount(IBCommonUtils.getBFCurrencyAmount(initialFeeAmount, dealDetails.getF_IsoCurrencyCode()));
                }
                LOGGER.info("Initial Fee Amount Value:" + getF_OUT_initialFeesAmount().getCurrencyAmount());
                LOGGER.info("Adjustment Fee amount Value:" + getF_OUT_adjustmentFeesAmount().getCurrencyAmount());
            }
        }
    }

    private void updateExistingAdjustmentFee(IBOIB_DLI_DealDetails dealDetails, String adjustmentFeeRuleId,
        BigDecimal adjustmentFeesAmount) {

        ArrayList<String> params = new ArrayList<>();
        params.add(IBConstants.ACTIVE);
        params.add(dealDetails.getF_PROCESSCONFIGID());
        params.add(adjustmentFeeRuleId);

        List<IBOIB_CFG_FeesConfig> resultFeesConfig = (List<IBOIB_CFG_FeesConfig>) BankFusionThreadLocal.getPersistanceFactory()
            .findByQuery(IBOIB_CFG_FeesConfig.BONAME, SELECT_ADJUSTMENTFEESCONFIG, params, null, false);

        if (resultFeesConfig != null && !resultFeesConfig.isEmpty()) {
            params.clear();
            params.add(resultFeesConfig.get(0).getBoID());
            params.add(getF_IN_dealId());
            params.add(IBConstants.NOTPAID);
            params.add(IBConstants.PROCESS);

            List<IBOIB_DLI_DealAssetChargesdtls> resultDealAssetChargeDtls =
                (List<IBOIB_DLI_DealAssetChargesdtls>) BankFusionThreadLocal.getPersistanceFactory()
                    .findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, SELECT_DEALASSETCHARGESDTLS, params, null, false);

            if (resultDealAssetChargeDtls != null && !resultDealAssetChargeDtls.isEmpty()) {
            	if (adjustmentFeesAmount.compareTo(BigDecimal.ZERO) > 0) {
	                resultDealAssetChargeDtls.get(0).setF_ChargeAmount(adjustmentFeesAmount);
	                resultDealAssetChargeDtls.get(0).setF_OriginalChgAmount(adjustmentFeesAmount);
	                resultDealAssetChargeDtls.get(0).setF_UNPAIDCHARGEAMOUNT(adjustmentFeesAmount);
	                if (resultFeesConfig.get(0).getF_ISTAXABLE().equalsIgnoreCase("Y")) {
	                    BigDecimal adjstmntFeeTaxAmount = executeFeeRule(resultFeesConfig.get(0).getF_TAXORRULEID());
	                    resultDealAssetChargeDtls.get(0).setF_TaxAmount(adjstmntFeeTaxAmount);
	                    resultDealAssetChargeDtls.get(0).setF_OriginalTaxAmount(adjstmntFeeTaxAmount);
	                    resultDealAssetChargeDtls.get(0).setF_UNPAIDTAXAMOUNT(adjstmntFeeTaxAmount);
	                }
            	} else {
            		BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOIB_DLI_DealAssetChargesdtls.BONAME, SELECT_DEALASSETCHARGESDTLS, params);
            	}
            }
        }
    }

    private BigDecimal executeFeeRule(String initialFeeRuleId) {
        BigDecimal feeAmount = BigDecimal.ZERO;
        try {
            if (IBCommonUtils.isValidString(initialFeeRuleId)
                && IBCommonUtils.isValidRuleId(initialFeeRuleId, CommonConstants.EMPTY_STRING)) {

                RuleInputRq ruleInputRq = new RuleInputRq();
                RuleInputData ruleData = new RuleInputData();
                SystemParam systemParam = new SystemParam();
                systemParam.setParamName(IBConstants.DEALID_SYSTEMOBJECT_CONSTANTS);
                systemParam.setParamValue(getF_IN_dealId());
                ruleData.addInputParam(systemParam);
                ruleData.setRuleId(initialFeeRuleId);
                ruleData.addInputData(getDealSysObjectDetails());
                ruleData.setXmlContext("Default");
                ruleInputRq.setRuleInputList(ruleData);

                RuleExecRsData response = IBCommonUtils.executeRule(ruleInputRq);

                if (response.getRuleType().equals(IBConstants.RULE_TYPE_FORMULA_CONSTANTS) && response.getRuleData() != null) {
                    List<String> responseList = (List<String>) response.getRuleData();
                    if (responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
                        feeAmount = new BigDecimal(responseList.get(CommonConstants.INTEGER_ZERO));
                    }
                }
            }
        } catch (Exception exception) {
            LOGGER.info("Rule Exection failed while deriving default Value, Rule ID : " + initialFeeRuleId);
        }
        return feeAmount;
    }

    private SystemObjectOutputDetail getDealSysObjectDetails() {

        SystemObjectOutputDetail sysObjectDetail = new SystemObjectOutputDetail();
        sysObjectDetail.setSystemObjectName(IBOIB_DLI_DealDetails.BONAME);

        List<Object> feeDetailsObjList = new ArrayList<>();
        feeDetailsObjList.add(IBCommonUtils.getDealDetails(getF_IN_dealId()));
        sysObjectDetail.setSystemObjectList(feeDetailsObjList);

        return sysObjectDetail;
    }

    private void persistAdjustmentFeeUDF(BigDecimal adjustmentFeesAmount) {
        BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
        String whereClause = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + "= ? ";
        ArrayList<Object> params = new ArrayList<Object>();
        params.add(getF_IN_dealId());
        List<IBOIB_DLI_DealAditionalDtls> dealAdditionalDetails = (List) IBCommonUtils.getBankFusionEnvironment().getFactory()
            .findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, params, null, false);
        IBOUDFEXTIB_DLI_DealAditionalDtls ibDealAdditionalDetailsUD =
            CeUtils.getDealAdditionalDetailsExtensionDtls(dealAdditionalDetails.get(0).getBoID());

        String adjustmentFeeUDF = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, "ADJUSTMENT_FEE_AMOUNT",
            "", CeConstants.ADFIBCONFIGLOCATION);
        LOGGER.info("ADJUSTMENT_FEE_AMOUNT Value:" + adjustmentFeeUDF);
        // process the results
        if (ibDealAdditionalDetailsUD != null) {
            UserDefinedFields userDefinedFields = ibDealAdditionalDetailsUD.getUserDefinedFields();
            if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {

                for (int i = 0; i < userDefinedFields.getUserDefinedFieldCount(); i++) {

                    if (userDefinedFields.getUserDefinedField(i).getFieldName().equals(adjustmentFeeUDF)) {
                        LOGGER.info("ADJUSTMENT_FEE_AMOUNT Value Set:" + userDefinedFields.getUserDefinedField(i).getFieldName());
                        userDefinedFields.getUserDefinedField(i).setFieldValue(adjustmentFeesAmount);
                    }
                }
            }
            ibDealAdditionalDetailsUD.setUserDefinedFields(userDefinedFields);
        }
        BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
    }
}
