package com.ce.bankfusion.ib.fatom;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineConfigID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineConfig;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateAstCatIDForPricingEngineConf;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class PopulateAstCatIDForPricingEngineConf extends AbstractCE_IB_PopulateAstCatIDForPricingEngineConf{

	/**
	 * 
	 */
	private static final long serialVersionUID = 450097353584979884L;
	private transient final static Log LOGGER = LogFactory.getLog(PopulateAstCatIDForPricingEngineConf.class.getName());

	public PopulateAstCatIDForPricingEngineConf()
	{
		super();
	}

	public PopulateAstCatIDForPricingEngineConf(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		Integer currentPage = null;
		boolean errorOccurred = false;
		try
		{
			FileReader reader = new FileReader(System.getProperty(CeConstants.ADFIBCONFIGLOCATION)+"conf/pageCounter.txt");
			BufferedReader bufferedReader = new BufferedReader(reader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				currentPage = Integer.parseInt(line);
			}
			reader.close();
		} catch (Exception e) {
			LOGGER.info("Error while reading the pageCounter to start with : " + e.getLocalizedMessage());
			e.printStackTrace();
			errorOccurred = true;
		}
		int totalPages = 0;
		if(null != currentPage )
		{
			do
			{
				LOGGER.info("Started the page : "+ currentPage);
				IPagingData pagingData = new PagingData(currentPage==0?1:currentPage,250);
				pagingData.setRequiresTotalPages(true);
				List<IBOIB_AST_AssetCategory> allAssetCats = factory.findAll(IBOIB_AST_AssetCategory.BONAME, pagingData, false);
				totalPages = pagingData.getTotalPages();
				for(IBOIB_AST_AssetCategory eachAsset : allAssetCats)
				{
					Integer listser;
					Integer groupCD;
					Integer toolNo;
					try {
						listser = Integer.parseInt(eachAsset.getF_CATEGORYNAME());
					}
					catch(Exception e)
					{
						LOGGER.info("The with asset catID " + eachAsset.getBoID() + "is not having listser");
						continue;
					}
					try {
						LOGGER.info("Came in for reading gcd,tlNo for asset with category ID : " + eachAsset.getBoID());
						GetAssetAttributeNames assetAttributeNames = new GetAssetAttributeNames(env);
						assetAttributeNames.setF_IN_categoryID(eachAsset.getBoID());
						assetAttributeNames.setF_IN_onlyAttributeMode(false);
						assetAttributeNames.setF_IN_dealID("Dummy");
						assetAttributeNames.process(env);
						groupCD = assetAttributeNames.getF_OUT_GROUPCD();
						toolNo = assetAttributeNames.getF_OUT_TOOLNO();
					}
					catch(Exception e)
					{
						LOGGER.info("Reading of gcd,tlNo failed for asset with category ID : " + eachAsset.getBoID());
						continue;
					}

					CE_IB_PricingEngineConfigID key = new CE_IB_PricingEngineConfigID();
					key.setF_GRP_CD(groupCD);
					key.setF_LISTSER(listser);
					key.setF_TOOLNO(toolNo);
					LOGGER.info("Came in for astCatID update for GCD, TLN and LISTSER : " + groupCD + " , " + toolNo + " , " + listser);
					IBOCE_IB_PricingEngineConfig pricingListFromDB = (IBOCE_IB_PricingEngineConfig) factory.findByPrimaryKey(IBOCE_IB_PricingEngineConfig.BONAME, key, true);
					if(null != pricingListFromDB)
					{
						pricingListFromDB.setF_ASSETCATEGORYID(eachAsset.getBoID());
						LOGGER.info("Updated astCatID " + eachAsset.getBoID() +  " for GCD, TLN and LISTSER : " + groupCD + " , " + toolNo + " , " + listser);
					}
				}

				LOGGER.info("Completed the page : "+ currentPage);
				++currentPage;
				//updating the file
				try
				{
					FileWriter writer = new FileWriter(System.getProperty(CeConstants.ADFIBCONFIGLOCATION)+"conf/pageCounter.txt", false);
					if(currentPage > totalPages)
					{
						writer.write("Completed all the pages!");
					}
					else
					{
						writer.write(currentPage.toString());
					}
					writer.close();
				}
				catch(Exception e)
				{
					LOGGER.info("Error while updating the pageCounter to start with : " + e.getLocalizedMessage());
					e.printStackTrace();
					errorOccurred = true;
					break;
				}
				BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
				BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
			}while(currentPage <= totalPages);
		}
		if(errorOccurred)
			LOGGER.info("The population of asset category ID tool is completed with errors!!");
		else
			LOGGER.info("The population of asset category ID tool is completed successfully!!");
	}
}
