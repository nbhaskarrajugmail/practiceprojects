package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalArea;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalAreaAndCoordinates;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalAsset;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalWell;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadTechnicalAnalysisDtls;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;
import bf.com.misys.technical.dtls.ib.types.TitleDeedSource;

public class ReadTechnicalAnalysisDtls extends AbstractCE_IB_ReadTechnicalAnalysisDtls {

	private static final Log LOGGER = LogFactory.getLog(ReadTechnicalAnalysisDtls.class);
	private IBOIB_DLI_DealDetails dealDetails;
	private static final String TITLE_DEED_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + "=?";
	public ReadTechnicalAnalysisDtls(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("Getting Technical Analysis Dtls for Deal " + getF_IN_islamicBankingObject().getDealID());
		TechnicalAnalysisDtls technicalAnalysisDtls = null;
		technicalAnalysisDtls = new TechnicalAnalysisDtls();
		technicalAnalysisDtls = getTechnicalAnalysisDtls();
		setF_OUT_technicalAnalysisDtls(technicalAnalysisDtls);
	}

	private TechnicalAnalysisDtls getTechnicalAnalysisDtls() {

		TechnicalAnalysisDtls technicalAnalysisDtls = new TechnicalAnalysisDtls();
		TechnicalFarmDtlList technicalFarmDtlList = new TechnicalFarmDtlList();
		TechnicalAreaDtlList technicalAreaDtlList = new TechnicalAreaDtlList();
		TechnicalAreaCoordinateDtlList technicalAreaCoordinateDtlList = new TechnicalAreaCoordinateDtlList();
		TechnicalAreaCoordinateDtlList finalSetCoordinateList = new TechnicalAreaCoordinateDtlList();
		TechnicalCropDtlList technicalCropDtlList = new TechnicalCropDtlList();
		TechincalAssetDtlsList techincalAssetDtlsList = new TechincalAssetDtlsList();
		AssetUDFsCollection technicalAssetUDFs = new AssetUDFsCollection();
		AssetUDFsCollection finalAssetUDFs = new AssetUDFsCollection();
		TechnicalWellDtlsList technicalWellDtlsList= new TechnicalWellDtlsList();
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(0);
		pagingRequest.setRequestedPage(0);
		pagingRequest.setTotalPages(0);
		pagedQuery.setPagingRequest(pagingRequest);

		String whereQuery = " WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_TechnicalFarm> farmDtls = (ArrayList<IBOCE_IB_TechnicalFarm>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_TechnicalFarm.BONAME, whereQuery, param, null, true);

		if (farmDtls != null && !farmDtls.isEmpty()) {
			for (int i = 0; i < farmDtls.size(); i++) {

				String referenceNum = farmDtls.get(i).getBoID();
				TechnicalFarmDtl technicalFarmDtl = new TechnicalFarmDtl();
				technicalFarmDtl.setDate(farmDtls.get(i).getF_IBDATE());
				technicalFarmDtl.setDealId(farmDtls.get(i).getF_IBDEALID());
				technicalFarmDtl.setEastCoordinate(farmDtls.get(i).getF_IBEASTCOORDINATE().toString());
				technicalFarmDtl.setEastCoordinateO(farmDtls.get(i).getF_IBEASTCOORDINATE().toString());
				technicalFarmDtl.setElectricitySrcAvailable(farmDtls.get(i).isF_IBELECTRICITYAVAILABLE());
				technicalFarmDtl.setFarmType(farmDtls.get(i).getF_IBFARMTYPE());
				technicalFarmDtl.setFarmTypeRef(farmDtls.get(i).getF_IBFARMTYPE());
				technicalFarmDtl.setInspectorName(farmDtls.get(i).getF_IBINSPECTOR());
				technicalFarmDtl.setNorthCoordinate(farmDtls.get(i).getF_IBNORTHCOORDINATE().toString());
				technicalFarmDtl.setNorthCoordinateO(farmDtls.get(i).getF_IBNORTHCOORDINATEO().toString());
				technicalFarmDtl.setNotesAndConditions(farmDtls.get(i).getF_IBNOTESCONDITIONS().toString());
				technicalFarmDtl.setNumberOfReceipt(farmDtls.get(i).getF_IBNUMOFRECEIPT());
				technicalFarmDtl.setOtherFindings(farmDtls.get(i).getF_IBOTHERFINDINGS());
				technicalFarmDtl.setPurpose(farmDtls.get(i).getF_IBPURPOSE());
				technicalFarmDtl.setPurposeRef(farmDtls.get(i).getF_IBPURPOSE());
				technicalFarmDtl.setReferenceNumber(referenceNum);
				technicalFarmDtl.setSignExist(farmDtls.get(i).isF_IBSIGNEXIST());
				technicalFarmDtl.setSoilType(farmDtls.get(i).getF_IBSOILTYPE());
				technicalFarmDtl.setSoilTypeRef(farmDtls.get(i).getF_IBSOILTYPE());
				technicalFarmDtl.setWaterAvailabilty(farmDtls.get(i).getF_IBWATERAVAILABILITY());
				technicalFarmDtl.setWaterAvailabiltyRef(farmDtls.get(i).getF_IBWATERAVAILABILITY());
				technicalFarmDtl.setAreaAssignedForSpclPrj(farmDtls.get(i).getF_IBAREAASSIGNEDFORSPCLPRJ());
				// Details for fisherman
				technicalFarmDtl.setLicenseNumber(farmDtls.get(i).getF_IBLICENSENUMBER());
				technicalFarmDtl.setFishLicenseDate(farmDtls.get(i).getF_IBFISHLICENSEDATE());
				technicalFarmDtl.setFishLicenseDateHijri(farmDtls.get(i).getF_IBFISHLICENSEDATEHIJRI());
				technicalFarmDtl.setLicenseType(farmDtls.get(i).getF_IBLICENSETYPE());
				technicalFarmDtl.setLicenseSource(farmDtls.get(i).getF_IBLICENSESOURCE());
				technicalFarmDtl.setNoOfBoats(farmDtls.get(i).getF_IBNOOFBOATS());
				technicalFarmDtl.setFishNorthCoordinate(farmDtls.get(i).getF_IBFISHNORTHCOORDINATE());
				technicalFarmDtl.setFishNorthCoordinateO(farmDtls.get(i).getF_IBFISHNORTHCOORDINATEO());
				technicalFarmDtl.setFishEastCoordinate(farmDtls.get(i).getF_IBFISHEASTCOORDINATE());
				technicalFarmDtl.setFishEastCoordinateO(farmDtls.get(i).getF_IBFISHEASTCOORDINATEO());
				technicalFarmDtl.setFishPort(farmDtls.get(i).getF_IBFISHPORT());
				technicalFarmDtl.setLetterNumber(farmDtls.get(i).getF_IBLETTERNUMBER());
				technicalFarmDtl.setLetterDate(farmDtls.get(i).getF_IBLETTERDATE());
				technicalFarmDtl.setLetterDateHijri(farmDtls.get(i).getF_IBLETTERDATEHIJRI());
				technicalFarmDtl.setLetterSource(farmDtls.get(i).getF_IBLETTERSOURCE());
				technicalFarmDtl.setWealthLetterNumber(farmDtls.get(i).getF_IBWEALTHLETTERNUMBER());
				technicalFarmDtl.setWealthLetterDate(farmDtls.get(i).getF_IBWEALTHLETTERDATE());
				technicalFarmDtl.setWealthLetterDateHijri(farmDtls.get(i).getF_IBWEALTHLETTERDATEHIJRI());
				technicalFarmDtl.setWealthLetterSource(farmDtls.get(i).getF_IBWEALTHLETTERSOURCE());
				
				technicalFarmDtlList.addTechnicalFarmDtlList(technicalFarmDtl);

				TechnicalAreaDtl[] techAreaDtls = getTechnicalAreaDtls(referenceNum);
				

				for (TechnicalAreaDtl areaDtl : techAreaDtls) {
					technicalAreaDtlList.addTechnicalAreaDtlList(areaDtl);
					String refNum = areaDtl.getReferenceNumber();
					String titleDeedid = areaDtl.getTitleDeedId();

					TechnicalAreaCoordinateDtl[] techAreaCoordinateArrayList = getTechnicalAreaCoordinateDtls(refNum,
							titleDeedid);
					technicalAreaCoordinateDtlList.setTechnicalAreaCoordinateDtlList(techAreaCoordinateArrayList);
					for (TechnicalAreaCoordinateDtl areaCoordinateDtl : technicalAreaCoordinateDtlList
							.getTechnicalAreaCoordinateDtlList()) {
						finalSetCoordinateList.addTechnicalAreaCoordinateDtlList(areaCoordinateDtl);
					}

				}

				TechnicalCropDtl[] technicalCropDtls = getTechnicalCropDtls(referenceNum);
				for (TechnicalCropDtl cropDtl:technicalCropDtls) {
					technicalCropDtlList.addTechnicalCropDtlList(cropDtl);
				}
				//technicalCropDtlList.setTechnicalCropDtlList(technicalCropDtls);
				TechnicalWellDtl[] technicalWellDtls = getTechnicalWellDtls(referenceNum);
				for(TechnicalWellDtl wellDtl:technicalWellDtls) {
					technicalWellDtlsList.addTechnicalWellDtlList(wellDtl);
				}
				//technicalWellDtlsList.setTechnicalWellDtlList(technicalWellDtls);
				TechnicalAssetDtl[] technicalAssetDtls = getTechnicalAssetDtls(referenceNum);
				for(TechnicalAssetDtl technicalAssetDtl:technicalAssetDtls) {
					techincalAssetDtlsList.addTechincalAssetDtlsList(technicalAssetDtl);
				}
				//techincalAssetDtlsList.setTechincalAssetDtlsList(technicalAssetDtls);

				for (TechnicalAssetDtl assetDtl : techincalAssetDtlsList.getTechincalAssetDtlsList()) {
					String assetid = assetDtl.getAssetId();
					AssetUDF[] techAssetUDFs = CeUtils.getAssetAttributes(assetid, getF_IN_islamicBankingObject().getDealID());

					technicalAssetUDFs.setAssetUDFs(techAssetUDFs);
					for (AssetUDF assetUDF : technicalAssetUDFs.getAssetUDFs()) {

						finalAssetUDFs.addAssetUDFs(assetUDF);
					}
				}

			}
		}

		technicalFarmDtlList.setPagedQuery(pagedQuery);
		technicalAreaDtlList.setPagedQuery(pagedQuery);
		finalSetCoordinateList.setPagedQuery(pagedQuery);
		technicalCropDtlList.setPagedQuery(pagedQuery);
		techincalAssetDtlsList.setPagedQuery(pagedQuery);
		technicalAnalysisDtls.setTechnicalFarmDtlsList(technicalFarmDtlList);
		technicalAnalysisDtls.setTechnicalAreaCoordinatesList(finalSetCoordinateList);
		technicalAnalysisDtls.setTechnicalAreaDtlsList(technicalAreaDtlList);
		technicalAnalysisDtls.setTechnicalAssetDtlsList(techincalAssetDtlsList);
		technicalAnalysisDtls.setTechnicalCropDtlsList(technicalCropDtlList);
		technicalAnalysisDtls.setTechnicalAssetUDFs(finalAssetUDFs);
		technicalAnalysisDtls.setTechnicalWellDtlsList(technicalWellDtlsList);
		return technicalAnalysisDtls;
	}

	private TechnicalAreaDtl[] getTechnicalAreaDtls(String referenceNum) {
		List<TechnicalAreaDtl> technicalAreaDtls = new ArrayList<>();
		String whereQuery = " WHERE " + IBOCE_IB_TechincalArea.IBREFERENCENUMBER + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(referenceNum);
		List<IBOCE_IB_TechincalArea> areaDtls = (ArrayList<IBOCE_IB_TechincalArea>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_TechincalArea.BONAME, whereQuery, param, null, true);
		String TITLE_DEED_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + "=?";
		if (areaDtls != null && !areaDtls.isEmpty()) {
			for (int i = 0; i < areaDtls.size(); i++) {

				String titleDeedId = areaDtls.get(i).getF_IBTITLEDEEDID();
				TechnicalAreaDtl technicalAreaDtl = new TechnicalAreaDtl();
				technicalAreaDtl.setAreaAssigned(areaDtls.get(i).getF_IBAREAASSIGNED().toString());
				technicalAreaDtl.setAreaCanBeUsed(areaDtls.get(i).getF_IBAREACANBEUSED().toString());
				technicalAreaDtl.setAreaCanBeUsedForAllDeeds(areaDtls.get(i).getF_IBAREACANBEUSEDFORALL().toString());
				technicalAreaDtl.setAreaUsed(areaDtls.get(i).getF_IBAREAUSED().toString());
				technicalAreaDtl.setAreaUsedForAllDeeds(areaDtls.get(i).getF_IBAREACANBEUSEDFORALL().toString());
				technicalAreaDtl.setReferenceNumber(referenceNum);
				technicalAreaDtl.setTitleDeedId(titleDeedId);
				
				int titleDeedVersion =CommonConstants.INTEGER_ONE;
				String whereClause = "WHERE "+IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER +"=? AND "+IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID +"=?";
				ArrayList<String> paramTD = new ArrayList<>();
				paramTD.add(getF_IN_islamicBankingObject().getDealID());
				paramTD.add(titleDeedId);
				List<IBOCE_IB_DealTitleDeedDtls> dealTitleDeeds=BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, paramTD, null);
				if(dealTitleDeeds.size()>0) {
					titleDeedVersion = Integer.parseInt(dealTitleDeeds.get(0).getF_IBTITLEDEEDVERSIONNUM());
				}
				TitleDeedSource vTitleDeedSource = new TitleDeedSource();
				CE_TITLEDEEDDETAILSID titleDeedID  =new CE_TITLEDEEDDETAILSID();
				titleDeedID.setF_TITLEDEEDID(titleDeedId);
				titleDeedID.setF_TITLEDEEDVERSION(titleDeedVersion);
				IBOCE_TITLEDEEDDETAILS titleDeedDetail= (IBOCE_TITLEDEEDDETAILS) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,titleDeedID , true);
				technicalAreaDtl.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());
				technicalAreaDtl.setTotalArea(titleDeedDetail.getF_AREASIZE().toString());
				technicalAreaDtl.setTitleDescription(titleDeedDetail.getF_NOTES());
				technicalAreaDtl.setLandPlanNumber(titleDeedDetail.getF_LANDPLANNUMBER());
				technicalAreaDtl.setLandPlotNumber(titleDeedDetail.getF_LANDPLOTNUMBER());
				technicalAreaDtl.setTitleDeedSource(IBCommonUtils.getGCChildDesc("TITLEDEEDSOURCE", titleDeedDetail.getF_TITLEDEEDSOURCE()));
				technicalAreaDtl.setTitleDeedType(IBCommonUtils.getGCChildDesc("TITLEDEEDTYPE", titleDeedDetail.getF_TITLEDEEDTYPE()));
				technicalAreaDtl.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());
								
				//technicalAreaDtl.setTitleDescription(areaDtls.get(i).getF_IBDESCRIPTION());
				technicalAreaDtl.setTotalArea(areaDtls.get(i).getF_IBTOTALAREA().toString());
				technicalAreaDtl.setTotalAreaForAllDeeds(areaDtls.get(i).getF_IBTOTALAREAFORALL().toString());

				technicalAreaDtls.add(technicalAreaDtl);
			}
		}
		TechnicalAreaDtl[] techarea = technicalAreaDtls.toArray(new TechnicalAreaDtl[technicalAreaDtls.size()]);

		return techarea;
	}

	private TechnicalAreaCoordinateDtl[] getTechnicalAreaCoordinateDtls(String referenceNum, String titleDeedId) {
		List<TechnicalAreaCoordinateDtl> technicalAreaCoordinateDtlList = new ArrayList<TechnicalAreaCoordinateDtl>();
		String whereQuery = " WHERE " + IBOCE_IB_TechincalAreaAndCoordinates.IBREFERENCENUMBER + " =?" + " AND "
				+ IBOCE_IB_TechincalAreaAndCoordinates.IBTITLEDEEDID + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(referenceNum);
		param.add(titleDeedId);
		List<IBOCE_IB_TechincalAreaAndCoordinates> areaCoordinateDtls = (ArrayList<IBOCE_IB_TechincalAreaAndCoordinates>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOCE_IB_TechincalAreaAndCoordinates.BONAME, whereQuery, param, null, true);

		if (areaCoordinateDtls != null && !areaCoordinateDtls.isEmpty()) {
			for (int i = 0; i < areaCoordinateDtls.size(); i++) {

				TechnicalAreaCoordinateDtl technicalAreaCoordinateDtl = new TechnicalAreaCoordinateDtl();
				technicalAreaCoordinateDtl.setEastCoordinate(areaCoordinateDtls.get(i).getF_IBEASTCOORDINATE().toString());
				technicalAreaCoordinateDtl.setEastCoordinateO(areaCoordinateDtls.get(i).getF_IBEASTCOORDINATEO().toString());
				technicalAreaCoordinateDtl.setNorthCoordinate(areaCoordinateDtls.get(i).getF_IBNORTHCOORDINATE().toString());
				technicalAreaCoordinateDtl.setNorthCoordinateO(areaCoordinateDtls.get(i).getF_IBNORTHCOORDINATEO().toString());
				technicalAreaCoordinateDtl.setReferenceNumber(referenceNum);
				technicalAreaCoordinateDtl.setSerail(areaCoordinateDtls.get(i).getF_IBSERIALID());
				technicalAreaCoordinateDtl.setTitleDeedId(titleDeedId);
				technicalAreaCoordinateDtl.setDefaultCoordinates(areaCoordinateDtls.get(i).isF_IBDEFAULTCOORDINATES());
				technicalAreaCoordinateDtlList.add(technicalAreaCoordinateDtl);
			}
		}
		TechnicalAreaCoordinateDtl[] techCoordinate = technicalAreaCoordinateDtlList
				.toArray(new TechnicalAreaCoordinateDtl[technicalAreaCoordinateDtlList.size()]);

		return techCoordinate;
	}

	private TechnicalCropDtl[] getTechnicalCropDtls(String referenceNum) {
		List<TechnicalCropDtl> techCropList = new ArrayList<TechnicalCropDtl>();
		String whereQuery = " WHERE " + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(referenceNum);
		List<IBOCE_IB_TechnicalCrop> cropDtls = (ArrayList<IBOCE_IB_TechnicalCrop>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_TechnicalCrop.BONAME, whereQuery, param, null, true);

		if (cropDtls != null && !cropDtls.isEmpty()) {
			for (int i = 0; i < cropDtls.size(); i++) {

				TechnicalCropDtl technicalCropDtl = new TechnicalCropDtl();
				technicalCropDtl.setArea(cropDtls.get(i).getF_IBAREA().toString());
				technicalCropDtl.setCropType(cropDtls.get(i).getF_IBCROPTYPEID());
				technicalCropDtl.setForPalm(cropDtls.get(i).getF_IBFORPALM());
				technicalCropDtl.setForPalmRef(cropDtls.get(i).getF_IBFORPALM());
				technicalCropDtl.setInsuredByFarmer(cropDtls.get(i).isF_IBISINSUREDBYFARMER());
				technicalCropDtl.setLengthOfWateringMethod(cropDtls.get(i).getF_IBLENGTHOFWATERINGMACHINE().toString());
				technicalCropDtl.setMainActivity(cropDtls.get(i).getF_IBMAINACTIVITY());
				technicalCropDtl.setMainActivityRef(cropDtls.get(i).getF_IBMAINACTIVITY());
				technicalCropDtl.setNoOfSeedling(cropDtls.get(i).getF_IBNOOFSEEDLINGS());
				technicalCropDtl.setReferenceNumber(referenceNum);
				technicalCropDtl.setSeedlingType(cropDtls.get(i).getF_IBSEEDLINGSTYPE());
				technicalCropDtl.setSeedlingTypeRef(cropDtls.get(i).getF_IBSEEDLINGSTYPE());
				technicalCropDtl.setStatus(cropDtls.get(i).getF_IBSTATUS());
				technicalCropDtl.setStatusRef(cropDtls.get(i).getF_IBSTATUS());
				technicalCropDtl.setTotalAreaForAlCrop(cropDtls.get(i).getF_IBTOTALAREA().toString());
				technicalCropDtl.setWateringMethod(cropDtls.get(i).getF_IBWATERINGMETHOD());
				technicalCropDtl.setWateringMethodRef(cropDtls.get(i).getF_IBWATERINGMETHOD());
				technicalCropDtl.setSeedlingType(cropDtls.get(i).getF_IBSEEDLINGSTYPE());
				technicalCropDtl.setSeedlingTypeRef(cropDtls.get(i).getF_IBSEEDLINGSTYPE());
				techCropList.add(technicalCropDtl);
			}
		}
		TechnicalCropDtl[] techCrop = techCropList.toArray(new TechnicalCropDtl[techCropList.size()]);

		return techCrop;
	}

	private TechnicalAssetDtl[] getTechnicalAssetDtls(String referenceNum) {
		List<TechnicalAssetDtl> techAssetDtlList = new ArrayList<TechnicalAssetDtl>();
		String whereQuery = " WHERE " + IBOCE_IB_TechincalAsset.IBREFERENCENUMBER + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(referenceNum);
		List<IBOCE_IB_TechincalAsset> assetDtls = (ArrayList<IBOCE_IB_TechincalAsset>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_TechincalAsset.BONAME, whereQuery, param, null, true);

		if (assetDtls != null && !assetDtls.isEmpty()) {
			for (int i = 0; i < assetDtls.size(); i++) {

				TechnicalAssetDtl technicalAssetDtl = new TechnicalAssetDtl();
				technicalAssetDtl.setAssetCategory(CeUtils.getAssetCategory(assetDtls.get(i).getF_IBASSETCATEGORY()));
				technicalAssetDtl.setAssetId(assetDtls.get(i).getBoID());
				technicalAssetDtl.setAssetName(assetDtls.get(i).getF_IBASSETNAME());
				technicalAssetDtl.setReferenceNumber(assetDtls.get(i).getF_IBREFERENCENUMBER());
				techAssetDtlList.add(technicalAssetDtl);
			}
		}
		TechnicalAssetDtl[] techAsset = techAssetDtlList.toArray(new TechnicalAssetDtl[techAssetDtlList.size()]);

		return techAsset;
	}

	private TechnicalWellDtl[] getTechnicalWellDtls(String referenceNum) {
		List<TechnicalWellDtl> techWellList = new ArrayList<TechnicalWellDtl>();
		String whereQuery = " WHERE " + IBOCE_IB_TechnicalWell.IBREFERENCENUMBER + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(referenceNum);
		List<IBOCE_IB_TechnicalWell> wellDtls = (ArrayList<IBOCE_IB_TechnicalWell>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_TechnicalWell.BONAME, whereQuery, param, null, true);

		if (wellDtls != null && !wellDtls.isEmpty()) {
			for (IBOCE_IB_TechnicalWell technicalWellDtl : wellDtls) {

				TechnicalWellDtl vTechnicalWellDtlList = new TechnicalWellDtl();
				vTechnicalWellDtlList.setEastCoordinate(technicalWellDtl.getF_IBEASTCOORDINATE());
				vTechnicalWellDtlList.setEastCoordinateO(technicalWellDtl.getF_IBEASTCOORDINATEO());
				vTechnicalWellDtlList.setIsWellUsed(technicalWellDtl.getF_IBISWELLUSED());
				vTechnicalWellDtlList.setLicenseDate(technicalWellDtl.getF_IBLICENSEDATE());
				vTechnicalWellDtlList.setLicenseDateHijri(technicalWellDtl.getF_IBLICENSEDATEHIJRI());
				vTechnicalWellDtlList.setLicenseNumber(technicalWellDtl.getF_IBLICENSENUMBER());
				vTechnicalWellDtlList.setNorthCoordinate(technicalWellDtl.getF_IBNORTHCOORDINATE());
				vTechnicalWellDtlList.setNorthCoordinateO(technicalWellDtl.getF_IBNORTHCOORDINATEO());
				vTechnicalWellDtlList.setOldBranchCode(technicalWellDtl.getF_IBOLDBRANCHCODE());
				vTechnicalWellDtlList.setOldContractID(technicalWellDtl.getF_IBOLDCONTRACTID());
				vTechnicalWellDtlList.setReferenceNumber(technicalWellDtl.getF_IBREFERENCENUMBER());
				vTechnicalWellDtlList.setSelect(false);
				vTechnicalWellDtlList.setSerialNumber(technicalWellDtl.getF_IBSERIALNUMBER());
				vTechnicalWellDtlList.setTitleDeedId(technicalWellDtl.getF_IBTITLEDEEDID());
				if (StringUtils.isNotEmpty(technicalWellDtl.getF_IBTITLEDEEDID())) {
					ArrayList<String> params = new ArrayList<>();
					params.add(technicalWellDtl.getF_IBTITLEDEEDID());
					List<IBOCE_TITLEDEEDDETAILS> titleDeedDetails = (List) IBCommonUtils.getPersistanceFactory()
							.findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME, TITLE_DEED_WHERE_CLAUSE, params, null, false);
					vTechnicalWellDtlList.setTitleDescription(titleDeedDetails.get(0).getF_NOTES());
				}
				vTechnicalWellDtlList.setWellAir(technicalWellDtl.getF_IBWELLAIR());
				vTechnicalWellDtlList.setWellArch(technicalWellDtl.getF_IBWELLARCH());
				vTechnicalWellDtlList.setWellDepth(technicalWellDtl.getF_IBWELLDEPTH());
				vTechnicalWellDtlList.setWellStatus(technicalWellDtl.getF_IBWELLSTATUS());
				vTechnicalWellDtlList.setWellType(technicalWellDtl.getF_IBWELLTYPE());
				techWellList.add(vTechnicalWellDtlList);
			}
		}
		TechnicalWellDtl[] techWell = techWellList.toArray(new TechnicalWellDtl[techWellList.size()]);
		return techWell;
	}

}
