/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DefaultSelectedAssets;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetThirdPartyDetails;

/**
 * @author Aklesh
 *
 */
public class DefaultSelectedAssets extends AbstractCE_IB_DefaultSelectedAssets {

	private static final long serialVersionUID = 7137308733675905581L;

	public DefaultSelectedAssets(BankFusionEnvironment env) {
		super(env);

	}

	public DefaultSelectedAssets() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		boolean advPaymentVisibility = false;
		for(AssetProgressReport assetProgressReport: getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportList()) {
			if(assetProgressReport.getReportStatus().equals("New")&&CommonConstants.EMPTY_STRING.equalsIgnoreCase(getF_IN_reportStatus())) {
				IBCommonUtils.raiseUnparameterizedEvent(44000401);
			}else {
				
			}
		}
		if (isF_IN_isCooperativeAssParty()) {
			advPaymentVisibility = true;
			if (getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportListCount() == 0) {
				advPaymentVisibility = true;
			} else if (getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportListCount() == 1) {
				if (getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportList(0).getCollectAdvancePayment()
						.equals("YES") && CommonConstants.EMPTY_STRING.equalsIgnoreCase(getF_IN_reportStatus()))
					advPaymentVisibility = false;
			} else if (getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportListCount() == 2
					&& getF_IN_reportStatus().equals("New")) {
				advPaymentVisibility = true;
			} else {
				advPaymentVisibility = false;
			}
		}
		setF_OUT_collectAdvPayReadOnly(advPaymentVisibility);
		getF_OUT_assetProgressReportDetails().removeAllAssetProgressDetailsList();
		for (AssetProgressDetails assetProgressDetails : getF_IN_hiddenAssetProgressReportDetails().getAssetProgressDetailsList()) {
			if(assetProgressDetails.getReportID().equals(getF_IN_reportID())) {
				getF_OUT_assetProgressReportDetails().addAssetProgressDetailsList(assetProgressDetails);
			}
		}
		if(getF_OUT_assetProgressReportDetails().getAssetProgressDetailsListCount()==CommonConstants.INTEGER_ZERO) {
			String previousReportID = CommonConstants.EMPTY_STRING;
			for(AssetProgressReport assetProgressReport: getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportList()) {
				if(assetProgressReport.getDisbursementNumber()==getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportListCount()) {
					previousReportID = assetProgressReport.getReportID();
				}
			}
			Map<String, BigDecimal> assetPreviousCalcCost = new HashMap<String, BigDecimal>();
			Map<String, BigDecimal> assetPreviousFinalCost = new HashMap<String, BigDecimal>();
			for (AssetProgressDetails asset : getF_IN_hiddenAssetProgressReportDetails()
					.getAssetProgressDetailsList()) {
				if (!asset.getReportID().equals(getF_IN_reportID()) && asset.getReportID().equals(previousReportID)) {
					assetPreviousCalcCost.put(asset.getAssetID(), asset.getAccumulatedCalculatedCost().getCurrencyAmount());
					assetPreviousFinalCost.put(asset.getAssetID(), asset.getAccumulatedFinalCost().getCurrencyAmount());

				}
			}
			
			//Retrieve Assets of deal
			AssetInfoAndStudyFatom assetAndStudyFatom = new AssetInfoAndStudyFatom(env);
			assetAndStudyFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
			assetAndStudyFatom.setF_IN_mode("READ");
			assetAndStudyFatom.process(env);
			AssetThirdPartyDetails [] assetTPDetails= assetAndStudyFatom.getF_OUT_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
			for (AssetThirdPartyDetails assetThirdPartyDetails : assetTPDetails) {
			    if(null != assetThirdPartyDetails.isReplaced() && !assetThirdPartyDetails.isReplaced()) {
				AssetProgressDetails  assetProgressDetails = new AssetProgressDetails();
				BFCurrencyAmount defaultCost = new BFCurrencyAmount();
				defaultCost.setCurrencyAmount(new BigDecimal(0));
				defaultCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				assetProgressDetails.setAssetCategory(assetThirdPartyDetails.getAssetCategory());
				assetProgressDetails.setAssetID(assetThirdPartyDetails.getAssetSerial());
				assetProgressDetails.setAssetName(assetThirdPartyDetails.getAssetName());
				assetProgressDetails.setAttribute7(BigDecimal.ZERO);
				assetProgressDetails.setAttribute8(BigDecimal.ZERO);
				assetProgressDetails.setAttribute9(BigDecimal.ZERO);
				assetProgressDetails.setGroupCD(assetThirdPartyDetails.getGroupCD());
				assetProgressDetails.setInvoiceAmount(defaultCost);
				assetProgressDetails.setInvoiceRequired(false);
				assetProgressDetails.setListNumber(0);
				assetProgressDetails.setReportID(getF_IN_reportID());
				assetProgressDetails.setStudyAttribute7(assetThirdPartyDetails.getAttribute7());
				assetProgressDetails.setStudyAttribute8(assetThirdPartyDetails.getAttribute8());
				assetProgressDetails.setStudyAttribute9(assetThirdPartyDetails.getAttribute9());
				assetProgressDetails.setToolNO(assetThirdPartyDetails.getToolNO());
				assetProgressDetails.setIsAssetPriced(assetThirdPartyDetails.getIsAssetPriced());
				assetProgressDetails.setIsAssetDividable(assetThirdPartyDetails.getIsAssetDividable());
				assetProgressDetails.setOriginalAssetStudyCost(assetThirdPartyDetails.getAssetStudyCost());
				assetProgressDetails.setOriginalFinalCost(assetThirdPartyDetails.getFinalCost());
				assetProgressDetails.setAccumulatedCalculatedCost(defaultCost );
				assetProgressDetails.setAccumulatedFinalCost(defaultCost);
				assetProgressDetails.setNetCalculatedCost(defaultCost);
				assetProgressDetails.setNetFinalCost(defaultCost);
				assetProgressDetails.setPreviousCalculatedCost(defaultCost);
				assetProgressDetails.setPreviousFinalCost(defaultCost);
				assetProgressDetails.setPrevouslyDisbursedAmount(defaultCost);
				assetProgressDetails.setPrevouslyUnDisbursedAmount(defaultCost);
				assetProgressDetails.setEastCoordinate(CommonConstants.BIGDECIMAL_ZERO);
				assetProgressDetails.setEastCoordinateO(CommonConstants.INTEGER_ZERO);
				assetProgressDetails.setInvoiceAmount(defaultCost);
				assetProgressDetails.setInvoiceCompletionPercentage(CommonConstants.BIGDECIMAL_ZERO);
				assetProgressDetails.setNorthCoordinate(CommonConstants.BIGDECIMAL_ZERO);
				assetProgressDetails.setNorthCoordinateO(CommonConstants.INTEGER_ZERO);
				assetProgressDetails.setIsAssetDisbursed(false);
				assetProgressDetails.setBoatMachineName(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setBoatMachineNumber(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setBoatSerialNumber(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setDeductionreason(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setAssetNotes(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setMachineNumber(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setMachineType(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setPriceListNumber(CommonConstants.EMPTY_STRING);
				assetProgressDetails.setPriceListYear(0);
				assetProgressDetails.setSelect(false);
				
				assetProgressDetails.setActualFinalCost(defaultCost);
				assetProgressDetails.setAllowedFinalCost(defaultCost);
				assetProgressDetails.setDeductionAmount(defaultCost);
				assetProgressDetails.setFinalCostAfterDeduction(defaultCost);
				
				
				Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(getF_IN_hiddenAssetProgressReportDetails().getAssetProgressReportList(), assetProgressDetails.getAssetID());
				BigDecimal previousReportsFinalCost = costMap.get("FINALCOST");
				BFCurrencyAmount previouslyDisbursedAmount = new BFCurrencyAmount();
				previouslyDisbursedAmount.setCurrencyAmount(previousReportsFinalCost);
				previouslyDisbursedAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				assetProgressDetails.setPrevouslyDisbursedAmount(previouslyDisbursedAmount);
				
				
				
				BFCurrencyAmount previousCalcCost = new BFCurrencyAmount();
				previousCalcCost.setCurrencyAmount(assetPreviousCalcCost.get(assetProgressDetails.getAssetID()));
				previousCalcCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				assetProgressDetails.setPreviousCalculatedCost(previousCalcCost);
				
				BFCurrencyAmount previousFinalCost = new BFCurrencyAmount();
				previousFinalCost.setCurrencyAmount(assetPreviousFinalCost.get(assetProgressDetails.getAssetID()));
				previousFinalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				assetProgressDetails.setPreviousFinalCost(previousFinalCost);
				
				getF_OUT_assetProgressReportDetails().addAssetProgressDetailsList(assetProgressDetails);
			}
			}
		}
		
	}

}
