package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalArea;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalAreaAndCoordinates;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalAsset;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalWell;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistTechAnalysisDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.eventcode.BusinessEventSupport;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;

public class PersistTechAnalysisDtls extends AbstractCE_IB_PersistTechAnalysisDtls {

	private static final long serialVersionUID = 1L;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	Log LOG = LogFactory.getLog(PersistTechAnalysisDtls.class.getName());
	public static final int SAVE_CHANGES_TO_PROCCED = 40312083;
	private static final String TECHNICALANAYLIS_MADATORY = "technicalAnalysisMandatory";
	private static final String TECHPRODUCTPROPERTY = "conf/business/techAnaysisProductMap.properties";
	public PersistTechAnalysisDtls(BankFusionEnvironment env) {
		super(env);

	}

	public PersistTechAnalysisDtls() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {

		TechnicalAnalysisDtls technicalAnalysisDtls = getF_IN_techAnalysisDtls();
		IslamicBankingObject bankingObject = getF_IN_islamicBankingObject();
		String subProductID = bankingObject.getSubProductID();
		String technicalAnayMand = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TECHPRODUCTPROPERTY,
				subProductID + "." + TECHNICALANAYLIS_MADATORY, "", CeConstants.ADFIBCONFIGLOCATION);
		if (!("NO".equalsIgnoreCase(technicalAnayMand))) {
			if (!(technicalAnalysisDtls.getTechnicalFarmDtlsList().getTechnicalFarmDtlList().length > 0)) {

				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(SAVE_CHANGES_TO_PROCCED, new Object[] {},
						LOG, env);

			}
		}
		persistTechFarmDtls(technicalAnalysisDtls.getTechnicalFarmDtlsList());
		persistTechAreaDtls(technicalAnalysisDtls.getTechnicalAreaDtlsList());
		persistTechAreaCoordinates(technicalAnalysisDtls.getTechnicalAreaCoordinatesList());
		persistTechCropDtls(technicalAnalysisDtls.getTechnicalCropDtlsList());
		persistTechAssetDtls(technicalAnalysisDtls.getTechnicalAssetDtlsList());
		persistTechWellDtls(technicalAnalysisDtls.getTechnicalWellDtlsList());
	}

	private void persistTechFarmDtls(TechnicalFarmDtlList technicalFarmDtlsList) {

		IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
		String dealId = islamicBankingObject.getDealID();
		deleteTechFarmDtls(dealId);
		for (TechnicalFarmDtl farmDtl : technicalFarmDtlsList.getTechnicalFarmDtlList()) {

			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			IBOCE_IB_TechnicalFarm newTechFarmDtlObj = (IBOCE_IB_TechnicalFarm) factory
					.getStatelessNewInstance(IBOCE_IB_TechnicalFarm.BONAME);
			newTechFarmDtlObj.setF_IBDATE(farmDtl.getDate());
			newTechFarmDtlObj.setF_IBEASTCOORDINATE(farmDtl.getEastCoordinate().toString());
			newTechFarmDtlObj.setF_IBEASTCOORDINATEO(farmDtl.getEastCoordinateO().toString());
			newTechFarmDtlObj.setF_IBELECTRICITYAVAILABLE(farmDtl.getElectricitySrcAvailable());
			newTechFarmDtlObj.setF_IBFARMTYPE(farmDtl.getFarmTypeRef());
			newTechFarmDtlObj.setF_IBINSPECTOR(farmDtl.getInspectorName());
			newTechFarmDtlObj.setF_IBNORTHCOORDINATE(farmDtl.getNorthCoordinate().toString());
			newTechFarmDtlObj.setF_IBNORTHCOORDINATEO(farmDtl.getNorthCoordinateO());
			newTechFarmDtlObj.setF_IBNOTESCONDITIONS(farmDtl.getNotesAndConditions());
			newTechFarmDtlObj.setF_IBNUMOFRECEIPT(farmDtl.getNumberOfReceipt());
			newTechFarmDtlObj.setF_IBOTHERFINDINGS(farmDtl.getOtherFindings());
			newTechFarmDtlObj.setF_IBPURPOSE(farmDtl.getPurposeRef());
			newTechFarmDtlObj.setF_IBSIGNEXIST(farmDtl.getSignExist());
			newTechFarmDtlObj.setF_IBSOILTYPE(farmDtl.getSoilTypeRef());
			newTechFarmDtlObj.setF_IBWATERAVAILABILITY(farmDtl.getWaterAvailabiltyRef());
			newTechFarmDtlObj.setF_IBDEALID(dealId);
			newTechFarmDtlObj.setF_IBAREAASSIGNEDFORSPCLPRJ(farmDtl.getAreaAssignedForSpclPrj());
			//Fisherman Details
			
			newTechFarmDtlObj.setF_IBLICENSENUMBER(farmDtl.getLicenseNumber());
			newTechFarmDtlObj.setF_IBFISHLICENSEDATE(farmDtl.getFishLicenseDate());
			newTechFarmDtlObj.setF_IBFISHLICENSEDATEHIJRI(farmDtl.getFishLicenseDateHijri());
			newTechFarmDtlObj.setF_IBLICENSETYPE(farmDtl.getLicenseType());
			newTechFarmDtlObj.setF_IBLICENSESOURCE(farmDtl.getLicenseSource());
			newTechFarmDtlObj.setF_IBNOOFBOATS(farmDtl.getNoOfBoats());
			newTechFarmDtlObj.setF_IBFISHNORTHCOORDINATE(farmDtl.getFishNorthCoordinate());
			newTechFarmDtlObj.setF_IBFISHNORTHCOORDINATEO(farmDtl.getFishNorthCoordinateO());
			newTechFarmDtlObj.setF_IBFISHEASTCOORDINATE(farmDtl.getFishEastCoordinate());
			newTechFarmDtlObj.setF_IBFISHEASTCOORDINATEO(farmDtl.getFishEastCoordinateO());
			newTechFarmDtlObj.setF_IBFISHPORT(farmDtl.getFishPort());
			newTechFarmDtlObj.setF_IBLETTERNUMBER(farmDtl.getLetterNumber());
			newTechFarmDtlObj.setF_IBLETTERDATE(null);
			if(farmDtl.getLetterDate()!=null) {
				newTechFarmDtlObj.setF_IBLETTERDATE(farmDtl.getLetterDate());
			}
			newTechFarmDtlObj.setF_IBLETTERDATEHIJRI(farmDtl.getLetterDateHijri());
			newTechFarmDtlObj.setF_IBLETTERSOURCE(farmDtl.getLetterSource());
			newTechFarmDtlObj.setF_IBWEALTHLETTERNUMBER(farmDtl.getWealthLetterNumber());
			newTechFarmDtlObj.setF_IBWEALTHLETTERDATE(null);
			if(farmDtl.getWealthLetterDate()!=null) {
				newTechFarmDtlObj.setF_IBWEALTHLETTERDATE(farmDtl.getWealthLetterDate());
			}
			newTechFarmDtlObj.setF_IBWEALTHLETTERDATEHIJRI(farmDtl.getWealthLetterDateHijri());
			newTechFarmDtlObj.setF_IBWEALTHLETTERSOURCE(farmDtl.getWealthLetterSource());
			
			
			newTechFarmDtlObj.setBoID(farmDtl.getReferenceNumber());
			factory.beginTransaction();
			factory.create(IBOCE_IB_TechnicalFarm.BONAME, newTechFarmDtlObj);
			deleteRelatedOtherDetailsForReference(farmDtl.getReferenceNumber());
			factory.commitTransaction();

		}
	}

	private void deleteRelatedOtherDetailsForReference(String refernceNum) {
		deleteTechAreaDtls(refernceNum);
		deleteTechAssetDtls(refernceNum, "");
		deleteTechAreaCoordinateDtls(refernceNum);
		deleteTechCropDtls(refernceNum);
		deleteTechWellDtls(refernceNum);
		
	}

	private void persistTechAreaDtls(TechnicalAreaDtlList technicalAreaDtlsList) {
		for (TechnicalAreaDtl areaDtl : technicalAreaDtlsList.getTechnicalAreaDtlList()) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			IBOCE_IB_TechincalArea newTechAreDtlObj = (IBOCE_IB_TechincalArea) factory
					.getStatelessNewInstance(IBOCE_IB_TechincalArea.BONAME);
			newTechAreDtlObj.setF_IBAREAASSIGNED(areaDtl.getAreaAssigned());
			newTechAreDtlObj.setF_IBAREACANBEUSED(
					null != areaDtl.getAreaCanBeUsed().toString() ? areaDtl.getAreaCanBeUsed().toString() : "0");
			newTechAreDtlObj.setF_IBAREACANBEUSEDFORALL(
					null != areaDtl.getAreaCanBeUsedForAllDeeds().toString() ? areaDtl.getAreaCanBeUsedForAllDeeds().toString()
							: "0");
			newTechAreDtlObj.setF_IBAREAUSED(areaDtl.getAreaUsed());
			newTechAreDtlObj.setF_IBAREAUSEDFORALL(
					null != areaDtl.getAreaUsedForAllDeeds().toString() ? areaDtl.getAreaUsedForAllDeeds().toString() : "0");
			newTechAreDtlObj.setF_IBDESCRIPTION(areaDtl.getTitleDescription());
			newTechAreDtlObj.setF_IBREFERENCENUMBER(areaDtl.getReferenceNumber());
			newTechAreDtlObj
					.setF_IBTOTALAREA(null != areaDtl.getTotalArea().toString() ? areaDtl.getTotalArea().toString() : "0");
			newTechAreDtlObj.setF_IBTOTALAREAFORALL(
					null != areaDtl.getTotalAreaForAllDeeds().toString() ? areaDtl.getTotalAreaForAllDeeds() : "0");
			newTechAreDtlObj.setF_IBTITLEDEEDID(areaDtl.getTitleDeedId());
			factory.beginTransaction();
			factory.create(IBOCE_IB_TechincalArea.BONAME, newTechAreDtlObj);
			factory.commitTransaction();

		}

	}

	public int deleteTechAreaDtls(String refernceNum) {
		int res = 0;
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(refernceNum);
			String TECHAREA_WHERECLAUSE = "where " + IBOCE_IB_TechincalArea.IBREFERENCENUMBER + " = ? " ;
			res = factory.bulkDelete(IBOCE_IB_TechincalArea.BONAME, TECHAREA_WHERECLAUSE, params);
			factory.commitTransaction();
		return res;
	}

	public int deleteTechAreaCoordinateDtls(String refernceNum) {
		int res = 0;
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList params = new ArrayList<>();
			params.add(refernceNum);
			String TECHAREACOORDINATE_WHERECLAUSE = "where " + IBOCE_IB_TechincalAreaAndCoordinates.IBREFERENCENUMBER
					+ " = ? " ;
			res = factory.bulkDelete(IBOCE_IB_TechincalAreaAndCoordinates.BONAME, TECHAREACOORDINATE_WHERECLAUSE,
					params);
			factory.commitTransaction();
		return res;
	}

	public int deleteTechAssetDtls(String refernceNum, String assetId) {
		int res = 0;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(refernceNum);
		//params.add(assetId);
		String TECHASSET_WHERECLAUSE = "where " + IBOCE_IB_TechincalAsset.IBREFERENCENUMBER + " = ? ";
		res = factory.bulkDelete(IBOCE_IB_TechincalAsset.BONAME, TECHASSET_WHERECLAUSE, params);
		factory.commitTransaction();
		return res;
	}

	public int deleteTechCropDtls(String refernceNum) {
		int res = 0;
		if ((StringUtils.isNotEmpty(refernceNum))) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(refernceNum);
			String TECHCROP_WHERECLAUSE = "where " + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " = ? ";
			res = factory.bulkDelete(IBOCE_IB_TechnicalCrop.BONAME, TECHCROP_WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}
	
	public int deleteTechWellDtls(String refernceNum) {
		int res = 0;
		if ((StringUtils.isNotEmpty(refernceNum))) {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(refernceNum);
			String TECHWELL_WHERECLAUSE = "where " + IBOCE_IB_TechnicalWell.IBREFERENCENUMBER + " = ? ";
			res = factory.bulkDelete(IBOCE_IB_TechnicalWell.BONAME, TECHWELL_WHERECLAUSE, params);
			factory.commitTransaction();
		}
		return res;
	}

	public int deleteTechFarmDtls(String dealId) {
		int res = 0;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		String TECHFARM_WHERECLAUSE = "where " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ? ";
		res = factory.bulkDelete(IBOCE_IB_TechnicalFarm.BONAME, TECHFARM_WHERECLAUSE, params);
		factory.commitTransaction();
		return res;
	}

	private void persistTechAreaCoordinates(TechnicalAreaCoordinateDtlList technicalAreaCoordinatesList) {
		//Map<String,String> refrencenumbersProcessed = new HashMap<String,String>();
		for (TechnicalAreaCoordinateDtl coordinateDtl : technicalAreaCoordinatesList
				.getTechnicalAreaCoordinateDtlList()) {
			/*if (refrencenumbersProcessed.get(coordinateDtl.getReferenceNumber())==null) {
				deleteTechAreaCoordinateDtls(coordinateDtl.getReferenceNumber(), coordinateDtl.getTitleDeedId(),
						coordinateDtl.getSerail());
				refrencenumbersProcessed.put(coordinateDtl.getReferenceNumber(), coordinateDtl.getReferenceNumber());
			}*/
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			IBOCE_IB_TechincalAreaAndCoordinates newTechAreaCorrDtlObj = (IBOCE_IB_TechincalAreaAndCoordinates) factory
					.getStatelessNewInstance(IBOCE_IB_TechincalAreaAndCoordinates.BONAME);
			newTechAreaCorrDtlObj.setF_IBEASTCOORDINATE(coordinateDtl.getEastCoordinate());
			newTechAreaCorrDtlObj.setF_IBEASTCOORDINATEO(coordinateDtl.getEastCoordinateO());
			newTechAreaCorrDtlObj.setF_IBNORTHCOORDINATE(coordinateDtl.getNorthCoordinate());
			newTechAreaCorrDtlObj.setF_IBNORTHCOORDINATEO(coordinateDtl.getEastCoordinateO());
			newTechAreaCorrDtlObj.setBoID(GUIDGen.getNewGUID());
			newTechAreaCorrDtlObj.setF_IBREFERENCENUMBER(coordinateDtl.getReferenceNumber());
			newTechAreaCorrDtlObj.setF_IBTITLEDEEDID(coordinateDtl.getTitleDeedId());
			newTechAreaCorrDtlObj.setF_IBSERIALID(coordinateDtl.getSerail());
			newTechAreaCorrDtlObj.setF_IBDEFAULTCOORDINATES(coordinateDtl.getDefaultCoordinates()==null?false:coordinateDtl.getDefaultCoordinates());
			factory.beginTransaction();
			factory.create(IBOCE_IB_TechincalAreaAndCoordinates.BONAME, newTechAreaCorrDtlObj);
			factory.commitTransaction();

		}
	}

	private void persistTechCropDtls(TechnicalCropDtlList technicalCropDtlsList) {

		for (TechnicalCropDtl cropDtl : technicalCropDtlsList.getTechnicalCropDtlList()) {
			if (!cropDtl.getReferenceNumber().equals(CommonConstants.EMPTY_STRING)) {
				// deleteTechCropDtls(cropDtl.getReferenceNumber());
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
				IBOCE_IB_TechnicalCrop newTechCropDtlObj = (IBOCE_IB_TechnicalCrop) factory
						.getStatelessNewInstance(IBOCE_IB_TechnicalCrop.BONAME);
				newTechCropDtlObj.setF_IBAREA(cropDtl.getArea());
				newTechCropDtlObj.setF_IBCROPTYPEID(cropDtl.getCropType());
				newTechCropDtlObj.setF_IBFORPALM(cropDtl.getForPalm());
				newTechCropDtlObj.setF_IBISINSUREDBYFARMER(cropDtl.getInsuredByFarmer());
				newTechCropDtlObj.setF_IBLENGTHOFWATERINGMACHINE(cropDtl.getLengthOfWateringMethod());
				newTechCropDtlObj.setF_IBMAINACTIVITY(cropDtl.getMainActivity());
				newTechCropDtlObj.setF_IBNOOFSEEDLINGS(cropDtl.getNoOfSeedling());
				newTechCropDtlObj.setF_IBREFERENCENUMBER(cropDtl.getReferenceNumber());
				newTechCropDtlObj.setF_IBSEEDLINGSTYPE(cropDtl.getSeedlingType());
				newTechCropDtlObj.setF_IBSTATUS(cropDtl.getStatus());
				newTechCropDtlObj.setF_IBTOTALAREA(
						null != cropDtl.getTotalAreaForAlCrop().toString() ? cropDtl.getTotalAreaForAlCrop().toString()
								: "0");
				newTechCropDtlObj.setF_IBWATERINGMETHOD(cropDtl.getWateringMethod());
				newTechCropDtlObj.setBoID(GUIDGen.getNewGUID());
				factory.beginTransaction();
				factory.create(IBOCE_IB_TechnicalCrop.BONAME, newTechCropDtlObj);
				factory.commitTransaction();
			}
		}
	}

	private void persistTechAssetDtls(TechincalAssetDtlsList technicalAssetDtlsList) {
		for (TechnicalAssetDtl assetDtl : technicalAssetDtlsList.getTechincalAssetDtlsList()) {

			//deleteTechAssetDtls(assetDtl.getReferenceNumber(), assetDtl.getAssetId());
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			IBOCE_IB_TechincalAsset newTechAssetDtlObj = (IBOCE_IB_TechincalAsset) factory
					.getStatelessNewInstance(IBOCE_IB_TechincalAsset.BONAME);
			newTechAssetDtlObj.setF_IBASSETCATEGORY(assetDtl.getAssetCategory().getCategory());
			newTechAssetDtlObj.setBoID(assetDtl.getAssetId());
			newTechAssetDtlObj.setF_IBASSETNAME(assetDtl.getAssetName());
			newTechAssetDtlObj.setF_IBREFERENCENUMBER(assetDtl.getReferenceNumber());
			factory.beginTransaction();
			factory.create(IBOCE_IB_TechincalAsset.BONAME, newTechAssetDtlObj);
			factory.commitTransaction();
			CeUtils.persistAssetUDFs(getF_IN_islamicBankingObject().getDealID(), 
					assetDtl.getAssetId(), getF_IN_techAnalysisDtls().getTechnicalAssetUDFs());
		}

	}

	private void persistTechWellDtls(TechnicalWellDtlsList technicalWellDtlsList) {

		for (TechnicalWellDtl wellDtl : technicalWellDtlsList.getTechnicalWellDtlList()) {
			if (!wellDtl.getReferenceNumber().equals(CommonConstants.EMPTY_STRING)) {
				// deleteTechWellDtls(wellDtl.getReferenceNumber());
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
				IBOCE_IB_TechnicalWell newTechWellDtlObj = (IBOCE_IB_TechnicalWell) factory
						.getStatelessNewInstance(IBOCE_IB_TechnicalWell.BONAME);

				newTechWellDtlObj.setBoID(GUIDGen.getNewGUID());
				newTechWellDtlObj.setF_IBEASTCOORDINATE(
						wellDtl.getEastCoordinate() == null ? new BigDecimal(0) : wellDtl.getEastCoordinate());
				newTechWellDtlObj.setF_IBEASTCOORDINATEO(
						wellDtl.getEastCoordinateO() == null ? 0 : wellDtl.getEastCoordinateO());
				newTechWellDtlObj.setF_IBISWELLUSED(wellDtl.getIsWellUsed());
				newTechWellDtlObj.setF_IBLICENSEDATE(wellDtl.getLicenseDate());
				newTechWellDtlObj.setF_IBLICENSEDATEHIJRI(wellDtl.getLicenseDateHijri());
				newTechWellDtlObj.setF_IBLICENSENUMBER(wellDtl.getLicenseNumber());
				newTechWellDtlObj.setF_IBNORTHCOORDINATE(
						wellDtl.getNorthCoordinate() == null ? new BigDecimal(0) : wellDtl.getNorthCoordinate());
				newTechWellDtlObj.setF_IBNORTHCOORDINATEO(
						wellDtl.getNorthCoordinateO() == null ? 0 : wellDtl.getNorthCoordinateO());
				newTechWellDtlObj.setF_IBOLDBRANCHCODE(wellDtl.getOldBranchCode());
				newTechWellDtlObj.setF_IBOLDCONTRACTID(wellDtl.getOldContractID());
				newTechWellDtlObj.setF_IBREFERENCENUMBER(wellDtl.getReferenceNumber());
				newTechWellDtlObj.setF_IBSERIALNUMBER(wellDtl.getSerialNumber());
				newTechWellDtlObj.setF_IBTITLEDEEDID(wellDtl.getTitleDeedId());
				newTechWellDtlObj.setF_IBWELLAIR(wellDtl.getWellAir()==null?CommonConstants.INTEGER_ZERO:wellDtl.getWellAir());
				newTechWellDtlObj.setF_IBWELLARCH(wellDtl.getWellArch()==null?CommonConstants.INTEGER_ZERO:wellDtl.getWellArch());
				newTechWellDtlObj.setF_IBWELLDEPTH(wellDtl.getWellDepth()==null?CommonConstants.INTEGER_ZERO:wellDtl.getWellDepth());
				newTechWellDtlObj.setF_IBWELLSTATUS(wellDtl.getWellStatus());
				newTechWellDtlObj.setF_IBWELLTYPE(wellDtl.getWellType());
				factory.beginTransaction();
				factory.create(IBOCE_IB_TechnicalWell.BONAME, newTechWellDtlObj);
				factory.commitTransaction();
			}
		}
	}

}
