package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_EnableDisableButtonsOfRelBB;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_EnableDisableButtonsOfRelBB;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class EnableDisableButtonsOfRelBB extends AbstractCE_IB_EnableDisableButtonsOfRelBB
        implements ICE_IB_EnableDisableButtonsOfRelBB {

    public EnableDisableButtonsOfRelBB() {
        // TODO Auto-generated constructor stub
    }
    private static final Log LOGGER = LogFactory.getLog(GetPartyDetailsByPartyNationalID.class);

    public EnableDisableButtonsOfRelBB(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
       String agentPartyID = getF_IN_agentDtlPartyID();
       String relationPartyID = getF_IN_dealRelationPartyID();
       String relationdtlsID = getF_IN_dealrelationDtlsId();
       String agentRelationdtlsID = getF_IN_agentRelationDtlsId();
       Boolean isViewOnly = isF_IN_isViewOnly();
       if(isViewOnly)
       {
           setF_OUT_disableAgentNewButton(true);
           setF_OUT_disableAgentPartyButton(true);
           setF_OUT_disableRelationNewButton(true);
           setF_OUT_disablerelationPartyButton(true);
       }
       else
       {
           
           if(IBCommonUtils.isNotEmpty(relationdtlsID) && IBCommonUtils.isEmpty(relationPartyID))
               setF_OUT_disableRelationNewButton(true);
           else
               setF_OUT_disableRelationNewButton(false);
           if(IBCommonUtils.isNotEmpty(relationdtlsID))
               setF_OUT_disablerelationPartyButton(false);
           else
               setF_OUT_disablerelationPartyButton(true);
           if(IBCommonUtils.isNotEmpty(agentRelationdtlsID))
               setF_OUT_disableAgentPartyButton(false);
           else
               setF_OUT_disableAgentPartyButton(true);
           if(IBCommonUtils.isEmpty(agentPartyID) && IBCommonUtils.isEmpty(agentRelationdtlsID) && IBCommonUtils.isEmpty(relationdtlsID) )
               setF_OUT_disableAgentNewButton(true);
           else
               setF_OUT_disableAgentNewButton(false);
               
       }
    }
}
