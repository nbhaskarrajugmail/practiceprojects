package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressPricedValidation;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.finastra.fbe.mmk.fd.validation.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;

public class AssetProgressPricedValidation extends AbstractCE_IB_AssetProgressPricedValidation {

	private static final long serialVersionUID = 1L;

	public AssetProgressPricedValidation(BankFusionEnvironment env) {
		super(env);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		System.err.println();
		// for non-priced asset
		if (isF_IN_isMachine() && !isF_IN_pricedAsset()
				&& getF_IN_invoiceAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) <= 0) {
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.INVOICE_AMOUNT_MANDATORY);
		}
		BFCurrencyAmount invoiceAmount = getF_IN_invoiceAmount();
		if (getF_IN_mode().equals("PERCENTAGE")) {
			invoiceAmount.setCurrencyAmount(getF_IN_originalStudyCost().multiply(getF_IN_progressPercent())
					.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP));
		}
		if (getF_IN_mode().equals("INVOICEAMOUNT")&& invoiceAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) == 0) {
			invoiceAmount.setCurrencyAmount(getF_IN_originalStudyCost().multiply(getF_IN_progressPercent())
					.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP));
		}
		if (getF_IN_mode().equals("SAVE")) {
			Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(
					getF_IN_assetProgressReportDetails().getAssetProgressReportList(), getF_IN_assetID());
			
			BigDecimal calcCost = costMap.get("CALCULATEDCOST");
			//BigDecimal finalCost = costMap.get("FINALCOST");
			if(isF_IN_isMachine() && calcCost.compareTo(BigDecimal.ZERO)>0) {
				IBCommonUtils.raiseUnparameterizedEvent(44000429);
			}
			
		}
		// if invoice amount is entered
		if (null != invoiceAmount.getCurrencyAmount()
				&& invoiceAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) {
			if (getF_IN_mode().equals("INVOICEAMOUNT")||getF_IN_mode().equals("PERCENTAGE")) {
				BigDecimal percentage = CalculateStudyGrantApproval
						.calculateParticipationPercentage(getF_IN_originalStudyCost(), getF_IN_originalFinalCost());
				setF_OUT_assetCost(invoiceAmount);
				BFCurrencyAmount finalCalculatedCost = new BFCurrencyAmount();
				finalCalculatedCost.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
				finalCalculatedCost.setCurrencyAmount(invoiceAmount.getCurrencyAmount().multiply(percentage)
						.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP));
				setF_OUT_finalCalculatedCost(finalCalculatedCost);

				BigDecimal progressPercent = finalCalculatedCost.getCurrencyAmount().multiply(new BigDecimal(100))
						.divide(getF_IN_originalFinalCost(), 2, RoundingMode.HALF_UP);
				setF_OUT_progressPercent(progressPercent);
				Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(
						getF_IN_assetProgressReportDetails().getAssetProgressReportList(), getF_IN_assetID());

				BFCurrencyAmount previousReportsCost = new BFCurrencyAmount();
				previousReportsCost.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
				previousReportsCost.setCurrencyAmount(costMap.get("CALCULATEDCOST"));
				BFCurrencyAmount previousReportsFinalCost = new BFCurrencyAmount();
				previousReportsFinalCost.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
				previousReportsFinalCost.setCurrencyAmount(costMap.get("FINALCOST"));

				BFCurrencyAmount netCost = new BFCurrencyAmount();
				netCost.setCurrencyAmount(
						invoiceAmount.getCurrencyAmount().subtract(previousReportsCost.getCurrencyAmount()));
				netCost.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
				BFCurrencyAmount netFinalCost = new BFCurrencyAmount();
				netFinalCost.setCurrencyAmount(
						finalCalculatedCost.getCurrencyAmount().subtract(previousReportsFinalCost.getCurrencyAmount()));
				netFinalCost.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
				setF_OUT_netCost(netCost);
				setF_OUT_netFinalCost(netFinalCost);
				setF_OUT_previousCost(previousReportsCost);
				setF_OUT_previousFinalCost(previousReportsFinalCost);
			}
		}
		// if price related fields are empty
		else if (isF_IN_isMachine() && isF_IN_pricedAsset() && (IBCommonUtils.isNullOrEmpty(getF_IN_machineNumber())
				|| IBCommonUtils.isNullOrEmpty(getF_IN_machineType())
				|| IBCommonUtils.isNullOrEmpty(getF_IN_priceListNumber()) || getF_IN_priceListYear().equals(0))) {
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.INVOICE_AMOUNT_MANDATORY);
		}

	}

}
