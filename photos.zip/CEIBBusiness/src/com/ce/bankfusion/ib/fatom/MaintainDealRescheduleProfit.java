package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_MaintainDealRescheduleProfit;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.util.IBCommonUtils;

public class MaintainDealRescheduleProfit extends AbstractCE_IB_MaintainDealRescheduleProfit {

    private static final long serialVersionUID = 1L;

    public MaintainDealRescheduleProfit() {
        super();
    }

    public MaintainDealRescheduleProfit(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        BigDecimal hundred = new BigDecimal(100);
        BFCurrencyAmount rescheduleProfitAmount = getF_IN_newRecheduleProfit();
        BigDecimal scheduleFeesPercentage = getF_IN_scheduleFeesPercentage();
        BigDecimal feesPercentage = getF_IN_feesPercentage();
        BFCurrencyAmount scheduleFeesAmount = getF_IN_scheduleFeesAmount();
        BFCurrencyAmount feesAmount = getF_IN_feesAmount();
        MathContext precision = MathContext.DECIMAL32;
        if (null != rescheduleProfitAmount && rescheduleProfitAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) {
            if (isF_IN_isFeesAmount()) {
                if (rescheduleProfitAmount.getCurrencyAmount().compareTo(feesAmount.getCurrencyAmount()) >= 0
                    && feesAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) >= 0) {
                    scheduleFeesAmount
                        .setCurrencyAmount(rescheduleProfitAmount.getCurrencyAmount().subtract(feesAmount.getCurrencyAmount()));
                    scheduleFeesPercentage =
                        (scheduleFeesAmount.getCurrencyAmount().divide(rescheduleProfitAmount.getCurrencyAmount(),precision))
                            .multiply(hundred);
                    feesPercentage = hundred.subtract(scheduleFeesPercentage);
                } else
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FEES_LESS_OR_EQUAL_TO_PROFIT_CEIB);
            }
            else if (isF_IN_isScheduleFeesAmount()) {
                if (rescheduleProfitAmount.getCurrencyAmount().compareTo(scheduleFeesAmount.getCurrencyAmount()) >= 0
                    && scheduleFeesAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) >= 0) {
                    feesAmount
                        .setCurrencyAmount(rescheduleProfitAmount.getCurrencyAmount().subtract(scheduleFeesAmount.getCurrencyAmount()));
                    feesPercentage =
                        (feesAmount.getCurrencyAmount().divide(rescheduleProfitAmount.getCurrencyAmount(),precision))
                            .multiply(hundred);
                    scheduleFeesPercentage = hundred.subtract(feesPercentage);
                } else
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_SCHEDULE_FEES_LESS_OR_EQUAL_TO_PROFIT_CEIB);
            }
            else if (isF_IN_isFeesPercentage()) {
                if (feesPercentage.compareTo(hundred) <= 0 && feesPercentage.compareTo(BigDecimal.ZERO) >= 0) {
                    feesAmount.setCurrencyAmount((feesPercentage.divide(hundred,precision)).multiply(rescheduleProfitAmount.getCurrencyAmount(),precision));
                    scheduleFeesAmount
                        .setCurrencyAmount(rescheduleProfitAmount.getCurrencyAmount().subtract(feesAmount.getCurrencyAmount()));
                    scheduleFeesPercentage =
                        (scheduleFeesAmount.getCurrencyAmount().divide(rescheduleProfitAmount.getCurrencyAmount(),precision)).multiply(hundred);
                } else
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_SCHEDULE_FEES_PERCENTAGE_CANNOT_BE_NEG_CEIB);
            }
            else if (isF_IN_isScheduleFeesPercentage()) {
                if (scheduleFeesPercentage.compareTo(hundred) <= 0 && scheduleFeesPercentage.compareTo(BigDecimal.ZERO) >= 0) {
                    scheduleFeesAmount
                        .setCurrencyAmount((scheduleFeesPercentage.divide(hundred,precision)).multiply(rescheduleProfitAmount.getCurrencyAmount(),precision));
                    feesAmount
                        .setCurrencyAmount(rescheduleProfitAmount.getCurrencyAmount().subtract(scheduleFeesAmount.getCurrencyAmount()));
                    feesPercentage = (feesAmount.getCurrencyAmount().divide(rescheduleProfitAmount.getCurrencyAmount(),precision)).multiply(hundred);
                } else
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_SCHEDULE_FEES_PERCENTAGE_CANNOT_BE_NEG_CEIB);
            }
            else{
                feesAmount.setCurrencyAmount((feesPercentage.divide(hundred,precision)).multiply(rescheduleProfitAmount.getCurrencyAmount()));
                scheduleFeesAmount
                    .setCurrencyAmount(rescheduleProfitAmount.getCurrencyAmount().subtract(feesAmount.getCurrencyAmount()));
                scheduleFeesPercentage =
                    (scheduleFeesAmount.getCurrencyAmount().divide(rescheduleProfitAmount.getCurrencyAmount(),precision)).multiply(hundred);
            }
        } else
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCHEDULE_PROFIT_AMOUNT_MIN_VALID_CEIB);
        setF_OUT_feesAmount(feesAmount);
        setF_OUT_feesPercentage(feesPercentage.setScale(6,RoundingMode.HALF_UP));
        setF_OUT_scheduleFeesAmount(scheduleFeesAmount);
        setF_OUT_scheduleFeesPercentage(scheduleFeesPercentage.setScale(6,RoundingMode.HALF_UP));
    }

}
