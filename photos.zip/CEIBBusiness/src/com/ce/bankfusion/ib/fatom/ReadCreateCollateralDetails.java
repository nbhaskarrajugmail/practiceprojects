package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DocumentSourceForCollateral;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadCreateCollateralDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_ReadCreateCollateralDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.ce.bankfusion.ib.util.CollateralUtil;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CreateCollateralRqDetails;
import bf.com.misys.ib.types.IslamicBankingObject;
import edu.emory.mathcs.backport.java.util.Arrays;

public class ReadCreateCollateralDetails extends AbstractCE_IB_ReadCreateCollateralDetails
        implements ICE_IB_ReadCreateCollateralDetails {

    private static final transient Log LOGGER = LogFactory.getLog(ReadCreateCollateralDetails.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public ReadCreateCollateralDetails() {
        // TODO Auto-generated constructor stub
    }

    public ReadCreateCollateralDetails(BankFusionEnvironment env) {
        super(env);

    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method-->" + getF_IN_ibObject().getDealID());
        setRequestTypeGClist();
        setF_OUT_collateralTypeGClist(CollateralUtil.getAllCollateralTypes(env));
        getCreateCollaterals(env);
        getCollateralRequestDetails();
        LOGGER.info("Exiting from process method-->" + getF_IN_ibObject().getDealID());

    }

    private void getCreateCollaterals(BankFusionEnvironment env) {
        LOGGER.info("Entering into getCreateCollaterals method-->" + getF_IN_ibObject().getDealID());
        StringBuilder queryCondition = new StringBuilder(" WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + "= ?");
        //AND "+ IBOCE_IB_DealCollateralDtls.IBSTATUS+ CollateralRequestDtlsUtils.COLLATERAL_QUERY;
        IslamicBankingObject ibo = getF_IN_ibObject();
        if(null != ibo.getTransactionID() && !ibo.getTransactionID().equals(ibo.getDealID())) {
            if(!queryCondition.toString().contains(ibo.getTransactionID())) {
            queryCondition.append(" OR "+IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID+" = '"+ibo.getTransactionID()+"'");
            }
         }else {
            queryCondition.append(" AND ("+IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID+" = '' OR "+IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID+ " IS NULL)");
        }
        ArrayList<String> param = new ArrayList<String>();
        param.add(getF_IN_ibObject().getDealID());
        List<IBOCE_IB_DealCollateralDtls> createCollateralDetails = (ArrayList<IBOCE_IB_DealCollateralDtls>) factory
                .findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, queryCondition.toString(), param, null, true);
        
        
       getF_OUT_createCollateralRqDetailsList().removeAllCreateCollateralRqDetailsList();
        if (null != createCollateralDetails && !createCollateralDetails.isEmpty()) {
            for (IBOCE_IB_DealCollateralDtls dealCollateralDtls : createCollateralDetails) {
                CreateCollateralRqDetails createCollateralRqDetails = new CreateCollateralRqDetails();
                createCollateralRqDetails.setCollateralID(dealCollateralDtls.getBoID());
                createCollateralRqDetails.setCollateralType(dealCollateralDtls.getF_IBCOLLATERALTYPE());
                for (GcCodeDetail gcCodedtl : getF_OUT_collateralTypeGClist().getGcCodeDetails()) {
                    if (createCollateralRqDetails.getCollateralType().equals(gcCodedtl.getCodeReference())) {
                        createCollateralRqDetails.setCollateralTypeDesc(gcCodedtl.getCodeDescription());
                        break;
                    }
                }
                BFCurrencyAmount currencyAmt = IBCommonUtils.getBFCurrencyAmount(dealCollateralDtls.getF_IBCOVERVALUE(),
                        getF_IN_ibObject().getCurrency());
                createCollateralRqDetails.setCoverValue(currencyAmt);
                createCollateralRqDetails.setDescription(dealCollateralDtls.getF_IBDESCRIPTION());
                createCollateralRqDetails.setDocDate(dealCollateralDtls.getF_IBDOCUMENTDATE());
                createCollateralRqDetails.setDocnum(dealCollateralDtls.getF_IBDOCUMENTNUMBER());
                createCollateralRqDetails.setDocSourceId(dealCollateralDtls.getF_IBDOCUMENTSOURCE());
                IBOCE_IB_DocumentSourceForCollateral documentSourceForCollateral  = (IBOCE_IB_DocumentSourceForCollateral) factory.findByPrimaryKey(IBOCE_IB_DocumentSourceForCollateral.BONAME, createCollateralRqDetails.getDocSourceId(), true);
                createCollateralRqDetails.setDocSourceDesc(null != documentSourceForCollateral?documentSourceForCollateral.getF_IBDOCUMENTVALUE():null);
                createCollateralRqDetails.setExpiryDate(dealCollateralDtls.getF_IBEXPIRYDATE());
                createCollateralRqDetails.setIsDocUploaded(dealCollateralDtls.isF_IBISDOCUPLOADED());
                createCollateralRqDetails.setRequestID(dealCollateralDtls.getF_IBREQUESTID());
                createCollateralRqDetails.setRequestType(dealCollateralDtls.getF_IBREQUESTTYPE());
                createCollateralRqDetails.setReviewDate(dealCollateralDtls.getF_IBREVIEWDATE());
                createCollateralRqDetails.setSelect(false);
                createCollateralRqDetails.setSystemStatus(dealCollateralDtls.getF_IBSYSTEMSTATUS());
                getF_OUT_createCollateralRqDetailsList().addCreateCollateralRqDetailsList(createCollateralRqDetails);
            }
        }
        LOGGER.info("Exiting from getCreateCollaterals method-->" + getF_IN_ibObject().getDealID());
    }

    private void getCollateralRequestDetails() {
        LOGGER.info("Entering into getCollateralRequestDetails method--->" + getF_IN_ibObject().getDealID());
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + "= ? and " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTTYPE+ " != ? " );
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_ibObject().getDealID());
        params.add(CollateralUtil.REQ_TYP_EXISTING);
        for (CreateCollateralRqDetails createCollateralRqDetails : getF_OUT_createCollateralRqDetailsList()
                .getCreateCollateralRqDetailsList()) {
            queryCondition.append(" AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTID + " != ? ");
            params.add(createCollateralRqDetails.getRequestID());
        }
        if(getF_IN_ibObject().getTransactionName().equals("DEAL")) {
            queryCondition.append(" AND ("+IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID+" = '' OR "+IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID+ " IS NULL)");
        }else {
            queryCondition.append(" AND "+IBOCE_IB_DealCollateralDtls.IBSTATUS+" != ?");
            params.add("DELETED");
        }
        List<IBOCE_IB_CollateralRevaluationDetails> createRequestCollateralDetails = (List<IBOCE_IB_CollateralRevaluationDetails>) factory
                .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, queryCondition.toString(), params, null, false);
        getF_OUT_collateralReqDetailsList().removeAllCollateralRequestDetailsList();
        if (null != createRequestCollateralDetails && !createRequestCollateralDetails.isEmpty()) {
            for (IBOCE_IB_CollateralRevaluationDetails reqCollateralDtls : createRequestCollateralDetails) {
                CollateralRequestDetails collateralRequestDetails = new CollateralRequestDetails();
                collateralRequestDetails.setRequestID(reqCollateralDtls.getBoID());
                BFCurrencyAmount availableAmt = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBAVAILABLEBALANCE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setAvailableBalance(availableAmt);
                collateralRequestDetails.setCategoryType(reqCollateralDtls.getF_IBCATEGORYTYPE());
                // collateralRequestDetails.setCollateralID(reqCollateralDtls.getF_COLLATERALID());
                BFCurrencyAmount coverValue = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBCOVERVALUE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setCoverValue(coverValue);
                collateralRequestDetails.setDescription(reqCollateralDtls.getF_IBDESCRIPTION());
                collateralRequestDetails.setRequestType(reqCollateralDtls.getF_IBREQUESTTYPE());
				ListGenericCodeRs lsGenericCodesReq = IBCommonUtils.getGCList("REQ_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesReq.getGcCodeDetails()) {
					if (reqCollateralDtls.getF_IBREQUESTTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setRequestTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}
				ListGenericCodeRs lsGenericCodesCat = IBCommonUtils.getGCList("CATEGORY_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesCat.getGcCodeDetails()) {

					if (reqCollateralDtls.getF_IBCATEGORYTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setCategoryTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}
 
                collateralRequestDetails.setTitleDeedIDPK(reqCollateralDtls.getF_IBTITLEDEEDIDPK());
                collateralRequestDetails.setTitleDeedNum(reqCollateralDtls.getF_IBTITLEDEEDNUM());
                collateralRequestDetails.setSelect(false);
                getF_OUT_collateralReqDetailsList().addCollateralRequestDetailsList(collateralRequestDetails);
            }
        }
        LOGGER.info("Exiting from getCollateralRequestDetails method-->" + getF_IN_ibObject().getDealID());
    }

    private void setRequestTypeGClist() {
        LOGGER.info("Entering into setRequestTypeGClist method-->" + getF_IN_ibObject().getDealID());
        ListGenericCodeRs gcList = IBCommonUtils.getGCList(CollateralUtil.REQUSEST_TYPE_REFERENCE);
        getF_OUT_requestTypeGClist().removeAllGcCodeDetails();
        for (GcCodeDetail gcCodeDetail : gcList.getGcCodeDetails()) {
            if (!CollateralUtil.REQ_TYP_EXISTING.equals(gcCodeDetail.getCodeReference())) {
                getF_OUT_requestTypeGClist().addGcCodeDetails(gcCodeDetail);
            }
        }
        LOGGER.info("Exiting from setRequestTypeGClist method-->" + getF_IN_ibObject().getDealID());
    }

}
