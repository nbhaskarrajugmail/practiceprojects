/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateTitledDeedInfo;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.technical.dtls.ib.types.TechnicalAnalysisDtls;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;

/**
 * @author Aklesh
 *
 */
public class PopulateTitledDeedInfo extends AbstractCE_IB_PopulateTitledDeedInfo {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String TITLE_DEED_LOCATION_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDLOCATION.TITLEDEEDID
			+ "=?";

	public PopulateTitledDeedInfo(BankFusionEnvironment env) {
		super(env);
	}

	public PopulateTitledDeedInfo() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		TechnicalAnalysisDtls technicalAnalysis = getF_IN_technicalAnalysisDtls();
		String titleDeedId = getF_IN_titleDeedID();
		int titleDeedVersion = CommonConstants.INTEGER_ONE;
		String whereClause = "WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + "=? AND "
				+ IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID + "=?";
		ArrayList<String> paramTD = new ArrayList<>();
		paramTD.add(getF_IN_dealID());
		paramTD.add(titleDeedId);
		List<IBOCE_IB_DealTitleDeedDtls> dealTitleDeeds = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, paramTD, null);
		if (dealTitleDeeds.size() > 0) {
			titleDeedVersion = Integer.parseInt(dealTitleDeeds.get(0).getF_IBTITLEDEEDVERSIONNUM());
		}
		CE_TITLEDEEDDETAILSID titleDeedID = new CE_TITLEDEEDDETAILSID();
		titleDeedID.setF_TITLEDEEDID(titleDeedId);
		titleDeedID.setF_TITLEDEEDVERSION(titleDeedVersion);
		IBOCE_TITLEDEEDDETAILS titleDeedDetail = (IBOCE_TITLEDEEDDETAILS) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedID, true);
		ArrayList<String> params = new ArrayList<>();
		params.add(titleDeedId);
		for (TechnicalAreaDtl technicalAreaDtl : technicalAnalysis.getTechnicalAreaDtlsList()
				.getTechnicalAreaDtlList()) {
			if (technicalAreaDtl.getSelect()) {

				technicalAreaDtl.setTotalArea(titleDeedDetail.getF_AREASIZE().toString());
				technicalAreaDtl.setTitleDescription(titleDeedDetail.getF_NOTES());
				technicalAreaDtl.setLandPlanNumber(titleDeedDetail.getF_LANDPLANNUMBER());
				technicalAreaDtl.setLandPlotNumber(titleDeedDetail.getF_LANDPLOTNUMBER());
				technicalAreaDtl.setTitleDeedSource(
						IBCommonUtils.getGCChildDesc("TITLEDEEDSOURCE", titleDeedDetail.getF_TITLEDEEDSOURCE()));
				technicalAreaDtl.setTitleDeedType(
						IBCommonUtils.getGCChildDesc("TITLEDEEDTYPE", titleDeedDetail.getF_TITLEDEEDTYPE()));
				// TODO I have to get GC Parent from GD
				// technicalAreaDtl.setTitleDeedType(titleDeedDetail.getF_TITLEDEEDSRC());
				technicalAreaDtl.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());
				technicalAreaDtl.setTotalArea(titleDeedDetail.getF_AREASIZE().toString());
				if (titleDeedID.equals(technicalAreaDtl.getTitleDeedId())) {
					TechnicalAreaCoordinateDtlList technicalAreaCoordinateDtlList = new TechnicalAreaCoordinateDtlList();
					for (TechnicalAreaCoordinateDtl technicalAreaCoordinateDtl : getF_IN_technicalAnalysisDtls()
							.getTechnicalAreaCoordinatesList().getTechnicalAreaCoordinateDtlList()) {
						if (technicalAreaCoordinateDtl.getReferenceNumber().equals(getF_IN_referenceNumber())) {
							technicalAreaCoordinateDtlList
									.addTechnicalAreaCoordinateDtlList(technicalAreaCoordinateDtl);
						}
					}
					setF_OUT_technicalAreaCoordinateDtlList(technicalAreaCoordinateDtlList);
				} else {
					List<IBOCE_TITLEDEEDLOCATION> titleDeedLocationDetails = (List) factory.findByQuery(
							IBOCE_TITLEDEEDLOCATION.BONAME, TITLE_DEED_LOCATION_WHERE_CLAUSE, params, null, false);
					boolean firstRowTrue = false;
					technicalAnalysis.getTechnicalAreaCoordinatesList().removeAllTechnicalAreaCoordinateDtlList();
					for (IBOCE_TITLEDEEDLOCATION titleDeedLocation : titleDeedLocationDetails) {
						TechnicalAreaCoordinateDtl technicalAreaCoordinateDtl = new TechnicalAreaCoordinateDtl();
						technicalAreaCoordinateDtl.setEastCoordinate(titleDeedLocation.getF_LOCEASTDEGREE().toString());
						technicalAreaCoordinateDtl
								.setEastCoordinateO(titleDeedLocation.getF_LOCEASTSECTION().toString());
						technicalAreaCoordinateDtl
								.setNorthCoordinate(titleDeedLocation.getF_LOCNORTHDEGREE().toString());
						technicalAreaCoordinateDtl
								.setNorthCoordinateO(titleDeedLocation.getF_LOCNORTHSECTION().toString());
						technicalAreaCoordinateDtl.setReferenceNumber(getF_IN_referenceNumber());
						technicalAreaCoordinateDtl.setDefaultCoordinates(false);
						technicalAreaCoordinateDtl.setSelect(false);
						if (!firstRowTrue) {
							firstRowTrue = true;
							technicalAreaCoordinateDtl.setSelect(true);
						}
						technicalAreaCoordinateDtl.setSelect(false);
						technicalAreaCoordinateDtl.setSerail(titleDeedLocation.getF_SERIAL());
						technicalAreaCoordinateDtl.setTitleDeedId(titleDeedId);
						technicalAnalysis.getTechnicalAreaCoordinatesList()
								.addTechnicalAreaCoordinateDtlList(technicalAreaCoordinateDtl);

					}
					setF_OUT_technicalAreaCoordinateDtlList(technicalAnalysis.getTechnicalAreaCoordinatesList());
				}

				setF_OUT_technicalAreaDtl(technicalAreaDtl);
			} else {

				TechnicalAreaDtl technicalAreaDtlNew = new TechnicalAreaDtl();

				technicalAreaDtlNew.setTotalArea(titleDeedDetail.getF_AREASIZE().toString());
				technicalAreaDtlNew.setTitleDescription(titleDeedDetail.getF_NOTES());
				technicalAreaDtlNew.setLandPlanNumber(titleDeedDetail.getF_LANDPLANNUMBER());
				technicalAreaDtlNew.setLandPlotNumber(titleDeedDetail.getF_LANDPLOTNUMBER());
				technicalAreaDtl.setTitleDeedSource(
						IBCommonUtils.getGCChildDesc("TITLEDEEDSOURCE", titleDeedDetail.getF_TITLEDEEDSOURCE()));
				technicalAreaDtl.setTitleDeedType(
						IBCommonUtils.getGCChildDesc("TITLEDEEDTYPE", titleDeedDetail.getF_TITLEDEEDTYPE()));
				technicalAreaDtlNew.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());

				List<IBOCE_TITLEDEEDLOCATION> titleDeedLocationDetails = (List) factory.findByQuery(
						IBOCE_TITLEDEEDLOCATION.BONAME, TITLE_DEED_LOCATION_WHERE_CLAUSE, params, null, false);
				boolean firstRowTrue = false;
				technicalAnalysis.getTechnicalAreaCoordinatesList().removeAllTechnicalAreaCoordinateDtlList();
				for (IBOCE_TITLEDEEDLOCATION titleDeedLocation : titleDeedLocationDetails) {
					TechnicalAreaCoordinateDtl technicalAreaCoordinateDtl = new TechnicalAreaCoordinateDtl();
					technicalAreaCoordinateDtl.setEastCoordinate(titleDeedLocation.getF_LOCEASTDEGREE().toString());
					technicalAreaCoordinateDtl.setEastCoordinateO(titleDeedLocation.getF_LOCEASTSECTION().toString());
					technicalAreaCoordinateDtl.setNorthCoordinate(titleDeedLocation.getF_LOCNORTHDEGREE().toString());
					technicalAreaCoordinateDtl.setNorthCoordinateO(titleDeedLocation.getF_LOCNORTHSECTION().toString());
					technicalAreaCoordinateDtl.setReferenceNumber(getF_IN_referenceNumber());
					technicalAreaCoordinateDtl.setDefaultCoordinates(false);
					technicalAreaCoordinateDtl.setSelect(false);
					if (!firstRowTrue) {
						firstRowTrue = true;
						technicalAreaCoordinateDtl.setSelect(true);
					}
					technicalAreaCoordinateDtl.setSelect(false);
					technicalAreaCoordinateDtl.setSerail(titleDeedLocation.getF_SERIAL());
					technicalAreaCoordinateDtl.setTitleDeedId(titleDeedId);
					technicalAnalysis.getTechnicalAreaCoordinatesList()
							.addTechnicalAreaCoordinateDtlList(technicalAreaCoordinateDtl);

				}
				setF_OUT_technicalAreaCoordinateDtlList(technicalAnalysis.getTechnicalAreaCoordinatesList());
				setF_OUT_technicalAreaDtl(technicalAreaDtlNew);

			}

		}
		if (technicalAnalysis.getTechnicalAreaDtlsList().getTechnicalAreaDtlListCount() == 0) {
			TechnicalAreaDtl technicalAreaDtlNew = new TechnicalAreaDtl();

			technicalAreaDtlNew.setTotalArea(titleDeedDetail.getF_AREASIZE().toString());
			technicalAreaDtlNew.setTitleDescription(titleDeedDetail.getF_NOTES());
			technicalAreaDtlNew.setLandPlanNumber(titleDeedDetail.getF_LANDPLANNUMBER());
			technicalAreaDtlNew.setLandPlotNumber(titleDeedDetail.getF_LANDPLOTNUMBER());
			technicalAreaDtlNew.setTitleDeedSource(
					IBCommonUtils.getGCChildDesc("TITLEDEEDSOURCE", titleDeedDetail.getF_TITLEDEEDSOURCE()));
			technicalAreaDtlNew.setTitleDeedType(
					IBCommonUtils.getGCChildDesc("TITLEDEEDTYPE", titleDeedDetail.getF_TITLEDEEDTYPE()));
			technicalAreaDtlNew.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());

			List<IBOCE_TITLEDEEDLOCATION> titleDeedLocationDetails = (List) factory
					.findByQuery(IBOCE_TITLEDEEDLOCATION.BONAME, TITLE_DEED_LOCATION_WHERE_CLAUSE, params, null, false);
			boolean firstRowTrue = false;
			technicalAnalysis.getTechnicalAreaCoordinatesList().removeAllTechnicalAreaCoordinateDtlList();
			for (IBOCE_TITLEDEEDLOCATION titleDeedLocation : titleDeedLocationDetails) {
				TechnicalAreaCoordinateDtl technicalAreaCoordinateDtl = new TechnicalAreaCoordinateDtl();
				technicalAreaCoordinateDtl.setEastCoordinate(titleDeedLocation.getF_LOCEASTDEGREE().toString());
				technicalAreaCoordinateDtl.setEastCoordinateO(titleDeedLocation.getF_LOCEASTSECTION().toString());
				technicalAreaCoordinateDtl.setNorthCoordinate(titleDeedLocation.getF_LOCNORTHDEGREE().toString());
				technicalAreaCoordinateDtl.setNorthCoordinateO(titleDeedLocation.getF_LOCNORTHSECTION().toString());
				technicalAreaCoordinateDtl.setReferenceNumber(getF_IN_referenceNumber());
				technicalAreaCoordinateDtl.setDefaultCoordinates(false);
				technicalAreaCoordinateDtl.setSelect(false);
				if (!firstRowTrue) {
					firstRowTrue = true;
					technicalAreaCoordinateDtl.setSelect(true);
				}
				technicalAreaCoordinateDtl.setSelect(false);
				technicalAreaCoordinateDtl.setSerail(titleDeedLocation.getF_SERIAL());
				technicalAreaCoordinateDtl.setTitleDeedId(titleDeedId);
				technicalAnalysis.getTechnicalAreaCoordinatesList()
						.addTechnicalAreaCoordinateDtlList(technicalAreaCoordinateDtl);

			}

			setF_OUT_technicalAreaCoordinateDtlList(technicalAnalysis.getTechnicalAreaCoordinatesList());
			setF_OUT_technicalAreaDtl(technicalAreaDtlNew);
		}
	}
}
