package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineConfigID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineConfig;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PricingEngineConfigurationSearch;
import com.ce.bankfusion.ib.util.PricingEngineConfUtil;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.Asset;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.InputFieldsDtls;
import bf.com.misys.ib.types.ListPricingEngineConfsRs;
import bf.com.misys.ib.types.OtherDtls;
import bf.com.misys.ib.types.OutputFieldsDtls;
import bf.com.misys.ib.types.PricingEngineConf;
import bf.com.misys.ib.types.PricingEngineConfSearch;
import bf.com.misys.ib.types.RateDetails;

public class PricingEngineSearch extends AbstractCE_IB_PricingEngineConfigurationSearch{
    private static final long serialVersionUID = 1L;
    
    public static final int E_ASS_CAT_OR_GCD_MANDATORY_IB = 44000413;

    public PricingEngineSearch() {
        super();
    }

    public PricingEngineSearch(BankFusionEnvironment env) {

    }

    public void process(BankFusionEnvironment env) throws BankFusionException {
        
        if(getF_IN_mode().equals("ASSET_CLEAR")) {
            String category = getF_IN_AssetCategory().getCategorization();
            if(!category.isEmpty()) {
                AsstCategory assetCategory = new AsstCategory();
                IBCommonUtils.intializeDefaultvalues(assetCategory);
                setF_OUT_AssetCategory(assetCategory );
                
                PricingEngineConfSearch searchCategory = new PricingEngineConfSearch();
                IBCommonUtils.intializeDefaultvalues(searchCategory);
                setF_OUT_searchCriteria(searchCategory );
            }
        }
        else {
    	PricingEngineConfSearch criteria = getF_IN_listPricingEngineConfsRq().getPricingEngineConfSearch();
    	ListPricingEngineConfsRs pricingEngineList = new ListPricingEngineConfsRs();
    	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    	List<IBOCE_IB_PricingEngineConfig> dbData ;
    	PagingRequest pageInfo = getF_IN_listPricingEngineConfsRq().getPagedQuery().getPagingRequest();
    	IPagingData pagingData = new PagingData(pageInfo.getRequestedPage()==0?1:pageInfo.getRequestedPage(), 
				pageInfo.getNumberOfRows()==0?10:pageInfo.getNumberOfRows());
        pagingData.setRequiresTotalPages(true);
        if(StringUtils.isBlank(criteria.getAssetCategoryID()) && (null == criteria.getGroupCD() || criteria.getGroupCD() < 0)
        		&&  (null == criteria.getToolNo() || criteria.getToolNo() <= 0))
        {
        	IBCommonUtils.raiseUnparameterizedEvent(E_ASS_CAT_OR_GCD_MANDATORY_IB);
        }
		if(StringUtils.isNotBlank(criteria.getAssetCategoryID()))
    	{
    		String whereClause = "WHERE " + IBOCE_IB_PricingEngineConfig.ASSETCATEGORYID + " = ?";
    		ArrayList params = new ArrayList<>();
    		params.add(criteria.getAssetCategoryID());
    		dbData = factory.findByQuery(IBOCE_IB_PricingEngineConfig.BONAME, whereClause, params, pagingData,
    				true);
    	}
    	else if(null != criteria.getGroupCD() && criteria.getGroupCD() >= 0 ||
    			null != criteria.getToolNo() && criteria.getToolNo() > 0 ||
    			null != criteria.getListser() && criteria.getListser() > 0 )
    	{
    	    StringBuffer whereClause = new StringBuffer(" WHERE");
    	    ArrayList query = new ArrayList<>();
    
    	    if(criteria.getGroupCD() >= 0) {
    	        whereClause.append(" " + IBOCE_IB_PricingEngineConfig.GRP_CDPK + " = ?");
    	        query.add(criteria.getGroupCD());
    	        if(criteria.getToolNo() > 0) {
    	            whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.TOOLNOPK + " = ?");
                  query.add(criteria.getToolNo());
    	        }
    	        if(criteria.getListser() > 0) {
    	            whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.LISTSERPK + " = ?");
                  query.add(criteria.getListser());
    	        }
    	        
    	        
    	   }
    	    if(criteria.getToolNo() > 0) {
    	        if(whereClause.length()>10) {
    	            whereClause.delete(6, whereClause.length());
    	            query.clear();
    	        }
    	            whereClause.append(" " + IBOCE_IB_PricingEngineConfig.TOOLNOPK + " = ?");
                  query.add(criteria.getToolNo());
    	        if(criteria.getGroupCD() >= 0) {
    	            whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.GRP_CDPK + " = ?");
                  query.add(criteria.getGroupCD()); 
    	        }
    	        if(criteria.getListser() > 0) {
    	            whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.LISTSERPK + " = ?");
                  query.add(criteria.getListser());
    	        }

          }
          if(criteria.getListser() > 0) {
              if(whereClause.length()>10) {
                  whereClause.delete(6, whereClause.length());
                  query.clear();
              }
                  whereClause.append(" " + IBOCE_IB_PricingEngineConfig.LISTSERPK + " = ?");
                  query.add(criteria.getListser());
              
                  if(criteria.getGroupCD() >= 0) {
                      whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.GRP_CDPK + " = ?");
                      query.add(criteria.getGroupCD()); 
                  }
                  if(criteria.getToolNo() > 0) {
                      whereClause.append(" AND " + IBOCE_IB_PricingEngineConfig.TOOLNOPK + " = ?");
                      query.add(criteria.getToolNo());
                  }
                  
          }
    		
    		dbData = factory.findByQuery(IBOCE_IB_PricingEngineConfig.BONAME, whereClause.toString(), query, pagingData ,
    				false);
    		
    	}
    	else
    	{
    		dbData = factory.findAll(IBOCE_IB_PricingEngineConfig.BONAME, pagingData, false);
    	}
    	if(null != dbData && dbData.size()>0) {
    		for(IBOCE_IB_PricingEngineConfig pricingEng : dbData) {

    			PricingEngineConf vPriEng = new PricingEngineConf();
    			IBCommonUtils.intializeDefaultvalues(vPriEng);
    			Asset assetObj = new Asset();
    			if(!pricingEng.getF_ASSETCATEGORYID().isEmpty()) {
      			assetObj.setId(pricingEng.getF_ASSETCATEGORYID());
      			String category = AssetCategoryUtil.getCategoryQualifiedName(pricingEng.getF_ASSETCATEGORYID(), factory, null);
      			category = category.replace(">", ">>");
      			category = (String) category.subSequence(0, category.lastIndexOf(">>"));
      			vPriEng.setAssetCategory(category);
      			vPriEng.setAssetCategoryID(pricingEng.getF_ASSETCATEGORYID());
    			}
    			CE_IB_PricingEngineConfigID configID = (CE_IB_PricingEngineConfigID) pricingEng.getCompositeBOID();
    			vPriEng.setGroupCD(configID.getF_GRP_CD());
    			vPriEng.setListser(configID.getF_LISTSER());
    			vPriEng.setToolNo(configID.getF_TOOLNO());

    			InputFieldsDtls inputFieldsDtls = new InputFieldsDtls();
    			IBCommonUtils.intializeDefaultvalues(inputFieldsDtls);
    			inputFieldsDtls.setAttr1ID(pricingEng.getF_LBL1_CD());
    			//inputFieldsDtls.setAttr1Label("attr1Label");
    			inputFieldsDtls.setAttr2ID(pricingEng.getF_LBL2_CD());
    			//inputFieldsDtls.setAttr2Label("attr2Label");
    			inputFieldsDtls.setAttr3ID(pricingEng.getF_LBL3_CD());
    			//inputFieldsDtls.setAttr3Label("attr3Label");
    			inputFieldsDtls.setAttr4ID(pricingEng.getF_LBL4_CD());
    			//inputFieldsDtls.setAttr4Label("attr4Label");
    			inputFieldsDtls.setAttr5ID(pricingEng.getF_LBL5_CD());
    			//inputFieldsDtls.setAttr5Label("attr5Label");
    			vPriEng.setInputFieldsDtls(inputFieldsDtls );

    			OutputFieldsDtls outputFieldsDtls = new OutputFieldsDtls();
    			IBCommonUtils.intializeDefaultvalues(outputFieldsDtls);
    			outputFieldsDtls.setAttr6ID(pricingEng.getF_RES1_CD());
    			//outputFieldsDtls.setAttr6Label("attr6Label");
    			outputFieldsDtls.setAttr7ID(pricingEng.getF_RES2_CD());
    			//outputFieldsDtls.setAttr7Label("attr7Label");
    			outputFieldsDtls.setAttr8ID(pricingEng.getF_RES3_CD());
    			//outputFieldsDtls.setAttr8Label("attr8Label");
    			outputFieldsDtls.setAttr9ID(pricingEng.getF_RES4_CD());
    			//outputFieldsDtls.setAttr9Label("attr9Label");
    			
    			if(null != pricingEng.getF_RES1_SHOW() && pricingEng.getF_RES1_SHOW()==1) {
    				outputFieldsDtls.setAttr6ShowInReport(true);
    			}else {
    				outputFieldsDtls.setAttr6ShowInReport(false);
    			}

    			if(null != pricingEng.getF_RES2_SHOW() && pricingEng.getF_RES2_SHOW()==1) {
    				outputFieldsDtls.setAttr7ShowInReport(true);
    			}else {
    				outputFieldsDtls.setAttr7ShowInReport(false);
    			}

    			if(null != pricingEng.getF_RES3_SHOW() && pricingEng.getF_RES3_SHOW()==1) {
    				outputFieldsDtls.setAttr9ShowInReport(true);
    			}else {
    				outputFieldsDtls.setAttr9ShowInReport(false);
    			}

    			if(null != pricingEng.getF_HLP_IND() && pricingEng.getF_HLP_IND()==1) {
    				outputFieldsDtls.setAttr9ShowInReport(true);
    			}else {
    				outputFieldsDtls.setAttr9ShowInReport(false);
    			}

    			vPriEng.setOutputFieldsDtls(outputFieldsDtls);
    			
    			PricingEngineConfUtil.populateAttrNamesAndVisibilty(vPriEng);

    			RateDetails rateDetails = new RateDetails();
    			IBCommonUtils.intializeDefaultvalues(rateDetails);
    			rateDetails.setRate1Desc(String.valueOf(pricingEng.getF_RAT1_LBL()));
    			rateDetails.setRate1Value(pricingEng.getF_RAT1());
    			rateDetails.setRate2Desc(String.valueOf(pricingEng.getF_RAT2_LBL()));
    			rateDetails.setRate2Value(pricingEng.getF_RAT2());
    			rateDetails.setRate3Desc(String.valueOf(pricingEng.getF_RAT3_LBL()));
    			rateDetails.setRate3Value(pricingEng.getF_RAT3());
    			rateDetails.setRate4Desc(String.valueOf(pricingEng.getF_RAT4_LBL()));
    			rateDetails.setRate4Value(pricingEng.getF_RAT4());
    			rateDetails.setRate5Desc(String.valueOf(pricingEng.getF_RAT5_LBL()));
    			rateDetails.setRate5Value(pricingEng.getF_RAT5());
    			rateDetails.setRate6Desc(String.valueOf(pricingEng.getF_RAT6_LBL()));
    			rateDetails.setRate6Value(pricingEng.getF_RAT6());

    			vPriEng.setRateDetails(rateDetails);

    			OtherDtls otherDtls = new OtherDtls();
    			IBCommonUtils.intializeDefaultvalues(otherDtls);
    			otherDtls.setCalcFormula1(pricingEng.getF_CALC_FORMULA1());
    			otherDtls.setCalcFormula2(pricingEng.getF_CALC_FORMULA2());
    			otherDtls.setCntInd(pricingEng.getF_CNT_IND());
    			otherDtls.setFormulaExpl(pricingEng.getF_CALC_FORMULA_EXPL());
    			if(null != pricingEng.getF_HLP_IND() && pricingEng.getF_HLP_IND()==1) {
    				otherDtls.setHlpInd(true);
    			}else {
    				otherDtls.setHlpInd(false);
    			}

    			if(null != pricingEng.getF_NO_RULE() && pricingEng.getF_NO_RULE()==1) {
    				otherDtls.setNoRule(true);
    			}else {
    				otherDtls.setNoRule(false);
    			}

    			if(null != pricingEng.getF_OUT_RATE_IND() && pricingEng.getF_OUT_RATE_IND()==1) {
    				otherDtls.setOutRateInd(true);
    			}else {
    				otherDtls.setOutRateInd(false);
    			}

    			if(null != pricingEng.getF_PRICE_CTRL() && pricingEng.getF_PRICE_CTRL()==1) {
    				otherDtls.setPriceCtrl(true);
    			}else {
    				otherDtls.setPriceCtrl(false);
    			}

    			if(null != pricingEng.getF_PRJ_IND() && pricingEng.getF_PRJ_IND()==1) {
    				otherDtls.setPrjInd(true);
    			}else {
    				otherDtls.setPrjInd(false);
    			}

    			if(null != pricingEng.getF_STOP_IND() && pricingEng.getF_STOP_IND()==1) {
    				otherDtls.setStopInd(true);
    			}else {
    				otherDtls.setStopInd(false);
    			}
    			otherDtls.setRank(pricingEng.getF_RANK());
    			otherDtls.setStopDateG(pricingEng.getF_STOP_DAT_G());
    			otherDtls.setStopDateH(pricingEng.getF_STOP_DAT());


    			vPriEng.setOtherDtls(otherDtls);
    			pricingEngineList.addPricingEngineConfList(vPriEng );
    		}
    	}else {
    		pricingEngineList.removeAllPricingEngineConfList();
    	}


    	PagingRequest pageInfoRes = new PagingRequest();
        pageInfoRes.setNumberOfRows(pagingData.getPageSize());
        pageInfoRes.setRequestedPage(pagingData.getCurrentPageNumber());
        pageInfoRes.setTotalPages(pagingData.getTotalPages());	
        PagedQuery pagedQuery = new PagedQuery();
        pagedQuery.setPagingRequest(pageInfoRes);
        pricingEngineList.setPagedQuery(pagedQuery);
        
    	setF_OUT_listPricingEngineConf(pricingEngineList);
    	setF_OUT_newVisibility(false);
    }
    }
}
