package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.HashMap;

import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CMN_DealStepDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.fatom.PopulateEmailParamsObject;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.EmailParams;
import bf.com.misys.ib.types.IslamicBankingObject;

public class PopulateEmailParamsObjectExtn extends PopulateEmailParamsObject {

	public EmailParams setEmailParamsObject(IslamicBankingObject islamicBankingObject) {
		EmailParams emailParams = super.setEmailParamsObject(islamicBankingObject);
		HashMap<String, String> map = new HashMap<>();

		// Deal Start Date
		IBOIB_DLI_DealDetails dealRec = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		String dealStartDate = dealRec.getF_DealStartDate().toString();
		map.put("DealStartDate", dealStartDate);
		
		BigDecimal dealAmount = dealRec.getF_DealAmt();
		dealAmount = IBCommonUtils.scaleAmount(dealRec.getF_IsoCurrencyCode(),dealAmount);
        map.put("DealAmount", dealAmount.toString());
        
        BigDecimal dealPrincipalAmount = dealRec.getF_PrincipleAmt();
        dealPrincipalAmount = IBCommonUtils.scaleAmount(dealRec.getF_IsoCurrencyCode(),dealPrincipalAmount);
        map.put("DealPrincipalAmount", dealPrincipalAmount.toString());
        
        map.put("UserName", islamicBankingObject.getUserID());
        IBOIB_CMN_DealStepDetails dealStepDetails = IBCommonUtils.getCurrentStepForProcess(islamicBankingObject.getTransactionID(),
                islamicBankingObject.getTransactionName(), islamicBankingObject.getStepID());
        String reversedStepName = IBCommonUtils.getMultiLangStepName(islamicBankingObject.getStepID(), islamicBankingObject.getProcessConfigID());
        map.put("ReversedStepName", reversedStepName);
        String reversedReason = IBConstants.DECISION_RETURNED.equalsIgnoreCase(dealStepDetails.getF_DEALSTATUS())?dealStepDetails.getF_REASONCODE():IBConstants.EMPTY_STRING;
        String reversedReasonDesc = IBCommonUtils.getGCChildDesc("REASONCODES", reversedReason); 
        map.put("ReversedReason", reversedReasonDesc);

		// Followup date
		String followUpDate = IBCommonUtils.getBFBusinessDate().toString();
		map.put("FollowUpDate", followUpDate);

		// Followup days
		String followUpDays = String.valueOf(DealFollowUpUtils.getFollowUpPeriodConfigured());
		map.put("FollowUpDays", followUpDays);

		emailParams.setUserExtension(map);
		return emailParams;
	}
}
