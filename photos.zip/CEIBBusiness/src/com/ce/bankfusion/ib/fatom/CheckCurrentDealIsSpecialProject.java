/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CheckCurrentDealIsSpecialProject;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * @author Aklesh
 */
public class CheckCurrentDealIsSpecialProject extends AbstractCE_IB_CheckCurrentDealIsSpecialProject {

    private static final long serialVersionUID = 7137308733675905581L;

    private static final Log LOGGER = LogFactory.getLog(CheckCurrentDealIsSpecialProject.class);

    public CheckCurrentDealIsSpecialProject(BankFusionEnvironment env) {
        super(env);

    }

    public CheckCurrentDealIsSpecialProject() {
        super();

    }

    @Override
    public void process(BankFusionEnvironment env) {
        List<String> specialLoanProcessesList = new ArrayList<>();
        setF_OUT_assetStudyCostReadOnly(true);
        boolean isSpecialproject = false;

        String specialLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_PROGRESS_RULES_CONF_FILE,
            CeConstants.SPECIAL_LOAN_SUBPRODUCTS, "", CeConstants.ADFIBCONFIGLOCATION);

        if (specialLoanProcesses != null && !specialLoanProcesses.isEmpty()) {
            specialLoanProcessesList =
                IBCommonUtils.isNotEmpty(specialLoanProcesses) ? Arrays.asList(specialLoanProcesses.split(",")) : new ArrayList<String>();
        }
        if (specialLoanProcessesList.contains(getF_IN_subProductID())) {
            isSpecialproject = true;

            if (!getF_IN_mode().equals("VIEW") && !isF_IN_isDealEnquiry()
                && getF_IN_editMode().equals(CeConstants.ASSET_AND_STUDY_ONLY_MODE)) {
                setF_OUT_assetStudyCostReadOnly(false);
            }
        }
        setF_OUT_isSpecialProject(isSpecialproject);
    }

}
