package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealRelationshipAgentsForAParty;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.DealRelationshipDetails;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipAgents;

public class GetDealRelationshipAgentsForAParty extends AbstractCE_IB_GetDealRelationshipAgentsForAParty {

    public GetDealRelationshipAgentsForAParty(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) throws BankFusionException {
        DealRelationshipDetails dealRelationshipDetails = getF_IN_dealRelationshipDetails();
        RelationshipAgents relationshipAgents[] = dealRelationshipDetails.getRelationshipAgents();
        getF_OUT_dealRelationshipDetails().removeAllRelationshipAgents();
        if(IBCommonUtils.isEmpty(getF_IN_relationshipDetailId()))
            return;
        for (RelationshipAgents vRelationshipAgents : relationshipAgents) {
            if (vRelationshipAgents.getRelationshipDtlId().equals(getF_IN_relationshipDetailId())) {
            	vRelationshipAgents.setSelect(false);
                getF_OUT_dealRelationshipDetails().addRelationshipAgents(vRelationshipAgents);
            }    
        }
        
        if(getF_OUT_dealRelationshipDetails() != null && getF_OUT_dealRelationshipDetails().getRelationshipAgentsCount() > 0) {
        	getF_OUT_dealRelationshipDetails().getRelationshipAgents(0).setSelect(true);
        }
    }

}
