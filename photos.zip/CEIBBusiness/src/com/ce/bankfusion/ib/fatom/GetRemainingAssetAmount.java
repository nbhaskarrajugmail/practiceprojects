package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetRemainingAssetAmount;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetThirdPartyDTL;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.PurchaseOrderDetails;

public class GetRemainingAssetAmount extends AbstractCE_IB_GetRemainingAssetAmount {

    private static final long serialVersionUID = 1L;

    private transient final static Log LOGGER = LogFactory.getLog(GetRemainingAssetAmount.class.getName());
    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    private static final String PO_PROCESSED_STATUS = "Processed";
	private static final Object PO_COMPLETED_STATUS = "Completed";
    @SuppressWarnings("deprecation")
    public GetRemainingAssetAmount(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) {
        if (getF_IN_editMode().equals(CeConstants.ASSET_REPLACEMENT_MODE) && IBCommonUtils.isNotEmpty(getF_IN_dealId())) {
            BigDecimal totalAssetCost = BigDecimal.ZERO;
            BigDecimal replacedAssetCost = BigDecimal.ZERO;
            BigDecimal tempTotalAmount = BigDecimal.ZERO;
            BFCurrencyAmount amountLeft = new BFCurrencyAmount();
           
            ArrayList<String> params = new ArrayList<String>();
            params.add(getF_IN_dealId());
            String whereClause= "where "+IBOIB_DLI_DealAssetThirdPartyDTL.DealNo+"=?";
            List<IBOIB_DLI_DealAssetThirdPartyDTL> dealAssetThirdParties =
                factory.findByQuery(IBOIB_DLI_DealAssetThirdPartyDTL.BONAME, whereClause, params, null, true);
			if (null != dealAssetThirdParties) {
				for (IBOIB_DLI_DealAssetThirdPartyDTL tp : dealAssetThirdParties)
					totalAssetCost = totalAssetCost.add(tp.getF_Amount());
			}
            AssetThirdPartyDetailsList assetTPList = getF_IN_assetThirdPartyDetailsList();
            AssetThirdPartyDetails[] assetTPDetailsList = assetTPList.getAssetThirdPartyDetails();
            String selectedAssetID = CommonConstants.EMPTY_STRING;
            for (AssetThirdPartyDetails assetTPDetail : assetTPDetailsList) {
            	if(assetTPDetail.isSelect())
            		selectedAssetID = assetTPDetail.getAssetSerial();
                tempTotalAmount =  tempTotalAmount.add(assetTPDetail.getDisplayCost().getCurrencyAmount());
                if (null !=assetTPDetail.getReplaced() && assetTPDetail.getReplaced()) {
                    replacedAssetCost = replacedAssetCost.add(assetTPDetail.getDisplayCost().getCurrencyAmount());
                    
                }
               // else  nonReplacedAssetCost = nonReplacedAssetCost.add(assetTPDetail.getDisplayCost().getCurrencyAmount());
            }
            BigDecimal totalDisbursedAmountForReplaced = calculateDisbursedAmount(assetTPList, selectedAssetID);
            
            //tempTotalAmount=tempTotalAmount.subtract(totalDisbursedAmountForReplaced);  
            tempTotalAmount=tempTotalAmount.subtract(replacedAssetCost.subtract(totalDisbursedAmountForReplaced));            
            tempTotalAmount=totalAssetCost.subtract(tempTotalAmount);           
            amountLeft.setCurrencyAmount(IBCommonUtils.scaleAmount("SAR", tempTotalAmount));
            amountLeft.setCurrencyCode("SAR");
            assetTPList.setAssetThirdPartyDetails(assetTPDetailsList);
            setF_OUT_amountLeft(amountLeft);
        }
    }
    
	private BigDecimal calculateDisbursedAmount(AssetThirdPartyDetailsList assetTPDetailsList, String assetID) {
		BigDecimal disburseAmount = BigDecimal.ZERO;
		BigDecimal assetDisbursedAmount = BigDecimal.ZERO;
		IssuePOFatom issuePOFatom = new IssuePOFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		issuePOFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		issuePOFatom.setF_IN_mode("RETRIEVE");
		issuePOFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		IssuePayOrderDtls issuePaymentOrders = issuePOFatom.getF_OUT_issuePayOrderDtls();
		PoAssetDisbursementDetails[] poAssetDisbursementDtls = issuePaymentOrders.getPoAssetDisbursementDetails();
			
		for (PurchaseOrderDetails purchaseOrderDetails : issuePaymentOrders.getPurchaseOrderDetails()) {
			if (purchaseOrderDetails.getPoStatus().equals(PO_COMPLETED_STATUS)
					|| purchaseOrderDetails.getPoStatus().equals(PO_PROCESSED_STATUS)) {
				for (PoAssetDisbursementDetails poAssetDisbursementDetails : poAssetDisbursementDtls) {
					if (purchaseOrderDetails.getPurchaseOrderID()
							.equals(poAssetDisbursementDetails.getPurchaseOrderID())) {
						for (AssetThirdPartyDetails assetThirdPartyDetails : assetTPDetailsList
								.getAssetThirdPartyDetails()) {
							if (assetThirdPartyDetails.getAssetSerial().equals(poAssetDisbursementDetails.getAssetID())
									&& assetThirdPartyDetails.isReplaced()) {

								disburseAmount = disburseAmount.add(
										poAssetDisbursementDetails.getCurrentDisbursedAmount().getCurrencyAmount());
							}
						}
					}
				}
				for (PoAssetDisbursementDetails poAssetDisbursementDetails : poAssetDisbursementDtls) {
					if (poAssetDisbursementDetails.getAssetID().equals(assetID) && purchaseOrderDetails
							.getPurchaseOrderID().equals(poAssetDisbursementDetails.getPurchaseOrderID())) {
						assetDisbursedAmount = assetDisbursedAmount
								.add(poAssetDisbursementDetails.getCurrentDisbursedAmount().getCurrencyAmount());
					}
				}
			}
		}
		BFCurrencyAmount assetDisbursedBFAmount = new BFCurrencyAmount();
		assetDisbursedBFAmount.setCurrencyAmount(assetDisbursedAmount);
		assetDisbursedBFAmount.setCurrencyCode("SAR");
		setF_OUT_assetDisbursedAmount(assetDisbursedBFAmount);
		
		return disburseAmount;
	}
}

