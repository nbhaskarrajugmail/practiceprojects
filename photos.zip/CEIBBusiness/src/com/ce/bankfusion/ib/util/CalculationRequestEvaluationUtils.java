package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.fatom.ReadIssuePayOrderDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCollateral;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.types.ModuleConfigDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.AgricultureDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ResidentialDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.PaymentSchedule;
import bf.com.misys.ib.spi.types.PaymentScheduleList;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;


public class CalculationRequestEvaluationUtils {
	
	private static IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	
	public static BFCurrencyAmount getCalculateTotalCoverValue(CollateralRequestDetails collateralReqDtls,CollateralRequestDetailsList collateralReqDtlsGrid,
			ResidentialDetails residentialReqDtls, TitleDeedDetailsList titleDeedListResidential,AgricultureDetails agricultureReqDtls,TitleDeedDetailsList titleDeedListAgriculture,
			WellDetails wellReqDtls,WellDetailsList wellList,TreeDetails treeReqDtls, TreesDetailsList treeList,
			BuildingDetails buildingReqDtls, BuildingsDetailsList buildingList,String titleDeedNum,IslamicBankingObject islamicBankingObject)
	{
		BFCurrencyAmount totalCoverValue = new BFCurrencyAmount();//Total cover value
        totalCoverValue.setCurrencyAmount(BigDecimal.ZERO);
        
        if(collateralReqDtlsGrid.getCollateralRequestDetailsListCount()>0) {
            CollateralRequestDetails[] collateral = collateralReqDtlsGrid.getCollateralRequestDetailsList();//Array of List
            for(CollateralRequestDetails collateralDtls : collateral) {
                if(collateralDtls.getStatus().equals("DELETED")){
                    continue;
                }
                if(collateralDtls.isSelect()) {
                    
                    if(collateralReqDtls.getRequestType().equals("Existing")) {
                    	totalCoverValue.setCurrencyAmount(totalCoverValue.getCurrencyAmount().
                        add(collateralReqDtls.getExistingRequestdtls().getUtilizeAmount().getCurrencyAmount()));
                    	
                    	totalCoverValue.setCurrencyCode(collateralReqDtls.getExistingRequestdtls().getUtilizeAmount().getCurrencyCode());
                    	
                    }else if(collateralReqDtls.getRequestType().equals("No-Evaluation")){
                    	totalCoverValue.setCurrencyAmount(totalCoverValue.getCurrencyAmount().
                        add(collateralReqDtls.getNoEvalRequestdtls().getCoverValue().getCurrencyAmount()));
                    	
                    	totalCoverValue.setCurrencyCode(collateralReqDtls.getNoEvalRequestdtls().getCoverValue().getCurrencyCode());
                    	
                    }else if(collateralReqDtls.getRequestType().equals("Personal")) {
                        totalCoverValue.setCurrencyAmount(totalCoverValue.getCurrencyAmount().
                        add(collateralReqDtls.getPersonalRequest().getCoverValue().getCurrencyAmount()));
                        
                        totalCoverValue.setCurrencyCode(collateralReqDtls.getPersonalRequest().getCoverValue().getCurrencyCode());
                        
                    }else if(collateralReqDtls.getRequestType().equals("Non-Personal")) {
                    		if(collateralReqDtls.getCategoryType().equalsIgnoreCase("Agricultural"))
                    		{
                    			for(TitleDeedDetails titleDeed :titleDeedListAgriculture.getTitleDeedDetailsList()) 
                    			{
                        			if(titleDeed.getAgricultureDetails().getStatus().equals("Selected"))
                        			{		
                        				totalCoverValue.setCurrencyAmount(totalCoverValue.getCurrencyAmount().
                    					add(titleDeed.getAgricultureDetails().getNetCoverValue().getCurrencyAmount()));
                        			}
                        		}
                    		}
                    		if((collateralReqDtls.getCategoryType().equalsIgnoreCase("Residential")) || 
                    				(collateralReqDtls.getCategoryType().equalsIgnoreCase("Commercial")))
                    			
                    		{
                    			for(TitleDeedDetails titleDeed :titleDeedListResidential.getTitleDeedDetailsList())
                    			{
                    				if(titleDeed.getResidentialDetails().getStatus().equals("Selected"))
                    				{	totalCoverValue.setCurrencyAmount(totalCoverValue.getCurrencyAmount().
                    					add(titleDeed.getResidentialDetails().getNetEvaluationValue().getCurrencyAmount()));
                    			
                    				}
                    			}
                    		}
                        
                    }
                    
                    
                }
                else
                {
                	totalCoverValue.setCurrencyAmount
                	(totalCoverValue.getCurrencyAmount().
                	add(collateralDtls.getCoverValue().getCurrencyAmount()));
                	
                	totalCoverValue.setCurrencyCode(collateralDtls.getCoverValue().getCurrencyCode());
                }
                
               
            }
        }
        

		return totalCoverValue;
		
	}
	
	
	public static BFCurrencyAmount getAvailableBalancePersonal(CollateralRequestDetails collateralReqDtls)
	{
		BFCurrencyAmount availableBalancePersonal = collateralReqDtls.getPersonalRequest().getAvailableBalance();//Total cover value
		availableBalancePersonal.setCurrencyAmount
		(availableBalancePersonal.getCurrencyAmount().
		subtract(collateralReqDtls.getPersonalRequest().getCoverValue().getCurrencyAmount()));
    	
		availableBalancePersonal.setCurrencyCode(collateralReqDtls.getPersonalRequest().getAvailableBalance().getCurrencyCode());
		return availableBalancePersonal;
		
	}

	public static BFCurrencyAmount getTotalEvaluationValueResidential(ResidentialDetails residentialReqDtls, TitleDeedDetailsList titleDeedList)
	{
		BFCurrencyAmount totalEvaluationValueResidential = new BFCurrencyAmount();//Total cover value
		totalEvaluationValueResidential.setCurrencyAmount(BigDecimal.ZERO);
        
		if(titleDeedList.getTitleDeedDetailsListCount()>0) {
            TitleDeedDetails[] titleDeed = titleDeedList.getTitleDeedDetailsList();//Array of List
            for(TitleDeedDetails titleDeedDtls : titleDeed) {
                if(titleDeedDtls.isSelect()) {
                	totalEvaluationValueResidential.setCurrencyAmount(totalEvaluationValueResidential.getCurrencyAmount().
                	add(residentialReqDtls.getLandArea().multiply(residentialReqDtls.getPricePerSqM().getCurrencyAmount())).
                	add(residentialReqDtls.getBuiltArea().multiply(residentialReqDtls.getPricePerBuildSqM().getCurrencyAmount())).
                	add(residentialReqDtls.getUtilityAreaSize().multiply(residentialReqDtls.getUtilityPrice().getCurrencyAmount())).
                	add(residentialReqDtls.getCompoundWallHeight().multiply(residentialReqDtls.getWallPrice().getCurrencyAmount())).
                	add(residentialReqDtls.getShadowSize().multiply(residentialReqDtls.getShadowPrice().getCurrencyAmount())));
                	
                	totalEvaluationValueResidential.setCurrencyCode(residentialReqDtls.getTotalEvaluationValue().getCurrencyCode());
                	
                }
             }
           
		}
		return totalEvaluationValueResidential;
		
		
	}
		//CurrencyCode
	public static BFCurrencyAmount getNetEvaluationValueResidential(CollateralRequestDetails collateraldtls,ResidentialDetails residentialReqDtls, TitleDeedDetailsList titleDeedListResidential,
			String titleDeedNum,IslamicBankingObject islamicBankingObject)
	{
		
		ModuleConfigDetails moduleConfigDetails = null;
		BFCurrencyAmount netEvaluationValueResidential = new BFCurrencyAmount();
		netEvaluationValueResidential.setCurrencyAmount(BigDecimal.ZERO);
		if(collateraldtls.getCategoryType().equals("Residential"))
		{
		if(residentialReqDtls.isIsPrevMortgageAmt())
		{
			 moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO2RESIDENTIAL");
		     String residentialHaircutRatio2 = moduleConfigDetails.getValue();
		     BigDecimal haircutValue = new BigDecimal(residentialHaircutRatio2).divide(new BigDecimal(100));
			 netEvaluationValueResidential.setCurrencyAmount
		     (getTotalEvaluationValueResidential( residentialReqDtls,  titleDeedListResidential).getCurrencyAmount().
		     subtract(residentialReqDtls.getMortgageAmt().getCurrencyAmount()).
		     multiply(haircutValue));
		 
		}
		else
		{
			moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO1RESIDENTIAL");
		    String residentialHaircutRatio1 = moduleConfigDetails.getValue();
		    BigDecimal haircutValue = new BigDecimal(residentialHaircutRatio1).divide(new BigDecimal(100));
		    netEvaluationValueResidential.setCurrencyAmount
		    (getTotalEvaluationValueResidential( residentialReqDtls,  titleDeedListResidential).getCurrencyAmount().
		    multiply(haircutValue));
		     
		}
		}
		else
		{
			if(residentialReqDtls.isIsPrevMortgageAmt())
			{
				 moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO2COMMERCIAL");
			     String residentialHaircutRatio2 = moduleConfigDetails.getValue();
			     BigDecimal haircutValue = new BigDecimal(residentialHaircutRatio2).divide(new BigDecimal(100));
				 netEvaluationValueResidential.setCurrencyAmount
			     (getTotalEvaluationValueResidential( residentialReqDtls,  titleDeedListResidential).getCurrencyAmount().
			     subtract(residentialReqDtls.getMortgageAmt().getCurrencyAmount()).
			     multiply(haircutValue));
			 
			}
			else
			{
				moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO1COMMERCIAL");
			    String residentialHaircutRatio1 = moduleConfigDetails.getValue();
			    BigDecimal haircutValue = new BigDecimal(residentialHaircutRatio1).divide(new BigDecimal(100));
			    netEvaluationValueResidential.setCurrencyAmount
			    (getTotalEvaluationValueResidential( residentialReqDtls,  titleDeedListResidential).getCurrencyAmount().
			    multiply(haircutValue));
			     
			}
		}
		
		if(netEvaluationValueResidential.getCurrencyAmount().compareTo(BigDecimal.ZERO)<0)
		{
			netEvaluationValueResidential.setCurrencyAmount(BigDecimal.ZERO);
		}
		
		netEvaluationValueResidential.setCurrencyCode(residentialReqDtls.getNetEvaluationValue().getCurrencyCode());
	     
		return netEvaluationValueResidential;
		
	}
	
	public static BFCurrencyAmount getCostOfLandAgriculture(AgricultureDetails agricultureReqDtls, TitleDeedDetailsList titleDeedList)
	{
		BFCurrencyAmount costOfLandAgriculture = new BFCurrencyAmount();//Total cover value
		costOfLandAgriculture.setCurrencyAmount(BigDecimal.ZERO);
        
		if(titleDeedList.getTitleDeedDetailsListCount()>0) {
            TitleDeedDetails[] titleDeed = titleDeedList.getTitleDeedDetailsList();//Array of List
            for(TitleDeedDetails titleDeedDtls : titleDeed) {
                if(titleDeedDtls.isSelect()) {
                	costOfLandAgriculture.setCurrencyAmount(costOfLandAgriculture.getCurrencyAmount().
                	add(agricultureReqDtls.getFarmSizeInDunum().
                	multiply(agricultureReqDtls.getDunumPrice().getCurrencyAmount())));
                	
                	costOfLandAgriculture.setCurrencyCode(agricultureReqDtls.getDunumPrice().getCurrencyCode());
                	
                	
                }
                
        }
		
		}
		return costOfLandAgriculture;
	}
	
	public static BFCurrencyAmount getCostOfWellsAgriculture(WellDetails wellReqDtls, WellDetailsList wellList)
	{
		BFCurrencyAmount costOfWellAgriculture = new BFCurrencyAmount();//Total cover value
		costOfWellAgriculture.setCurrencyAmount(BigDecimal.ZERO);
        
		if(wellList.getWellDetailsListCount()>0) {
            WellDetails[] well = wellList.getWellDetailsList();//Array of List
            for(WellDetails wellDtls : well) {
                if(wellDtls.isSelect()) {
                	costOfWellAgriculture.setCurrencyAmount(costOfWellAgriculture.getCurrencyAmount().
                	add(wellReqDtls.getPrice().getCurrencyAmount()));
                	
                	costOfWellAgriculture.setCurrencyCode(wellReqDtls.getPrice().getCurrencyCode());
                	
                }
                else
                {
                	costOfWellAgriculture.setCurrencyAmount(costOfWellAgriculture.getCurrencyAmount().
                	add(wellDtls.getPrice().getCurrencyAmount()));
                	
                	costOfWellAgriculture.setCurrencyCode(wellDtls.getPrice().getCurrencyCode());
                }
        }
		
		}
		
		return costOfWellAgriculture;
		
	}
	
	public static BFCurrencyAmount getCostOfTreesAgriculture(TreeDetails treeReqDtls, TreesDetailsList treeList)
	{
		BFCurrencyAmount costOfTreeAgriculture = new BFCurrencyAmount();//Total cover value
		costOfTreeAgriculture.setCurrencyAmount(BigDecimal.ZERO);
        
		if(treeList.getTreesDetailsListCount()>0) {
            TreeDetails[] tree = treeList.getTreesDetailsList();//Array of List
            for(TreeDetails treeDtls : tree) {
                if(treeDtls.isSelect()) {
                	
                	BigDecimal trees = new BigDecimal(treeReqDtls.getNoOfTrees());
                	
                	costOfTreeAgriculture.setCurrencyAmount(costOfTreeAgriculture.getCurrencyAmount().
                	add((trees.multiply(treeReqDtls.getPricePerTree().getCurrencyAmount()))));
                	
                	costOfTreeAgriculture.setCurrencyCode(treeReqDtls.getCost().getCurrencyCode());
                	
                }
                else
                {
                	costOfTreeAgriculture.setCurrencyAmount(costOfTreeAgriculture.getCurrencyAmount().
                	add(treeDtls.getCost().getCurrencyAmount()));
                	
                	costOfTreeAgriculture.setCurrencyCode(treeDtls.getCost().getCurrencyCode());
                }
        }
		
		}
		
		return costOfTreeAgriculture;
		
	}
	
	public static BFCurrencyAmount getCostPerTreesAgriculture(TreeDetails treeReqDtls)
	{
		BFCurrencyAmount costPerTreesAgriculture = new BFCurrencyAmount();//Total cover value
		costPerTreesAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		
		BigDecimal trees = new BigDecimal(treeReqDtls.getNoOfTrees());
    	
		costPerTreesAgriculture.setCurrencyAmount(trees.multiply(treeReqDtls.getPricePerTree().getCurrencyAmount()));
        
		return costPerTreesAgriculture;
		
	}
	
	
	
	public static BFCurrencyAmount getCostOfBuildingAgriculture(BuildingDetails buildingReqDtls, BuildingsDetailsList buildingList)
	{
		BFCurrencyAmount costOfBuildingAgriculture = new BFCurrencyAmount();//Total cover value
		costOfBuildingAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		
        
		if(buildingList.getBuildingsDetailsListCount()>0) {
            BuildingDetails[] building = buildingList.getBuildingsDetailsList();//Array of List
            for(BuildingDetails buildingDtls : building) {
                if(buildingDtls.isSelect()) {
                	costOfBuildingAgriculture.setCurrencyAmount(costOfBuildingAgriculture.getCurrencyAmount().
                	add(buildingReqDtls.getBuildingsize().multiply(buildingReqDtls.getPricePerSqM().getCurrencyAmount())));
                	
                	costOfBuildingAgriculture.setCurrencyCode(buildingReqDtls.getCost().getCurrencyCode());
                	
                }
                else
                {
                	costOfBuildingAgriculture.setCurrencyAmount(costOfBuildingAgriculture.getCurrencyAmount().
                	add(buildingDtls.getCost().getCurrencyAmount()));
                	
                	costOfBuildingAgriculture.setCurrencyCode(buildingDtls.getCost().getCurrencyCode());
                }
        }
		
		}
		return costOfBuildingAgriculture;
		
	}
	
	public static BFCurrencyAmount getCostPerBuildingAgriculture(BuildingDetails buildingReqDtls)
	{
		BFCurrencyAmount costPerBuildingAgriculture = new BFCurrencyAmount();//Total cover value
		costPerBuildingAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		
		costPerBuildingAgriculture.setCurrencyAmount
		(buildingReqDtls.getBuildingsize().multiply(buildingReqDtls.getPricePerSqM().getCurrencyAmount()));
		
		return costPerBuildingAgriculture;
		
	}
	
	
	//CurrencyCode
	public static BFCurrencyAmount getTotalEvaluationValueOfAgriculture(AgricultureDetails agricultureReqDtls,TitleDeedDetailsList titleDeedListAgriculture,
			WellDetails wellReqDtls,WellDetailsList wellList,TreeDetails treeReqDtls, TreesDetailsList treeList,
			BuildingDetails buildingReqDtls, BuildingsDetailsList buildingList)
	{
      BFCurrencyAmount totalEvaluationValueOfAgriculture = new BFCurrencyAmount();
      totalEvaluationValueOfAgriculture.setCurrencyAmount(BigDecimal.ZERO);
      BigDecimal totalTreeValue = BigDecimal.ZERO;
      BigDecimal totalBuildingValue = BigDecimal.ZERO;
      BigDecimal totalWellValue = BigDecimal.ZERO;
      for (TreeDetails treeReqDtls1 : treeList.getTreesDetailsList()) {
          totalTreeValue = totalTreeValue.add(treeReqDtls1.getCost().getCurrencyAmount());
      }
      for (BuildingDetails buildingReqDtls1 : buildingList.getBuildingsDetailsList()) {
          totalBuildingValue = totalBuildingValue.add(buildingReqDtls1.getCost().getCurrencyAmount());
      }
      for (WellDetails wellDtls1 : wellList.getWellDetailsList()) {
          totalWellValue = totalWellValue.add(wellDtls1.getPrice().getCurrencyAmount());
      }



      totalEvaluationValueOfAgriculture.setCurrencyAmount(totalEvaluationValueOfAgriculture.getCurrencyAmount()
              .add(getCostOfLandAgriculture(agricultureReqDtls, titleDeedListAgriculture).getCurrencyAmount())
              .add(totalTreeValue)
              .add(totalBuildingValue)
              .add(totalWellValue));

      totalEvaluationValueOfAgriculture.setCurrencyCode(agricultureReqDtls.getTotalCoverValue().getCurrencyCode());



      return totalEvaluationValueOfAgriculture;
		
	}
	
	//CurrencyCode
	public static BFCurrencyAmount getNetEvaluationValueOfAgriculture(AgricultureDetails agricultureReqDtls,TitleDeedDetailsList titleDeedListAgriculture,
			WellDetails wellReqDtls,WellDetailsList wellList,TreeDetails treeReqDtls, TreesDetailsList treeList,
			BuildingDetails buildingReqDtls, BuildingsDetailsList buildingList,String titleDeedNum,IslamicBankingObject islamicBankingObject)
	{
		
		BFCurrencyAmount netEvaluationValueOfAgriculture = new BFCurrencyAmount();
		netEvaluationValueOfAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		ModuleConfigDetails moduleConfigDetails = null; 
		
	      
		if(agricultureReqDtls.isIsPrevMortgageAmt())
		{	
			 moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO2AGRICULTURE");
		     String agricultureHairCutRatio2 = moduleConfigDetails.getValue();
		     BigDecimal haircutValue = new BigDecimal(agricultureHairCutRatio2).divide(new BigDecimal(100));
			 netEvaluationValueOfAgriculture.setCurrencyAmount
		     (getTotalEvaluationValueOfAgriculture( agricultureReqDtls, titleDeedListAgriculture,wellReqDtls, wellList, treeReqDtls,  treeList,
		     buildingReqDtls,  buildingList).getCurrencyAmount().
		     subtract(agricultureReqDtls.getMortgageAmt().getCurrencyAmount()).
		     multiply(haircutValue));
		}
		else {
			 moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue("HAIRCUTRATIO1AGRICULTURE");
		     String agricultureHairCutRatio1 = moduleConfigDetails.getValue();
		     BigDecimal haircutValue = new BigDecimal(agricultureHairCutRatio1).divide(new BigDecimal(100));
			 netEvaluationValueOfAgriculture.setCurrencyAmount
		     (getTotalEvaluationValueOfAgriculture( agricultureReqDtls, titleDeedListAgriculture,wellReqDtls, wellList, treeReqDtls,  treeList,
		     buildingReqDtls,  buildingList).getCurrencyAmount().
		     multiply(haircutValue));
			
			
		}
		
		if(netEvaluationValueOfAgriculture.getCurrencyAmount().compareTo(BigDecimal.ZERO)<0)
		{
			netEvaluationValueOfAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		}
		
		
		netEvaluationValueOfAgriculture.setCurrencyCode(agricultureReqDtls.getNetCoverValue().getCurrencyCode());
		
		return netEvaluationValueOfAgriculture;
		
	}
	
	//CurrencyCode
	public static BFCurrencyAmount getMortgageAmtForResidential(String titleDeedNum ,IslamicBankingObject islamicBankingObject)
	{
		  String whereClauseForDealCollateralDtls = " WHERE " + IBOCE_IB_DealCollateralDtls.IBTITLEDEEDNUM + " = ?" + " AND "
				  											  + IBOCE_IB_DealCollateralDtls.IBSYSTEMSTATUS + " = ?";  
		  String whereClauseForDealCollateral = " WHERE " + IBOIB_IDI_DealCollateral.COLLATERALID + " = ?";       //Give Collateral ID
		  String whereClauseForDealDtls = " WHERE " + IBOIB_DLI_DealDetails.DealNo + " = ?";
		  
		  ReadLoanDetailsRs readLoanDetailsRs = null;
		  
		  BFCurrencyAmount mortgageAmountForResidential = new BFCurrencyAmount();
		  mortgageAmountForResidential.setCurrencyAmount(BigDecimal.ZERO);
		  
	  	  ArrayList<String> paramForDealCollateralDtls = new ArrayList<String>();
	  	  paramForDealCollateralDtls.add(titleDeedNum);//Pass TitleDeedId
	  	  paramForDealCollateralDtls.add(CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED);
	      List<IBOCE_IB_DealCollateralDtls> dealCollateralTitleId = factory.findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClauseForDealCollateralDtls, paramForDealCollateralDtls, null, true);
	      
	      for(IBOCE_IB_DealCollateralDtls forDealCollateralTitleIdDtls : dealCollateralTitleId)
	      {
	    	  ArrayList<String> paramsForDealCollateral = new ArrayList<String>();
	    	  paramsForDealCollateral.add(forDealCollateralTitleIdDtls.getBoID());//CollateralID
	    	  List<IBOIB_IDI_DealCollateral> dealCollateralId = factory.findByQuery(IBOIB_IDI_DealCollateral.BONAME, whereClauseForDealCollateral, paramsForDealCollateral, null, true);
	    	  
	    	  for(IBOIB_IDI_DealCollateral forDealCollateralIdDtls : dealCollateralId)
	    	  {
	        	  //if(getOutstandingAmt(forDealCollateralIdDtls.getF_DEALNO(),islamicBankingObject).compareTo(BigDecimal.ZERO)>0)
	        		  ArrayList<String> paramForDealDtls = new ArrayList<String>();
	        		  paramForDealDtls.add(forDealCollateralIdDtls.getF_DEALNO());//Pass TitleDeedId
	        		  List<IBOIB_DLI_DealDetails> dealDtlsList = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, whereClauseForDealDtls, paramForDealDtls, null, true);
	        		  for(IBOIB_DLI_DealDetails dealDtlsEach : dealDtlsList)  
		        		{
		        			if(!dealDtlsEach.getF_DealAccountId().isEmpty())
		        		  {
		        		  		readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealDtlsEach.getBoID());
		        		  		LoanPayments[] loanPayments = readLoanDetailsRs.getDealDetails().getPaymentSchedule();
		        		  		BigDecimal paidPrincipal = BigDecimal.ZERO;
		        		  		for(LoanPayments loanPaymentsDtls:loanPayments)
		        		  		{
		        		  			paidPrincipal = paidPrincipal.add(loanPaymentsDtls.getPrincipalAmtPaid());
		        		  			   
		        		  		}
		        		  		mortgageAmountForResidential.setCurrencyAmount(mortgageAmountForResidential.getCurrencyAmount().
		        		  				add(forDealCollateralIdDtls.getF_AMOUNT().
		        		  						subtract(paidPrincipal)));
		        		  }
		        		}
	    	  }
	      }
	      	
	      if(mortgageAmountForResidential.getCurrencyAmount().compareTo(BigDecimal.ZERO)<0)
	      	{
	      		mortgageAmountForResidential.setCurrencyAmount(BigDecimal.ZERO);
	      	}
	      
	   return mortgageAmountForResidential;
		
	}
	
	
	//CurrencyCode
	public static BFCurrencyAmount getMortgageAmtForAgriculture(String titleDeedNum ,IslamicBankingObject islamicBankingObject)
	{
		  String whereClauseForDealCollateralDtls = " WHERE " + IBOCE_IB_DealCollateralDtls.IBTITLEDEEDNUM + " = ?" + " AND " 
				  											  + IBOCE_IB_DealCollateralDtls.IBSYSTEMSTATUS + " = ?" ;  
		  String whereClauseForDealCollateral = " WHERE " + IBOIB_IDI_DealCollateral.COLLATERALID + " = ?";       //Give Collateral ID
		  String whereClauseForDealDtls = " WHERE " + IBOIB_DLI_DealDetails.DealNo + " = ?";
		  
		  ReadLoanDetailsRs readLoanDetailsRs = null;
		  
		  BFCurrencyAmount mortgageAmountForAgriculture = new BFCurrencyAmount();
		  mortgageAmountForAgriculture.setCurrencyAmount(BigDecimal.ZERO);
		  
	  	  ArrayList<String> paramForDealCollateralDtls = new ArrayList<String>();
	  	  paramForDealCollateralDtls.add(titleDeedNum);//Pass TitleDeedId
	  	  paramForDealCollateralDtls.add(CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED);
	      List<IBOCE_IB_DealCollateralDtls> dealCollateralTitleId = factory.findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, whereClauseForDealCollateralDtls, paramForDealCollateralDtls, null, true);
	      
	      for(IBOCE_IB_DealCollateralDtls forDealCollateralTitleIdDtls : dealCollateralTitleId)
	      {
	    	  ArrayList<String> paramsForDealCollateral = new ArrayList<String>();
	    	  paramsForDealCollateral.add(forDealCollateralTitleIdDtls.getBoID());//Pass CollateralID(IDPK)
	    	  List<IBOIB_IDI_DealCollateral> dealCollateralId = factory.findByQuery(IBOIB_IDI_DealCollateral.BONAME, whereClauseForDealCollateral, paramsForDealCollateral, null, true);
	    	  
	    	  for(IBOIB_IDI_DealCollateral forDealCollateralIdDtls : dealCollateralId)
	    	  {
	        	  //if(getOutstandingAmt(forDealCollateralIdDtls.getF_DEALNO(),islamicBankingObject).compareTo(BigDecimal.ZERO)>0)
	        	   ArrayList<String> paramForDealDtls = new ArrayList<String>();
	        	   paramForDealDtls.add(forDealCollateralIdDtls.getF_DEALNO());//Pass TitleDeedId
	        	   List<IBOIB_DLI_DealDetails> dealDtlsList = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, whereClauseForDealDtls, paramForDealDtls, null, true);
	        	   for(IBOIB_DLI_DealDetails dealDtlsEach : dealDtlsList)  
		        	{
		        			if(!dealDtlsEach.getF_DealAccountId().isEmpty())
		        		  {
		        		  		readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealDtlsEach.getBoID());
		        		  		LoanPayments[] loanPayments = readLoanDetailsRs.getDealDetails().getPaymentSchedule();
		        		  		BigDecimal paidPrincipal = BigDecimal.ZERO;
		        		  		for(LoanPayments loanPaymentsDtls:loanPayments)
		        		  		{
		        		  			paidPrincipal = paidPrincipal.add(loanPaymentsDtls.getPrincipalAmtPaid());
		        		  			   
		        		  		}
		        		  		mortgageAmountForAgriculture.setCurrencyAmount(mortgageAmountForAgriculture.getCurrencyAmount().
		        		  				add(forDealCollateralIdDtls.getF_AMOUNT().
		        		  						subtract(paidPrincipal)));
		        		  }
		        	}
	        		  
	    	  }
	      }
	      if(mortgageAmountForAgriculture.getCurrencyAmount().compareTo(BigDecimal.ZERO)<0)
	      	{
	    	  mortgageAmountForAgriculture.setCurrencyAmount(BigDecimal.ZERO);
	      	}

	   return mortgageAmountForAgriculture;
		
	}
	
	public static BigDecimal getOutstandingAmt(String dealId,IslamicBankingObject islamicBankingObject) {

		BigDecimal outstandingAmt = BigDecimal.ZERO;
		ReadLoanDetailsRs readLoanRs = null;
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			PaymentScheduleList paymentScheduleList = new PaymentScheduleList();
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| IBCommonUtils.getBFBusinessDate().equals(row.getRepaymentDate())) {
						PaymentSchedule paymentSchedule = new PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						outstandingAmt = outstandingAmt.add(paymentSchedule.getRepaymentAmt());

					}
				}
			}

			// outstandingAmt =
			// readLoanRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount();

			for (LoanPayments paymentSch : readLoanRs.getDealDetails().getPaymentSchedule()) {
				if (paymentSch.getRepaymentDate().equals(IBCommonUtils.getBFBusinessDate())
						&& paymentSch.getRepaymentAmtUnPaid().compareTo(BigDecimal.ZERO) > 0) {
					EarlyAssetPayoffUtils assetPayoffUtils = new EarlyAssetPayoffUtils();
					List<IBOCE_IB_EarlyAssetPayoffDtls> earlyAssetDtls = assetPayoffUtils
							.getReschReqExistingObjStatusCompleted(dealId);
					if (null != earlyAssetDtls && earlyAssetDtls.size() > 0) {
						Timestamp earlyAssetDate = earlyAssetDtls.get(0).getF_IBRECLASTMODIFIEDDATE();
						if (earlyAssetDate.equals(IBCommonUtils.getBFBusinessDateTime())) {
							outstandingAmt = outstandingAmt.add(paymentSch.getRepaymentAmtUnPaid());
						}
					}
				}
				{

				}
			}
		}
		return IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), outstandingAmt);
	}

	
	

}
