package com.ce.bankfusion.ib.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_Validations;
import com.misys.bankfusion.common.BankFusionMessages;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.ib.constants.AdditionalFieldConstants;
import com.misys.bankfusion.ib.util.StepSetupUtils;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.ProcessManagementUtils;
import com.misys.ib.systeminformation.IIslamicBankingInformation;
import com.misys.ib.systeminformation.IIslamicBankingInformationService;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;
import com.trapedza.bankfusion.servercommon.services.cache.ICacheService;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.bankfusion.workflow.attributes.AllWorkflowTasksMetadata;
import bf.com.misys.bankfusion.workflow.attributes.TaskLinkCustomProperties;
import bf.com.misys.cbs.services.ListGenericCodeRq;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.InputListHostGCRq;
import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.cbs.types.header.MessageStatus;
import bf.com.misys.cbs.types.header.RsHeader;
import bf.com.misys.cbs.types.header.SubCode;
import bf.com.misys.ib.types.ManageProcessManagementsList;
import bf.com.misys.ib.types.ProcessManagement;
import bf.com.misys.ib.types.Validation;
import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationConfList;

public class ValidationsUtil {
	
	private static final Log LOGGER = LogFactory.getLog(ValidationsUtil.class);
	
	public static Map<String, Validation> getValidationList()
	{
		//TODO - try loading it on server startup
		ICacheService cache = (ICacheService) ServiceManager.getService(ServiceManager.CACHE_SERVICE);
		String cacheKey = ValidationExceptionConstants.VALIDATION_CACHE_KEY+BankFusionThreadLocal.getUserLocale().toString();
		Map<String, Validation> validationsMap = (Map) cache.cacheGet(cacheKey, ValidationExceptionConstants.VALIDATION_CACHE_TYPE);
		if(null == validationsMap || validationsMap.isEmpty())
		{
			validationsMap = new ConcurrentHashMap<>(); 
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			List<IBOCE_IB_Validations> validationList = factory.findAll(IBOCE_IB_Validations.BONAME, null);
			if(null != validationList && !validationList.isEmpty())
			{
				for(IBOCE_IB_Validations eachValidation : validationList)
				{
					Validation vValidations = new Validation();
					vValidations.setValidationID(eachValidation.getBoID());
					//name and description will be same
					String validationDesc = BankFusionMessages.getFormattedMessage(BankFusionMessages.MESSAGE_LEVEL, eachValidation.getF_IBVALIDATIONEVTNUM(), 
							BankFusionThreadLocal.getBankFusionEnvironment(), new Object[] {});
					vValidations.setName(validationDesc);
					vValidations.setDescription(validationDesc);
					vValidations.setImplClass(eachValidation.getF_IBIMPLCLASS());
					try
					{
						Class.forName(eachValidation.getF_IBIMPLCLASS());
					}
					catch(Exception e)
					{
						LOGGER.error("Error occurred while loading the validation impl class : "+e.toString(),e);
						IBCommonUtils.raiseParametrizedEvent(ValidationExceptionConstants.E_VALIDATION_LOADING_FAILED,
								new String[] {eachValidation.getBoID()});
					}
					validationsMap.put(eachValidation.getBoID(), vValidations);
				}
			}
			cache.cachePut(cacheKey, ValidationExceptionConstants.VALIDATION_CACHE_TYPE,validationsMap);
		}
		return validationsMap;
	}
	
	public static Validation getValidation(String validationID)
	{
		Map<String, Validation> validations = getValidationList();
		Validation validation = validations.get(validationID);
		return validation;
	}
	
	public static ListGenericCodeRs getProcessList()
	{
		ListGenericCodeRs genericCodeRs = new ListGenericCodeRs();
		ManageProcessManagementsList processList = ProcessManagementUtils.listProcesses();
		for(ProcessManagement process : processList.getProcessManagement())
		{
			GcCodeDetail vGcCodeDetails = new GcCodeDetail();
			vGcCodeDetails.setCodeReference(process.getProcessConfigID());
			vGcCodeDetails.setCodeDescription(process.getProcessName());
			genericCodeRs.addGcCodeDetails(vGcCodeDetails);
		}
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(20);
		pagingRequest.setRequestedPage(1);
		pagingRequest.setTotalPages(1);
		pagedQuery.setPagingRequest(pagingRequest );
		genericCodeRs.setPagedQuery(pagedQuery );
		RsHeader rsHeader = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setCodes(new SubCode[] {});
		rsHeader.setStatus(status );
		genericCodeRs.setRsHeader(rsHeader );
		return genericCodeRs;
	}
	
	public static ListGenericCodeRs getStepList(String processConfigID)
	{
		ListGenericCodeRs genericCodeRs = new ListGenericCodeRs();
		IIslamicBankingInformation islamicBankingInformation = ((IIslamicBankingInformationService) ServiceManagerFactory.getInstance()
				.getServiceManager().getServiceForName(IIslamicBankingInformationService.IB_INFORMATION_SERVICE)).getInfo();
		IBOIB_CFG_ProcessConfig processConfig = ProcessManagementUtils.findProcessConfigDetails(processConfigID);
		AllWorkflowTasksMetadata allWorkflowTasksMetadata =
				islamicBankingInformation.getAllStepsForTemplate("", processConfig.getF_TEMPLATEID(), "");
		for(TaskLinkCustomProperties step : allWorkflowTasksMetadata.getTaskLinkCustomProperties())
		{
			GcCodeDetail vGcCodeDetails = new GcCodeDetail();
			String stepID = step.getTaskMicroflowName();
			vGcCodeDetails.setCodeReference(stepID);
			IBOIB_CFG_StepDetails processStepDetails = StepSetupUtils.findStepDetailsProcessConfIdAndUniqueStepId(stepID, processConfigID);
			if(null == processStepDetails)
			{
				processStepDetails = StepSetupUtils.findStepDetailsByUniqueStepId(stepID, true);
			}
			vGcCodeDetails.setCodeDescription(processStepDetails.getF_STEPNAME());
			genericCodeRs.addGcCodeDetails(vGcCodeDetails);
		}
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(20);
		pagingRequest.setRequestedPage(1);
		pagingRequest.setTotalPages(1);
		pagedQuery.setPagingRequest(pagingRequest );
		genericCodeRs.setPagedQuery(pagedQuery );
		RsHeader rsHeader = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setCodes(new SubCode[] {});
		rsHeader.setStatus(status );
		genericCodeRs.setRsHeader(rsHeader );
		//genericCodeRs = getAllStepList();
		return genericCodeRs;
	}
	
	public static ValidationConf saveOrUpdate(ValidationConf validationConf)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		if(StringUtils.isNotBlank(validationConf.getValidationConfID()))
		{
			IBOCE_IB_ValidationConfiguration confFromDB = (IBOCE_IB_ValidationConfiguration) factory.
					findByPrimaryKey(IBOCE_IB_ValidationConfiguration.BONAME, validationConf.getValidationConfID(), true);
			confFromDB.setF_IBACTIONTYPE(validationConf.getActionType());
			confFromDB.setF_IBAPPROVALUSERID(validationConf.getApprovalUserID());
			confFromDB.setF_IBVALIDATIONID(validationConf.getValidationID());
			confFromDB.setF_IBSTEPID(validationConf.getStepID());
			confFromDB.setF_IBPROCESSCONFIGID(validationConf.getProcessID());
			confFromDB.setF_IBFILTERBYBRANCH(validationConf.isIsFilterBasedOnBranch());
			confFromDB.setF_IBGROUP(validationConf.isIsGroup());
			/*Event raiseEvent = new Event();
	        raiseEvent.setEventNumber(ValidationExceptionConstants.I_CONFIG_AMENDED);
	        EventsHelper.handleEvent(raiseEvent, BankFusionThreadLocal.getBankFusionEnvironment());*/
	        BusinessEventSupport.getInstance().raiseBusinessInfoEvent(ValidationExceptionConstants.I_CONFIG_AMENDED, new Object[] {}, 
	        		LOGGER, BankFusionThreadLocal.getBankFusionEnvironment());
			//IBCommonUtils.raiseUnparameterizedEvent(ValidationExceptionConstants.I_CONFIG_AMENDED);
		}
		else
		{
			IBOCE_IB_ValidationConfiguration newConf = (IBOCE_IB_ValidationConfiguration) factory.
					getStatelessNewInstance(IBOCE_IB_ValidationConfiguration.BONAME);
			String confID = GUIDGen.getNewGUID();
			validationConf.setValidationConfID(confID);
			newConf.setBoID(confID);
			newConf.setF_IBACTIONTYPE(validationConf.getActionType());
			newConf.setF_IBAPPROVALUSERID(validationConf.getApprovalUserID());
			newConf.setF_IBVALIDATIONID(validationConf.getValidationID());
			newConf.setF_IBSTEPID(validationConf.getStepID());
			newConf.setF_IBPROCESSCONFIGID(validationConf.getProcessID());
			newConf.setF_IBFILTERBYBRANCH(validationConf.isIsFilterBasedOnBranch());
			newConf.setF_IBGROUP(validationConf.isIsGroup());
			factory.create(IBOCE_IB_ValidationConfiguration.BONAME, newConf);
			BusinessEventSupport.getInstance().raiseBusinessInfoEvent(ValidationExceptionConstants.I_CONFIG_SAVED, new Object[] {}, 
	        		LOGGER, BankFusionThreadLocal.getBankFusionEnvironment());
		}
		return validationConf;
	}
	public static ValidationConf deleteValidationConf(ValidationConf validationConf)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		if(StringUtils.isNotBlank(validationConf.getValidationConfID()))
		{
			String whereClause = "WHERE " + IBOCE_IB_ValidationConfiguration.IBVALIDATIONCONFID + " = ?";
			ArrayList<String> params = new ArrayList<>();
			params.add(validationConf.getValidationConfID());
			factory.bulkDelete(IBOCE_IB_ValidationConfiguration.BONAME, whereClause, params);
			BusinessEventSupport.getInstance().raiseBusinessInfoEvent(ValidationExceptionConstants.I_CONFIG_REMOVED, new Object[] {}, 
	        		LOGGER, BankFusionThreadLocal.getBankFusionEnvironment());
		}
		
		return validationConf;
	}
	
	//during read of deal validation list
	public static ValidationConfList getValidationListForProcessAndStep(String processConfigID, String stepID)
	{
		ValidationConfList validationList = new ValidationConfList();
		String whereClause = "WHERE " + IBOCE_IB_ValidationConfiguration.IBSTEPID + " = ? AND "
				+IBOCE_IB_ValidationConfiguration.IBPROCESSCONFIGID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(stepID);
		params.add(processConfigID);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOCE_IB_ValidationConfiguration> configuredValidationList = factory.findByQuery(IBOCE_IB_ValidationConfiguration.BONAME, whereClause, params, null, false);
		for(IBOCE_IB_ValidationConfiguration validationConf : configuredValidationList)
		{
			ValidationConf conf = new ValidationConf();
			conf.setActionType(validationConf.getF_IBACTIONTYPE());
			conf.setApprovalUserID(validationConf.getF_IBAPPROVALUSERID());
			conf.setProcessID(validationConf.getF_IBPROCESSCONFIGID());
			conf.setStepID(validationConf.getF_IBSTEPID());
			conf.setValidationConfID(validationConf.getBoID());
			conf.setValidationID(validationConf.getF_IBVALIDATIONID());
			conf.setIsFilterBasedOnBranch(validationConf.isF_IBFILTERBYBRANCH());
			conf.setIsGroup(validationConf.isF_IBGROUP());
			validationList.addValidationConf(conf);
			
		}
		return validationList;
	}
	
	public static IBOCE_IB_ValidationConfiguration getValidationConf(String validationConfId)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_ValidationConfiguration conf = (IBOCE_IB_ValidationConfiguration) factory.findByPrimaryKey(IBOCE_IB_ValidationConfiguration.BONAME, 
				validationConfId, true);
		return conf;
	}
	
	public static String getValidationID(String validationConfId)
	{
		String validationID = CommonConstants.EMPTY_STRING;
		IBOCE_IB_ValidationConfiguration conf = getValidationConf(validationConfId);
		if(null != conf)
		{
			validationID = conf.getF_IBVALIDATIONID();
		}
		return validationID;
	}

	public static ListGenericCodeRs getAllStepList() {
		ListGenericCodeRs genericCodeRs = new ListGenericCodeRs();
		List<IBOIB_CFG_StepDetails> allSteps = StepSetupUtils.findAllStepByProcessConfigId(null, true);
		for(IBOIB_CFG_StepDetails step : allSteps) {
			GcCodeDetail vGcCodeDetails = new GcCodeDetail();
			vGcCodeDetails.setCodeReference(step.getF_UNIQUESTEPID());
			vGcCodeDetails.setCodeDescription(step.getF_STEPNAME());
			genericCodeRs.addGcCodeDetails(vGcCodeDetails);
		}
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(20);
		pagingRequest.setRequestedPage(1);
		pagingRequest.setTotalPages(1);
		pagedQuery.setPagingRequest(pagingRequest );
		genericCodeRs.setPagedQuery(pagedQuery );
		RsHeader rsHeader = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setCodes(new SubCode[] {});
		rsHeader.setStatus(status );
		genericCodeRs.setRsHeader(rsHeader );
		return genericCodeRs;
	}
	
	public static ListGenericCodeRs getStatusActionList() {
		ListGenericCodeRs genericCodeRs = new ListGenericCodeRs();
		ListGenericCodeRq listGenericCodeRq = new ListGenericCodeRq();
		InputListHostGCRq inputListCodeValueRq = new InputListHostGCRq();
		inputListCodeValueRq.setCbReference("VALIDATIONAPPROVALSTATUS");
		listGenericCodeRq.setInputListCodeValueRq(inputListCodeValueRq );
		HashMap param = new HashMap();
		param.put("listGenericCodeRq", listGenericCodeRq);
		HashMap<String, Object> outputParam = MFExecuter.executeMF(
				"CB_GCD_ListGenericCodes_SRV", IBCommonUtils.getBankFusionEnvironment(),
				param);
		ListGenericCodeRs listGenericCodeRs = (ListGenericCodeRs) outputParam
				.get("listGenericCodeRs");
		for(GcCodeDetail gcCode : listGenericCodeRs.getGcCodeDetails()) {
			if(ValidationExceptionConstants.STATUS_REJECTED.equals(gcCode.getCodeReference()) ||
					ValidationExceptionConstants.STATUS_APPROVED.equals(gcCode.getCodeReference()))
			{
			GcCodeDetail vGcCodeDetails = new GcCodeDetail();
			vGcCodeDetails.setCodeReference(gcCode.getCodeReference());
			vGcCodeDetails.setCodeDescription(gcCode.getCodeDescription());
			genericCodeRs.addGcCodeDetails(vGcCodeDetails);
			}
		}
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(20);
		pagingRequest.setRequestedPage(1);
		pagingRequest.setTotalPages(1);
		pagedQuery.setPagingRequest(pagingRequest );
		genericCodeRs.setPagedQuery(pagedQuery );
		RsHeader rsHeader = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setCodes(new SubCode[] {});
		rsHeader.setStatus(status );
		genericCodeRs.setRsHeader(rsHeader );
		return genericCodeRs;
	}

}
