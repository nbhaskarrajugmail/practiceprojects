package com.ce.bankfusion.ib.util;

import java.util.ArrayList;
import java.util.List;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_AssetCatAttrbts;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UDFInformation;

public class CEUDFUtils {

	public static List<UDFInformation> filterUDFForDealExistingAsset(List<UDFInformation> udfInformation) {
		List<UDFInformation> udfResultInformation = new ArrayList<UDFInformation>();
		for (UDFInformation udfInformation2 : udfInformation) {
			String attributeName = ((IBOIB_IDI_AssetCatAttrbts) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_IDI_AssetCatAttrbts.BONAME, udfInformation2.getUDFNAME(), true))
							.getF_ATTRID();
			if (attributeName != null && (attributeName.equals("Attribute-6") || attributeName.equals("Attribute-7")
					|| attributeName.equals("Attribute-8") || attributeName.equals("Attribute-9"))) {
				udfResultInformation.add(udfInformation2);
			}

		}

		return udfResultInformation;

	}
}
