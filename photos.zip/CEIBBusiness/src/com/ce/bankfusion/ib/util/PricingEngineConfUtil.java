package com.ce.bankfusion.ib.util;

import com.ce.bankfusion.ib.fatom.GetAssetAttributeNames;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetThirdPartyAttributePanelVisibility;
import bf.com.misys.ib.types.AttrVisibiltyFlags;
import bf.com.misys.ib.types.PricingEngineConf;

public class PricingEngineConfUtil {
	
	public static AttrVisibiltyFlags populateAttrNamesAndVisibilty(PricingEngineConf pricingEngineConf)
	{
		AttrVisibiltyFlags attrVisibiltyFlags = new AttrVisibiltyFlags();
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
		GetAssetAttributeNames assetAttributeNames = new GetAssetAttributeNames(env);
		assetAttributeNames.setF_IN_categoryID(pricingEngineConf.getAssetCategoryID());
		assetAttributeNames.setF_IN_onlyAttributeMode(true);
		assetAttributeNames.process(env);
		pricingEngineConf.getInputFieldsDtls().setAttr1Label(assetAttributeNames.getF_OUT_attribute1Label());
		pricingEngineConf.getInputFieldsDtls().setAttr2Label(assetAttributeNames.getF_OUT_attribute2Label());
		pricingEngineConf.getInputFieldsDtls().setAttr3Label(assetAttributeNames.getF_OUT_attribute3Label());
		pricingEngineConf.getInputFieldsDtls().setAttr4Label(assetAttributeNames.getF_OUT_attribute4Label());
		pricingEngineConf.getInputFieldsDtls().setAttr5Label(assetAttributeNames.getF_OUT_attribute5Label());
		
		pricingEngineConf.getOutputFieldsDtls().setAttr6Label(assetAttributeNames.getF_OUT_attribute6Label());
		pricingEngineConf.getOutputFieldsDtls().setAttr7Label(assetAttributeNames.getF_OUT_attribute7Label());
		pricingEngineConf.getOutputFieldsDtls().setAttr8Label(assetAttributeNames.getF_OUT_attribute8Label());
		pricingEngineConf.getOutputFieldsDtls().setAttr9Label(assetAttributeNames.getF_OUT_attribute9Label());
		
		AssetThirdPartyAttributePanelVisibility attributeVisibility  = assetAttributeNames.getF_OUT_assetThirdPartyAttributePanelVisibility();
		attrVisibiltyFlags.setShowAttr1(attributeVisibility.getPanelVisibilityAttribute1());
		attrVisibiltyFlags.setShowAttr2(attributeVisibility.getPanelVisibilityAttribute2());
		attrVisibiltyFlags.setShowAttr3(attributeVisibility.getPanelVisibilityAttribute3());
		attrVisibiltyFlags.setShowAttr4(attributeVisibility.getPanelVisibilityAttribute4());
		attrVisibiltyFlags.setShowAttr5(attributeVisibility.getPanelVisibilityAttribute5());
		attrVisibiltyFlags.setShowAttr6(attributeVisibility.getPanelVisibilityAttribute6());
		attrVisibiltyFlags.setShowAttr7(attributeVisibility.getPanelVisibilityAttribute7());
		attrVisibiltyFlags.setShowAttr8(attributeVisibility.getPanelVisibilityAttribute8());
		attrVisibiltyFlags.setShowAttr9(attributeVisibility.getPanelVisibilityAttribute9());
		
		return attrVisibiltyFlags;
	}

}
