package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_GrandApprovalCalculatedID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_GrandApprovalCalculated;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIBVW_DealPartyDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetThirdPartyDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.webservice.common.util.WebServiceInvocationHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.msgs.v1r0.CustCustomerExposureInput;
import bf.com.misys.cbs.msgs.v1r0.ReadCustomerPortfolioRq;
import bf.com.misys.cbs.msgs.v1r0.ReadCustomerPortfolioRs;

public class ADFTechGrantAssetUtils {
	private transient final static Log logger = LogFactory
			.getLog(ADFTechGrantAssetUtils.class.getName());
	
	// 1
	public static String prepareSP3(String v_toolno, String v_grp_cd, String v_var1, String v_var2, String v_var3,
				String v_var4, String v_var5, String v_cur_listser, String v_stdy_ach_flg, String v_dealno) throws Exception {
			// return "12|23|34|45|true|";
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			factory.beginTransaction();
			Connection _Connection =factory.getJDBCConnection();
			String _ProcedureName = "{ CALL CUSTOMEXTN.EXECUTESP3";
			CallableStatement cs = null;
			try {
				// prepare store procedure command with parameters count
				_ProcedureName += " (";
				for (int i = 1; i <= 17; i++)
					_ProcedureName += "?,";
				_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

				// prepare the callable statement
				cs = _Connection.prepareCall(_ProcedureName);

				// set value for each parameter
				cs.setString(1, "CUSTOMEXTN.STDY_PKG_CALC.CALC_" + v_grp_cd);
				cs.setString(2, v_toolno);
				cs.setString(3, v_grp_cd);
				cs.setString(4, v_var1);
				cs.setString(5, v_var2);
				cs.setString(6, v_var3);
				cs.setString(7, v_var4);
				cs.setString(8, v_var5);
				cs.setString(15, v_cur_listser);
				cs.setString(16, v_stdy_ach_flg);
				cs.setString(17, v_dealno);

				// set output parameters ...
				cs.registerOutParameter(9, java.sql.Types.VARCHAR);
				cs.registerOutParameter(10, java.sql.Types.VARCHAR);
				cs.registerOutParameter(11, java.sql.Types.VARCHAR);
				cs.registerOutParameter(12, java.sql.Types.VARCHAR);
				cs.registerOutParameter(13, java.sql.Types.VARCHAR);
				cs.registerOutParameter(14, java.sql.Types.VARCHAR);

				// execute the stored procedures
				cs.execute();

				// return result
				return cs.getString(9) + "|" + cs.getString(10) + "|" + cs.getString(11) + "|" + cs.getString(12) + "|"
						+ cs.getString(13) + "|" + cs.getString(14);

			} catch (Exception e) {
				factory.rollbackTransaction();
				throw e;
			} finally {
				factory.commitTransaction();
				if (cs != null)
					cs.close();
				_Connection.close();
			}
		}

		//
		public static String prepareSP2(String v_toolno, String v_grp_cd, String v_var1, String v_var2, String v_var3,
				String v_var4, String v_var5, String v_cur_listser, String v_bld, String v_stdy_ach_flg, String v_dealno) throws Exception {
			// return "13|24|35|46|false|error occured";
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			factory.beginTransaction();
			Connection _Connection =factory.getJDBCConnection();
			CallableStatement cs = null;
			//String _ProcedureName = "{ CALL CALC_" + v_grp_cd;
			String _ProcedureName = "{ CALL CUSTOMEXTN.EXECUTESP2";
			try {
				// prepare store procedure command with parameters count
				_ProcedureName += " (";
				for (int i = 1; i <= 18; i++)
					_ProcedureName += "?,";
				_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

				// prepare the callable statement
				cs = _Connection.prepareCall(_ProcedureName);

				// set value for each parameter
				cs.setString(1, "CUSTOMEXTN.STDY_PKG_CALC.CALC_" + v_grp_cd);
				cs.setString(2, v_toolno);
				cs.setString(3, v_grp_cd);
				cs.setString(4, v_var1);
				cs.setString(5, v_var2);
				cs.setString(6, v_var3);
				cs.setString(7, v_var4);
				cs.setString(8, v_var5);
				cs.setString(15, v_cur_listser);
				cs.setString(16, v_bld);
				cs.setString(17, v_stdy_ach_flg);
				cs.setString(18, v_dealno);
				// set output parameters ...
				cs.registerOutParameter(9, java.sql.Types.VARCHAR);
				cs.registerOutParameter(10, java.sql.Types.VARCHAR);
				cs.registerOutParameter(11, java.sql.Types.VARCHAR);
				cs.registerOutParameter(12, java.sql.Types.VARCHAR);
				cs.registerOutParameter(13, java.sql.Types.VARCHAR);
				cs.registerOutParameter(14, java.sql.Types.VARCHAR);

				// execute the stored procedures
				cs.execute();

				// return result
				return cs.getString(9) + "|" + cs.getString(10) + "|" + cs.getString(11) + "|" + cs.getString(12) + "|"
						+ cs.getString(13);

			} catch (Exception e) {
				factory.rollbackTransaction();
				throw e;
			} finally {
				factory.commitTransaction();
				if (cs != null)
					cs.close();
				_Connection.close();
			}
		}

		
		public static String prepareSP1(String v_toolno, String v_grp_cd, String v_var1, String v_var2, String v_var3,
				String v_var4, String v_var5, String v_cur_listser, String v_stdy_ach_flg, String v_dealno) throws Exception {
			// return "14|25|36|47|true|";
			//Connection _Connection = getConnection();
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			factory.beginTransaction();
			Connection _Connection =factory.getJDBCConnection();
			CallableStatement cs = null;
			String _ProcedureName = "{ CALL CUSTOMEXTN.EXECUTESP1";
			try {
				// prepare store procedure command with parameters count
				_ProcedureName += " (";
				for (int i = 1; i <= 17; i++)
					_ProcedureName += "?,";
				// _ProcedureName += "?,";
				_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

				// prepare the callable statement
				cs = _Connection.prepareCall(_ProcedureName);

				// set value for each parameter
				cs.setString(1, "CUSTOMEXTN.STDY_PKG_CALC.CALC_" + v_grp_cd);
				cs.setString(2, v_toolno);
				cs.setString(3, v_grp_cd);
				cs.setString(4, v_var1);
				cs.setString(5, v_var2);
				cs.setString(6, v_var3);
				cs.setString(7, v_var4);
				cs.setString(8, v_var5);
				cs.setString(15, v_cur_listser);
				cs.setString(16, v_stdy_ach_flg);
				cs.setString(17, v_dealno);
				cs.setString(9, v_var1);
				cs.setString(10, v_var1);
				
				// set output parameters ...
				cs.registerOutParameter(9, java.sql.Types.VARCHAR);
				cs.registerOutParameter(10, java.sql.Types.VARCHAR);
				cs.registerOutParameter(11, java.sql.Types.VARCHAR);
				cs.registerOutParameter(12, java.sql.Types.VARCHAR);
				cs.registerOutParameter(13, java.sql.Types.VARCHAR);
				cs.registerOutParameter(14, java.sql.Types.VARCHAR);

				// execute the stored procedures
				cs.execute();
				
				// return result
				return cs.getString(9) + "|" + cs.getString(10) + "|" + cs.getString(11) + "|" + cs.getString(12) + "|"
						+ cs.getString(13) + "|" + cs.getString(14);

			} catch (Exception e) {
				factory.rollbackTransaction();
				throw e;
			} finally {
				factory.commitTransaction();
				if (cs != null)
					cs.close();
				_Connection.close();
			}
		}

		// 21,25,26,35,40
		public static String prepareSP4(String v_toolno, String v_grp_cd, String v_var1, String v_var2, String v_var3,
				String v_var4, String v_var5, String v_cur_listser, String v_stdy_ach_flg, String v_dealno) throws Exception {
			// return "15|26|37|48|true||";
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			factory.beginTransaction();
			Connection _Connection =factory.getJDBCConnection();
			String _ProcedureName = "{ CALL CUSTOMEXTN.EXECUTESP4";
			CallableStatement cs = null;
			try {
				// prepare store procedure command with parameters count
				_ProcedureName += " (";
				for (int i = 1; i <= 18; i++)
					_ProcedureName += "?,";
				_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

				// prepare the callable statement
				cs = _Connection.prepareCall(_ProcedureName);

				// set value for each parameter
				cs.setString(1, "CUSTOMEXTN.STDY_PKG_CALC.CALC_" + v_grp_cd);
				cs.setString(2, v_toolno);
				cs.setString(3, v_grp_cd);
				cs.setString(4, v_var1);
				cs.setString(5, v_var2);
				cs.setString(6, v_var3);
				cs.setString(7, v_var4);
				cs.setString(8, v_var5);
				cs.setString(16, v_cur_listser);
				cs.setString(17, v_stdy_ach_flg);
				cs.setString(18, v_dealno);
				// set output parameters ...
				cs.registerOutParameter(9, java.sql.Types.VARCHAR);
				cs.registerOutParameter(10, java.sql.Types.VARCHAR);
				cs.registerOutParameter(11, java.sql.Types.VARCHAR);
				cs.registerOutParameter(12, java.sql.Types.VARCHAR);
				cs.registerOutParameter(13, java.sql.Types.VARCHAR);
				cs.registerOutParameter(14, java.sql.Types.VARCHAR);
				cs.registerOutParameter(15, java.sql.Types.VARCHAR);

				// execute the stored procedures
				cs.execute();
				// return result
				return cs.getString(9) + "|" + cs.getString(10) + "|" + cs.getString(11) + "|" + cs.getString(12) + "|"
						+ cs.getString(13) + "|" + cs.getString(14) + "|" + cs.getString(15);
			} catch (Exception e) {
				factory.rollbackTransaction();
				throw e;
			} finally {
				factory.commitTransaction();
				if (cs != null)
					cs.close();
				_Connection.close();
			}
		}
		public static void updateDealAssetDtls(String DealNum, String AssetNo, BigDecimal Cost) throws Exception {
			try {
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

				// Filter Query
				String whereClause = " WHERE IBDEALNO = ? AND IBASSETDETAILSID = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add(DealNum);
				queryParams.add(AssetNo);

				List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
						whereClause, queryParams, null, true);

				// process the results
				for (IBOIB_DLI_DealAssetDtls dealAssetDtl : dealAssetDtls) {
					dealAssetDtl.setF_ASSETCOST(Cost);
					dealAssetDtl.setF_PRINCIPALAMOUNT(Cost);
					dealAssetDtl.setF_PROFITAMOUNT(Cost);
					dealAssetDtl.setF_SELLPRICEPRINCIPALAMT(Cost);
					dealAssetDtl.setF_SELLPRICEPROFITAMT(Cost);
				}
			} catch (Exception se) {
				throw se;
			}
		}

		public static void updateDealAssetThirdPartyDtls(String DealNum, String AssetNo, BigDecimal Cost) throws Exception {
			try {
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

				// Filter Query
				String whereClause = " WHERE IBDEALNO = ? AND IBASSETDETAILID = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add(DealNum);
				queryParams.add(AssetNo);

				List<IBOIB_DLI_DealAssetThirdPartyDTL> dealThirdPartyDtls = factory
						.findByQuery(IBOIB_DLI_DealAssetThirdPartyDTL.BONAME, whereClause, queryParams, null, true);

				// process the results
				for (IBOIB_DLI_DealAssetThirdPartyDTL dealThirdPartyDtl : dealThirdPartyDtls) {
					dealThirdPartyDtl.setF_Amount(Cost);
				}
			} catch (Exception se) {
				throw se;
			}
		}

		public static void updateDealAdditionalDtls(String DealNum, BigDecimal TotalCost) throws Exception {
			try {
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

				// Filter Query
				String whereClause = " WHERE IBDEALNO = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add(DealNum);

				List<IBOIB_DLI_DealAditionalDtls> dealAditionalDtls = factory
						.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, queryParams, null, true);

				// process the results
				for (IBOIB_DLI_DealAditionalDtls dealAditionalDtl : dealAditionalDtls) {
					dealAditionalDtl.setF_AssetCost(TotalCost);
					dealAditionalDtl.setF_PROFITASSETCOST(TotalCost);
					dealAditionalDtl.setF_ProfitCost(TotalCost);
				}
			} catch (Exception se) {
				throw se;
			}
		}

		public static void updateDealDetails(String DealNum, BigDecimal TotalCost) throws Exception {
			try {
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

				// Filter Query
				String whereClause = " WHERE IBDEALNOPK = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add(DealNum);

				List<IBOIB_DLI_DealDetails> dealDetails = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, whereClause,
						queryParams, null, true);

				// process the results
				for (IBOIB_DLI_DealDetails deal : dealDetails) {
					deal.setF_DealAmt(TotalCost);
					deal.setF_PrincipleAmt(TotalCost);
				}
			} catch (Exception se) {
				throw se;
			}
		}

		public static String getDealCustomer(String DealNumber) throws Exception {
			try {
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
				// Filter Query
				String whereClause = " WHERE IBASSOCIATIONTYPE = ? AND IBDEALNO = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add("PC");
				queryParams.add(DealNumber);

				// Execute and retrieve result
				List<IBOIB_IDI_DealCustomerDetail> dealCustomerDetail = factory
						.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, whereClause, queryParams, null, true);

				// process the results
				for (IBOIB_IDI_DealCustomerDetail dealCustomer : dealCustomerDetail) {
					return dealCustomer.getF_CUSTOMERID();
				}

				return "";
			} catch (Exception e) {
				throw e;
			}
		}

		public static BigDecimal getCustomerLiabilty(String DealNumber) throws Exception {
			BigDecimal totalLiability = BigDecimal.ZERO;
			try {
				String _CustomerId = getDealCustomer(DealNumber);
				logger.info("Deal customer :"+_CustomerId);
				Set<String> uniquePartners = new HashSet<>();
				uniquePartners.add(_CustomerId);
				List<String> firstLevelPartners = getPartnersInDeal(DealNumber);
				//Getting second level Partners
				for(String firstLevelPartner : firstLevelPartners) {
					logger.info("Partner :"+firstLevelPartner);
					uniquePartners.add(firstLevelPartner);
					List<String> dealsOfPartner = getDealsOfPartner(firstLevelPartner);
					for(String dealId : dealsOfPartner) {
						List<String> secondLevelPartners = getPartnersInDeal(dealId);
						for(String secondPartner : secondLevelPartners) {
							logger.info("Partner's partner :"+secondPartner);
							uniquePartners.add(secondPartner);
						}
					}
				}
				for(String partnerId : uniquePartners) {
					String partyURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, "IB_PARTY_WS_URL", "false");
					ReadCustomerPortfolioRq _RqPayLoad = new ReadCustomerPortfolioRq();
					CustCustomerExposureInput custCustomerExposureInput = new CustCustomerExposureInput();
					custCustomerExposureInput.setCustomerID(partnerId);
	
					_RqPayLoad.setCustCustomerExposureInput(custCustomerExposureInput);
					WebServiceInvocationHelper invokeWS = new WebServiceInvocationHelper();
					HashMap<String, Object> outputParams = (HashMap<String, Object>) invokeWS.invokeSynchronousCallGeneric(
							_RqPayLoad, partyURL+"/bfweb/services/UB_CMN_CustomerDetails_SRVWS?wsdl",
							"UB_CMN_CustomerDetails_SRV");
	
					ReadCustomerPortfolioRs _ReadCustomerPortfolioRs = (ReadCustomerPortfolioRs) outputParams
							.get("ReadCustomerPortfolioRs");
					if(_ReadCustomerPortfolioRs.getCustomerPortfolioDetail().getTotalLiabilty()!=null && _ReadCustomerPortfolioRs.getCustomerPortfolioDetail().getTotalLiabilty().getAmount()!=null) {
						BigDecimal liability = _ReadCustomerPortfolioRs.getCustomerPortfolioDetail().getTotalLiabilty().getAmount()
								.multiply(new BigDecimal(-1));
						totalLiability = totalLiability.add(liability);
						logger.info("Partner : "+partnerId+" and liability is :"+liability);
					}
					
				}
			} catch (Exception e) {
				throw e;
			}
			return totalLiability;
		}
		private static List<String> getDealsOfPartner(String firstLevelPartner) {
			List<String> partnerDeals = new ArrayList<>();
			String query = " WHERE "+IBOIBVW_DealPartyDetails.CustomerID+" =?";
			ArrayList<String> params = new ArrayList<>();
			params.add(firstLevelPartner);
			List<IBOIBVW_DealPartyDetails> dealPartyDetailsList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOIBVW_DealPartyDetails.BONAME, query, params, null, true);
			if(dealPartyDetailsList!=null && !dealPartyDetailsList.isEmpty()) {
				for(IBOIBVW_DealPartyDetails dealPartyDetail : dealPartyDetailsList) {
					partnerDeals.add(dealPartyDetail.getBoID());
				}
			}
			return partnerDeals;
		}

		private static List<String> getPartnersInDeal(String dealNumber) {
			ArrayList<String> dealInvalidStatuses = new ArrayList<>();
			dealInvalidStatuses.add(IBConstants.CLOSED);
			dealInvalidStatuses.add(IBConstants.CANCELLED);
			dealInvalidStatuses.add(CeConstants.DEAL_STATUS_EXPIRED);
			dealInvalidStatuses.add(IBConstants.REJECTED);
			List<String> partnerPartyIds = new ArrayList<>();
			String query = " WHERE "+IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE+" =? AND "+IBOCE_IB_DealRelationshipDetails.IBDEALID+" =?";
			ArrayList<String> params = new ArrayList<>();
			params.add(CeConstants.PARTNER_RELATIONTYPE);
			params.add(dealNumber);
			List<IBOCE_IB_DealRelationshipDetails> relationShipList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, query, params, null, true);
			if(relationShipList!=null && !relationShipList.isEmpty()) {
				for(IBOCE_IB_DealRelationshipDetails relation : relationShipList) {
					IBOIB_DLI_DealDetails dealDetail = (IBOIB_DLI_DealDetails) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, relation.getF_IBDEALID(),true);
					if(!dealInvalidStatuses.contains(dealDetail.getF_Status())){
						partnerPartyIds.add(relation.getF_IBPARTYID());
					}
				}
			}
			return partnerPartyIds;
		}

		/* Changes of CX to be made (3) */
		public static void addGrantApprovalCalculated(String DealNum, String AssetNo) throws Exception {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			IBOCE_IB_GrandApprovalCalculated approvalCalculated = (IBOCE_IB_GrandApprovalCalculated) factory
					.getStatelessNewInstance(IBOCE_IB_GrandApprovalCalculated.BONAME);
			CE_IB_GrandApprovalCalculatedID pkID = new CE_IB_GrandApprovalCalculatedID();
			pkID.setF_IBDEALASSETID(AssetNo);
			pkID.setF_IBDEALID(DealNum);
			approvalCalculated.setCE_IB_GrandApprovalCalculatedID(pkID);
			factory.create(IBOCE_IB_GrandApprovalCalculated.BONAME, approvalCalculated);
			
		}

		public static void removeGrantApprovalCalculated(String DealNum, String AssetNo) throws Exception {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			
			CE_IB_GrandApprovalCalculatedID pkID = new CE_IB_GrandApprovalCalculatedID();
			pkID.setF_IBDEALASSETID(AssetNo);
			pkID.setF_IBDEALID(DealNum);
			try{
				factory.remove(IBOCE_IB_GrandApprovalCalculated.BONAME, pkID);
			}catch(BankFusionException bfe) {
			    logger.info("********Grant Approval Calculation not found***********");
			}
		}

		public static boolean hasGrantApprovalCalculated(String DealNum, String AssetNo) throws Exception {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			CE_IB_GrandApprovalCalculatedID pkID = new CE_IB_GrandApprovalCalculatedID();
			pkID.setF_IBDEALASSETID(AssetNo);
			pkID.setF_IBDEALID(DealNum);
			IBOCE_IB_GrandApprovalCalculated approvalCalculateds = (IBOCE_IB_GrandApprovalCalculated) factory.findByPrimaryKey(IBOCE_IB_GrandApprovalCalculated.BONAME, pkID, true);
			if (approvalCalculateds != null && approvalCalculateds.getCE_IB_GrandApprovalCalculatedID()!=null) {
				return true;
			}
			return false;
		}

		public static String validateStudyPackage(String v_dealno) throws Exception {
			// return "13|24|35|46|false|error occured";
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			factory.beginTransaction();
			Connection _Connection =factory.getJDBCConnection();
			CallableStatement cs = null;
			String _ProcedureName = "{ CALL CUSTOMEXTN.STDY_PKG_CALC.chk_valid_stdy";
			try {
				// prepare store procedure command with parameters count
				_ProcedureName += " (";
				for (int i = 1; i <= 4; i++)
					_ProcedureName += "?,";
				_ProcedureName = _ProcedureName.substring(0, _ProcedureName.length() - 1) + ") }";

				// prepare the callable statement
				cs = _Connection.prepareCall(_ProcedureName);

				// set value for each parameter
				cs.setString(1, v_dealno);
				
				// set output parameters ...
				cs.registerOutParameter(2, java.sql.Types.VARCHAR);
				cs.registerOutParameter(3, java.sql.Types.VARCHAR);
				cs.registerOutParameter(4, java.sql.Types.VARCHAR);
				
				// execute the stored procedures
				cs.execute();

				// return result
				return cs.getString(2) + "$" + cs.getString(3) + "$" + cs.getString(4);

			} catch (Exception e) {
				factory.rollbackTransaction();
				throw e;
			} finally {
				factory.commitTransaction();
				if (cs != null)
					cs.close();
				_Connection.close();
			}
		}
}
