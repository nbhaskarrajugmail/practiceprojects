package com.ce.bankfusion.ib.util;

public class CeConstants {

    // generic codes
    public static final String IBHOSTFREQCODE = "IBHOSTFREQCODE";

    public static final String IBREPAYMENTFREQUENCY = "IBREPAYMENTFREQUENCY";

    public static final String PROFITMETHOD = "PROFITMETHOD";

    public static final String FLATRATE = "FLATRATE";

    public static final String PROFITDISMETHOD = "PROFITDISMETHOD";

    public static final String FOLLOWUP_ASSIGN_STATUS_INPROGRESS = "INPROGRESS";

    public static final String ADF_JOBTITLE_PARENT = "CEADFJOBTITLE";

    // Read profit matrix
    public static final String READ_PROFITMATRIX_SRV = "IB_DLI_ReadProfitMatrixName_SRV";

    public static final String READ_PROFITMATRIX_SRV_INPUT_PRODID = "ProductID";

    public static final String READ_PROFITMATRIX_SRV_INPUT_SUBPRODID = "SubProductID";

    public static final String READ_PROFITMATRIX_SRV_INPUT_STATUS = "status";

    public static final String READ_PROFITMATRIX_SRV_INPUT_DELFLAG = "isDeletedFlag";

    public static final String READ_PROFITMATRIX_SRV_OUTPUT_RES = "Result";

    public static final String STATUS_ACTIVE = "ACTIVE";

    // vector columns of profit matrix details BO
    public static final String VECTOR_COL_PROFITMATRIXDETAILS_NAME = "IB_PFT_PROFITMATRIXDETAILS_Name";

    public static final String VECTOR_COL_PROFITMATRIXDETAILS_PROFITMATRIXID = "IB_PFT_PROFITMATRIXDETAILS_ProfitMatrixID";

    public static final String SCREENTAGID_IBO_PRODUCTID = "islamicBankingObject:productID";

    public static final String SCREENTAGID_IBO_SUBPRODUCTID = "islamicBankingObject:subProductID";

    public static final String POST_MANUAL_COLLECTION_MF_NAME = "IB_SPI_PostManualCollection_SRV";

    public static final String CONST_UPDATE = "UPDATE";

    // event codes
    public static final int E_USE_EARLY_SETTLEMENT_ADF_IB = 44000212;

    public static final int E_EARLY_ASSET_PAYOFF_REQ_ALREADY_EXISTS_ADF_IB = 44000211;

    public static final int E_LOAN_ARREAR_STATE_ACTIVITY_NOT_ALLOWED_ADF_IB = 44000213;

    public static final int E_DEAL_HAS_NO_ASSETS_DISBURSED_IB = 44000214;

    public static final int E_FOLLOWUP_ASSIGNED_TO_DIFF_USER_IB = 44000218;

    public static final int E_FOLLOWUP_NOT_ALLOWED_DEAL_NOT_DISBURSED_IB = 44000219;

    /* Follow up is not allowed, as deal is fully satisfied. */
    public static final int E_FOLLOWUP_NOT_ALLOWED_DEAL_FULLY_SATISFIED_IB = 44000220;

    /* No Negative follow up to amend. */
    public static final int E_NO_NEG_FOLLOWUPS_TO_AMEND_IB = 44000223;

    /* Follow up cannot be amended, as previous Follow up date is after {0} days. */
    public static final int E_PREV_FOLLOWUP_DATE_AFTER_CONFIGURED_DAYS_IB = 44000224;

    /* Follow up in progress already exists, to amend use Follow up Amend process. */
    public static final int E_FOLLOWUP_IN_PROGRESS_EXIST_IB = 44000225;

    /* Follow up cannot be amended, as previous Follow up is assigned to {0}. */
    public static final int E_FOLLOWUP_IS_NOT_ASSIGNED_TO_THIS_USER_IB = 44000226;

    /* Deal cannot be recalled, as there is no Negative followup initiated before {0} days. */
    public static final int E_DEAL_CANNOT_BE_RECALLED_IB = 44000227;

    /* Follow up cannot be amended, as Recall process is in progress for previous Follow up. */
    public static final int E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB = 44000229;

    /* No Technical Analysis done for this deal. */
    public static final int E_NO_TECH_ANALYSIS_DONE_IB = 44000230;

    /* Customer is marked as Freeze. Cannot Proceed. */
    public static final int E_PARTY_FREEZE_IB = 44000246;

    /* Deal is on Hold */
    public static final int E_DEAL_ON_HOLD = 44000242;

    public static final int E_DEAL_NOT_ON_HOLD = 44000253;

    // EarlyAssetPayoff
    public static final String EARLYASSETPAYOFF_PRC = "CE_IB_EarlyAssetPayoff_PRC";

    public static final String TASKINPUT_PAYLOAD_INPUT = "taskInputPayload";

    public static final String INPUT_MODE_LOAD = "ON_LOAD";

    public static final String INPUT_MODE_SELECT = "ON_SELECT";

    public static final String GCCODE_EARLYASSETPAYOFFSTATUS = "EARLYASSETPAYOFFSTATUS";

    public static final String GCCODE_EARLYASSETPAYOFFSTATUS_COMPLETED = "COMPLETED";

    public static final String GCCODE_EARLYASSETPAYOFFSTATUS_INPROGRESS = "INPROGRESS";

    public static final String ASSET_PAYOFF_STATUS_NEW = "NEW";

    public static final String ASSET_PAYOFF_STATUS_COMPLETED = "COMPLETED";

    public static final String PAYMENTAMOUNTTYPE_EARLYASSETPAYOFF = "EARLYASSETPAYOFF";

    public static final String REGSERVICE_ACCENTRIES_INPUT1 = "accEntriesRegistrationDtls";

    public static final String REGSERVICE_ACCENTRIES_INPUT2 = "mode";

    public static final String REGSERVICE_CALLING_MODE = "create";

    public static final String REGSERVICE_ACCENTRIES_OUTPUT1 = "transactionId";

    public static final String ACC_FORMAT_TYPE_STA = "STA";

    public static final String ADFIBCONFIGLOCATION = "ADFIBconfigLocation";

    public static final String DIS_PERIOD_IN_YRS = "Disbursement_Period_In_Years";

    public static final String SUBSIDY_PERCENTAGE = "Subsidy_Percentage";

    public static final String IS_ASSET_DISBURSED = "Is_Asset_Disbursed";

    public static final String UPFRONT_PROFIT_COLLECTION = "UPFRONT_PROFIT_COLLECTION_METHOD";

    public static final String INITIAL_FEES_COLLECTION = "INITIAL_FEES_COLLECTION_METHOD";

    public static final String UPFRONT_PROFIT_AMOUNT = "Upfront_Profit_Amount";

    public static final String GRACE_PERIOD_IN_YEARS = "Grace_Period_In_Years";

    public static final String PAYMENT_FREQUENCY = "Payment_Frequency";

    public static final String SCHEDULE_PROFIT = "Schedule_Profit_Amount";

    public static final String PRICING_METHOD = "Pricing_Method";

    public static final String PROFIT_METHOD = "Profit_Method";

    public static final String PROFIT_DISTRIBUTION_METHOD = "Profit_Distribution_Method";

    public static final String PROFIT_RATE = "Profit_Rate";

    public static final String UDFPROPERTY = "conf/udf/udf.properties";

    public static final String REPAYMENT_STATUS_ARREAR = "ARREAR";

    public static final String ASSETSTATUS_EARLYPAIDOFF = "EARLYPAIDOFF";

    public static final String QUERYSTRING_WHERE = " WHERE ";

    public static final String DEALFOLLOWUPPROCESS_PRC = "CE_IB_DealFollowUp_PRC";

    public static final String FOLLOWUP_STATUS_NEGATIVE = "NEGATIVE";

    public static final String FOLLOWUP_STATUS_POSITIVE = "POSITIVE";

    public static final String FOLLOWUP_PROPERTY_FILE = "conf/custom.properties";

    public static final String FOLLOWUP_PERIOD_IN_DAYS = "FollowUp_Period_In_Days";

    public static final String DEAL_FOLLOWUP_AMEND_PAGE_ACTION = "FOLLOWUPAMENDPROCESS";

    public static final String ASSET_PAYOFF_PAGE_ACTION = "ASSETPAYOFF";

    public static final String ASSET_STATUS_DISBURSED = "DISBURSED";

    public static final String ASSET_STATUS_DISBURSED_DESC = "Disbursed";

    public static final String UPFRONT_PROFIT_COLLECTION_METHOD = "UPFRONT_PROFIT_COLLECTION_METHOD";

    public static final String FEE_COLLECTION_METHOD = "Fee_Collection_Method";

    public static final String WRKFLOW_RULES_PROPERTY_FILE = "conf/Workflow/Workflow_Rules.properties";

    public static final String HOLD_RULES_FILE = "conf/business/holdrules.xml";

    public static final String RECALLPRC_WRKFLOWRULE = "RecallProcess_CheckUser";

    public static final String ASSETSTATUS_RECALL = "RECALL";

    public static final String Collection_Account = "Collection_Account";

    public static final String Credit_Account = "Credit_Account";

    public static final String UPFRONT_PROFIT_PERCENTAGE = "UPFRONT_PROFIT_PERCENTAGE";

    public static final String RESCHEDULE_PAGE_ACTION = "CREATENEWRESCHEDULEREQUEST";

    public static final String GCPARENT_CEFOLLOWUPSTATUS = "CEFOLLOWUPSTATUS";

    public static final String SUBSIDY_HANDLING_PERIOD_IN_MONTHS = "Subsidy_Handling_Period_In_Months";

    public static final String STEPID_PROCESSDEALPOSTPONE = "PROCESSDEALPOSTPONE";

    public static final String DEAL_STATUS_HOLD = "HOLD";

    public static final String DEAL_STATUS_UNHOLD = "UNHOLD";

    public static final String DEAL_STATUS_UNHOLD_REQUESTED = "REQUESTED";

    public static final String DEAL_STATUS_UNHOLD_APPROVED = "APPROVED";

    public static final String DEAL_STATUS_EXPIRED = "EXPIRED";

    public static final String VALIDATEPARTYFREEZE_PRC = "CE_IB_ValidatePartyFreeze_PRC";

    public static final String FREEZE_STATUS = "FREEZE_STATUS";

    public static final String FREEZE_REASON = "FREEZE_REASON";

    public static final String FREEZE_DOCNUMBER = "FREEZE_DOCNUMBER";

    public static final String FREEZE_DOCDATE = "FREEZE_DOCDATE";

    public static final String FREEZE_FINANCIAL_STATUS = "FREEZE_FINANCIAL_STATUS";

    public static final String FREEZE_NOTES = "FREEZE_NOTES";

    public static final String FREEZE_STEP_DEALINIT = "FREEZE_STEP_DEALINIT";

    public static final String FREEZE_STEP_REQACTIVATE = "FREEZE_STEP_REQACTIVATE";

    public static final String FREEZE_STEP_INITTECHANALYSIS = "FREEZE_STEP_INITTECHANALYSIS";

    public static final String FREEZE_STEP_STUDY = "FREEZE_STEP_STUDY";

    public static final String FREEZE_STEP_GRANTAPPROVAL = "FREEZE_STEP_GRANTAPPROVAL";

    public static final String FREEZE_STEP_SIGNCONTRACT = "FREEZE_STEP_SIGNCONTRACT";

    public static final String FREEZE_STEP_ASSETPROGRESS = "FREEZE_STEP_ASSETPROGRESS";

    public static final String FREEZE_BB_RELATIONINFO = "FREEZE_BB_RELATIONINFO";

    public static final String ASSET_LIST_CHANGE_UDF = "ASSET_LIST_CHANGE_UDF";

    public static final String RELATIONSHIP_PANEL_DISPLAY_FILE = "conf/business/relationshipPanelDisplay.xml";

    public static final String INITIAL_FEE_RULE_FILE = "conf/business/calculateAdjustmentFee.properties";

    public static final String INITIAL_FEE_RULE = "Initial_Fee_Rule";

    public static final String ADJUSTMENT_FEE_RULE = "Adjustment_Fee_Rule";

    public static final String ADF_FOLLOW_UP_USER_BRANCH_GROUP = "ADFFOLLOWUPUPSRBRNCHGRP";

    public static final String LIST_ALL_BRANCH_SRV = "CB_CMN_ListBranch_SRV";

    public static final String FOLLOW_UP_ASSIGN_CONF_FILE = "conf/business/followUpAssignmentConf.properties";

    public static final String FIRST_FOLLOW_UP_START_PERIOD_IN_MONTHS = "First_Follow_Up_Start_Period_In_Months";

    public static final String FIRST_FOLLOW_UP_END_PERIOD_IN_MONTHS = "First_Follow_Up_End_Period_In_Months";

    public static final String MONTHS_AFTER_LAST_FOLLOW_UP = "Months_After_Last_FollowUp";
	
	public static final String COLLATERAL_CUSTOM_CONF_FILE = "conf/business/customCollateral.properties";
    
    public static final String COLLATERAL_RELATIONSHIP_TYPES = "CollateralRelationShipTypes";
    
    public static final String VALIDATE_ON = "VALIDATE_ON";

    /* ID and Party ID should belong to the main customer */
    public static final int E_ID_PARTYID_BELONG_TO_MAIN_CUSTOMER = 44000248;

    /* Pledge Amount cannot be greater than Deal Amount */
    public static final int E_PLEDGEAMT_CANNOT_BE_GREATER_THAN_DEAL_AMT_IB = 44000250;

    /* From Date should be greater than or equal to Deal Date */
    public static final int E_FROM_DATE_SHOULD_BE_GREATER_THAN_DEAL_DATE_IB = 44000251;

    /* To Date should be less than or equal to Maturity Date. */
    public static final int E_TO_DATE_LESSTHAN_MARTURITY_DATE_IB = 44000252;

    /* Freezed party cannot be added */
    public static final int E_FREEZED_PARTY_CANNOT_BE_ADDED_IB = 44000254;

    /* Deceased party cannoe be added */
    public static final int E_DECEASED_PARTY_CANNOT_BE_ADDED_IB = 44000255;

    /* ADF employee cannot be added */
    public static final int E_ADF_EMPLOYEE_CANNOT_BE_ADDED_IB = 44000256;

    /* Party with due liabilities cannot be added */
    public static final int E_PARTY_WITH_DUE_LIABILITIES_CANNOT_BE_ADDED_IB = 44000257;

    /* Atleast one party in Agents is needed */
    public static final int E_ATLEAST_ONEAGENT_IS_NEEDED_IB = 44000258;

    /* Party cannot be same as Agent above */
    public static final int E_PARTY_CANNOT_BE_SAME_AS_AGENT_IB = 44000259;

    /* To Date should be greater than From Date. */
    public static final int E_TO_DATE_CANNOT_BE_LESSTHAN_FROM_DATE_IB = 44000260;

    /* Party with same relationship type cannot be added. */
    public static final int E_PARTY_WITH_SAME_REL_TYPE_CANNOT_BE_ADDED_IB = 44000261;

    /* Silo Year and Silo Area is mandatory for Pledge Type {0} */
    public static final int E_SILO_YEAR_AND_SILO_AREA_IS_MANDATORY_IB = 44000262;

    /* Party {0} with same Agent Source {1} is already added. */
    public static final int E_PARTY_WITH_SAME_AGENT_SOURCE_CANNOT_BE_ADDED_IB = 44000263;

    /* Sadad payment constants */
    public static final String SADAD_PYMT_SCHEDULED = "SCHEDULED";

    public static final String SADAD_PYMT_UPDATE = "UPDATE_INVOICE";

    public static final String SADAD_PYMT_CANCEL = "CANCEL_INVOICE";

    public static final String SADAD_PYMT_ON_SADAD = "ON_SADAD";

    public static final String SADAD_PYMT_CANCELLED = "CANCELLED";

    public static final String SADAD_PYMT_REVERSED = "REVERSED";

    public static final String SADAD_PYMT_PAID = "PAID";

    public static final int E_CANNOT_DELETE_SADAD_INVOICE = 44000265;

    public static final int E_DEAL_HAS_NO_ACTIVE_INVOICE = 44000267;
    
    /* Refund Fees*/
    
    public static final String REFUNDFEES_PRC = "CE_IB_RefundFees_PRC";
    
    public static final String EXECUTEREFUNDFEES_PRC = "CE_IB_ExecuteRefundFees_PRC";
    
    public static final int E_PARTY_OTHER_BANK_ACC_MANDATORY= 44000269;
    
    public static final int E_ATLEAST_ONE_FEE_TOBE_SCHEDULED= 44000270;
    
    public static final String ASSET_STUDY_AND_INFO_CONF_FILE = "conf/business/assetStudyAndInfoConf.properties";
    
    public static final String EXLUCDE_DISBURSE_PERIOD_PRICINGMATRIXID = "conf/business/configPricingMatrix.properties";
    
    public static final String ASSET_ONLY_MODE = "AssetOnly";
    public static final String ASSET_AND_STUDY_ONLY_MODE = "AssetAndStudyOnly";
    public static final String STUDY_AND_GRANTAPPROVAL_ONLY_MODE = "StudyAndGrantApprovalOnly";
    public static final String ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE = "AssetAndStudyWithFinal"; 
    public static final String MACHINE_TYPE_ASSET_PRODUCTID = "DUMMYPRODUCT";
    public static String INCLUDELIABILITY = "IncludeLiability";
    public static String TOTAL_FINAL_COST_UDFNAME = "TotalAssetFinalCost";
    public static String NORMAL_LOANS = "NormalLoanOriginationProcess";
    public static String WORKING_CAPITAL_LOANS = "WorkingCapitalOriginProcess";
    public static String SPECIAL_LOANS = "SpecialLoanOriginationProcess";
    
    public static final String DEAL_EFFECTIVE_DATE_UDF="Deal_Effective_Date";
    public static final String ASSET_TENOR = "Asset_Tenor";
    
    public static final String UPFRONT_PROFIT_PER_UDF = "Upfront_Profit_Percentage";
    public static final String SCHEDULE_PROFIT_PERCENTAGE = "Schedule_Profit_Percentage";
    public static final String PROFIT_AMOUNT = "Profit_Amount";
    
    
    public static final int E_EFF_DATE_NOT_LESSTHAN_DEALSTARTDATE_CEIB = 44000280;
    public static final int E_DEAL_EFF_DATE_CANNOT_BE_NWD_CEIB = 44000281;
    public static final int E_PERCENTAGE_CANNOT_BE_NEG_CEIB = 44000282;
    
    public static final String TITLE_DEED_TYPES_CONF_FILE = "conf/business/titleDeedInfo.properties";
	
    public static final String TITLE_DEED_TYPES = "TileDeedTypes";
    
    public static final String RELATIONSHIP_TYPES_CONF_FILE = "conf/business/relationshipTypesForLiability.properties";
	
    public static final String RELATIONSHIP_TYPES = "relationshipTypes";
    
    public static final String PERSONAL_REQUEST_CONF_FILE = "conf/business/personalRequestInfo.properties";
	
    public static final String PERSONAL_REQUEST_AVAILABLE_BALANCE = "PersonalRequestAvailableBalance";
    
    public static final String ALLLOWED_NUMBER_OF_PERSONAL_TYPES = "AllowedNoOfPersonalTypes";
    
    public static final String PARTNER_RELATIONTYPE = "2";
    
    public static final int E_NO_OUTSTANDING_AMNT_LEFT_CEIB = 44000294;
    public static final int E_SCHEDULE_GENERATION_MANDATORY_CEIB = 44000295;
    public static final int E_UNSCHEDULE_PRINCIPAL_AMOUNT_CEIB = 44000296;
    public static final int E_UNSCHEDULE_PROFIT_AMOUNT_CEIB = 44000297;
    public static final int E_UNSCHEDULE_FEES_AMOUNT_CEIB = 44000298;
    public static final int E_RESCHEDULE_PAYMENT_DATE_MIN_VALID_CEIB = 44000299;
    public static final int E_RESCHEDULE_DISBURSE_AMOUNT_ZERO_CEIB = 44000300;
    public static final int E_RESCHEDULE_INST_DATE_MIN_VALID_CEIB = 44000301;
    public static final int E_SCHEDULE_PRINCIPAL_AMOUNT_MAX_VALID_CEIB = 44000302;
    public static final int E_SCHEDULE_PROFIT_AMOUNT_MAX_VALID_CEIB = 44000303;
    public static final int E_SCHEDULE_FEES_AMOUNT_MAX_VALID_CEIB = 44000304;
    public static final int E_SCHEDULE_NOOF_INSTALLMENTS_MIN_VALID_CEIB = 44000305;
    public static final int E_DT_CANNOT_BE_LESSTHAN_RESCH_PAYMENT_DT_CEIB = 44000306;
    public static final int E_RESCH_PAYMENT_DT_CANNOT_BE_BLANK_CEIB = 44000307;
    public static final int E_NEW_FREQ_CANNOT_BE_EMPTY_CEIB = 44000308;
    public static final int E_DATE_CANNOT_BE_BLANK_CE_IB = 44000309;
    public static final int E_SCHEDULE_FEES_PERCENTAGE_CANNOT_BE_NEG_CEIB=44000310;    
    public static final int E_SCHEDULE_FEES_LESS_OR_EQUAL_TO_PROFIT_CEIB=44000311;
    public static final int E_FEES_LESS_OR_EQUAL_TO_PROFIT_CEIB=44000312;
    public static final int E_RESCHEDULE_PROFIT_AMOUNT_MIN_VALID_CEIB=44000315;
    public static final int E_VALIDATE_AMNTS_ON_SAVE_INST_CEIB = 44000314;
    
    public static final String REFUND_STATUS_SCHEDULED = "SCHEDULED";
    public static final int E_REFUND_ZERO_PROFIT_TO_PROCEED = 44000343;
    public static final String MODE_SCHEDULE = "SCHEDULE";
    public static final String MODE_CANCEL = "CANCEL";
    public static final String PAYMENT_STATUS_FULLY_PAID = "FULLY PAID";
    public static final String PAYMENT_STATUS_UNPAID = "UNPAID";
    public static final String PAYMENT_STATUS_ARREAR = "ARREAR";
    public static final String PAYMENT_STATUS_PARTIAL_PAID = "PARTIALLY PAID";
    public static final String IBINSTALLMENTSTATUS_REFERENCE = "IBINSTALLMENTSTATUS";
    public static final String PAYMENT_MODE_TOSURPLUS = "TOSURPLUS";
    public static final String RESCHREFUNDPROFIT = "RESCHREFUNDPROFIT";
    public static final String TRANS_TYPE_PAY = "PAY";
    public static final String EXCHANGE_RATE_TYPE_SPOT = "SPOT";
    public static final String PAYMENT_METHOD_TRF = "TRF";
    public static final String STATUS_SCHEDULED = "SCHEDULED";
    public static final String STATUS_REFUNDED = "REFUNDED";
    public static final String ACTION_DELETE = "delete";
    public static final String NOACCOUNT = "NOACCOUNT";
    public static final String TRANSACTION_TYPE_REFUNDRESCHEDULEFEES = "REFUNDRESCHEDULEFEES";
    public static final int E_CLEAR_RESCHEDULE_TO_PROCEED = 44000341;
    public static final int E_CLEAR_ARREARS_TO_PROCEED = 44000340;
    
    public static final String REFUND_STATUS_GC_REF = "REFUNDSTATUS";
    public static final String REFUND_STATUS_REFUNDED = "REFUNDED";
    public static final int E_DEAL_RESCH_PAYMENT_DATE_MIN_CEIB = 44000346;
    public static final int E_RESCH_REQ_REFUNDED_CEIB = 44000347;
    public static final int E_REFUND_RESCH_REQ_EXISTS_CEIB = 44000348;
    public static final int E_REFUND_HOST_AMOUNTS_CHANGE_CEIB = 44000351;
    
    public static final int E_TRANSFER_DEBT_REQ_DT_MANDATORY_CEIB = 44000356;
    public static final int E_TD_DOCUMENT_NO_MANDATORY_CEIB = 44000357;
    public static final int E_TD_DOCUMENT_DT_MANDATORY_CEIB = 44000358;
    public static final int E_TD_REASON_MANDATORY_CEIB = 44000359;
    public static final int E_TD_VALIDATE_OS_AMOUNTS_CEIB = 44000360;
    public static final String TD_STATUS_GC_PARENT_REF = "CEIBTDSTATUS";
    public static final String TD_REASON_GC_PARENT_REF = "CEIBTDREASON";
    public static final String TD_STATUS_SCHEDULED = "SCHEDULED";
    public static final String TD_STATUS_TRANSFERRED = "TRANSFERRED";
    public static final String TD_PROPERTIES_FILE = "conf/business/transferOfDebts.properties";
    public static final String TD_PROCESS_CONFIG_ID = "tdProcessConfigID";
    public static final String IS_DEAL_FULLY_DISBURSED = "IS_DEAL_FULLY_DISBURSED";//udf field
    public static final String PSEUDONYM_FORMAT_TYPE = "PSU";
    public static final String TD_LOAN_SETTLE_ACC = "tdLoanSettlementAccountID";
    public static final String CHANNEL_API = "1";
    public static final String DEAL_STATUS_TD_INITIATED = "TRANSFEROFDEBT";
    public static final String DEAL_STATUS_TROUBLED_PROJECT_REQ = "TRANSFEROFDEBTREQ";
    public static final String TROUBLED_PROJECT_REQ_PORTAL_STATUS_UDF = "PORTAL_STATUS";
    public static final String TROUBLED_PROJECT_REQ_STOP_DATE_UDF = "TRBLD_PRJT_STOP_DATE";
    public static final String TROUBLED_PROJECT_REQ_APRVL_DATE_UDF = "TRBLD_PRJT_APRVL_DATE";
    public static final String TROUBLED_PROJECT_REQ_PAST_AMT_UDF = "PAY_OFF_AMT";
    
    public static final String CREDIT_RATING = "CreditRating";

	public static final String CEPROFITFEECOLLMETOD = "CEPROFITFEECOLLMETOD";
	
    public static final String PROJECTNEWTECH = "PROJECTNEWTECH";
    
    public static final String NORMAL_LOAN_PROCESSES = "NormalLoanProcess";
    public static final String SPECIAL_LOAN_PROCESSES = "SpecialLoanProcess";
    
    public static final String ISSUE_PAY_ORDER_CONF_FILE = "conf/business/issuepayorder.properties";
    public static final String INITIAL_FEES_PAID_TAX_RULE="Initial_Fees_Tax_Rule";
    public static final String ADJUSTMENT_FEES_PAID_TAX_RULE="Adjustment_Fee_Tax_Rule";
    public static final String INITIAL_FEES_FEESID="Initial_Fees_FeesId";
    public static final String ADJUSTMENT_FEES_FEESID="Adjustment_Fees_FeesId";

    public static final int INVOICE_AMOUNT_MANDATORY=44000428;
    public static final String SPECIAL_LOAN_SUBPRODUCTS = "SpecialLoanSubproducts";
    public static final String NORMAL_LOAN_TOOLIDS_NO_EXCEPTION = "NormalLoanTOOLsWithNoException";
    public static final String ASSET_PROGRESS_RULES_CONF_FILE = "conf/business/assetProgressRulesConf.properties";
    public static final String AL_BAN_TRESS_TOOLS = "OrdinaryAlBanTrees";
    public static final String CATTLE_CONTRACT_PRODUCTS = "CattleContractProducts";
    public static final String AL_BAN_TRESS_TERM = "OrdinaryAlBanTreesTerm";
    public static final String CATTLE_CONTRACT_TERM = "CattleContractTerm";
    public static final String NORMAL_PROTECTED_HOUSE = "NormalProtectedHouse";
    public static final String NORMAL_PROTECTED_HOUSE_TERM = "NormalProtectedHouseTerm";
    public static final String MOBILE_BEES_PRODUCTS = "MobileBeesProducts";
    public static final String MOBILE_BEES_TERM = "MobileBeesTerm";
    public static final String BOAT_TOOL_ID = "BoatToolID";
    public static final String BOAT_TERM = "BoatTerm";
    public static final String WELL_TOOL_ID = "WellToolID";
    public static final String FOLD_TOOL_ID = "FoldToolID";
    public static final String PALM_IRRIG_NET_TOOL_ID = "PalmIrrigationNetwrk";
    public static final String PALM_FLUITS_TOOL_ID = "PalmFluits";
    public static final String PALM_FRUITS_TOOL_ID = "PalmFruits";
    public static final String PALM_TERM = "PalmTerm";
    public static final String TRACTOR_TOOL_ID = "TractorToolID";
    public static final String TRACTOR_ASS_TOOL_ID = "TractorAccessories";
    public static final String WASTE_TANK_TOOL_ID = "WasteTankToolID";
    public static final String ASSET_REPLACEMENT_MODE="AssetReplacementOnly";
    public static final String ASSET_REPLACEMENT_SYS_BB="ASSETREPLACEMENTS";    
    public static final int E_VALIDATE_ASSET_COST_IN_ASSET_REPLACEMENT_IB=44000434;
    public static final String STATUS_NEW = "New";
    public static final String MODE_RETRIEVE = "RETRIEVE";
    public static final String NORMAL_LOAN_MIN_PROG_PERC1 = "NormalLoanMinCompletion1";
    public static final String NORMAL_LOAN_MIN_PROG_PERC2 = "NormalLoanMinCompletion2";
    public static final String SPECIAL_LOAN_MIN_PROG_PERC1 = "SpecialLoanMinCompletion1";
    public static final String SPECIAL_LOAN_MIN_PROG_PERC2 = "SpecialLoanMinCompletion2";
    public static final String CO_OPERATIVE_ASSOCIATION_PARTY = "CoOperativeAssPartySubType";
    public static final String CO_OPERATIVE_ASSOCIATION_PERCENTAGE = "CoOperativeAssPartyPerc";
    
    public static final String INITIAL_FEES_TAX_PERC="Initial_Fees_Tax_Percentage";
    public static final String ADJUSTMENT_FEES_TAX_PERC="Adjustment_Fees_Tax_Percentage";
    
    public static final String APPROVE= "APPROVE";
    public static final String COMPLETED="COMPLETED";
    
    public static final String RESCHEDULE_TYPE_GENERATE = "GENERATE";
    public static final String RESCHEDULE_TYPE_POSTPONE = "POSTPONE";
    public static final String RESCHEDULE_TYPE_DISTRIBUTE = "DISTRIBUTE";
}
