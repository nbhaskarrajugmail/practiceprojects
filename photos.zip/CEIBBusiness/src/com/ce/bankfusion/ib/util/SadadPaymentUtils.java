package com.ce.bankfusion.ib.util;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.sadad.invoice.BillInvoice;
import com.ce.sadad.invoice.FeeInvoiceData;
import com.ce.sadad.invoice.InvoiceCheckGenerator;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.InvokeSyncWebServiceImpl;

import bf.com.misys.bankfusion.attributes.BFHeader;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.bankfusion.attributes.WebService;
import bf.com.misys.ib.types.SadadPayments;
import bf.com.misys.msgs.party.v12.PartyDetailsRq;
import bf.com.misys.msgs.party.v12.PartyFetchPayloadRq;
import bf.com.misys.party.ws.ReadPartyWSRq;
import bf.com.misys.party.ws.ReadPartyWSRs;
import bf.com.trapedza.bankfusion.webservices.Authentication;
import bf.com.trapedza.bankfusion.webservices.Bfgenericsoapheader;

public class SadadPaymentUtils {
	
	private static final Log LOGGER = LogFactory.getLog(SadadPaymentUtils.class);
	public static final int E_SADAD_INVOICE_CREATION_FAILED = 44000418;
	private static String QUERY_SURPLUSACCOUNT = " WHERE " + IBOUB_CNF_SurplusAccountDetails.UBACCOUNTID + " = ? ";
	private static String QUERY_ACCOUNTDETAIL = " WHERE " + IBOAttributeCollectionFeature.ACCOUNTID + " = ? ";
	public static String queryDealAditionalDtlsUDCheckSADAD(String dealID) throws Exception {
		try {
			String upfrontProfitCollection = StringUtils.EMPTY;
			IBOCE_IB_DealReschedule dealReschedule = RescheduleUtils.getReschReqExistingObjStatusNotCompleted(dealID);
			if(dealReschedule != null) {
				upfrontProfitCollection = dealReschedule.getF_IBRESCHEDULECOLLMETHOD();
			} else {
				//String dealAddDtlsidpk = queryDealAditionalDtls(dealID);
				// set the factory connection
				IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
				// Filter Query
				String whereClause = " WHERE IBDEALNOPK = ?";
				// Add Parameters
				ArrayList<String> queryParams = new ArrayList<String>();
				queryParams.add(dealID);
	
				List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD = factory
						.findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClause, queryParams, null, true);
				String fee_collection_method = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
						CeConstants.UDFPROPERTY, CeConstants.FEE_COLLECTION_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
				// process the results
				for (IBOUDFEXTIB_DLI_DealDetails eachDealDetailsUD : dealDetailsUD) {
					UserDefinedFields userDefinedFields = eachDealDetailsUD.getUserDefinedFields();
					if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
						for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
							/* Upfront Profit Collection */
							if (userDefinedFld.getFieldName().equals(fee_collection_method)) {
								upfrontProfitCollection = (String) userDefinedFld.getFieldValue();
								break;
							}
						}
					}
				}
			}
			return upfrontProfitCollection;
		} catch (Exception se) {
			throw se;
		}
	}
	
	public static String queryDealAditionalDtls(String DealNum) throws Exception {
		try {
			String idpk = StringUtils.EMPTY;

			// set the factory connection
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

			// Filter Query
			String whereClause = " WHERE IBDEALNO = ?";
			// Add Parameters
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(DealNum);

			List<IBOIB_DLI_DealAditionalDtls> dealAddtionalDetails = factory
					.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, queryParams, null, true);

			// process the results
			for (IBOIB_DLI_DealAditionalDtls dealAdditionalDetails : dealAddtionalDetails) {
				idpk = dealAdditionalDetails.getBoID();
			}
			return idpk;
		} catch (Exception se) {
			throw se;
		}

	}
	
	public static String createSadadPayment(SadadPayments paymentDtl, String dealID)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		if(StringUtils.isNotBlank(paymentDtl.getPaymentID()))
		{
			IBOCE_IB_SadadPayments sadadPayments = (IBOCE_IB_SadadPayments) factory.findByPrimaryKey(IBOCE_IB_SadadPayments.BONAME,paymentDtl.getPaymentID(),false);
			//sadadPayments.setF_IBDEALCHARGEDTLID(paymentDtl.getFeeID());
			//sadadPayments.setF_IBPAYMENTSTATUS(paymentDtl.getPaymentStatus());
			sadadPayments.setF_IBSTATUS(paymentDtl.getStatus());
			sadadPayments.setF_IBSTEPID(paymentDtl.getStepId());
			sadadPayments.setF_IBUSERDELETE(paymentDtl.isDelete());
			return paymentDtl.getPaymentID();
		}
		else
		{
			IBOCE_IB_SadadPayments sadadPayments = (IBOCE_IB_SadadPayments) factory.getStatelessNewInstance(IBOCE_IB_SadadPayments.BONAME);
			//see if we can save the value dealChargeDetailsID - no, a single change can have multiple collections
			//the 'paymentDtl.getPaymentID()' will not be null. - not true. As of now keeping it as a new ID.
			String paymentID = GUIDGen.getNewGUID();
			sadadPayments.setBoID(paymentID);
			sadadPayments.setF_IBDEALCHARGEDTLID(paymentDtl.getFeeID());//here the feeId will hold the dealChargeDetailsID
			sadadPayments.setF_IBDEALID(dealID);
			sadadPayments.setF_IBSTATUS(paymentDtl.getStatus());
			sadadPayments.setF_IBSTEPID(paymentDtl.getStepId());
			sadadPayments.setF_IBINVOICEDATE(null);
			factory.create(IBOCE_IB_SadadPayments.BONAME, sadadPayments);
			return paymentID;
		}
		
	}
	
	public static String createSadadInvoice(String nationalID, String dealID, BigDecimal chargeAmount, BigDecimal taxAmount, String feesID)
	{
		FeeInvoiceData feeInvoiceData = new FeeInvoiceData();
		try {
			feeInvoiceData.setBillAccount(nationalID);
			feeInvoiceData.setBillAmount(chargeAmount);
			feeInvoiceData.setDueDate(SystemInformationManager.getInstance().getBFBusinessDate());
			//get expiry date with one month gap - TODO waiting for BA's suggestion
			java.util.Date expiryDate = IBCommonUtils.getNextPaymentDate(SystemInformationManager.getInstance().getBFBusinessDate(), DealInitiationConstants.FREQ_MONTHLY, 1, 1, 0, false, 0);
			feeInvoiceData.setExpiryDate(new Date(expiryDate.getTime()));
			feeInvoiceData.setVatAmount(taxAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String invoiceID = generateBillInvoiceforFee(feeInvoiceData);
		persistFeeInvoiceDetails(feeInvoiceData, invoiceID, feesID,dealID);
		return invoiceID;
	}

	public static void persistFeeInvoiceDetails(FeeInvoiceData feeInvoiceData, String invoiceID, String feesID, String dealID) {

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_FeesPaymentStatus feesPaymentStatus = (IBOCE_IB_FeesPaymentStatus) factory
				.getStatelessNewInstance(IBOCE_IB_FeesPaymentStatus.BONAME);
		feesPaymentStatus.setBoID(invoiceID);
		feesPaymentStatus.setF_IBDEALID(dealID);
		feesPaymentStatus.setF_IBFEESPAYMENTAMNTPAID(CommonConstants.BIGDECIMAL_ZERO);
		feesPaymentStatus.setF_IBFEESPAYMENTFAMNT(feeInvoiceData.getBillAmount());
		feesPaymentStatus.setF_IBFEESPAYMENTFEESID(feesID);
		feesPaymentStatus.setF_IBFEESPAYMENTISCANCEL(false);
		feesPaymentStatus.setF_IBFEESPAYMENTNATIONALID(feeInvoiceData.getBillAccount());
		factory.create(IBOCE_IB_FeesPaymentStatus.BONAME, feesPaymentStatus);
	}
	
	public static void cancelInvoice(String invoiceID, String chargeDetailID)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		BillInvoice billInvoice = new BillInvoice();
		String status = billInvoice.deleteBillInvoice(invoiceID);
		if("Success".equalsIgnoreCase(status))
		{
			IBOCE_IB_FeesPaymentStatus feePaymtStatus = (IBOCE_IB_FeesPaymentStatus) factory.findByPrimaryKey(IBOCE_IB_FeesPaymentStatus.BONAME, invoiceID, false);
			feePaymtStatus.setF_IBFEESPAYMENTISCANCEL(true);
		}
		else
		{
			IBOIB_DLI_DealAssetChargesdtls chargeDtls = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, chargeDetailID, false);
			IBCommonUtils.raiseParametrizedEvent(CeConstants.E_CANNOT_DELETE_SADAD_INVOICE, new String[] {chargeDtls.getF_DUPLICATECHARGENAME()});
		}
	}
	
	public static String generateBillInvoiceforFee(FeeInvoiceData feeData) {
		String invoiceID = StringUtils.EMPTY;
		Map<String, Object> result = new HashMap<String, Object>();
		if (feeData != null) {
			LOGGER.info("Generating Invoice for the initial study, for Account " + feeData.getBillAccount());
			LOGGER.info("Payment Amount: " + feeData.getBillAmount()+" Bill account: "+feeData.getBillAccount()+" Due Date And Expiry date:"+feeData.getDueDate());
			BillInvoice billInvoice = new BillInvoice();
			try {
				result  = billInvoice.genBillInvoiceforFee(feeData);
			} catch (Exception exception) {
				LOGGER.error("Sadad invoice creation failed : " + exception.getLocalizedMessage());
				IBCommonUtils.raiseUnparameterizedEvent(E_SADAD_INVOICE_CREATION_FAILED);
			}
			Object status = (String) result.get("status");
			if(null != status && "Success".equalsIgnoreCase(status.toString()))
			{
				invoiceID = (String) result.get("invoiceId");
			}
			else
			{
				Object statusCode = result.get("statusCode");
				LOGGER.error("Sadad invoice creation failed with statusCode : " + (null != statusCode?statusCode:null));
				IBCommonUtils.raiseUnparameterizedEvent(E_SADAD_INVOICE_CREATION_FAILED);
			}
			LOGGER.info("The Result of sending invoice to SADAD is : " + result);
		}
		return invoiceID;
	}
	
	public static String getNationalId(String partyId) {
		try {
			ReadPartyWSRq partyWSRq = new ReadPartyWSRq();
			partyWSRq.setPartyID(partyId);
			ReadPartyWSRs partyWSRs = readParty(partyWSRq, BankFusionThreadLocal.getBankFusionEnvironment());
			String partyType = partyWSRs.getPartyBasicDetails().getPartyType().getCode();

			PartyFetchPayloadRq fetchPayloadRq = new PartyFetchPayloadRq();
			fetchPayloadRq.setPartyId(partyId);
			fetchPayloadRq.setPartyType(partyType);
			HashMap<String, PartyFetchPayloadRq> partyPayload = new HashMap<String, PartyFetchPayloadRq>();
			partyPayload.put("partyFetchPayloadRq", fetchPayloadRq);
			HashMap loanOutput = MFExecuter.executeMF("CE_IB_GetPartyDetails_SRV", partyPayload,
					BankFusionThreadLocal.getUserLocator().getStringRepresentation());
			PartyDetailsRq readLoanDtlsRs = (PartyDetailsRq) loanOutput.get("PartyDetailsRq");
			if (partyType.equals("1062")) {
				return readLoanDtlsRs.getPartyDetails().getPartyTaxDtl().getGstRegistration().getIdReference();
			} else {
				return readLoanDtlsRs.getPartyDetails().getEntPtyBasicDtls().getRegNumber();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	public static ReadPartyWSRs readParty(ReadPartyWSRq rq, BankFusionEnvironment env) {
		String partyURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
				"IB_PARTY_WS_URL", "false");
		ReadPartyWSRs rs = new ReadPartyWSRs();
		InvokeSyncWebServiceImpl invokeWS = new InvokeSyncWebServiceImpl(env);
		WebService param = new WebService();
		BFHeader bfHeader = new BFHeader();
		bfHeader.setCorrelationID(GUIDGen.getNewGUID());
		bfHeader.setZone(env.getUserSession().getZone());
		param.setBfHeader(bfHeader);
		param.setOperationName("PT_PFN_ReadPartyWS_SRV");
		param.setRequestPayload(rq);
		param.setResponsePayload(rs);
		param.setServiceName(partyURL + "/bfweb/services/ReadPartyWS?wsdl");
		param.setTimeOut(30000);
		param.setSecurityCheckRequired(false);
		Bfgenericsoapheader soap = new Bfgenericsoapheader();
		Authentication authentication = new Authentication();
		String authProvider = getServerAuthProvider();
		if (authProvider.equalsIgnoreCase("CAS")) {
			authentication.setUserLocator(env.getUserLocn().getStringRepresentation());
		} else {
			authentication.setUserName("system");
			authentication.setPassword("system");
		}
		soap.setAuthentication(authentication);
		soap.setBFHeader(bfHeader);
		param.setCustomHeader(soap);
		invokeWS.setF_IN_WebService(param);
		invokeWS.process(env);
		rs = (ReadPartyWSRs) invokeWS.getF_OUT_Response();
		return rs;
	}
	public static String getServerAuthProvider() {
		return BankFusionPropertySupport.getServerProperty("AuthenticationProvider");
	}
	
	public static void createReverseEntry(IBOCE_IB_SadadPayments payment) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_SadadPayments sadadPayments = (IBOCE_IB_SadadPayments) factory.getStatelessNewInstance(IBOCE_IB_SadadPayments.BONAME);
		sadadPayments.setBoID(GUIDGen.getNewGUID());
		sadadPayments.setF_IBDEALCHARGEDTLID(payment.getF_IBDEALCHARGEDTLID());//here the feeId will hold the dealChargeDetailsID
		sadadPayments.setF_IBDEALID(payment.getF_IBDEALID());
		sadadPayments.setF_IBSTATUS(CeConstants.SADAD_PYMT_REVERSED);
		sadadPayments.setF_IBINVOICEID(payment.getF_IBINVOICEID());
		sadadPayments.setF_IBORIGINVOICEID(payment.getF_IBORIGINVOICEID());
		sadadPayments.setF_IBSTEPID(payment.getF_IBSTEPID());
		sadadPayments.setF_IBINVOICEDATE(payment.getF_IBINVOICEDATE());
		sadadPayments.setF_IBUSERDELETE(payment.isF_IBUSERDELETE());
		factory.create(IBOCE_IB_SadadPayments.BONAME, sadadPayments);
	}
	
	public static void cancelAllInvoiceForTheDeal(String dealID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_SadadPayments.IBDEALID + " = ? AND " + IBOCE_IB_SadadPayments.IBSTATUS + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		params.add(CeConstants.SADAD_PYMT_ON_SADAD);
		List<IBOCE_IB_SadadPayments> sadadPayments = factory.findByQuery(IBOCE_IB_SadadPayments.BONAME,whereClause, params, null, false);
		if(null != sadadPayments && !sadadPayments.isEmpty()) {
			for(IBOCE_IB_SadadPayments sadadPayment:  sadadPayments)
			{
				cancelInvoice(sadadPayment.getF_IBINVOICEID(), sadadPayment.getF_IBDEALCHARGEDTLID());
				sadadPayment.setF_IBSTATUS(CeConstants.SADAD_PYMT_CANCELLED);
			}
		}
	}

	public static void updateInvoiceForRepayment(String dealID, String loanAccountId, List<Date> repaymentDatesList) {
		LOGGER.info("Starting the method updateInvoiceForRepayment dealID -->" + dealID);
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = GUIDGen.getNewGUID();
		BigDecimal surplusAmount = getSurplusAmount(loanAccountId);
		for (Date repaymentDate : repaymentDatesList) {
			ArrayList<Object> params = new ArrayList<>();
			String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
					+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? ";
			params.add(dealID);
			params.add(repaymentDate);
			List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupExisting = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, true);
			BigDecimal finalBillAmount = getBillInvoiceAmount(paymentSchBreakupExisting);
			BigDecimal finalBillAmountTemp = finalBillAmount;
			if (BigDecimal.ZERO.compareTo(finalBillAmount.subtract(surplusAmount)) < 0) {
				finalBillAmount = finalBillAmount.subtract(surplusAmount);
				params.clear();
				params.add(loanAccountId);
				params.add(SadadMessageConstants.REPAY);
				params.add(repaymentDate);
				params.add(SadadMessageConstants.EXPIRE);
				StringBuffer billInvoiceWhereClause = new StringBuffer(
						"WHERE  " + IBOCE_BILLINVOICE.BILLACCT + "=? and " + IBOCE_BILLINVOICE.BILLCATEGORY + "=? ");
				billInvoiceWhereClause.append(" AND " + IBOCE_BILLINVOICE.BILLDUEDATE + "=?" +" AND "+IBOCE_BILLINVOICE.BILLACTION + " <> ?");

				List<IBOCE_BILLINVOICE> billInvoiceRecordsList = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceWhereClause.toString(), params, null, true);
				if (null != billInvoiceRecordsList && !billInvoiceRecordsList.isEmpty()) {
					updateExistingInvoice(dealID, billInfoList, params, finalBillAmount, billInvoiceRecordsList);
				} else {
					createNewBillInvoice(loanAccountId, billInfoList, reqID, repaymentDate, finalBillAmount);
				}
			}
			if (BigDecimal.ZERO.compareTo(surplusAmount) < 0) {
				surplusAmount = surplusAmount.subtract(finalBillAmountTemp);
			}
			if (BigDecimal.ZERO.compareTo(surplusAmount) > 0) {
				surplusAmount = BigDecimal.ZERO;
			}

		}
		if (billInfoList != null && billInfoList.size() > 0) {
			callSadadBillInvoiceApi(billInfoList, reqID);
		}
		LOGGER.info("Completed the method updateInvoiceForRepayment dealID -->" + dealID);
	}

	public static void updateInvoiceForAssetPayOffRepayment(String dealID, String loanAccountId, Date repaymentDate,
			BigDecimal finalBillAmount, int repaymentNo, String transactionId) {
		LOGGER.info("Starting the method updateInvoiceForAssetPayOffRepayment dealID -->" + dealID);
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = transactionId;
		BigDecimal surplusAmount = getSurplusAmount(loanAccountId);
		ArrayList<Object> params = new ArrayList<>();
		if (BigDecimal.ZERO.compareTo(finalBillAmount.subtract(surplusAmount)) < 0) {
			finalBillAmount = finalBillAmount.subtract(surplusAmount);
			params.add(loanAccountId);
			params.add(SadadMessageConstants.REPAY);
			params.add(repaymentDate);
			params.add(SadadMessageConstants.EXPIRE);
			StringBuffer billInvoiceWhereClause = new StringBuffer(
					"WHERE  " + IBOCE_BILLINVOICE.BILLACCT + "=? and " + IBOCE_BILLINVOICE.BILLCATEGORY + "=? ");
			billInvoiceWhereClause.append(" AND " + IBOCE_BILLINVOICE.BILLDUEDATE + "=?" +" AND "+IBOCE_BILLINVOICE.BILLACTION + " <> ?");

			List<IBOCE_BILLINVOICE> billInvoiceRecordsList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceWhereClause.toString(), params, null, true);
			if (null != billInvoiceRecordsList && !billInvoiceRecordsList.isEmpty()) {
				updateExistingInvoice(dealID, billInfoList, params, finalBillAmount, billInvoiceRecordsList, repaymentNo);
			} else {
				createNewBillInvoice(loanAccountId, billInfoList, reqID, repaymentDate, finalBillAmount,repaymentNo);
			}
		}
		if (billInfoList != null && billInfoList.size() > 0) {
			callSadadBillInvoiceApi(billInfoList, reqID);
		}
		LOGGER.info("Completed the method updateInvoiceForAssetPayOffRepayment dealID -->" + dealID);
	}
	public static void cancelInvoiceForRepayment(String dealID, String loanAccountId, List<Date> repaymentDatesList) {
		LOGGER.info("Starting the method cancelInvoiceForRepayment dealID -->" + dealID);
		List<InvoiceData> cancelBillInfoList = new ArrayList<InvoiceData>();
		String reqID = GUIDGen.getNewGUID();
		for (Date repaymentDate : repaymentDatesList) {
			ArrayList<Object> params = new ArrayList<>();
			params.add(loanAccountId);
			params.add(SadadMessageConstants.REPAY);
			params.add(repaymentDate);
			params.add(SadadMessageConstants.EXPIRE);
			StringBuffer billInvoiceWhereClause = new StringBuffer(
					"WHERE  " + IBOCE_BILLINVOICE.BILLACCT + "=? and " + IBOCE_BILLINVOICE.BILLCATEGORY + "=? ");
			billInvoiceWhereClause.append(" AND " + IBOCE_BILLINVOICE.BILLDUEDATE + "=?" +" AND "+IBOCE_BILLINVOICE.BILLACTION + " <> ?");

			List<IBOCE_BILLINVOICE> billInvoiceRecordsList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceWhereClause.toString(), params, null, true);
			if (null != billInvoiceRecordsList && !billInvoiceRecordsList.isEmpty()) {
				for(IBOCE_BILLINVOICE billInvoice : billInvoiceRecordsList)
				CancelExistingInvoice(dealID, cancelBillInfoList,billInvoiceRecordsList);
			}

		}
		if (cancelBillInfoList != null && cancelBillInfoList.size() > 0) {
			callSadadBillInvoiceApi(cancelBillInfoList, reqID);
		}
		LOGGER.info("Completed the method cancelInvoiceForRepayment dealID -->" + dealID);
	}

	public static BigDecimal getSurplusAmount(String loanAccountNo) {
		BigDecimal surplusAmount = BigDecimal.ZERO;
		String surplusAccount = null;

		ArrayList<String> params = new ArrayList<String>();
		params.add(loanAccountNo);
		List<IBOUB_CNF_SurplusAccountDetails> surplusDtls = (ArrayList<IBOUB_CNF_SurplusAccountDetails>) BankFusionThreadLocal
				.getPersistanceFactory()
				.findByQuery(IBOUB_CNF_SurplusAccountDetails.BONAME, QUERY_SURPLUSACCOUNT, params, null, true);
		if (null != surplusDtls && !surplusDtls.isEmpty()) {
			for (IBOUB_CNF_SurplusAccountDetails surplus : surplusDtls) {
				surplusAccount = surplus.getF_UBSURPLUSACCOUNT();
				ArrayList<String> params1 = new ArrayList<String>();
				params1.add(surplusAccount);
				List<IBOAttributeCollectionFeature> accountDetails = (ArrayList<IBOAttributeCollectionFeature>) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByQuery(IBOAttributeCollectionFeature.BONAME, QUERY_ACCOUNTDETAIL, params1, null, false);

				if (null != accountDetails && !accountDetails.isEmpty()) {
					IBOAttributeCollectionFeature accountDtl = (IBOAttributeCollectionFeature) accountDetails.get(0);
					if (null != accountDtl.getF_CLEAREDBALANCE()
							&& accountDtl.getF_CLEAREDBALANCE().compareTo(BigDecimal.ZERO) == 1)

						surplusAmount = accountDtl.getF_CLEAREDBALANCE();
				}
			}
		}
		return surplusAmount;
	}

	private static void CancelExistingInvoice(String dealID, List<InvoiceData> billInfoList,
			List<IBOCE_BILLINVOICE> billInvoiceRecordsList) {
		for (IBOCE_BILLINVOICE billInvoiceRecord : billInvoiceRecordsList) {
			InvoiceData data = new InvoiceData();
			data.setBillAccount(billInvoiceRecord.getF_BILLACCT());
			data.setBillAction(SadadMessageConstants.EXPIRE);
			data.setBillCategory(billInvoiceRecord.getF_BILLCATEGORY());
			data.setBillAmount(billInvoiceRecord.getF_BILLAMT());
			String[] boIdArray = billInvoiceRecord.getBoID().split("_");
			int billCycle = 0;
			if (null != boIdArray && boIdArray.length > 2)
				billCycle = Integer.parseInt(boIdArray[1]);
			data.setBillCycle(billCycle);
			data.setInvoiceId(billInvoiceRecord.getF_BILLINVOICENO());
			data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());
			billInfoList.add(data);
			updateCancelBillInvoiceDtls(billInvoiceRecord.getBoID(), SadadMessageConstants.EXPIRE);
		}
	}
	private static void updateExistingInvoice(String dealID, List<InvoiceData> billInfoList, ArrayList<Object> params,
			BigDecimal finalBillAmount, List<IBOCE_BILLINVOICE> billInvoiceRecordsList, int repaymentNo) {
		for (IBOCE_BILLINVOICE billInvoiceRecord : billInvoiceRecordsList) {
			InvoiceData data = new InvoiceData();
			data.setBillAccount(billInvoiceRecord.getF_BILLACCT());
			data.setBillAction(SadadMessageConstants.UPDATE);
			data.setBillCategory(billInvoiceRecord.getF_BILLCATEGORY());
			params.clear();
			params.add(dealID);
			params.add(billInvoiceRecord.getF_BILLDUEDATE());
			data.setBillAmount(finalBillAmount);
			int billCycle = repaymentNo;
			data.setBillCycle(billCycle);
			data.setInvoiceId(billInvoiceRecord.getF_BILLINVOICENO());
			data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());
			billInfoList.add(data);
			updateBillInvoiceDtls(billInvoiceRecord.getBoID(), finalBillAmount, SadadMessageConstants.UPDATE);
		}
	}
	private static void updateExistingInvoice(String dealID, List<InvoiceData> billInfoList, ArrayList<Object> params,
			BigDecimal finalBillAmount, List<IBOCE_BILLINVOICE> billInvoiceRecordsList) {
		for (IBOCE_BILLINVOICE billInvoiceRecord : billInvoiceRecordsList) {
			InvoiceData data = new InvoiceData();
			data.setBillAccount(billInvoiceRecord.getF_BILLACCT());
			data.setBillAction(SadadMessageConstants.UPDATE);
			data.setBillCategory(billInvoiceRecord.getF_BILLCATEGORY());
			params.clear();
			params.add(dealID);
			params.add(billInvoiceRecord.getF_BILLDUEDATE());
			data.setBillAmount(finalBillAmount);
			int billCycle = BillInvoiceHelper.billInvoiceCycle(data.getBillAccount(),
					billInvoiceRecord.getF_BILLDUEDATE());
			data.setBillCycle(billCycle);
			data.setInvoiceId(billInvoiceRecord.getF_BILLINVOICENO());
			data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());
			billInfoList.add(data);
			updateBillInvoiceDtls(billInvoiceRecord.getBoID(), finalBillAmount, SadadMessageConstants.UPDATE);
		}
	}
	private static void createNewBillInvoice(String loanAccountId, List<InvoiceData> billInfoList, String reqID,
			Date repaymentDate, BigDecimal finalBillAmount, int repaymentNo) {
		IBOCE_BILLINVOICE billInvoice = (IBOCE_BILLINVOICE) IBCommonUtils.getPersistanceFactory()
				.getStatelessNewInstance(IBOCE_BILLINVOICE.BONAME);
		int billInvCycle = repaymentNo;
		String idPk = GUIDGen.getNewGUID();
		if (billInvCycle > 0) {
			idPk += "_" + billInvCycle;
		}
		billInvoice.setBoID(idPk);
		String requestKey = reqID + "_" + billInvCycle;
		billInvoice.setF_REQUESTKEY(requestKey);
		billInvoice.setF_BILLACCT(loanAccountId);
		billInvoice.setF_BILLAMT(finalBillAmount);
		billInvoice.setF_BILLVATAMT(BigDecimal.ZERO);
		billInvoice.setF_BILLCATEGORY(SadadMessageConstants.REPAY);
		String invoiceId = GUIDGen.getNewGUID();
		while (!new InvoiceCheckGenerator().isInvoiceIdNotPresent(invoiceId)) {
			invoiceId = GUIDGen.getNewGUID();
		}
		int days = Integer.parseInt(new CEUtil().getModuleConfigurationValue(CEConstants.CE_SADAD_INTERFACE,
				SadadMessageConstants.DAYS_INVOICE_EXPIRY));
		Calendar cal = Calendar.getInstance();
		cal.setTime(repaymentDate);
		cal.add(Calendar.DATE, days);
		billInvoice.setF_BILLINVOICENO(invoiceId);
		billInvoice.setF_BILLDUEDATE(repaymentDate);
		billInvoice.setF_BILLEXPDATE(new Date(cal.getTime().getTime()));
		billInvoice.setF_BILLGENDATE(SystemInformationManager.getInstance().getBFBusinessDate());
		billInvoice.setF_BILLACTION(SadadMessageConstants.INITIAL);
		IBCommonUtils.getPersistanceFactory().create(IBOCE_BILLINVOICE.BONAME, billInvoice);

		InvoiceData data = new InvoiceData();
		data.setBillAccount(loanAccountId);
		data.setBillAction(SadadMessageConstants.UPDATE);
		data.setBillCategory(SadadMessageConstants.REPAY);

		data.setBillAmount(finalBillAmount);
		data.setBillCycle(billInvCycle);
		data.setInvoiceId(invoiceId);
		data.setDueDate(repaymentDate);
		billInfoList.add(data);
	}
	private static void createNewBillInvoice(String loanAccountId, List<InvoiceData> billInfoList, String reqID,
			Date repaymentDate, BigDecimal finalBillAmount) {
		IBOCE_BILLINVOICE billInvoice = (IBOCE_BILLINVOICE) IBCommonUtils.getPersistanceFactory()
				.getStatelessNewInstance(IBOCE_BILLINVOICE.BONAME);
		int billInvCycle = BillInvoiceHelper.billInvoiceCycle(loanAccountId, repaymentDate);
		String idPk = GUIDGen.getNewGUID();
		if (billInvCycle > 0) {
			idPk += "_" + billInvCycle;
		}
		billInvoice.setBoID(idPk);
		String requestKey = reqID + "_" + billInvCycle;
		billInvoice.setF_REQUESTKEY(requestKey);
		billInvoice.setF_BILLACCT(loanAccountId);
		billInvoice.setF_BILLAMT(finalBillAmount);
		billInvoice.setF_BILLVATAMT(BigDecimal.ZERO);
		billInvoice.setF_BILLCATEGORY(SadadMessageConstants.REPAY);
		String invoiceId = GUIDGen.getNewGUID();
		while (!new InvoiceCheckGenerator().isInvoiceIdNotPresent(invoiceId)) {
			invoiceId = GUIDGen.getNewGUID();
		}
		int days = Integer.parseInt(new CEUtil().getModuleConfigurationValue(CEConstants.CE_SADAD_INTERFACE,
				SadadMessageConstants.DAYS_INVOICE_EXPIRY));
		Calendar cal = Calendar.getInstance();
		cal.setTime(repaymentDate);
		cal.add(Calendar.DATE, days);
		billInvoice.setF_BILLINVOICENO(invoiceId);
		billInvoice.setF_BILLDUEDATE(repaymentDate);
		billInvoice.setF_BILLEXPDATE(new Date(cal.getTime().getTime()));
		billInvoice.setF_BILLGENDATE(SystemInformationManager.getInstance().getBFBusinessDate());
		billInvoice.setF_BILLACTION(SadadMessageConstants.INITIAL);
		IBCommonUtils.getPersistanceFactory().create(IBOCE_BILLINVOICE.BONAME, billInvoice);

		InvoiceData data = new InvoiceData();
		data.setBillAccount(loanAccountId);
		data.setBillAction(SadadMessageConstants.UPDATE);
		data.setBillCategory(SadadMessageConstants.REPAY);

		data.setBillAmount(finalBillAmount);
		data.setBillCycle(billInvCycle);
		data.setInvoiceId(invoiceId);
		data.setDueDate(repaymentDate);
		billInfoList.add(data);
	}

	private static void callSadadBillInvoiceApi(List<InvoiceData> billInfoList, String reqID) {
		LOGGER.info("After fetching Invoice details" + billInfoList.size());
		LOGGER.info("Before calling build Update" + reqID);
		String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billInfoList, SadadMessageConstants.REPAY,
				reqID);
		LOGGER.info("After calling build Update: " + message);
		SadadWebService wsCall = new SadadWebService();
		String response = null;
		String statusCode = null;
		try {
			LOGGER.info("Before calling SADAD Update");
			response = wsCall.callSADAD(message, SadadMessageConstants.INVOICE);
			LOGGER.info("After calling SADAD Update: " + response);
			statusCode = GenSADADReq.getStatusCode(response);
			LOGGER.info("statusCode: " + statusCode);
		} catch (IOException | SOAPException e) {
			LOGGER.error(e);
			if (e instanceof SOAPException)
				statusCode = "Webservice Connection Error";
			if (e instanceof IOException)
				statusCode = "I/O Error";
			e.printStackTrace();
		}
		if (null != statusCode && !statusCode.isEmpty() && statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
			LOGGER.info("updateInvoiceForRepayment is successful: " + statusCode);
		}
	}
	public static void updateCancelBillInvoiceDtls(String id, String billAction) {
		ArrayList<Object> columns = new ArrayList<>();
		String billInvUpdateQuery = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";
		columns.add(IBOCE_BILLINVOICE.BILLACTION);
		columns.add(IBOCE_BILLINVOICE.BILLEXPDATE);
		ArrayList<Object> paramValues = new ArrayList<>();
		paramValues.add(billAction);
		paramValues.add(IBCommonUtils.getBFBusinessDate());
		ArrayList<Object> params = new ArrayList<>();
		params.add(id);
		BankFusionThreadLocal.getPersistanceFactory().bulkUpdate(IBOCE_BILLINVOICE.BONAME, billInvUpdateQuery, params,
				columns, paramValues);
	}

	public static void updateBillInvoiceDtls(String id, BigDecimal amount, String billAction) {
		ArrayList<Object> columns = new ArrayList<>();
		String billInvUpdateQuery = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";
		columns.add(IBOCE_BILLINVOICE.BILLACTION);
		columns.add(IBOCE_BILLINVOICE.BILLAMT);
		ArrayList<Object> paramValues = new ArrayList<>();
		paramValues.add(billAction);
		paramValues.add(amount);
		ArrayList<Object> params = new ArrayList<>();
		params.add(id);
		BankFusionThreadLocal.getPersistanceFactory().bulkUpdate(IBOCE_BILLINVOICE.BONAME, billInvUpdateQuery, params,
				columns, paramValues);
	}

	private static BigDecimal getBillInvoiceAmount(List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupExisting) {
		BigDecimal finalBillAmount = BigDecimal.ZERO;
		if (null != paymentSchBreakupExisting && !paymentSchBreakupExisting.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : paymentSchBreakupExisting) {
				finalBillAmount = paymentSchBreakup.getF_IBPRINCIPALAMT().add(paymentSchBreakup.getF_IBPROFITAMT())
						.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())
						.subtract(paymentSchBreakup.getF_IBPRINCIPALAMTPAID())
						.subtract(paymentSchBreakup.getF_IBPROFITAMTPAID())
						.subtract(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID())
						.subtract(paymentSchBreakup.getF_IBSUBSIDYAMNT());
			}
		}
		return finalBillAmount;
	}

}
