package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealAssetRegistryDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.fatom.CalculateStudyGrantApproval;
import com.ce.bankfusion.ib.fatom.IssuePOFatom;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ib.types.AssetRegistryDtl;
import bf.com.misys.ib.types.AssetRegistryList;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.PurchaseOrderDetails;

public class AssetStudyAndInfoUtil {
	
	private static final Log LOGGER = LogFactory.getLog(AssetStudyAndInfoUtil.class);
	public static String ASSET_ORIGINAL_COST = "AssetOriginalCost";
	public static String ASSET_STUDY_COST = "AssetStudyCost";
	public static String ASSET_GRANT_APPROVAL_COST = "AssetGrantApprovalCost";
	public static String ASSET_FINAL_COST = "AssetFinalCost";
	public static String MACHINE_TYPE = "MachineType";
	private static String PROJECT_LATEST_TECHNOLOGIES = "ProjectNewTechnologies";
	private static String LATEST_TECHNOLOGY_PERCENTAGE = "LatestTechnologiesProjectPercentage";
	private static Integer E_MAXRATE_CHANGE_ALLOWED = 44000325;
	private static Integer E_RATE_INCREATE_NOT_ALLOWED_NORMAL_LOANS = 44000331;
	private static final String PO_PROCESSED_STATUS = "Processed";
	private static final Object PO_COMPLETED_STATUS = "Completed";
	private static String EXPECTED_GRANT_APP_PERC_UDF = "expectedGrantAppPercentage";
    private static String ENTERED_GRANT_APP_PERC_UDF = "EnteredGrantAppPerc";
	/** 
	 * This method will get the asset registry details. if assetserial is null then fetches by deal id
	 * Returns the registry dtl list
	 * @param dealId
	 * @param assetSerial
	 * @return String
	 */
	public static AssetRegistryList getDealAssetRegistryDetails(String dealId, String assetSerial) {
		AssetRegistryList assetRegistryList = new AssetRegistryList();
		if (!IBCommonUtils.isValidString(dealId)) {
			LOGGER.info("Deal is empty so returning null");
			return assetRegistryList;
		}
		String assetRegistryListQuery = " WHERE " + IBOCE_IB_DealAssetRegistryDtls.IBDEALID + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		if(assetSerial != null) {
			params.add(assetSerial);
			assetRegistryListQuery = assetRegistryListQuery + " AND "+ IBOCE_IB_DealAssetRegistryDtls.IBASSETSERIAL + " = ? ";
		}
		List<IBOCE_IB_DealAssetRegistryDtls> assetRegistyList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealAssetRegistryDtls.BONAME, assetRegistryListQuery, params, null, false);
		if(assetRegistyList == null || assetRegistyList.isEmpty()) {
			return assetRegistryList;
		}
		for(IBOCE_IB_DealAssetRegistryDtls dbDealAssetRegisty : assetRegistyList) {
			IBOCE_IB_RegistryAssetCfg dbRegistryAstCfg = (IBOCE_IB_RegistryAssetCfg) IBCommonUtils.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_RegistryAssetCfg.BONAME, dbDealAssetRegisty.getF_IBREGISTRYSERIALID());
			AssetRegistryDtl assetRegistryDtl = getRegAstCfg(dbRegistryAstCfg);
			assetRegistryDtl.setAssetSerial(dbDealAssetRegisty.getF_IBASSETSERIAL());
			assetRegistryList.addAssetRegistryList(assetRegistryDtl);
		}
		return assetRegistryList;
	}
	
	/**
	 * This method saves the deal asset registry details
	 * @param dealId
	 * @param reason
	 */
	public static void saveDealAssetRegistryDtls(String dealId, AssetRegistryList assetRegistryList) {
		String deleteQuery = " WHERE "+IBOCE_IB_DealAssetRegistryDtls.IBDEALID+" = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		IBCommonUtils.getPersistanceFactory().bulkDelete(IBOCE_IB_DealAssetRegistryDtls.BONAME, deleteQuery, params);
		for(AssetRegistryDtl assetRegistryDtl : assetRegistryList.getAssetRegistryList()) {
			IBOCE_IB_DealAssetRegistryDtls dealAssetRegDtl = (IBOCE_IB_DealAssetRegistryDtls) IBCommonUtils.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_DealAssetRegistryDtls.BONAME);
			dealAssetRegDtl.setBoID(GUIDGen.getNewGUID());
			dealAssetRegDtl.setF_IBDEALID(dealId);
			dealAssetRegDtl.setF_IBASSETSERIAL(assetRegistryDtl.getAssetSerial());
			dealAssetRegDtl.setF_IBREGISTRYID(assetRegistryDtl.getRegistryID());
			dealAssetRegDtl.setF_IBREGISTRYSERIALID(assetRegistryDtl.getRegistrySerial());
			IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_DealAssetRegistryDtls.BONAME, dealAssetRegDtl);
		}
	}
	
	public static AssetRegistryDtl getRegAstCfg(IBOCE_IB_RegistryAssetCfg dbRegistryAstCfg) {
		AssetRegistryDtl assetRegistryDtl = new AssetRegistryDtl();
		BFCurrencyAmount amount = new BFCurrencyAmount();
		amount.setCurrencyAmount(dbRegistryAstCfg.getF_IBPRICE());
		amount.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
		assetRegistryDtl.setPrice(amount);
		assetRegistryDtl.setRegistrySerial(dbRegistryAstCfg.getBoID());
		assetRegistryDtl.setRegistryID(dbRegistryAstCfg.getF_IBREGISTRYID());
		assetRegistryDtl.setModel(dbRegistryAstCfg.getF_IBMODEL());
		assetRegistryDtl.setVendorId(dbRegistryAstCfg.getF_IBVENDORID());
		assetRegistryDtl.setVendorName(dbRegistryAstCfg.getF_IBVENDORNAME());
		return assetRegistryDtl;
	}
	
	public static void validateMaxRateChange(String processConfigID, AssetThirdPartyDetails assetThirdPartyDetail, BigDecimal attr7Calculated, BigDecimal attr8Calculated, BigDecimal attr6Calculated,
			String attribute7Label, String attribute8Label, String attribute6Label) {
		LOGGER.info("Validating the max rate change allowed with value :"+assetThirdPartyDetail.getMaxRateChangeAllowed());
		LOGGER.info("Calculated Values 7,8,6 were :"+attr7Calculated+","+attr8Calculated+","+attr6Calculated);
		double attr6PercentageChange = 0.0;
		if(attr6Calculated!=null && attr6Calculated.compareTo(BigDecimal.ZERO)!=0) {
			attr6PercentageChange = ((assetThirdPartyDetail.getAttribute9().doubleValue()*100.0)/attr6Calculated.doubleValue())-100.0;
		}else if(assetThirdPartyDetail.getAttribute9()!=null) {
			attr6PercentageChange = 0.0;//assetThirdPartyDetail.getAttribute9().doubleValue();
		}
		LOGGER.info("percentage change for 6 :"+attribute6Label+" is :"+attr6PercentageChange);
		double attr7PercentageChange = 0.0;
		if(attr7Calculated!=null && attr7Calculated.compareTo(BigDecimal.ZERO)!=0) {
			attr7PercentageChange = ((assetThirdPartyDetail.getAttribute7().doubleValue()*100.0)/attr7Calculated.doubleValue())-100.0;
		}else if(assetThirdPartyDetail.getAttribute7()!=null) {
			attr7PercentageChange = 0.0;//assetThirdPartyDetail.getAttribute7().doubleValue();
		}
		LOGGER.info("percentage change for 7 :"+attribute7Label+" is :"+attr7PercentageChange);
		
		double attr8PercentageChange = 0.0;
		if(attr8Calculated!=null && attr8Calculated.compareTo(BigDecimal.ZERO)!=0) {
			attr8PercentageChange = ((assetThirdPartyDetail.getAttribute8().doubleValue()*100.0)/attr8Calculated.doubleValue())-100.0;
		}else if(assetThirdPartyDetail.getAttribute8()!=null) {
			attr8PercentageChange = 0.0;//assetThirdPartyDetail.getAttribute8().doubleValue();
		}
		LOGGER.info("percentage change for 8 :"+attribute8Label+" is :"+attr8PercentageChange);
		
		
		IBOIB_CFG_ProcessConfig processConfig = IBCommonUtils.getProcessConfigByPrimaryKey(processConfigID);
		if(processConfig.getF_TEMPLATEID().equalsIgnoreCase(CeConstants.NORMAL_LOANS)) {
			LOGGER.info("This is normal loan and checking for rate increase");
			if(attr7PercentageChange>0 || attr8PercentageChange>0 || attr6PercentageChange>0) {
				IBCommonUtils.raiseUnparameterizedEvent(E_RATE_INCREATE_NOT_ALLOWED_NORMAL_LOANS);
			}
		}
		
		if(attr7PercentageChange>20.0) {
			String[] parms = new String[2];
			parms[0] = attribute7Label;
			parms[1] = assetThirdPartyDetail.getMaxRateChangeAllowed().toString();
			IBCommonUtils.raiseParametrizedEvent(E_MAXRATE_CHANGE_ALLOWED, parms);
		}
		if(attr8PercentageChange>20.0) {
			String[] parms = new String[2];
			parms[0] = attribute8Label;
			parms[1] = assetThirdPartyDetail.getMaxRateChangeAllowed().toString();
			IBCommonUtils.raiseParametrizedEvent(E_MAXRATE_CHANGE_ALLOWED, parms);
		}
		if(attr6PercentageChange>20.0) {
			String[] parms = new String[2];
			parms[0] = attribute6Label;
			parms[1] = assetThirdPartyDetail.getMaxRateChangeAllowed().toString();
			IBCommonUtils.raiseParametrizedEvent(E_MAXRATE_CHANGE_ALLOWED, parms);
		}
		
	}
	
	public static Object getUDFValue(String udfName, String dealNo) {

		try {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			String whereClause = "WHERE "+IBOUDFEXTIB_DLI_DealDetails.DealNo +"= ?";
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(dealNo);

			List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD = factory
					.findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClause, queryParams, null, true);
			Object udfValue = 0;
			for (IBOUDFEXTIB_DLI_DealDetails dealDetailUD : dealDetailsUD) {
				UserDefinedFields userDefinedFields = dealDetailUD.getUserDefinedFields();
				if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
					for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
						if (userDefinedFld.getFieldName().equals(udfName)) {
							udfValue = userDefinedFld.getFieldValue();
						}
					}
				}
			}
			return udfValue;
		} catch (Exception se) {
			throw se;
		}
	}
	
	public static BigDecimal processFinalCost(IslamicBankingObject islamicBankingObject, BankFusionEnvironment env) {
		BigDecimal delta = BigDecimal.ZERO;
		String totalFinalCostUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.TOTAL_FINAL_COST_UDFNAME, "", CeConstants.ADFIBCONFIGLOCATION);
		BigDecimal totalFinalCost = (BigDecimal)AssetStudyAndInfoUtil.getUDFValue(totalFinalCostUdfName, islamicBankingObject.getDealID());
		LOGGER.info("Total final cost for the Deal :"+islamicBankingObject.getDealID()+" is:"+totalFinalCost.doubleValue());
		if(totalFinalCost == null || totalFinalCost.compareTo(BigDecimal.ZERO)==0) {
			return delta;
		}
		AssetInfoAndStudyFatom assetStudyAndInfoFatom = new AssetInfoAndStudyFatom(env);
		assetStudyAndInfoFatom.setF_IN_mode("RETRIEVE");
		assetStudyAndInfoFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetStudyAndInfoFatom.process(env);
		AssetThirdPartyDetailsList assetThirdPartyList = assetStudyAndInfoFatom.getF_OUT_assetThirdPartyDetailsList(); 
		
		BigDecimal totalAssetsApprovedCost = BigDecimal.ZERO;
		for(AssetThirdPartyDetails assetTPDtl : assetThirdPartyList.getAssetThirdPartyDetails()) {
			totalAssetsApprovedCost = totalAssetsApprovedCost.add(assetTPDtl.getGrantApprovalCost().getCurrencyAmount());
		}
		LOGGER.info("Total Assets final cost for the Deal :"+islamicBankingObject.getDealID()+" is:"+totalAssetsApprovedCost.doubleValue());
		BigDecimal increasedPercentage = totalFinalCost.multiply(new BigDecimal(100.0)).divide(totalAssetsApprovedCost, 2, RoundingMode.HALF_DOWN);
		LOGGER.info("Increased percentage is:"+increasedPercentage.doubleValue());
		
		BigDecimal totalAssetCostAfterGiven = BigDecimal.ZERO;
		AssetThirdPartyDetails[] assetThirdParties = assetThirdPartyList.getAssetThirdPartyDetails();
		for (AssetThirdPartyDetails assetThirdPartyDetails : assetThirdParties) {
			BigDecimal assetApprovedCost = assetThirdPartyDetails.getGrantApprovalCost().getCurrencyAmount();
			BigDecimal finalAmendedCost = assetApprovedCost.multiply(increasedPercentage).divide(new BigDecimal(100.0), 2, RoundingMode.HALF_DOWN);
			totalAssetCostAfterGiven = totalAssetCostAfterGiven.add(finalAmendedCost);
		}
		LOGGER.info("Total totalAssetCostAfterGiven for the Deal :"+islamicBankingObject.getDealID()+" is:"+totalAssetCostAfterGiven.doubleValue());
		delta = totalFinalCost.subtract(totalAssetCostAfterGiven);
		LOGGER.info("Left over total balance for the Deal :"+islamicBankingObject.getDealID()+" is:"+delta.doubleValue()+" .");
		return delta;
	}
	public static BigDecimal calculateGrantApprovalBeforeStudyCost(String dealID, BigDecimal loanRequestedAmount, BigDecimal liabilityAmount) {
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealID);
		IBOIB_CFG_ProcessConfig processConfig = (IBOIB_CFG_ProcessConfig) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_CFG_ProcessConfig.BONAME, dealDetails.getF_PROCESSCONFIGID(), true);
		String method = processConfig.getF_TEMPLATEID();
		//BigDecimal loanRequestedAmount = calculateLoanRequestedAmount();
		BigDecimal localLiabilityAmount = CommonConstants.BIGDECIMAL_ZERO;
		try {
			String liabilityUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
					CeConstants.INCLUDELIABILITY, "", CeConstants.ADFIBCONFIGLOCATION);
			String liability = (String)AssetStudyAndInfoUtil.getUDFValue(liabilityUdfName, dealID);
			if(liability == null || liability.equalsIgnoreCase(IBConstants.YES)) {
				localLiabilityAmount = liabilityAmount;
			}
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage());
		}
		BigDecimal loanApprovedAmount = new BigDecimal(0);
		String latestTechUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				PROJECT_LATEST_TECHNOLOGIES, "", CeConstants.ADFIBCONFIGLOCATION);
		String latestTechnologies = (String)AssetStudyAndInfoUtil.getUDFValue(latestTechUdfName, dealID);
		
		if(latestTechnologies != null && latestTechnologies.equalsIgnoreCase(IBConstants.YES)) {
			Double percentage = Double.valueOf(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE,
					LATEST_TECHNOLOGY_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION));
			LOGGER.info("Configured percentage for latest technologies is :"+percentage);
			percentage = percentage / 100;
			loanApprovedAmount = loanRequestedAmount.multiply(new BigDecimal(percentage));
		} else {
			List<String> normalLoanProcessesList = new ArrayList<>();
			String normalLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE, CeConstants.NORMAL_LOAN_PROCESSES, "",CeConstants.ADFIBCONFIGLOCATION);

			if (normalLoanProcesses != null && !normalLoanProcesses.isEmpty()) {
				normalLoanProcessesList = IBCommonUtils.isNotEmpty(normalLoanProcesses)? Arrays.asList(normalLoanProcesses.split(",")): new ArrayList<String>();
			}
			List<String> specialLoanProcessesList = new ArrayList<>();
			String specialLoanProcesses = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.ASSET_STUDY_AND_INFO_CONF_FILE, CeConstants.SPECIAL_LOAN_PROCESSES, "",CeConstants.ADFIBCONFIGLOCATION);

			if (specialLoanProcesses != null && !specialLoanProcesses.isEmpty()) {
				specialLoanProcessesList = IBCommonUtils.isNotEmpty(specialLoanProcesses)? Arrays.asList(specialLoanProcesses.split(",")): new ArrayList<String>();
			}
			if (normalLoanProcessesList.contains(method))
				loanApprovedAmount = CalculateStudyGrantApproval.calculateNormalLoan(loanRequestedAmount, localLiabilityAmount);
			if (specialLoanProcessesList.contains(method)) {
				loanApprovedAmount = CalculateStudyGrantApproval.calculateSpecialLoan(loanRequestedAmount, localLiabilityAmount);
			}
		}
		return loanApprovedAmount;
	}

	public static Map<String, BigDecimal> getDisbursedAmount(IslamicBankingObject islamicBankingObject) {
		
		IssuePOFatom issuePOFatom = new IssuePOFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		issuePOFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		issuePOFatom.setF_IN_mode("RETRIEVE");
		issuePOFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		IssuePayOrderDtls issuePaymentOrders = issuePOFatom.getF_OUT_issuePayOrderDtls();
		PoAssetDisbursementDetails[] poAssetDisbursementDtls = issuePaymentOrders.getPoAssetDisbursementDetails();
		Map<String, BigDecimal> assetDisbursedAmount = new HashMap<String, BigDecimal>();
		for (PurchaseOrderDetails purchaseOrderDetails : issuePaymentOrders.getPurchaseOrderDetails()) {
			if (purchaseOrderDetails.getPoStatus().equals(PO_COMPLETED_STATUS)
					|| purchaseOrderDetails.getPoStatus().equals(PO_PROCESSED_STATUS)) {
				for (PoAssetDisbursementDetails poAssetDisbursementDetails : poAssetDisbursementDtls) {
					if (purchaseOrderDetails.getPurchaseOrderID()
							.equals(poAssetDisbursementDetails.getPurchaseOrderID())) {
						BigDecimal disburseAmount = assetDisbursedAmount.get(poAssetDisbursementDetails.getAssetID());
						if(disburseAmount!=null) {
							disburseAmount = disburseAmount.add(poAssetDisbursementDetails.getCurrentDisbursedAmount().getCurrencyAmount());
						}else{
							disburseAmount = poAssetDisbursementDetails.getCurrentDisbursedAmount().getCurrencyAmount();
						}
						assetDisbursedAmount.put(poAssetDisbursementDetails.getAssetID(), disburseAmount);
					}
				}
			}
		}
		return assetDisbursedAmount;
	}
	public static BigDecimal getExpectedGrantAppPercentage(String dealID) {
        String expectedGrantAppUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                EXPECTED_GRANT_APP_PERC_UDF, "", CeConstants.ADFIBCONFIGLOCATION);
        BigDecimal expectedGrantAppPercentage = (BigDecimal)AssetStudyAndInfoUtil.getUDFValue(expectedGrantAppUdfName, dealID);
        return expectedGrantAppPercentage;
    }
    public static BigDecimal getEnteredGrantAppPercentage(String dealID) {
        String enteredGrantAppUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
                ENTERED_GRANT_APP_PERC_UDF, "", CeConstants.ADFIBCONFIGLOCATION);
        BigDecimal enteredGrantAppPercentage = (BigDecimal)AssetStudyAndInfoUtil.getUDFValue(enteredGrantAppUdfName, dealID);
        return enteredGrantAppPercentage;
    }
}
