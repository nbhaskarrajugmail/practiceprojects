package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.ib.cfg.dto.PriceListDto;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetUdfDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealPaymentSchedule;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.fatom.PopulateIBBuildingBlock;
import com.misys.bankfusion.ib.fatom.PrepareDisbursementAndDrawDownDtls;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.APIUtils;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOOrganisationGroup;
import com.trapedza.bankfusion.bo.refimpl.IBOOrganisationGroupUser;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOUser;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.CustomUDFType;
import bf.com.misys.bankfusion.attributes.MappingEntry;
import bf.com.misys.bankfusion.attributes.PickList;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.cbs.types.GcCodeDetails;
import bf.com.misys.ce.api.dto.CustomerLiabilitiesExt;
import bf.com.misys.ib.api.bb.dto.AdditionalFieldInfo;
import bf.com.misys.ib.api.bb.dto.AssetAttributeInfo;
import bf.com.misys.ib.api.bb.dto.CurrencyAmount;
import bf.com.misys.ib.ilo.types.UserDetails;
import bf.com.misys.ib.ilo.types.UserList;
import bf.com.misys.ib.msgs.v1r0.RetrievePartyBasicDetailsRq;
import bf.com.misys.ib.msgs.v1r0.RetrievePartyBasicDetailsRs;
import bf.com.misys.ib.schedule.payments.PaymentSchedule;
import bf.com.misys.ib.schedule.service.ProfitCalculationRq;
import bf.com.misys.ib.schedule.types.DrawDownAndDownPaymentDetails;
import bf.com.misys.ib.schedule.types.ScheduleBasicInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfoList;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.FinancialInfoDetail;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListAssetCfg;
import bf.com.misys.ib.types.PricingListCfg;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.RetrievePartyBasicDetailsInput;
import edu.emory.mathcs.backport.java.util.Collections;

public class CeUtils {

    private static  String whereClause = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + "= ? "; 
	private static  String whereClauseDeal = "WHERE "+IBOUDFEXTIB_DLI_DealDetails.DealNo +"= ?"; 
    
    public static PickList getPisckListObject() {
        PickList pickListItem = new PickList();
        return pickListItem;
    }

    public static String getProductIdForPickList(CustomUDFType inputPayload) {
        String productId = CommonConstants.EMPTY_STRING;
        if (inputPayload != null && inputPayload.getMappingEntryCount() > 0) {
            for (MappingEntry mappingEntry : inputPayload.getMappingEntry()) {
                if (mappingEntry.getKey().equalsIgnoreCase(CeConstants.SCREENTAGID_IBO_PRODUCTID)) {
                    productId = ((String) mappingEntry.getValue());
                    break;
                }
            }
        }
        return productId;
    }

    public static String getSubproductIdForPickList(CustomUDFType inputPayload) {
        String subproductId = CommonConstants.EMPTY_STRING;
        if (inputPayload != null && inputPayload.getMappingEntryCount() > 0) {
            for (MappingEntry mappingEntry : inputPayload.getMappingEntry()) {
                if (mappingEntry.getKey().equalsIgnoreCase(CeConstants.SCREENTAGID_IBO_SUBPRODUCTID)) {
                    subproductId = ((String) mappingEntry.getValue());
                    break;
                }
            }
        }
        return subproductId;
    }

    public static ReadAssetData readAssetData(IslamicBankingObject islamicBankingObject) {
        ReadAssetData readAssetData = new ReadAssetData();
        readAssetData.setF_IN_IslamicBankingObject(islamicBankingObject);
        readAssetData.process(BankFusionThreadLocal.getBankFusionEnvironment());
        return readAssetData;
    }

    public static int getMinDisbursementPeriod(ReadAssetData readAssetData) {
        int minDisbursementPeriod = 0;
        Map<String, Integer> assetTenorMap = new HashMap<>();
        String udfId = getUDFIDForDisbursementPeriodInYrs();
        if (readAssetData != null && readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
            for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {

                if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty() && assetUDF.getFieldId().equals(udfId)) {
                    assetTenorMap.put(assetUDF.getAssetid(), Integer.parseInt(assetUDF.getFieldValue()));
                }
            }
        }
        minDisbursementPeriod = (int) Collections.min(assetTenorMap.values());
        return minDisbursementPeriod;
    }

    public static int getAssetTenor(ReadAssetData readAssetData, String assetId) {
        if (readAssetData != null && readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
            for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {
                if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty()
                    && assetUDF.getFieldId().equals(getUDFIDForAssetTenor()) && assetId.equals(assetUDF.getAssetid())) {
                    return Integer.parseInt(assetUDF.getFieldValue());
                }
            }
        }
        return 0;
    }

    public static int getDisbursementPeriodForAsset(ReadAssetData readAssetData, String assetId) {
        if (readAssetData != null && readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
            for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {
                if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty()
                    && assetUDF.getFieldId().equals(getUDFIDForDisbursementPeriodInYrs()) && assetId.equals(assetUDF.getAssetid())) {
                    return Integer.parseInt(assetUDF.getFieldValue());
                }
            }
        }
        return 0;
    }

    public static Boolean isAssetDisbursed(String assetId) {
        IBOIB_AST_AssetDetails assetDetails =
            (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory().findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetId, true);
        return assetDetails != null && assetDetails.getF_STATUS().equals(CeConstants.ASSET_STATUS_DISBURSED);
    }

    public static int getMaxDisburementPeriodPlusAssetTenor(ReadAssetData readAssetData) {
        Map<String, Integer> assetUDFMap = new HashMap<>();
        int disbursementPeriodPlusAssetTenor = 0;
        if (readAssetData != null && readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
            for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {
                disbursementPeriodPlusAssetTenor = 0;
                if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty()
                    && (assetUDF.getFieldId().equals(getUDFIDForDisbursementPeriodInYrs())
                        || assetUDF.getFieldId().equals(getUDFIDForAssetTenor()))) {
                    if (assetUDFMap.containsKey(assetUDF.getAssetid())) {
                        disbursementPeriodPlusAssetTenor = assetUDFMap.get(assetUDF.getAssetid()).intValue();
                    }
                    disbursementPeriodPlusAssetTenor = disbursementPeriodPlusAssetTenor + Integer.parseInt(assetUDF.getFieldValue());
                    assetUDFMap.put(assetUDF.getAssetid(), disbursementPeriodPlusAssetTenor);
                }
            }
            if (!assetUDFMap.isEmpty())
                return (int) Collections.max(assetUDFMap.values());
        }
        return 0;

    }

    public static String getUDFIDForDisbursementPeriodInYrs() {
        return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, CeConstants.DIS_PERIOD_IN_YRS, "",
            CeConstants.ADFIBCONFIGLOCATION);
    }

    public static String getUDFIDForIsAssetDisbursed() {
        return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, CeConstants.IS_ASSET_DISBURSED, "",
            CeConstants.ADFIBCONFIGLOCATION);
    }

    public static Date getScheduleStartDate(Date dealEffectiveDate, String paymentFrequency, int disbursementPeriod) {
		return new Date(IBCommonUtils
				.getNextPaymentDate(dealEffectiveDate, paymentFrequency, 1, disbursementPeriod, 0, false, 0).getTime());
	}

    public static Date getFirstPaymentDate(Date scheduleStartDate, String paymentFrequency, String dealId) {

		Date firstPaymentDate = new Date(
				IBCommonUtils.getNextPaymentDate(scheduleStartDate, paymentFrequency, 1, 1, 0, false, 0).getTime());

		firstPaymentDate = CalendarUtil.getWorkingDateBasedOnNWDAndStartDate(firstPaymentDate, dealId, firstPaymentDate,
				true);
		return firstPaymentDate;
	}

    public static Date getLastPaymentDate(Date firstPaymentDate, String paymentFrequency, ReadAssetData readAssetData,
			String dealId, String assetId) {
		int assetTenor = 0;
		if(IBCommonUtils.isNullOrEmpty(assetId)) {
			assetTenor = getMaxAssetTenor(readAssetData);
		} else {
			assetTenor = getAssetTenor(readAssetData, assetId);
		}
		Date lastPaymentDate = new Date(IBCommonUtils.getNextPaymentDate(firstPaymentDate, paymentFrequency, 1,
				assetTenor, 0, false, 0).getTime());

		lastPaymentDate = CalendarUtil.getWorkingDateBasedOnNWDAndStartDate(lastPaymentDate, dealId, lastPaymentDate,
				true);

		return lastPaymentDate;
	}
    
    public static int getMaxAssetTenor(ReadAssetData readAssetData) {
		int minDisbursementPeriod = 0;
		Map<String, Integer> assetTenorMap = new HashMap<>();
		String udfId = getUDFIDForAssetTenor();
		if (readAssetData != null && readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
			for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {

				if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty()
						&& assetUDF.getFieldId().equals(udfId)) {
					assetTenorMap.put(assetUDF.getAssetid(), Integer.parseInt(assetUDF.getFieldValue()));
				}
			}
		}
		minDisbursementPeriod = (int) Collections.max(assetTenorMap.values());
		return minDisbursementPeriod;
	}
    
    public static String getUDFIDForAssetTenor() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.ASSET_TENOR, "", CeConstants.ADFIBCONFIGLOCATION);
	}

    public static int getScheduleDurationUnit(ReadAssetData readAssetData) {
        return getMaxDisburementPeriodPlusAssetTenor(readAssetData);
    }

    public static DrawDownAndDownPaymentDetails getDrawdownAndDownPaymentDtls(String dealId) {
        DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails = null;
        PrepareDisbursementAndDrawDownDtls prepareDisbursementAndDrawDownDtls = new PrepareDisbursementAndDrawDownDtls();
        prepareDisbursementAndDrawDownDtls.setF_IN_dealID(dealId);
        prepareDisbursementAndDrawDownDtls.process(BankFusionThreadLocal.getBankFusionEnvironment());
        drawDownAndDownPaymentDetails = prepareDisbursementAndDrawDownDtls.getF_OUT_drawDownAndDownPaymentDtls();
        return drawDownAndDownPaymentDetails;
    }

    public static BFCurrencyAmount getZeroAmount(String currencyCode) {
        BFCurrencyAmount zeroAmount = new BFCurrencyAmount();
        zeroAmount.setCurrencyAmount(BigDecimal.ZERO);
        zeroAmount.setCurrencyCode(currencyCode);
        return zeroAmount;
    }

    public static ProfitCalculationRq prepareProfitCalculateObjRq(ScheduleDetailedInfo scheduleDetailedInfo,
        ScheduleBasicInfo scheduleBasicInfo, String profitMethod, String baseFactor) {

        ProfitCalculationRq profitCalculationRq = new ProfitCalculationRq();
        profitCalculationRq.setBaseFactor(baseFactor);
        profitCalculationRq.setProfitCalculationMettod(profitMethod);

        bf.com.misys.ib.types.CalculateInterest calculateInterestInput = new bf.com.misys.ib.types.CalculateInterest();

        calculateInterestInput.setEndDate(scheduleDetailedInfo.getLastPaymentDate());
        bf.com.misys.ib.types.Currency profitCost_Ccy = new bf.com.misys.ib.types.Currency();
        profitCost_Ccy.setIsoCurrencyCode(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyCode());
        profitCost_Ccy.setAmount(scheduleBasicInfo.getProfitCost().getCurrencyAmount());
        calculateInterestInput.setInterestCost(profitCost_Ccy);

        bf.com.misys.ib.types.Currency dealPrincipal = new bf.com.misys.ib.types.Currency();
        dealPrincipal.setIsoCurrencyCode(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyCode());
        dealPrincipal.setAmount(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyAmount());
        calculateInterestInput.setInterestPrinciple(dealPrincipal);

        calculateInterestInput.setNoOfPayments(scheduleDetailedInfo.getNoOfPayment());
        calculateInterestInput.setStartDate(scheduleDetailedInfo.getScheduleStartDate());
        calculateInterestInput.setInterestRate(scheduleDetailedInfo.getProfitRate());

        profitCalculationRq.setCalculateInterestInput(calculateInterestInput);
        return profitCalculationRq;
    }

    public static HashMap prepareCalculateProfitRq(ScheduleDetailedInfo scheduleDetailedInfoObj, ScheduleBasicInfo scheduleBasicInfo,
        ProductConfiguration productConfiguration, DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails,
        IslamicBankingObject islamicBankingObject, String pricingMethod, String profitMethod, String baseFactor) {

        scheduleDetailedInfoObj.setCalculatedProfit(CeUtils.getZeroAmount(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyCode()));
        ScheduleDetailedInfoList infoList = new ScheduleDetailedInfoList();
        infoList.addScheduleDetailedInfoList(scheduleDetailedInfoObj);
        Map inputParams = new HashMap();

        Currency schedulePrinciple = new Currency();
        schedulePrinciple.setIsoCurrencyCode(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyCode());
        schedulePrinciple.setAmount(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyAmount());
        inputParams.put("schedulePrinciple", schedulePrinciple);
        inputParams.put("PaymentOption", scheduleDetailedInfoObj.getPaymentOption());
        inputParams.put("scheduleEndDate", scheduleDetailedInfoObj.getScheduleEndDate());
        inputParams.put("scheduleStartDate", scheduleDetailedInfoObj.getScheduleStartDate());

        Currency remainingProfit = new Currency();
        remainingProfit.setIsoCurrencyCode(scheduleBasicInfo.getDealPrincipleAmt().getCurrencyCode());
        remainingProfit.setAmount(BigDecimal.ZERO);
        inputParams.put("RemainingProfit", remainingProfit);
        inputParams.put("principalPayment", scheduleBasicInfo.getDealPrincipleAmt().getCurrencyAmount());
        inputParams.put("profitMatrixId", pricingMethod);
        inputParams.put("ScheduleType", scheduleDetailedInfoObj.getScheduleType());
        inputParams.put("scheduleBasicInfo", scheduleBasicInfo);
        inputParams.put("scheduleDetailedInfoList", infoList);
        inputParams.put("ProfitCalculationRq", CeUtils.prepareProfitCalculateObjRq(scheduleDetailedInfoObj, scheduleBasicInfo, profitMethod,
        		baseFactor));
        inputParams.put("fromCalcProfit", true);
        inputParams.put("fromViewSch", false);
        inputParams.put("scheduleDetailedInfo", scheduleDetailedInfoObj);
        inputParams.put("dealID", islamicBankingObject.getDealID());
        inputParams.put("financeType", productConfiguration.getFinanceType());
        inputParams.put("isHostScheduleGenerator", productConfiguration.getIsHostScheduleGenerator());
        inputParams.put("productID", islamicBankingObject.getProductID());
        inputParams.put("subProductID", islamicBankingObject.getSubProductID());
        inputParams.put("drawDownAndDownPaymentDetails", drawDownAndDownPaymentDetails);
        inputParams.put("isCalculateConstructionProfit", true);
        inputParams.put("isCallFromFatom", true);

        HashMap outputParams =
            MFExecuter.executeMF("IB_IDI_CalculateProfit_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
        return outputParams;
    }

    public static void persistSchedule(ArrayList<PaymentSchedule> paymentScheduleList, String dealId) {
        ArrayList<String> params = new ArrayList<String>();
        params.add(dealId);
        String whereClause = " WHERE " + IBOIB_DLI_DealPaymentSchedule.DEALNO + " = ?";

        BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOIB_DLI_DealPaymentSchedule.BONAME, whereClause, params);
        BankFusionThreadLocal.getPersistanceFactory().commitTransaction();

        for (PaymentSchedule paymentSchedule : paymentScheduleList) {
            IBOIB_DLI_DealPaymentSchedule dealPaymentSchedule = (IBOIB_DLI_DealPaymentSchedule) (BankFusionThreadLocal
                .getPersistanceFactory().getStatelessNewInstance(IBOIB_DLI_DealPaymentSchedule.BONAME));
            dealPaymentSchedule.setF_CARRYOVERPROFITAMT(BigDecimal.ZERO);
            dealPaymentSchedule.setF_CHARGEAMT(BigDecimal.ZERO);
            dealPaymentSchedule.setF_DEALNO(dealId);
            dealPaymentSchedule.setF_OUTSTANDINGBALANCE(paymentSchedule.getOutstandingPrincipalAmt().getCurrencyAmount());
            dealPaymentSchedule.setF_OUTSTANDINGPROFITCOST(paymentSchedule.getOutstandingProfitCost().getCurrencyAmount());
            dealPaymentSchedule.setF_PAYMENTDT(paymentSchedule.getRepaymentDate());
            dealPaymentSchedule.setF_PRINCIPALAMT(paymentSchedule.getPrincipleAmt().getCurrencyAmount());
            dealPaymentSchedule.setF_PROFITAMT(paymentSchedule.getProfitAmt().getCurrencyAmount());
            dealPaymentSchedule.setF_PROFITRATE(paymentSchedule.getProfitRate());
            dealPaymentSchedule.setF_REPAYMENTAMT(paymentSchedule.getRepaymentAmt().getCurrencyAmount());
            dealPaymentSchedule.setF_REPAYMENTNUMBER(paymentSchedule.getRepaymentNo());
            dealPaymentSchedule.setF_REPAYMENTTYPE(paymentSchedule.getRepaymentType());
            BankFusionThreadLocal.getPersistanceFactory().create(IBOIB_DLI_DealPaymentSchedule.BONAME, dealPaymentSchedule);
        }
        BankFusionThreadLocal.getPersistanceFactory().commitTransaction();

    }

    public static IslamicBankingObject prepareIslamicBankingObject(String dealId) {
        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
        IslamicBankingObject bankingObject = new IslamicBankingObject();
        bankingObject.setDealID(dealDetails.getBoID());
        bankingObject.setCurrency(dealDetails.getF_IsoCurrencyCode());
        bankingObject.setParentDealID(dealDetails.getF_ParentDealNo());
        bankingObject.setProcessConfigID(dealDetails.getF_PROCESSCONFIGID());
        bankingObject.setProductID(dealDetails.getF_ProductCode());
        bankingObject.setSubProductID(dealDetails.getF_ProductContextCode());
        bankingObject.setStartDate(dealDetails.getF_DEALEFFECTIVEDT());
        return bankingObject;
    }

    /**
     * get the {@code AsstCategory} object by asset category id
     * 
     * @param asstCategoryId - asset category ID
     * @return {@code AsstCategory}
     */
    public static AsstCategory getAssetCategory(String asstCategoryId) {

        AsstCategory assetCategory = new AsstCategory();
        assetCategory.setCategory(asstCategoryId);
        String categoryHirachyName =
            AssetCategoryUtil.getCategoryQualifiedName(asstCategoryId, BankFusionThreadLocal.getPersistanceFactory(), null);
        categoryHirachyName = categoryHirachyName.replace(">", ">>");
        categoryHirachyName = (String) categoryHirachyName.subSequence(0, categoryHirachyName.lastIndexOf(">>"));
        assetCategory.setCategorization(categoryHirachyName);
        return assetCategory;
    }

    /**
     * A initial object set for {@code PriceListDto}
     * 
     * @return {@code PriceListDto}
     */
    public static final PriceListDto getPriceListDto() {
        PriceListDto priceList = new PriceListDto();
        PricingList pricingList = new PricingList();
        PricingListCfg pricingListCfg = new PricingListCfg();
        PricingListAssetCfg assetCfg = new PricingListAssetCfg();
        pricingList.addPricingListDtls(pricingListCfg);
        pricingList.addPricingListAssetDtls(assetCfg);
        priceList.setPricingList(pricingList);
        return priceList;

    }

    public static String getAssetSubsidyPercentage(ReadAssetData readAssetData, String assetId) {
        String udfIdForSubsidyPercentage = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.SUBSIDY_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION);
        return getAssetUDFs(readAssetData, assetId, udfIdForSubsidyPercentage);
    }

    public static String getUDFValueAssetToBeDisbursed(ReadAssetData readAssetData, String assetId) {

        /*
         * String udfIdForAssetDisbursed = BankFusionPropertySupport.getPropertyBasedOnConfLocation( CeConstants.UDFPROPERTY,
         * CeConstants.IS_ASSET_DISBURSED, "","BFIBconfigLocation");
         */
        String udfIdForAssetDisbursed = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.IS_ASSET_DISBURSED, "", CeConstants.ADFIBCONFIGLOCATION);

        return getAssetUDFs(readAssetData, assetId, udfIdForAssetDisbursed);
    }

    public static String getAssetUDFs(ReadAssetData readAssetData, String assetId, String UdfId) {
        for (AssetUDF list : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {
            if (null != UdfId && list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldId().equals(UdfId) && list.getAssetid().equals(assetId)) {
                return list.getFieldValue();
            }
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static UserDefinedFields getUserExtension(String dealId) {

        String dealNo = dealId;
        IBOIB_DLI_DealAditionalDtls dealAdditionalDetails = IBCommonUtils.getDealAdditionalDetails(dealNo);
        IBOUDFEXTIB_DLI_DealAditionalDtls iboudfextAddtionalDtl = (IBOUDFEXTIB_DLI_DealAditionalDtls) BankFusionThreadLocal
            .getPersistanceFactory().findByPrimaryKey(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, dealAdditionalDetails.getBoID(), true);
        UserDefinedFields additionalUdfs = null;
        UserDefinedFields userDefinedFields = new UserDefinedFields();
        if (null != iboudfextAddtionalDtl) {
            additionalUdfs = iboudfextAddtionalDtl.getUserDefinedFields();
            additionalUdfs.setAssociatedBoName("IB_DLI_DealAditionalDtls");
            for (UserDefinedFld eachUdf : additionalUdfs.getUserDefinedField()) {
                userDefinedFields.addUserDefinedField(eachUdf);
            }
        }
        return userDefinedFields;
    }

    public static BigDecimal getFeesAmount(String dealId) {
        String feeCollectionMethod = "";
        BigDecimal calcFeesAmount = BigDecimal.ZERO;
        String feeCollectionMethodId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.INITIAL_FEES_COLLECTION, "", CeConstants.ADFIBCONFIGLOCATION);

        UserDefinedFields userDefinedFields = getUserExtension(dealId);

        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(feeCollectionMethodId)) {
                feeCollectionMethod = (String) list.getFieldValue();
            }

        }
        if ("DEDUCT FROM DISBURSEMENT".equals(feeCollectionMethod)) {
            calcFeesAmount = getDealChargeAmount(dealId);
        }

        return calcFeesAmount;

    }

    public static BigDecimal getUpfrontProfitAmount(String dealId) {
        String upfrontProfitMethod = "";
        BigDecimal upfrontAmount = BigDecimal.ZERO;
        BigDecimal calcUpfrontAmount = BigDecimal.ZERO;
        String upfrontProfitMethodId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.UPFRONT_PROFIT_COLLECTION, "", CeConstants.ADFIBCONFIGLOCATION);
        String upfrontProfitAmountId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.UPFRONT_PROFIT_AMOUNT, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = getUserExtension(dealId);

        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(upfrontProfitMethodId)) {
                upfrontProfitMethod = (String) list.getFieldValue();
            }
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                && list.getFieldName().equals(upfrontProfitAmountId)) {
                upfrontAmount = (BigDecimal) list.getFieldValue();
            }
        }
        if ("DEDUCT FROM DISBURSEMENT".equals(upfrontProfitMethod)) {
            calcUpfrontAmount = upfrontAmount;
        }

        return calcUpfrontAmount;

    }

    public static void sortPaymentSchedule(List<LoanPayments> paymentScheduleList) {

        Collections.sort(paymentScheduleList, new Comparator<LoanPayments>() {

            public int compare(LoanPayments o1, LoanPayments o2) {
                if (o1 == null || o2 == null) {
                    return 0;
                }

                if (o1.getRepaymentDate() == null || o2.getRepaymentDate() == null) {
                    return 0;
                }

                return o1.getRepaymentDate().toString().compareTo(o2.getRepaymentDate().toString());
            }
        });
    }

    public static AssetUDF[] getAssetAttributes(String assetId, String dealId) {

        List<AssetUDF> assetUdfCollection = new ArrayList<AssetUDF>();
        ArrayList<String> param = new ArrayList<String>();
        param.add(assetId);
        param.add(dealId);
        String whereClause = "WHERE " + IBOIB_AST_AssetUdfDetails.ASSETID + " =? and " + IBOIB_AST_AssetUdfDetails.DEALID + "= ?";

        @SuppressWarnings("unchecked")
        List<IBOIB_AST_AssetUdfDetails> iboAssetudfDetails = (List<IBOIB_AST_AssetUdfDetails>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOIB_AST_AssetUdfDetails.BONAME, whereClause, param, null, true);

        if ((iboAssetudfDetails != null) && (iboAssetudfDetails.size() > 0)) {

            for (IBOIB_AST_AssetUdfDetails iboAssetudfDetail : iboAssetudfDetails) {

                AssetUDF assetUdf = new AssetUDF();
                assetUdf.setAssetid(assetId);
                assetUdf.setFieldId(iboAssetudfDetail.getF_FIELDID());
                assetUdf.setFieldValue(iboAssetudfDetail.getF_FIELDVALUE());
                assetUdfCollection.add(assetUdf);
            }

        }
        return assetUdfCollection.toArray(new AssetUDF[assetUdfCollection.size()]);
    }

    public static void persistAssetUDFs(String dealId, String assetId, AssetUDFsCollection technicalAssetUDFs) {

        ArrayList<String> params = new ArrayList<>();
        params.add(assetId);
        StringBuffer whereClause = new StringBuffer("WHERE " + IBOIB_AST_AssetUdfDetails.ASSETID + "=? ");
		if (null != technicalAssetUDFs && technicalAssetUDFs.getAssetUDFsCount() > 0) {
			/*
			 * for (AssetUDF assetUDF : technicalAssetUDFs.getAssetUDFs()) { whereClause =
			 * whereClause.append(" ? ,"); params.add(assetUDF.getFieldId()); }
			 */
			// whereClause = new StringBuffer(whereClause.substring(0,
			// whereClause.lastIndexOf(","))).append(")");
			IBCommonUtils.getPersistanceFactory().bulkDelete(IBOIB_AST_AssetUdfDetails.BONAME, whereClause.toString(),params);
			IBCommonUtils.getPersistanceFactory().commitTransaction();
		}
        
        if (technicalAssetUDFs != null && technicalAssetUDFs.getAssetUDFsCount() > 0) {
            for (AssetUDF assetUDF : technicalAssetUDFs.getAssetUDFs()) {
                if (!IBCommonUtils.isNullOrEmpty(assetUDF.getFieldValue()) && !IBCommonUtils.isNullOrEmpty(assetId)
                    && assetId.equalsIgnoreCase(assetUDF.getAssetid())) {
                    IBOIB_AST_AssetUdfDetails iboAssetUdfDetail = (IBOIB_AST_AssetUdfDetails) IBCommonUtils.getPersistanceFactory()
                        .getStatelessNewInstance(IBOIB_AST_AssetUdfDetails.BONAME);
                    iboAssetUdfDetail.setF_ASSETID(assetId);
                    iboAssetUdfDetail.setF_FIELDID(assetUDF.getFieldId());
                    iboAssetUdfDetail.setF_FIELDVALUE(assetUDF.getFieldValue());
                    iboAssetUdfDetail.setF_DEALID(dealId);
                    IBCommonUtils.getPersistanceFactory().create(IBOIB_AST_AssetUdfDetails.BONAME, iboAssetUdfDetail);
                }
            }
        }
    }

    public static String getPaymentFrequency(FinancialInfoDetail financialInfoDetail) {
        String paymentFrequency = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.PAYMENT_FREQUENCY, "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(paymentFrequency))
                    return (String) list.getFieldValue();
            }
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static BigDecimal getProfitRate(FinancialInfoDetail financialInfoDetail) {
        String profitRate = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, CeConstants.PROFIT_RATE, "",
            CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(profitRate))
                    return (BigDecimal) list.getFieldValue();
            }
        }
        return BigDecimal.ZERO;
    }

    public static Integer getGraceInPeriod(FinancialInfoDetail financialInfoDetail) {
        String gracePeriodInYears = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.GRACE_PERIOD_IN_YEARS, "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(gracePeriodInYears))
                    return (Integer) list.getFieldValue();
            }
        }
        return new Integer(0);
    }

    public static BigDecimal getScheduleProfit(FinancialInfoDetail financialInfoDetail) {
        String scheduleProfit = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.SCHEDULE_PROFIT, "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(scheduleProfit))
                    return (BigDecimal) list.getFieldValue();
            }
        }
        return BigDecimal.ZERO;
    }

    public static String getProfitDistributionMethod(FinancialInfoDetail financialInfoDetail) {
        String profitDistributionMethod = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.PROFIT_DISTRIBUTION_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(profitDistributionMethod))
                    return (String) list.getFieldValue();
            }
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static String getPricingMethod(FinancialInfoDetail financialInfoDetail) {
        String pricingMethod = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, CeConstants.PRICING_METHOD,
            "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(pricingMethod))
                    return (String) list.getFieldValue();
            }
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static String getProfitMethod(FinancialInfoDetail financialInfoDetail) {
        String profitMethod = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, CeConstants.PROFIT_METHOD,
            "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(profitMethod))
                    return (String) list.getFieldValue();
            }
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static String getCollectionAccountValue(String dealID) {
        IBOUDFEXTIB_DLI_DealDetails iboudfextib_DLI_DealDetails = getDealDetailsExtensionDtls(dealID);
        String collectionAccount = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.Collection_Account, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = iboudfextib_DLI_DealDetails.getUserDefinedFields();
        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(collectionAccount))
                return (String) list.getFieldValue();
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static String getCreditAccountValue(String dealID) {
        IBOUDFEXTIB_DLI_DealDetails iboudfextib_DLI_DealDetails = getDealDetailsExtensionDtls(dealID);
        String collectionAccount = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.Credit_Account, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = iboudfextib_DLI_DealDetails.getUserDefinedFields();
        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(collectionAccount))
                return (String) list.getFieldValue();
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static Object getUDFValueByName(String dealID, String udfName) {
        IBOUDFEXTIB_DLI_DealDetails iboudfextib_DLI_DealDetails = getDealDetailsExtensionDtls(dealID);
        String udfKey =
            BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, udfName, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = iboudfextib_DLI_DealDetails.getUserDefinedFields();
        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(udfKey))
                return list.getFieldValue();
        }
        return CommonConstants.EMPTY_STRING;
    }

    public static IBOUDFEXTIB_DLI_DealDetails getDealDetailsExtensionDtls(String dealID) {
        IBOUDFEXTIB_DLI_DealDetails dealDtl_UDF = (IBOUDFEXTIB_DLI_DealDetails) BankFusionThreadLocal.getPersistanceFactory()
            .findByPrimaryKey(IBOUDFEXTIB_DLI_DealDetails.BONAME, dealID, true);

        return dealDtl_UDF;
    }

    public static Object getUDFValueByNameFromAdditionalDtls(String dealID, String udfName) {
      
        ArrayList<Object> params = new ArrayList<Object>();
        params.add(dealID);
        List<IBOIB_DLI_DealAditionalDtls> dealAdditionalDetails = (List) IBCommonUtils.getBankFusionEnvironment().getFactory()
            .findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, params, null, false);
        IBOUDFEXTIB_DLI_DealAditionalDtls iboudfextib_DLI_DealAdditionalDetails =
            getDealAdditionalDetailsExtensionDtls(dealAdditionalDetails.get(0).getBoID());
        String udfKey =
            BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, udfName, "", CeConstants.ADFIBCONFIGLOCATION);
        UserDefinedFields userDefinedFields = iboudfextib_DLI_DealAdditionalDetails.getUserDefinedFields();
        for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
            if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty() && list.getFieldName().equals(udfKey))
                return list.getFieldValue();
        }
        return CommonConstants.BIGDECIMAL_ZERO;
    }

    public static IBOUDFEXTIB_DLI_DealAditionalDtls getDealAdditionalDetailsExtensionDtls(String boID) {
        IBOUDFEXTIB_DLI_DealAditionalDtls dealDtl_UDF = (IBOUDFEXTIB_DLI_DealAditionalDtls) BankFusionThreadLocal.getPersistanceFactory()
            .findByPrimaryKey(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, boID, true);
        return dealDtl_UDF;
    }

    public static BigDecimal getUpfrontProfitPercentage(FinancialInfoDetail financialInfoDetail) {

        String upfrontProfitPercentage = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
            CeConstants.UPFRONT_PROFIT_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION);
        if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(upfrontProfitPercentage))
                    return (BigDecimal) list.getFieldValue();
            }
        }
        return BigDecimal.ZERO;
    }

    public static String getProductName(String productCode) {
        String productName = PanelUtils.getCodeDescr(productCode, DealInitiationConstants.PRODUCTNAME);
        return productName;
    }

    public static String getProcessName(String processConfigId) {

        IBOIB_CFG_ProcessConfig processConfig = IBCommonUtils.getProcessConfigByPrimaryKey(processConfigId);
        String procesName = processConfig.getF_PROCESSTYPE();
        return procesName;
    }

    public static HashMap getCustomerDtls(String dealId, String parentDealId) {
        String customerName = "";
        HashMap<String, String> customerDtls = new HashMap<>();
        IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(dealId);

        if (null == dealCustomerDetail && IBCommonUtils.isNotEmpty(parentDealId)) {
            dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(parentDealId);
        }

        if (null != dealCustomerDetail) {
            customerName = PanelUtils.readPartyDetails(dealCustomerDetail.getF_CUSTOMERID());
        }
        customerDtls.put("CUSTOMERID", dealCustomerDetail.getF_CUSTOMERID());
        customerDtls.put("CUSTOMERNAME", customerName);
        return customerDtls;
    }

	public static RetrievePartyBasicDetailsRs readDealPartyDetails(String dealID) {
		IBOIB_IDI_DealCustomerDetail customerDtls = IBCommonUtils.getDealPrimaryPartyDetails(dealID);
		String partyId = customerDtls.getF_CUSTOMERID();
		RetrievePartyBasicDetailsRq partyInput = new RetrievePartyBasicDetailsRq();
		RetrievePartyBasicDetailsInput detailsInput = new RetrievePartyBasicDetailsInput();
		detailsInput.setPartyId(partyId);
		partyInput.setRetrievePartyBasicDetailsRq(detailsInput);

		HashMap<String, RetrievePartyBasicDetailsRq> inputs = new HashMap<String, RetrievePartyBasicDetailsRq>();
		inputs.put(RescheduleConstants.RetrievePartyBasicDetailsRq, partyInput);
		HashMap partyOutput = MFExecuter.executeMF(RescheduleConstants.IB_PTY_RetrievePartyBasicDetails_SRV, inputs,
				BankFusionThreadLocal.getUserLocator().getStringRepresentation());
		RetrievePartyBasicDetailsRs partyDetails = (RetrievePartyBasicDetailsRs) partyOutput
				.get(RescheduleConstants.RetrievePartyBasicDetailsRs);
		return partyDetails;
	}
	public static boolean checkIfCooperativeParty(String dealID) {
		String partySubtype = CeUtils.readDealPartyDetails(dealID)
				.getRetrievePartyBasicDetailsRs().getPartyBasicDtls().getPartySubType();
		String cooperativeAssPartySubType = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.CO_OPERATIVE_ASSOCIATION_PARTY, "",
				CeConstants.ADFIBCONFIGLOCATION);
		
		return partySubtype.equals(cooperativeAssPartySubType);
	}
    public static String getBBMode(IslamicBankingObject islamicBankingObject) {
        PopulateIBBuildingBlock popBBDetails = new PopulateIBBuildingBlock(IBCommonUtils.getBankFusionEnvironment());
        popBBDetails.setF_IN_buildingBlockID(islamicBankingObject.getPhaseID());
        popBBDetails.setF_IN_TransactionID(islamicBankingObject.getTransactionID());
        popBBDetails.setF_IN_TransactionName(islamicBankingObject.getTransactionName());
        popBBDetails.setF_IN_isDealEnquiry(islamicBankingObject.getIsDealEnquiry());
        popBBDetails.setF_IN_processConfigID(islamicBankingObject.getProcessConfigID());
        popBBDetails.setF_IN_productCode(islamicBankingObject.getProductID());
        popBBDetails.setF_IN_productType(islamicBankingObject.getSubProductID());
        popBBDetails.setF_IN_stepID(islamicBankingObject.getStepID());
        popBBDetails.process(IBCommonUtils.getBankFusionEnvironment());
        return popBBDetails != null ? popBBDetails.getF_OUT_mode() : CommonConstants.EMPTY_STRING;
    }

    public static int getSubsidyHandlingPeriodConfigured() {
        String subsidyHandlingPeriodInMonths = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOWUP_PROPERTY_FILE,
            CeConstants.SUBSIDY_HANDLING_PERIOD_IN_MONTHS, "", CeConstants.ADFIBCONFIGLOCATION);
        return subsidyHandlingPeriodInMonths != null ? Integer.valueOf(subsidyHandlingPeriodInMonths) : 0;
    }

    public static HashMap<String, Object> getAssetUDFForAPI(String assetCategoryId, String dealId, AssetUDF[] assetUDFs) {
        HashMap<String, Object> assetUDFMap = new HashMap<>();
        List<AdditionalFieldInfo> additionalFieldInfoList = APIUtils.getAssetCategoryAddInfo(assetCategoryId, dealId);
        List<AssetAttributeInfo> assetAttributeList = APIUtils.getAssetCategoryAttributes(assetCategoryId, dealId);
        if (assetUDFs != null && assetUDFs.length > 0) {
            if (additionalFieldInfoList != null && !additionalFieldInfoList.isEmpty()) {
                for (AssetUDF assetUdf : assetUDFs) {
                    for (AdditionalFieldInfo additionalFieldInfo : additionalFieldInfoList) {
                        if (additionalFieldInfo.getAdditionalFieldDetails().getKey().equals(assetUdf.getFieldId()))
                            additionalFieldInfo.getAdditionalFieldDetails().setValue(assetUdf.getFieldValue());
                    }
                }
            }
            if (assetAttributeList != null && !assetAttributeList.isEmpty()) {
                for (AssetUDF assetUdf : assetUDFs) {
                    for (AssetAttributeInfo assetAttributeInfo : assetAttributeList) {
                        if (assetAttributeInfo.getAssetAttributeDetails().getKey().equals(assetUdf.getFieldId()))
                            assetAttributeInfo.getAssetAttributeDetails().setValue(assetUdf.getFieldValue());
                    }
                }
            }
        }
        assetUDFMap.put("additionalFieldInfoList", additionalFieldInfoList);
        assetUDFMap.put("assetAttributeList", assetAttributeList);
        return assetUDFMap;
    }

    public static BigDecimal getDealChargeAmount(String dealId) {
        BigDecimal paidFees = BigDecimal.ZERO;
        String whereClause = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ? AND " + IBOIB_DLI_DealAssetChargesdtls.ISUPFRONT
            + "='Y' AND " + IBOIB_DLI_DealAssetChargesdtls.ISWAIVED + " = 'N' AND " + IBOIB_DLI_DealAssetChargesdtls.CHARGEPAYMENTSTATUS
            + " = 'UNPAID'";
        ArrayList<String> params = new ArrayList<String>();
        params.add(dealId);
        List<IBOIB_DLI_DealAssetChargesdtls> list = new ArrayList<IBOIB_DLI_DealAssetChargesdtls>();
        list = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, whereClause, params, null,
            false);
        if (list.size() > 0) {
            IBOIB_DLI_DealAssetChargesdtls rec = list.get(0);
            paidFees = rec.getF_ChargeAmount();
        }
        return paidFees;
    }
    public static boolean isloggedInUserFromAdfFollowUpUserGroup() {
        String adfFollowUpUser = IBCommonUtils.getModuleConfigurationValue(CeConstants.ADF_FOLLOW_UP_USER_BRANCH_GROUP).getValue();
        String groupName = adfFollowUpUser.toUpperCase();
        List<IBOOrganisationGroup> groupList = new ArrayList<IBOOrganisationGroup>();
        ArrayList<String> params = new ArrayList<String>();
        String QUERY = null;
        QUERY = "WHERE UPPER(" + IBOOrganisationGroup.GROUPNAME + ")=?";
        params.add(groupName);
        if (!IBCommonUtils.isNullOrEmpty(groupName)) {
            groupList = (List<IBOOrganisationGroup>)  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOOrganisationGroup.BONAME, QUERY, params, null, false);
            params.clear();
            if(!IBCommonUtils.isNullOrEmpty(groupList)) {
            params.add(groupList.get(0).getBoID());
            String query = "WHERE " + IBOOrganisationGroupUser.GROUPID + " = ?";
            List<IBOOrganisationGroupUser> users =  BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOOrganisationGroupUser.BONAME, query, params, null, true);
            if (null != users && !users.isEmpty()) {
                for (IBOOrganisationGroupUser user : users) {
                    if (user.getF_USERNAME().equals(IBCommonUtils.getUserId())) {
                        return true;
                    }
                }
            }
            }
        }
        return false;
    }
    
    public static UserList getUserList(String branchCode) {
        UserList user = new UserList();
        List<IBOUser> userList = null;
        if (!IBCommonUtils.isNullOrEmpty(branchCode)) {           
            ArrayList<String> params = new ArrayList<String>();
            String QUERY = "WHERE UPPER(" + IBOUser.BRANCHSORTCODE + ")=?";
            params.add(branchCode);
            userList = (List<IBOUser>) BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOUser.BONAME, QUERY, params, null, false);
        }          
        else  userList = (List<IBOUser>) BankFusionThreadLocal.getPersistanceFactory().findAll(IBOUser.BONAME, null, true);

        if (userList != null && !(userList.isEmpty())) {
            for (IBOUser userListDB : userList) {
                UserDetails userDetails = new UserDetails();
                userDetails.setSelect(false);
                userDetails.setUserName(userListDB.getBoID());
                user.addUserDetailsList(userDetails);
            }
        }
        return user;
    }
    
    public static String getUserBranchCode() {
        return BankFusionThreadLocal.getUserSession().getBranchSortCode();
      }
    
    public static String getUDFIDForPaymentFrequency() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.PAYMENT_FREQUENCY, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForProfitRate() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.PROFIT_RATE, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForUpfrontProfitPercentage() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.UPFRONT_PROFIT_PER_UDF, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForUpfrontProfitAmnt() {
  		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
  				CeConstants.UPFRONT_PROFIT_AMOUNT, "", CeConstants.ADFIBCONFIGLOCATION);
  	}
    
    public static String getUDFIDForScheduleProfitAmnt() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.SCHEDULE_PROFIT, "", CeConstants.ADFIBCONFIGLOCATION);
	}
  
    public static String getUDFIDForScheduleProfitPercentage() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.SCHEDULE_PROFIT_PERCENTAGE, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForProfitAmount() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.PROFIT_AMOUNT, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForUpfrontProfitCollMethod() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.UPFRONT_PROFIT_COLLECTION_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    
    public static String getUDFIDForPricingMethod() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.PRICING_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    public static String getUDFIDForProfitMethod() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.PROFIT_METHOD, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    public static String getUDFIDForDealEffectiveDate() {
		return BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.DEAL_EFFECTIVE_DATE_UDF, "", CeConstants.ADFIBCONFIGLOCATION);
	}
    public static String getEventCodeMsg(String eventCodeNumber) {
    	Map inputParams = new HashMap();
    	inputParams.put("EventCodeNumber", eventCodeNumber);
    	 HashMap outputParams =
    	            MFExecuter.executeMF("CB_CMN_GetEventCodeDescription_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
    	if(outputParams != null && !outputParams.isEmpty()) {
    		if(outputParams.get("EventCodeDescription") != null)
    			return outputParams.get("EventCodeDescription").toString();
    	}
    	return null;
	}
    
    public static String getSurplusAccount(String loanAcctNo) {
 	   IBOUB_CNF_SurplusAccountDetails surplusAccountDetails = (IBOUB_CNF_SurplusAccountDetails) 
 			   IBCommonUtils.getPersistanceFactory().findByPrimaryKey(IBOUB_CNF_SurplusAccountDetails.BONAME, loanAcctNo, true);
 	   if(surplusAccountDetails != null)
 		   return surplusAccountDetails.getF_UBSURPLUSACCOUNT();
         return null;
 	}
	
	public static Object getUDFValueByNameFromDealDtls(String dealID, String udfName) {
        
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        
        ArrayList<String> queryParams = new ArrayList<String>();
        queryParams.add(dealID);
  
        List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD = factory
            .findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClauseDeal, queryParams, null, true);
        
        String udfKey =
            BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY, udfName, "", CeConstants.ADFIBCONFIGLOCATION);
        
        for (IBOUDFEXTIB_DLI_DealDetails eachDealDetailsUD : dealDetailsUD) {
            UserDefinedFields userDefinedFields = eachDealDetailsUD.getUserDefinedFields();
            if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
              for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
                if (userDefinedFld.getFieldName().equals(udfKey)) {
                  return userDefinedFld.getFieldValue();
                }
              }
            }
          }
        
        return CommonConstants.BIGDECIMAL_ZERO;
    }
	
	public static void updateIsDealFullyDisbursed(String dealNo)
	{
		ReadLoanDetailsRs loanDetails = IBCommonUtils.getLoanDetails(dealNo);
		BigDecimal totalDisbursedAmt = loanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount();
		BigDecimal totalPrincipalAmt = loanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt();
		if(totalPrincipalAmt.compareTo(totalDisbursedAmt) == 0)
		{
			IBOUDFEXTIB_DLI_DealDetails dealDtl_UDF = (IBOUDFEXTIB_DLI_DealDetails) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOUDFEXTIB_DLI_DealDetails.BONAME, dealNo, true);
			dealDtl_UDF.setValueOfCustomField(getIsDealFullyDisbursedUDFId(), "Y");
		}
		else
		{
			IBOUDFEXTIB_DLI_DealDetails dealDtl_UDF = (IBOUDFEXTIB_DLI_DealDetails) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOUDFEXTIB_DLI_DealDetails.BONAME, dealNo, true);
			dealDtl_UDF.setValueOfCustomField(getIsDealFullyDisbursedUDFId(), "N");

		}
	}
	public static String getIsDealFullyDisbursedUDFId()
	{
		String isDealFullyDisbursedUDFId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.UDFPROPERTY, CeConstants.IS_DEAL_FULLY_DISBURSED, "",
				CeConstants.ADFIBCONFIGLOCATION);
		return isDealFullyDisbursedUDFId;
	}
	
	public static String getDealStatusDesc(String statusCode)
	{
		String codeDesc;
        HashMap map = new HashMap();
        HashMap result = null;
        map.put("CodeDefReference", "DEALSTATUS");
        map.put("CodeId", 0);
        map.put("reference", statusCode);
        // Calling MF to get Description for Generic Code Parameter
        result = MFExecuter.executeMF("CB_GCD_GetCode_SRV", 
                map, BankFusionThreadLocal.getUserLocator().getStringRepresentation());
        codeDesc = (String) result.get("strDesc");
        return codeDesc; 
	}
	
	public static ArrayList<CustomerLiabilitiesExt> getCustomerLiabilityDetail(String customerId) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<HashMap> dealInfos = getDealIdsByCustomerId(customerId);
		ArrayList<CustomerLiabilitiesExt> listCustLiab = new ArrayList<CustomerLiabilitiesExt>();
		CustomerLiabilitiesExt eachCustLiab = null;
			for (int i = 0; i < dealInfos.size(); i++) {
				IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
						.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, (String) dealInfos.get(i).get("dealId"), true);
				if (null !=dealDetails.getF_DealAccountId()
						&& !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {
					eachCustLiab = new CustomerLiabilitiesExt();
					HashMap outstandingDtl = getOutstandingDetail((String) dealInfos.get(i).get("dealId"));
					eachCustLiab.setDealAccountID(dealDetails.getF_DealAccountId());
					CurrencyAmount bfCurrencyAmount = new CurrencyAmount();
					bfCurrencyAmount.setCurrency(dealDetails.getF_IsoCurrencyCode());
					bfCurrencyAmount.setAmount((BigDecimal)outstandingDtl.get("OUTSTANDINGAMOUNT"));
					eachCustLiab.setLiabilityAmount(bfCurrencyAmount);
					eachCustLiab.setDuedate((Date)outstandingDtl.get("DUEDATE"));
					if(bfCurrencyAmount.getAmount().compareTo(BigDecimal.ZERO)>0) {
						listCustLiab.add(eachCustLiab);
					}
				}
			}
		return listCustLiab;
	}
public static ArrayList<bf.com.misys.ib.types.CustomerLiabilities> getCustomerLiabilities(String customerId) {
		
		ListGenericCodeRs associationTypes = IBCommonUtils.getGCList("ASSCTYPE");
		ListGenericCodeRs relationshipTypes = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
		Map<String, String> gcCodes = new HashMap<>();
		for (GcCodeDetails gcCodeDetails : associationTypes.getGcCodeDetails()) {
			gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
		}
		for (GcCodeDetails gcCodeDetails : relationshipTypes.getGcCodeDetails()) {
			gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
		}

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<HashMap> dealInfos = getDealIdsByCustomerId(customerId);
		//bf.com.misys.ib.types.CustomerLiabilities eachCustLiab = new bf.com.misys.ib.types.CustomerLiabilities();
		ArrayList<bf.com.misys.ib.types.CustomerLiabilities> listCustLiab = new ArrayList<bf.com.misys.ib.types.CustomerLiabilities>();

		if (null != dealInfos && dealInfos.size() > 0) {
			for (int i = 0; i < dealInfos.size(); i++) {
				IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
						.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, (String) dealInfos.get(i).get("dealId"), true);
				if (null !=dealDetails.getF_DealAccountId()
						&& !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {
					 CustomerLiabilities eachCustLiab = new CustomerLiabilities();
					eachCustLiab.setDealId((String) dealInfos.get(i).get("dealId"));

					BigDecimal outstandingAmt = getOutstandingAmt(eachCustLiab.getDealId());
					BFCurrencyAmount bfCurrencyAmount = new BFCurrencyAmount();
					bfCurrencyAmount.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					bfCurrencyAmount.setCurrencyAmount(outstandingAmt);
					eachCustLiab.setLiabilityAmount(bfCurrencyAmount);
					eachCustLiab.setLiabilityToBePaid(bfCurrencyAmount);
					eachCustLiab.setDealAccountID(dealDetails.getF_DealAccountId());
					eachCustLiab.setSelect(false);
					String userRoleRef = (String) dealInfos.get(i).get("userRole");
					eachCustLiab.setUserRole(gcCodes.get(userRoleRef));
					eachCustLiab.setPurchaseOrderID(userRoleRef);
					//if (outstandingAmt.compareTo(BigDecimal.ZERO) > 0) {
					listCustLiab.add(eachCustLiab);
						//liabilitytoBepaid = liabilitytoBepaid.add(outstandingAmt);
					//}
				}
			}
		}

		return listCustLiab;

	}
	
	public static  BigDecimal getOutstandingAmt(String dealId) {

		BigDecimal outstandingAmt = BigDecimal.ZERO;
		ReadLoanDetailsRs readLoanRs = null;
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())) {
						bf.com.misys.ib.spi.types.PaymentSchedule paymentSchedule = new bf.com.misys.ib.spi.types.PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						outstandingAmt = outstandingAmt.add(paymentSchedule.getRepaymentAmt());
					}
				}
			}

			// outstandingAmt =
			// readLoanRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount();

			for (LoanPayments paymentSch : readLoanRs.getDealDetails().getPaymentSchedule()) {
				if (CalendarUtil.IsDate1EqualsToDate2(paymentSch.getRepaymentDate(),IBCommonUtils.getBFBusinessDate())
						&& paymentSch.getRepaymentAmtUnPaid().compareTo(BigDecimal.ZERO) > 0) {
					EarlyAssetPayoffUtils assetPayoffUtils = new EarlyAssetPayoffUtils();
					List<IBOCE_IB_EarlyAssetPayoffDtls> earlyAssetDtls = assetPayoffUtils
							.getReschReqExistingObjStatusCompleted(dealId);
					if (null != earlyAssetDtls && earlyAssetDtls.size() > 0) {
						Timestamp earlyAssetDate = earlyAssetDtls.get(0).getF_IBRECLASTMODIFIEDDATE();
						if (earlyAssetDate.equals(IBCommonUtils.getBFBusinessDateTime())) {
							outstandingAmt = outstandingAmt.add(paymentSch.getRepaymentAmtUnPaid());
						}
					}
				}
				{

				}
			}
		}
		return IBCommonUtils.scaleAmount(IBCommonUtils.getDealDetails(dealId).getF_IsoCurrencyCode(), outstandingAmt);
		}

	public static HashMap getOutstandingDetail(String dealId) {
		HashMap details = new HashMap();
		BigDecimal outstandingAmt = BigDecimal.ZERO;
		Date dueDate = null;
		ReadLoanDetailsRs readLoanRs = null;
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
									row.getRepaymentDate())) {
						bf.com.misys.ib.spi.types.PaymentSchedule paymentSchedule = new bf.com.misys.ib.spi.types.PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						outstandingAmt = outstandingAmt.add(paymentSchedule.getRepaymentAmt());
						dueDate = row.getRepaymentDate();
					}
				}
			}

			// outstandingAmt =
			// readLoanRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount();

			for (LoanPayments paymentSch : readLoanRs.getDealDetails().getPaymentSchedule()) {
				if (CalendarUtil.IsDate1EqualsToDate2(paymentSch.getRepaymentDate(), IBCommonUtils.getBFBusinessDate())
						&& paymentSch.getRepaymentAmtUnPaid().compareTo(BigDecimal.ZERO) > 0) {
					EarlyAssetPayoffUtils assetPayoffUtils = new EarlyAssetPayoffUtils();
					List<IBOCE_IB_EarlyAssetPayoffDtls> earlyAssetDtls = assetPayoffUtils
							.getReschReqExistingObjStatusCompleted(dealId);
					if (null != earlyAssetDtls && earlyAssetDtls.size() > 0) {
						Timestamp earlyAssetDate = earlyAssetDtls.get(0).getF_IBRECLASTMODIFIEDDATE();
						if (earlyAssetDate.equals(IBCommonUtils.getBFBusinessDateTime())) {
							outstandingAmt = outstandingAmt.add(paymentSch.getRepaymentAmtUnPaid());
							dueDate = paymentSch.getRepaymentDate();
						}
					}
				}
				{

				}
			}
		}
		details.put("OUTSTANDINGAMOUNT", IBCommonUtils.scaleAmount(IBCommonUtils.getDealDetails(dealId).getF_IsoCurrencyCode(), outstandingAmt));
		details.put("DUEDATE", dueDate);
		return details;
	}
	

	public static ArrayList getDealIdsByCustomerId(String customerID) {

		String GET_DEALID_FROM_RELATIONSHIP = " WHERE " + IBOCE_IB_DealRelationshipDetails.IBPARTYID + " = ?";
		String GET_DEALID_BY_CUST = " WHERE " + IBOIB_IDI_DealCustomerDetail.CUSTOMERID + " = ?";
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList dealInfos = new ArrayList<>();
		List<String> relationshipTypeslist = new ArrayList<>();
		String partyId = customerID;
		ArrayList params = new ArrayList();
		params.add(partyId);
		List<IBOIB_IDI_DealCustomerDetail> customerDeals = (List<IBOIB_IDI_DealCustomerDetail>) factory
				.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, GET_DEALID_BY_CUST, params, null, true);
		if (null != customerDeals && customerDeals.size() > 0) {
			for (int i = 0; i < customerDeals.size(); i++) {
				HashMap dealDtls = new HashMap<>();
				String userRole = customerDeals.get(i).getF_ASSOCIATIONTYPE();
				String eachDealIdByCustomer = customerDeals.get(i).getF_DEALID();

				dealDtls.put("userRole", userRole);
				dealDtls.put("dealId", eachDealIdByCustomer);
				dealInfos.add(dealDtls);
			}
		}
		String relationshipTypes = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.RELATIONSHIP_TYPES_CONF_FILE, CeConstants.RELATIONSHIP_TYPES, "",
				CeConstants.ADFIBCONFIGLOCATION);

		if (relationshipTypes != null && !relationshipTypes.isEmpty()) {
			relationshipTypeslist = IBCommonUtils.isNotEmpty(relationshipTypes)
					? Arrays.asList(relationshipTypes.split(","))
					: new ArrayList<String>();
		}
		List<IBOCE_IB_DealRelationshipDetails> dealsFromRelationship = (List<IBOCE_IB_DealRelationshipDetails>) factory
				.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, GET_DEALID_FROM_RELATIONSHIP, params, null, true);
		for (IBOCE_IB_DealRelationshipDetails iboce_IB_DealRelationshipDetails : dealsFromRelationship) {
			if (relationshipTypeslist.contains(iboce_IB_DealRelationshipDetails.getF_IBRELATIONSHIPTYPE())) {
				HashMap dealDtls = new HashMap<>();
				String userRole = iboce_IB_DealRelationshipDetails.getF_IBRELATIONSHIPTYPE();
				String eachDealIdByCustomer = iboce_IB_DealRelationshipDetails.getF_IBDEALID();

				dealDtls.put("userRole", userRole);
				dealDtls.put("dealId", eachDealIdByCustomer);
				dealInfos.add(dealDtls);
			}
		}
		return dealInfos;
	}
  public static BigDecimal calculateTaxOnFees(BigDecimal feesToBePaid, String property) {
      BigDecimal taxAmount=BigDecimal.ZERO;
      BigDecimal taxPercentage =new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
          property, "", CeConstants.ADFIBCONFIGLOCATION));
      taxAmount= feesToBePaid.multiply(taxPercentage).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
     return taxAmount;
  }
}
