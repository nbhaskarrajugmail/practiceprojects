package com.ce.bankfusion.ib.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.encryption.client.data.EncryptedData;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.messaging.webservice.runtime.impl.LoginInputRequest;
import com.misys.bankfusion.subsystem.messaging.webservice.runtime.impl.LogoutInputRequest;
import com.misys.bankfusion.subsystem.messaging.webservice.runtime.impl.ServiceResult;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.security.IEncryptionService;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.common.functions.CB_CMN_AutoNumber;
import com.misys.ib.api.bb.dto.IBSetReqPayload;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

import bf.com.misys.ib.types.DebtTrnsfrDeal;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.TrnsfDbtsRequest;

public class TransferOfDebtsUtil {
	
	private static final Log LOGGER = LogFactory.getLog(TransferOfDebtsUtil.class);
	
	public static final String API_METHOD_POST = "POST";
	public static final String IB_TECH_USER_ALIAS = "ibtechuser";
	
	public static void saveTDDtls(DebtTrnsfrDeal debtTrnsfrdDeal, TrnsfDbtsRequest transferOfDebtsRq, boolean isTroubleProjectRequested)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_TransferOfDebtDtls transferOfDebtsDtl = (IBOCE_IB_TransferOfDebtDtls) factory.getStatelessNewInstance(IBOCE_IB_TransferOfDebtDtls.BONAME);
		transferOfDebtsDtl.setF_IBNEWCUSTID(debtTrnsfrdDeal.getNewCustID());
		transferOfDebtsDtl.setF_IBNEWDEALID(debtTrnsfrdDeal.getNewDealID());
		transferOfDebtsDtl.setF_IBOLDCUSTID(debtTrnsfrdDeal.getCustID());
		transferOfDebtsDtl.setF_IBOLDDEALID(debtTrnsfrdDeal.getDealID());
		transferOfDebtsDtl.setF_IBTDREQDATE(transferOfDebtsRq.getRequestDate());
		transferOfDebtsDtl.setF_IBTDREQID(transferOfDebtsRq.getRequestID());
		transferOfDebtsDtl.setF_IBOSDEALAMT(debtTrnsfrdDeal.getNewDealAmt().getCurrencyAmount());
		transferOfDebtsDtl.setF_IBOSPRINCIPALAMT(debtTrnsfrdDeal.getNewPrincipalAmt().getCurrencyAmount());
		transferOfDebtsDtl.setF_IBOSPROFITAMT(debtTrnsfrdDeal.getNewProfitAmt().getCurrencyAmount());
		transferOfDebtsDtl.setF_IBTDSTATUS(CeConstants.TD_STATUS_SCHEDULED);
		transferOfDebtsDtl.setF_IBTDREQNOTE(transferOfDebtsRq.getRequestNote());
		transferOfDebtsDtl.setBoID(GUIDGen.getNewGUID());
		transferOfDebtsDtl.setF_IBTRBLPRJTRQSTED(isTroubleProjectRequested);
		factory.create(IBOCE_IB_TransferOfDebtDtls.BONAME, transferOfDebtsDtl);
	}
	
	public static void setBasicDtlsForNewDeal(String origDealID, IslamicBankingObject newDealIBObj)
	{
		IBOIB_DLI_DealDetails origDealDtls = IBCommonUtils.getDealDetails(origDealID);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		//deal details
		IBOIB_DLI_DealDetails newDealDtls = (IBOIB_DLI_DealDetails) factory.getStatelessNewInstance(IBOIB_DLI_DealDetails.BONAME);
		newDealDtls.setBoID(newDealIBObj.getDealID());
		newDealDtls.setF_BranchSortCode(origDealDtls.getF_BranchSortCode());
		newDealDtls.setF_ProductCode(newDealIBObj.getProductID());
		newDealDtls.setF_ProductContextCode(newDealIBObj.getSubProductID());
		newDealDtls.setF_Status(IBConstants.NEW);
		newDealDtls.setF_IsoCurrencyCode(origDealDtls.getF_IsoCurrencyCode());
		newDealDtls.setF_DealStartDate(SystemInformationManager.getInstance().getBFBusinessDate());
		newDealDtls.setF_DealInitDate(SystemInformationManager.getInstance().getBFBusinessDate());
		newDealDtls.setF_DEALEFFECTIVEDT(SystemInformationManager.getInstance().getBFBusinessDate());
		newDealDtls.setF_CREATEDBY(BankFusionThreadLocal.getUserId());
		newDealDtls.setF_PROCESSCONFIGID(newDealIBObj.getProcessConfigID());
		factory.create(IBOIB_DLI_DealDetails.BONAME, newDealDtls);
		//deal details UD
		IBOUDFEXTIB_DLI_DealDetails origDealDtlsUD = CeUtils.getDealDetailsExtensionDtls(origDealID);
		IBOUDFEXTIB_DLI_DealDetails newDealDtlsUD = (IBOUDFEXTIB_DLI_DealDetails) factory.getStatelessNewInstance(IBOUDFEXTIB_DLI_DealDetails.BONAME);
		newDealDtlsUD.setBoID(newDealIBObj.getDealID());
		if(null != origDealDtlsUD)
		{
			newDealDtlsUD.setUserDefinedFields(origDealDtlsUD.getUserDefinedFields());
		}
		factory.create(IBOUDFEXTIB_DLI_DealDetails.BONAME, newDealDtlsUD);
		//deal additional details
		IBOIB_DLI_DealAditionalDtls newDealAddDtls = (IBOIB_DLI_DealAditionalDtls) factory.getStatelessNewInstance(IBOIB_DLI_DealAditionalDtls.BONAME);
		String newID = GUIDGen.getNewGUID();
		newDealAddDtls.setBoID(newID);
		newDealAddDtls.setF_DealNo(newDealIBObj.getDealID());
		factory.create(IBOIB_DLI_DealAditionalDtls.BONAME, newDealAddDtls);
		//deal additional details UD
		IBOUDFEXTIB_DLI_DealAditionalDtls newDealAddDtlsUD = (IBOUDFEXTIB_DLI_DealAditionalDtls) factory.getStatelessNewInstance(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME);
		newDealAddDtlsUD.setBoID(newID);
		factory.create(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, newDealAddDtlsUD);
	}
	
	public static void setCustInfoForNewDeal(IslamicBankingObject newDealIBObj, String newPartyID)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_IDI_DealCustomerDetail newDealCustDtl = (IBOIB_IDI_DealCustomerDetail) factory.getStatelessNewInstance(IBOIB_IDI_DealCustomerDetail.BONAME);
		String newID = GUIDGen.getNewGUID();
		newDealCustDtl.setBoID(newID);
		newDealCustDtl.setF_ASSOCIATIONTYPE(IBConstants.PRIMARYCUSTOMER);
		newDealCustDtl.setF_CUSTOMERID(newPartyID);
		newDealCustDtl.setF_DEALID(newDealIBObj.getDealID());
		newDealCustDtl.setF_ISPROSPECT(false);
		newDealCustDtl.setF_ISSIGNED(false);
		newDealCustDtl.setF_SYSTEMSIGNED(false);
		factory.create(IBOIB_IDI_DealCustomerDetail.BONAME, newDealCustDtl);
		IBOUDFEXTIB_IDI_DealCustomerDetail newDealCustDtlUD = (IBOUDFEXTIB_IDI_DealCustomerDetail) factory.
				getStatelessNewInstance(IBOUDFEXTIB_IDI_DealCustomerDetail.BONAME);
		newDealCustDtlUD.setBoID(newID);
		factory.create(IBOUDFEXTIB_IDI_DealCustomerDetail.BONAME, newDealCustDtlUD);
		
	}
	
	public static IslamicBankingObject initiateNewDealForTransfer(String oldDealID, String userToken)
	{
		IslamicBankingObject ibObj= new IslamicBankingObject();
		IBOIB_DLI_DealDetails oldDealDtls = (IBOIB_DLI_DealDetails) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(
				IBOIB_DLI_DealDetails.BONAME, oldDealID, true);
		if(null != oldDealDtls)
		{
			IBSetReqPayload reqPayload =  new IBSetReqPayload();
			reqPayload.setProductID(oldDealDtls.getF_ProductCode());
			reqPayload.setSubProductID(oldDealDtls.getF_ProductContextCode());
			String processConfigID = readProcessConfigID();
			reqPayload.setProcessConfigID(processConfigID);
			//TODO - ideally get one of the user from the first step assigned userList for the TD process and pass it.
			reqPayload.setUserID(BankFusionThreadLocal.getUserId());
			try {
				LaunchProcessOutPut output = callLaunchProcess(reqPayload, userToken);
				String newDealId = output.getDealID();
				ibObj.setDealID(newDealId);
				ibObj.setProductID(oldDealDtls.getF_ProductCode());
				ibObj.setSubProductID(oldDealDtls.getF_ProductContextCode());
				ibObj.setProcessConfigID(processConfigID);
				ibObj.setTransactionID(output.getTransactionId());
				ibObj.setStepID(output.getStepID());
			}
			catch(Exception e)
			{
				IBCommonUtils.raiseUnparameterizedEvent(44000381);
			}
		}
		return ibObj;
	}
	
	public static String readProcessConfigID() {
		String tdProcessConfigID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.TD_PROPERTIES_FILE, CeConstants.TD_PROCESS_CONFIG_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		return tdProcessConfigID;
	}
	
	public static IBOCE_IB_TransferOfDebtDtls getTDRequestByNewDealID(String dealID)
	{
		IBOCE_IB_TransferOfDebtDtls transferOfDebtDtl = null;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_TransferOfDebtDtls.IBNEWDEALID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		List<IBOCE_IB_TransferOfDebtDtls> transferOfDebtsDtl = factory.findByQuery(IBOCE_IB_TransferOfDebtDtls.BONAME, whereClause, params, null, false);
		if(null != transferOfDebtsDtl && !transferOfDebtsDtl.isEmpty())
		{
			transferOfDebtDtl = transferOfDebtsDtl.get(0);
		}
		return transferOfDebtDtl;
	}
	
	public static String getLoanSettlemenetAcc()
	{
		String tdProcessConfigID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.TD_PROPERTIES_FILE, CeConstants.TD_LOAN_SETTLE_ACC, "",
				CeConstants.ADFIBCONFIGLOCATION);
		return tdProcessConfigID;
	}
	
	public static String getTechnicalUserToken()
	{
		String userToken = CommonConstants.EMPTY_STRING;
		try {
		String baseURLProp = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,"IB_BASE_URL","false");
		String loginRestAddress = baseURLProp + "/bfweb/rest/MisysSSOFBPService/SSOloginService/";
		IEncryptionService encryptionService =
				(IEncryptionService) ServiceManagerFactory.getInstance().getServiceManager().getServiceForName("EncryptionService");
		EncryptedData encryptedData = encryptionService.retrieve(IB_TECH_USER_ALIAS);
		
		LoginInputRequest loginRequest = new LoginInputRequest();
		loginRequest.setPassword(encryptedData.getDecryptedPassword());
		loginRequest.setUserName(encryptedData.getUserName());
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String payload = gson.toJson(loginRequest);
		
		URL url = new URL(loginRestAddress);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod(API_METHOD_POST);
        conn.setRequestProperty("Content-Type", "application/json");
        OutputStream os = conn.getOutputStream();
        os.write(payload.getBytes());
        os.flush();

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new Exception("Login failed for configured " + IB_TECH_USER_ALIAS);
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String output;
        StringBuffer jsonOutPut = new StringBuffer();
        while ((output = br.readLine()) != null) {
            jsonOutPut.append(output);
        }
        conn.disconnect();
        ServiceResult resposne = gson.fromJson(jsonOutPut.toString(), ServiceResult.class);
        userToken =  resposne.getResult();
		}
		catch(Exception e)
		{
			LOGGER.error("TransferOfDebts Request Initiation : Login failed for " + IB_TECH_USER_ALIAS);
			IBCommonUtils.raiseUnparameterizedEvent(44000381);
		}
		return userToken;
	}
	
	public static void logoutTechnicalUser(String userToken)
	{
		try
		{
		String baseURLProp = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,"IB_BASE_URL","false");
		String loginRestAddress = baseURLProp + "/bfweb/rest/MisysSSOFBPService/SSOLogoutService/";
		
		LogoutInputRequest logoutRequest = new LogoutInputRequest();
		logoutRequest.setUserLocator(userToken);
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String payload = gson.toJson(logoutRequest);
		
		URL url = new URL(loginRestAddress);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod(API_METHOD_POST);
        conn.setRequestProperty("Content-Type", "application/json");
        OutputStream os = conn.getOutputStream();
        os.write(payload.getBytes());
        os.flush();

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new Exception("Logout failed for configured " + IB_TECH_USER_ALIAS);
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String output;
        StringBuffer jsonOutPut = new StringBuffer();
        while ((output = br.readLine()) != null) {
            jsonOutPut.append(output);
        }
        conn.disconnect();
		}
		catch(Exception e)
		{
			LOGGER.error("TransferOfDebts Request Initiation : Logout failed for " + IB_TECH_USER_ALIAS);
			IBCommonUtils.raiseUnparameterizedEvent(44000381);
		}
	}
	
	public static LaunchProcessOutPut callLaunchProcess(IBSetReqPayload reqPayLoad, String userToken) throws Exception
	{
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String payload = gson.toJson(reqPayLoad);
		String baseURLProp = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,"IB_BASE_URL","false");
		String launchProcessUri = baseURLProp + "/bfweb/rest/service/ib/getLaunchProcessOutput/";
		
		URL url = new URL(launchProcessUri);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod(API_METHOD_POST);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("userlocator", userToken);

        OutputStream os = conn.getOutputStream();
        os.write(payload.getBytes());
        os.flush();

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
        	LOGGER.error("TransferOfDebts Request Initiation : Launch process API call failed");
            throw new Exception("Launch process API call failed");
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String output;
        StringBuffer jsonOutPut = new StringBuffer();
        while ((output = br.readLine()) != null) {
            jsonOutPut.append(output);
        }
        conn.disconnect();
        LaunchProcessOutPut resposne = gson.fromJson(jsonOutPut.toString(), LaunchProcessOutPut.class);
        return resposne;
		
	}
	
	public static String getTDRequestID()
	{
		String newTDRequestID = "REQ" + CB_CMN_AutoNumber.run(IBOCE_IB_TransferOfDebtDtls.BONAME,
				BankFusionThreadLocal.getBankFusionEnvironment());
		return newTDRequestID;
	}
	
	class LaunchProcessOutPut {
        public String getStepID() {
            return stepID;
        }
        public void setStepID(String stepID) {
            this.stepID = stepID;
        }
        public String getDealID() {
            return dealID;
        }
        public void setDealID(String dealID) {
            this.dealID = dealID;
        }
        String stepID;
        String dealID; 
        String transactionId;
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
        
    }

}
