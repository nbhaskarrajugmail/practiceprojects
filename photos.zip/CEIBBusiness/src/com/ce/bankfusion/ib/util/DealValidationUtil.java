package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.security.runtime.impl.UserUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.api.bb.dto.IBSetReqPayload;
import com.misys.ib.api.helper.LaunchProcessHelper;
import com.trapedza.bankfusion.bo.refimpl.IBOOrganisationGroupUser;
import com.trapedza.bankfusion.bo.refimpl.IBOUser;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.DealValidation;
import bf.com.misys.ib.types.DealValidationList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class DealValidationUtil {
	
	public static void initiateTheProcess(String dealID, String userID)
	{
		IBSetReqPayload reqPayload = new IBSetReqPayload();
		reqPayload.setDealID(dealID);
		reqPayload.setProcessConfigID(readProcessConfigID());
		reqPayload.setSearchPageId(readSearchPageID());
		reqPayload.setUserID(userID);
		LaunchProcessHelper.getLaunchProcessOutput(reqPayload,false);
	}

	public static Set<String> getuserList(IBOCE_IB_DealValidations dealValidation)
	{
		HashSet<String> users = new HashSet<>();
		String userOrRole = CommonConstants.EMPTY_STRING;
		boolean isGroup = false;
		boolean isFilterBasedOnBranch = false;
		IBOCE_IB_ValidationConfiguration conf = ValidationsUtil.getValidationConf(dealValidation.getF_IBVALIDATIONCONFID());
		if(null != conf)
		{
			userOrRole = conf.getF_IBAPPROVALUSERID();
			isGroup = conf.isF_IBGROUP();
			isFilterBasedOnBranch = conf.isF_IBFILTERBYBRANCH();
		}
		if(!isGroup)
		{
			users.add(userOrRole);
		}
		else
		{
			users.addAll(prepareUserList(userOrRole, isFilterBasedOnBranch,dealValidation.getF_IBDEALID()));
		}
		return users;
	}
	
	public static Set<String> prepareUserList(String groupID, boolean isFilterByBranch, String dealID)
	{
		HashSet<String> users = new HashSet<>();
		String query = "WHERE " + IBOOrganisationGroupUser.GROUPID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(groupID);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOOrganisationGroupUser> usersList = factory.findByQuery(IBOOrganisationGroupUser.BONAME, query, params, null, false);
		if(!isFilterByBranch)
		{
			for(IBOOrganisationGroupUser groupUser : usersList)
			{
				users.add(groupUser.getF_USERNAME());
			}
		}
		else
		{
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealID);
			String dealBranch = dealDetails.getF_BranchSortCode();
			for(IBOOrganisationGroupUser groupUser : usersList)
			{
				if(userBelongsToDealBranch(dealBranch, groupUser.getF_USERNAME()))
					users.add(groupUser.getF_USERNAME());
			}
		}
		return users;
	}
	private static boolean userBelongsToDealBranch(String dealBranch, String userId) {
		IBOUser userDetails = UserUtil.getUserDetails(userId);
		if(dealBranch.equalsIgnoreCase(userDetails.getF_BRANCHSORTCODE()))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public static String readSearchPageID() {
		String approvalSearchPageID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				ValidationExceptionConstants.PROPERTIES_FILE, ValidationExceptionConstants.APPROVAL_SEARCHPAGEID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		return approvalSearchPageID;
	}

	public static String readProcessConfigID() {
		String approvalProcessConfigID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				ValidationExceptionConstants.PROPERTIES_FILE, ValidationExceptionConstants.APPROVAL_PROCESSCONFIGID, "",
				CeConstants.ADFIBCONFIGLOCATION);
		return approvalProcessConfigID;
	}

	public static void validateForUserAction(DealValidationList dealValidationExceptionApprovals) {
		for(DealValidation eachValidation : dealValidationExceptionApprovals.getDealValidations())
		{
			if(StringUtils.isBlank(eachValidation.getStatus()))
			{
				IBCommonUtils.raiseUnparameterizedEvent(ValidationExceptionConstants.E_ALL_VALEXCP_NOT_ACTIONED);
			}
		}
		
	}
	
	public static BigDecimal getAttributeValue(int attributeID, int groupCD, int toolNo, IslamicBankingObject islamicBankingObject) {
		AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		assetInfoAndStudyFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		assetInfoAndStudyFatom.setF_IN_mode(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE);
		assetInfoAndStudyFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		AssetThirdPartyDetailsList assetList = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList();
		BigDecimal attribute = null;
		for(AssetThirdPartyDetails eachAssetDtl : assetList.getAssetThirdPartyDetails())
		{
			if(eachAssetDtl.getGroupCD() == groupCD && eachAssetDtl.getToolNO() == toolNo)
			{
				switch(attributeID)
				{
				case 1:
					attribute = eachAssetDtl.getAttribute1();
					break;
				case 2:
					attribute = eachAssetDtl.getAttribute2();
					break;
				case 3:
					attribute = eachAssetDtl.getAttribute3();
					break;
				case 4:
					attribute = eachAssetDtl.getAttribute4();
					break;
				case 5:
					attribute = eachAssetDtl.getAttribute5();
					break;
				case 6:
					attribute = eachAssetDtl.getAttribute6();
					break;
				case 7:
					attribute = eachAssetDtl.getAttribute7();
					break;
				case 8:
					attribute = eachAssetDtl.getAttribute8();
					break;
				case 9:
					attribute = eachAssetDtl.getAttribute9();
					break;
				default:
					break;
				}
			}
		}
		return attribute;
	}
}
