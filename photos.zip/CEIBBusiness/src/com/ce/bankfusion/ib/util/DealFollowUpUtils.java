package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpAssetDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpCropDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalCrop;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.misys.bankfusion.calendar.functions.DaysBetweenTwoDates;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ConfigureSearchPage;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealfollowup.dtls.ib.types.DealFollowUpDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpCropDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.IslamicBankingObject;

public class DealFollowUpUtils {

    private static final IBOIB_AST_AssetDetails assetDetails = null;

    private static String followUpConfQuery = " WHERE " + IBOCE_IB_FollowUpListConf.IBDEALID + " = ? ";

    private static String dealFollowUpDtlsQuery =
        " WHERE " + IBOCE_IB_DealFollowUpDtls.IBDEALID + " = ? ORDER BY " + IBOCE_IB_DealFollowUpDtls.IBFOLLOWUPDATE + " DESC";

    private static String technicalFarmQuery =
        CeConstants.QUERYSTRING_WHERE + IBOCE_IB_TechnicalFarm.IBDEALID + " =?  ORDER BY " + IBOCE_IB_TechnicalFarm.IBDATE + " DESC";

    private static String dealFollowupCropDtlsQuery = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpCropDtls.IBDEALFOLLOWUPID
        + " =? AND " + IBOCE_IB_DealFollowUpCropDtls.IBCROPID + " =? ";

    private static String technicalCropQuery = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " =? AND "
        + IBOCE_IB_TechnicalCrop.IBCROPTYPEID + " =? ";

    public static String dealFollowupAssetDtlsQuery = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpAssetDtls.IBFOLLOWUPID
        + " =? AND " + IBOCE_IB_DealFollowUpAssetDtls.IBASSETID + " =? ";

    public static String dealFollowUpDtlsQueryAsc = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpDtls.IBDEALID + " =? ORDER BY "
        + IBOCE_IB_DealFollowUpDtls.IBFOLLOWUPDATE + " ASC";

    public static String techFarm_whereQuery = " WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " =?";

    public static String dealAssetDtlsQuery =
        CeConstants.QUERYSTRING_WHERE + IBOIB_DLI_DealAssetDtls.DEALNO + " =? ORDER BY " + IBOIB_DLI_DealAssetDtls.ASSETDETAILSID + " ASC";

    public static String technicalCropQuery_refNum = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_TechnicalCrop.IBREFERENCENUMBER + " =? ";

    public static void validateUserAssignedToDealFollowup(String dealId) {
        String userAssignedInFollowupSheet = CommonConstants.EMPTY_STRING;
        IBOCE_IB_FollowUpListConf followUpListConfObj = getFollowUpConfObj(dealId);

        if (followUpListConfObj != null)
            userAssignedInFollowupSheet = followUpListConfObj.getF_IBINSPECTORNAME();
        else
            insertNewRecordToFollowUpAssignment(dealId);

        if (!IBCommonUtils.isNullOrEmpty(userAssignedInFollowupSheet)
            && !BankFusionThreadLocal.getUserSession().getUserId().equals(userAssignedInFollowupSheet))
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FOLLOWUP_ASSIGNED_TO_DIFF_USER_IB);
    }

    private static void insertNewRecordToFollowUpAssignment(String dealId) {
        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);

        IBOCE_IB_FollowUpListConf followupConf = (IBOCE_IB_FollowUpListConf) BankFusionThreadLocal.getPersistanceFactory()
            .getStatelessNewInstance(IBOCE_IB_FollowUpListConf.BONAME);
        followupConf.setF_IBCURRENTFOLLOWUPSTATUS(CommonConstants.EMPTY_STRING);
        followupConf.setF_IBCUSTOMERID((String) CeUtils.getCustomerDtls(dealId, dealDetails.getF_ParentDealNo()).get("CUSTOMERID"));
        followupConf.setF_IBCUSTOMERNAME((String) CeUtils.getCustomerDtls(dealId, dealDetails.getF_ParentDealNo()).get("CUSTOMERNAME"));
        followupConf.setF_IBDEALID(dealId);
        followupConf.setF_IBINSPECTORNAME(CommonConstants.EMPTY_STRING);
        followupConf.setF_IBLASTFOLLOWUPDATE(null);
        followupConf.setF_IBPROCESSNAME(CeUtils.getProcessName(dealDetails.getF_PROCESSCONFIGID()));
        followupConf.setF_IBSUBPRODUCTNAME(CeUtils.getProductName(dealDetails.getF_ProductCode()));
        followupConf.setF_IBDEALBRANCH(dealDetails.getF_BranchSortCode());
        IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_FollowUpListConf.BONAME, followupConf);
    }

    public static void validateUserAssignedToAmendFollowup(String dealId) {
        String userAssignedInFollowupSheet = CommonConstants.EMPTY_STRING;
        IBOCE_IB_FollowUpListConf followUpListConfObj = getFollowUpConfObj(dealId);

        if (followUpListConfObj != null)
            userAssignedInFollowupSheet = followUpListConfObj.getF_IBINSPECTORNAME();

        if (IBCommonUtils.isNullOrEmpty(userAssignedInFollowupSheet) || (!IBCommonUtils.isNullOrEmpty(userAssignedInFollowupSheet)
            && !BankFusionThreadLocal.getUserSession().getUserId().equals(userAssignedInFollowupSheet))) {
            String[] msgArgs = { userAssignedInFollowupSheet };
            IBCommonUtils.raiseParametrizedEvent(CeConstants.E_FOLLOWUP_IS_NOT_ASSIGNED_TO_THIS_USER_IB, msgArgs);
        }
    }

    public static IBOCE_IB_FollowUpListConf getFollowUpConfObj(String dealId) {
        ArrayList<String> queryParams = new ArrayList<>();
        queryParams.add(dealId);

        List<IBOCE_IB_FollowUpListConf> resultSet =
            IBCommonUtils.getPersistanceFactory().findByQuery(IBOCE_IB_FollowUpListConf.BONAME, followUpConfQuery, queryParams, null, true);
        if (resultSet != null && !resultSet.isEmpty()) {
            return resultSet.get(0);
        }
        return null;
    }

    public static void isFollowUpInProgressExist(String dealId) {
        boolean isFollowUpInProgressExist = false;
        IBOCE_IB_DealFollowUpDtls dealFollowUpObj = getPreviousFollowUpDtls(dealId);
        if (dealFollowUpObj != null /* && !dealFollowUpObj.isF_IBFOLLOWUPDONE() */
            && dealFollowUpObj.getF_IBFOLLOWUPSTATUS().equals(CeConstants.FOLLOWUP_STATUS_NEGATIVE)) {
            Date followUpdate = new Date(dealFollowUpObj.getF_IBFOLLOWUPDATE().getTime());
            long diffInDays =
                DaysBetweenTwoDates.run(followUpdate, IBCommonUtils.getBFBusinessDate(), IBCommonUtils.getBankFusionEnvironment());
            if ((int) diffInDays <= getFollowUpPeriodConfigured()) {
                isFollowUpInProgressExist = true;
            } else {
                validateIfRecallInProgress(dealId);
            }
        }
        if (isFollowUpInProgressExist)
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FOLLOWUP_IN_PROGRESS_EXIST_IB);
    }

    public static void validateIfRecallInProgress(String dealId) {
        IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtls = EarlyAssetPayoffUtils.getAssetPayoffExistingObjStatusNotCompleted(dealId, true);
        if (assetPayoffDtls == null || (assetPayoffDtls != null && assetPayoffDtls.isF_IBISRECALLACTION()))
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB);
    }

    public static void isPrevFollowUpStatusPositive(String dealId) {
        IBOCE_IB_DealFollowUpDtls dealFollowUpObj = getPreviousFollowUpDtls(dealId);
        if (dealFollowUpObj == null)
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_NEG_FOLLOWUPS_TO_AMEND_IB);

        if (dealFollowUpObj != null && !IBCommonUtils.isNullOrEmpty(dealFollowUpObj.getF_IBFOLLOWUPSTATUS())) {
            if (dealFollowUpObj.getF_IBFOLLOWUPSTATUS().equals(CeConstants.FOLLOWUP_STATUS_POSITIVE)) {
                IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_NEG_FOLLOWUPS_TO_AMEND_IB);
            } else {
                if (dealFollowUpObj.isF_IBFOLLOWUPDONE())
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_NEG_FOLLOWUPS_TO_AMEND_IB);

                Date followUpdate = new Date(dealFollowUpObj.getF_IBFOLLOWUPDATE().getTime());
                long diffInDays =
                    DaysBetweenTwoDates.run(followUpdate, IBCommonUtils.getBFBusinessDate(), IBCommonUtils.getBankFusionEnvironment());
                if ((int) diffInDays > getFollowUpPeriodConfigured()) {
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_NEG_FOLLOWUPS_TO_AMEND_IB);
                }
            }
        }
    }

    public static int getFollowUpPeriodConfigured() {
        String followUpPeriodInDays = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOWUP_PROPERTY_FILE,
            CeConstants.FOLLOWUP_PERIOD_IN_DAYS, "", CeConstants.ADFIBCONFIGLOCATION);
        return followUpPeriodInDays != null ? Integer.valueOf(followUpPeriodInDays) : 0;
    }

    public static boolean isFollowUpAmendProcess(String searchPageId) {
        boolean isFollowUpAmendProcess = false;
        if (!IBCommonUtils.isNullOrEmpty(searchPageId)) {
            IBOIB_CFG_ConfigureSearchPage searchPageObj = (IBOIB_CFG_ConfigureSearchPage) BankFusionThreadLocal.getPersistanceFactory()
                .findByPrimaryKey(IBOIB_CFG_ConfigureSearchPage.BONAME, searchPageId, true);
            if (searchPageObj != null && searchPageObj.getF_ACTION().equals(CeConstants.DEAL_FOLLOWUP_AMEND_PAGE_ACTION))
                isFollowUpAmendProcess = true;
        }

        return isFollowUpAmendProcess;
    }

    public static void validatePrevFollowUpDate(String dealId) {
        IBOCE_IB_DealFollowUpDtls dealFollowUpObj = getPreviousFollowUpDtls(dealId);
        if (dealFollowUpObj != null) {
            Date followUpdate = new Date(dealFollowUpObj.getF_IBFOLLOWUPDATE().getTime());
            long diffInDays =
                DaysBetweenTwoDates.run(followUpdate, IBCommonUtils.getBFBusinessDate(), IBCommonUtils.getBankFusionEnvironment());
            if ((int) diffInDays > getFollowUpPeriodConfigured()) {
                String[] msgArgs = { String.valueOf(getFollowUpPeriodConfigured()) };
                IBCommonUtils.raiseParametrizedEvent(CeConstants.E_PREV_FOLLOWUP_DATE_AFTER_CONFIGURED_DAYS_IB, msgArgs);
            }
        }
    }

    public static void validateIfDealIsNotCompletelyDisbursed(String dealId, ReadLoanDetailsRs readLoanDetailsRs) {
        IBOIB_DLI_DealAditionalDtls dealAddDtls = IBCommonUtils.getDealAdditionalDetails(dealId);
        BigDecimal pricnipalAmt = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt();

        if (null != dealAddDtls && null != dealAddDtls.getF_ChargeAmt())
            pricnipalAmt = pricnipalAmt.subtract(dealAddDtls.getF_ChargeAmt());

        if ((pricnipalAmt.subtract(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()))
            .compareTo(BigDecimal.ZERO) > 0)
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FOLLOWUP_NOT_ALLOWED_DEAL_NOT_DISBURSED_IB);
    }

    public static void validateIfDealIsFullySatsfied(ReadLoanDetailsRs readLoanDetailsRs) {
        if (readLoanDetailsRs != null
            && readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().compareTo(BigDecimal.ZERO) == 0)
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_FOLLOWUP_NOT_ALLOWED_DEAL_FULLY_SATISFIED_IB);
    }

    public static IBOCE_IB_TechnicalFarm getLatestTechnicalFarmObj(String dealId) {
        ArrayList<String> param = new ArrayList<>();
        param.add(dealId);
        List<IBOCE_IB_TechnicalFarm> technicalFarmDtls = (ArrayList<IBOCE_IB_TechnicalFarm>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_TechnicalFarm.BONAME, technicalFarmQuery, param, null, true);

        if (technicalFarmDtls != null && !technicalFarmDtls.isEmpty()) {
            return technicalFarmDtls.get(0);
        }

        return null;
    }

    public static void fetchAssetDetails(IslamicBankingObject islamicBankingObject, String assetId,
        FollowUpAssetDetails vFollowUpAssetDetails) {
        AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(IBCommonUtils.getBankFusionEnvironment());
        assetInfoAndStudyFatom.setF_IN_islamicBankingObject(islamicBankingObject);
        assetInfoAndStudyFatom.setF_IN_mode("RETRIEVE");
        assetInfoAndStudyFatom.process(IBCommonUtils.getBankFusionEnvironment());
        AssetThirdPartyDetails[] assetTPDetails = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
        for (AssetThirdPartyDetails aTPDtls : assetTPDetails) {
            if (aTPDtls.getAssetSerial().equals(assetId)) {
                vFollowUpAssetDetails.setAssetCategory(aTPDtls.getAssetCategory());

                BFCurrencyAmount studyCost = new BFCurrencyAmount();
                studyCost.setCurrencyAmount(IBCommonUtils.scaleAmount(aTPDtls.getAssetStudyCost().getCurrencyCode(),
                    aTPDtls.getAssetStudyCost().getCurrencyAmount()));
                studyCost.setCurrencyCode(aTPDtls.getAssetStudyCost().getCurrencyCode());
                BFCurrencyAmount finalCost = new BFCurrencyAmount();
                finalCost.setCurrencyAmount(
                    IBCommonUtils.scaleAmount(aTPDtls.getFinalCost().getCurrencyCode(), aTPDtls.getFinalCost().getCurrencyAmount()));
                finalCost.setCurrencyCode(aTPDtls.getFinalCost().getCurrencyCode());
                vFollowUpAssetDetails.setStudyCost(studyCost);
                vFollowUpAssetDetails.setFinalCost(finalCost);
                vFollowUpAssetDetails.setAssetName(aTPDtls.getAssetName());
                /*
                 * if (!assetDetails.getF_STATUS().equals(IBConstants.ASSET_STATUS_ACTIVE) &&
                 * !assetDetails.getF_STATUS().equals(IBConstants.ASSET_STATUS_INACTIVE)) { ListGenericCodeRs genricCodes =
                 * IBCommonUtils.getGCList(IBConstants.ASSETSTATUS); for (GcCodeDetail gcCodeDetails : genricCodes.getGcCodeDetails()) { if
                 * (assetDetails.getF_STATUS().equals(gcCodeDetails.getCodeReference())) {
                 * vFollowUpAssetDetails.setStatus(gcCodeDetails.getCodeDescription()); break; } } }
                 */

            }
        }

    }

    public static void fetchDealFollowUpCropDtl(String cropId, FollowUpCropDetails vFollowUpCropDetails, String dealCurrency) {

        IBOCE_IB_DealFollowUpCropDtls dealFollowUpCropDtls = (IBOCE_IB_DealFollowUpCropDtls) BankFusionThreadLocal.getPersistanceFactory()
            .findByPrimaryKey(IBOCE_IB_DealFollowUpCropDtls.BONAME, cropId, true);

        if (dealFollowUpCropDtls != null) {
            vFollowUpCropDetails.setUsedAreaInFollowUpReport(dealFollowUpCropDtls.getF_IBUSEDAREAINFOLLOWUPREP());
            vFollowUpCropDetails
                .setExpectedRevenue(IBCommonUtils.getBFCurrencyAmount(dealFollowUpCropDtls.getF_IBEXPECTEDREVENUE(), dealCurrency));
        }

    }

    public static void fetchTechnicalCropDtl(String cropId, FollowUpCropDetails vFollowUpCropDetails) {
        IBOCE_IB_TechnicalCrop technicalCropDtls = (IBOCE_IB_TechnicalCrop) BankFusionThreadLocal.getPersistanceFactory()
            .findByPrimaryKey(IBOCE_IB_TechnicalCrop.BONAME, cropId, true);

        vFollowUpCropDetails.setCropId(technicalCropDtls.getBoID());
        vFollowUpCropDetails.setArea(technicalCropDtls.getF_IBAREA());
        vFollowUpCropDetails.setAreaToBeCultivatedInTechReport(technicalCropDtls.getF_IBAREA());
        vFollowUpCropDetails.setCropType(IBCommonUtils.getGCChildDesc("CECROPTYPE", technicalCropDtls.getF_IBCROPTYPEID()));
        vFollowUpCropDetails.setForPalm(IBCommonUtils.getGCChildDesc("CETECHFORPALM",technicalCropDtls.getF_IBFORPALM()));
        vFollowUpCropDetails.setInsuredByFarmer(technicalCropDtls.isF_IBISINSUREDBYFARMER());
        vFollowUpCropDetails.setLengthOfWateringMethod(technicalCropDtls.getF_IBLENGTHOFWATERINGMACHINE());
        vFollowUpCropDetails.setMainActivity(IBCommonUtils.getGCChildDesc("CETECHMAINACTIVITY",technicalCropDtls.getF_IBMAINACTIVITY()));
        vFollowUpCropDetails.setNoOfSeedling(technicalCropDtls.getF_IBNOOFSEEDLINGS());
        vFollowUpCropDetails.setSeedlingType(IBCommonUtils.getGCChildDesc("CETECHSEEDLINGSTYPE",technicalCropDtls.getF_IBSEEDLINGSTYPE()));
        vFollowUpCropDetails.setStatus(IBCommonUtils.getGCChildDesc("CETECHSTATUS", technicalCropDtls.getF_IBSTATUS()));
        vFollowUpCropDetails.setTotalAreaForAlCrop(technicalCropDtls.getF_IBTOTALAREA());
        // vFollowUpCropDetails.setUsedAreaInTechReport(technicalCropDtls.get(0).get);
        vFollowUpCropDetails.setWateringMethod(IBCommonUtils.getGCChildDesc("CETECHWATERMETHOD",technicalCropDtls.getF_IBWATERINGMETHOD()));

    }

    public static IBOCE_IB_DealFollowUpDtls getPreviousFollowUpDtls(String dealId) {
        ArrayList param = new ArrayList();
        param.add(dealId);
        List<IBOCE_IB_DealFollowUpDtls> dealFollowUpDtls = (ArrayList<IBOCE_IB_DealFollowUpDtls>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_DealFollowUpDtls.BONAME, dealFollowUpDtlsQuery, param, null, true);

        if (dealFollowUpDtls != null && !dealFollowUpDtls.isEmpty()) {
            return dealFollowUpDtls.get(0);
        }
        return null;
    }

    public static void updateFollowUpStatus(String dealID) {
        IBOCE_IB_FollowUpListConf followUpListConfObj = DealFollowUpUtils.getFollowUpConfObj(dealID);
        if (followUpListConfObj != null) {
            followUpListConfObj.setF_IBCURRENTFOLLOWUPSTATUS(CeConstants.FOLLOWUP_ASSIGN_STATUS_INPROGRESS);
            IBCommonUtils.getPersistanceFactory().commitTransaction();
        }
    }

    public static boolean isAssetToBeRecalled(String dealID, String assetId) {
        IBOCE_IB_DealFollowUpDtls dealFollowUpDtls = getPreviousFollowUpDtls(dealID);
        if (dealFollowUpDtls != null) {
            ArrayList<String> param = new ArrayList<>();
            param.add(dealFollowUpDtls.getBoID());
            param.add(assetId);
            List<IBOCE_IB_DealFollowUpAssetDtls> dealFollowUpAssetDtls = (ArrayList<IBOCE_IB_DealFollowUpAssetDtls>) IBCommonUtils
                .getPersistanceFactory().findByQuery(IBOCE_IB_DealFollowUpAssetDtls.BONAME, dealFollowupAssetDtlsQuery, param, null, true);
            if (dealFollowUpAssetDtls != null && !dealFollowUpAssetDtls.isEmpty() && !dealFollowUpAssetDtls.get(0).isF_IBASSETEXIST()) {
                return true;
            }
        }
        return false;
    }

    public static List<IBOCE_IB_DealFollowUpDtls> getFollowUpDtlsFromDB(String dealId) {
        ArrayList<String> param = new ArrayList<>();
        param.clear();
        param.add(dealId);
        List<IBOCE_IB_DealFollowUpDtls> dealFollowUpDtls = (ArrayList<IBOCE_IB_DealFollowUpDtls>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_DealFollowUpDtls.BONAME, dealFollowUpDtlsQueryAsc, param, null, true);
        return dealFollowUpDtls;
    }

    public static void validateIfTechAnalysisIsDone(String dealID) {
        ArrayList<String> param = new ArrayList<>();
        param.add(dealID);
        List<IBOCE_IB_TechnicalFarm> farmDtls = (ArrayList<IBOCE_IB_TechnicalFarm>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_TechnicalFarm.BONAME, techFarm_whereQuery, param, null, true);

        if (farmDtls == null || farmDtls.isEmpty())
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NO_TECH_ANALYSIS_DONE_IB);

    }

    public static FollowUpDetails initializeFollowUpDetail(IBOIB_DLI_DealDetails dealDetails) {
        FollowUpDetails vFollowUpDetails = new FollowUpDetails();
        vFollowUpDetails.setDealId(dealDetails.getBoID());
        vFollowUpDetails.setDealStatus(IBCommonUtils.getGCChildDesc(DealInitiationConstants.DEALSTATUS, dealDetails.getF_Status()));
        vFollowUpDetails.setFollowUpDate(IBCommonUtils.getBFBusinessDate());
        vFollowUpDetails.setFollowUpDone(false);
        vFollowUpDetails.setFollowUpId(IBCommonUtils.getNewGUID());
        vFollowUpDetails.setInspectorName(BankFusionThreadLocal.getUserSession().getUserId());

        IBOCE_IB_TechnicalFarm technicalFarmObj = DealFollowUpUtils.getLatestTechnicalFarmObj(dealDetails.getBoID());
        if (technicalFarmObj != null) {
            vFollowUpDetails.setDateOfTechnicalReport(technicalFarmObj.getF_IBDATE());
            vFollowUpDetails.setTechnicalReportInspector(technicalFarmObj.getF_IBINSPECTOR());
            vFollowUpDetails.setTechnicalReportId(technicalFarmObj.getBoID());
        }

        IBOCE_IB_FollowUpListConf followUpListConfObj = DealFollowUpUtils.getFollowUpConfObj(dealDetails.getBoID());
        if (followUpListConfObj != null && IBCommonUtils.isNullOrEmpty(followUpListConfObj.getF_IBINSPECTORNAME()))
            vFollowUpDetails.setFollowUpOutsideTheSheet(true);
        return vFollowUpDetails;
    }

    public static void initializeFollowupAssetDtls(IslamicBankingObject islamicBankingObject, DealFollowUpDetails dealFollowUpDetails, String followupId, String dealId) {
        ArrayList<String> param = new ArrayList<>();
        param.add(dealId);
        List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = (ArrayList<IBOIB_DLI_DealAssetDtls>) IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, dealAssetDtlsQuery, param, null, true);
        if (dealAssetDtls != null && !dealAssetDtls.isEmpty()) {
            for (IBOIB_DLI_DealAssetDtls assetDtls : dealAssetDtls) {
                IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory()
                    .findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetDtls.getF_ASSETDETAILSID(), true);
                if (assetDetails != null && !assetDetails.getF_STATUS().equals(CeConstants.ASSETSTATUS_EARLYPAIDOFF)
                    && !assetDetails.getF_STATUS().equals(CeConstants.ASSETSTATUS_RECALL)) {
                    FollowUpAssetDetails vFollowUpAssetDetails = new FollowUpAssetDetails();
                    vFollowUpAssetDetails.setAssetId(assetDtls.getF_ASSETDETAILSID());
                    vFollowUpAssetDetails.setFollowUpId(followupId);
                    DealFollowUpUtils.fetchAssetDetails(islamicBankingObject, assetDtls.getF_ASSETDETAILSID(), vFollowUpAssetDetails);
                    dealFollowUpDetails.addFollowUpAssetDetails(vFollowUpAssetDetails);
                }
            }
        }
    }

    public static void initializeFollowUpCropDtls(DealFollowUpDetails dealFollowUpDetails, String followupId, String dealId,
        String dealCurrency) {
        IBOCE_IB_TechnicalFarm technicalFarmObj = DealFollowUpUtils.getLatestTechnicalFarmObj(dealId);
        if (technicalFarmObj != null) {
            ArrayList<String> param = new ArrayList<>();
            param.add(technicalFarmObj.getBoID());
            List<IBOCE_IB_TechnicalCrop> technicalCropDtls = (ArrayList<IBOCE_IB_TechnicalCrop>) IBCommonUtils.getPersistanceFactory()
                .findByQuery(IBOCE_IB_TechnicalCrop.BONAME, technicalCropQuery_refNum, param, null, true);

            if (technicalCropDtls != null && !technicalCropDtls.isEmpty()) {
                for (IBOCE_IB_TechnicalCrop technicalCrop : technicalCropDtls) {
                    FollowUpCropDetails vFollowUpCropDetails = new FollowUpCropDetails();
                    vFollowUpCropDetails.setCropId(technicalCrop.getBoID());
                    vFollowUpCropDetails.setArea(technicalCrop.getF_IBAREA());
                    vFollowUpCropDetails.setAreaToBeCultivatedInTechReport(technicalCrop.getF_IBAREA());
                    vFollowUpCropDetails.setCropType(IBCommonUtils.getGCChildDesc("CECROPTYPE", technicalCrop.getF_IBCROPTYPEID()));
                    vFollowUpCropDetails.setForPalm(IBCommonUtils.getGCChildDesc("CETECHFORPALM",technicalCrop.getF_IBFORPALM()));
                    vFollowUpCropDetails.setInsuredByFarmer(technicalCrop.isF_IBISINSUREDBYFARMER());
                    vFollowUpCropDetails.setLengthOfWateringMethod(technicalCrop.getF_IBLENGTHOFWATERINGMACHINE());
                    vFollowUpCropDetails.setMainActivity(IBCommonUtils.getGCChildDesc("CETECHMAINACTIVITY",technicalCrop.getF_IBMAINACTIVITY()));
                    vFollowUpCropDetails.setNoOfSeedling(technicalCrop.getF_IBNOOFSEEDLINGS());
                    vFollowUpCropDetails.setSeedlingType(IBCommonUtils.getGCChildDesc("CETECHSEEDLINGSTYPE",technicalCrop.getF_IBSEEDLINGSTYPE()));
                    vFollowUpCropDetails.setStatus(IBCommonUtils.getGCChildDesc("CETECHSTATUS", technicalCrop.getF_IBSTATUS()));
                    vFollowUpCropDetails.setTotalAreaForAlCrop(technicalCrop.getF_IBTOTALAREA());
                    // vFollowUpCropDetails.setUsedAreaInTechReport(technicalCropDtls.get(0).get);
                    vFollowUpCropDetails.setWateringMethod(IBCommonUtils.getGCChildDesc("CETECHWATERMETHOD",technicalCrop.getF_IBWATERINGMETHOD()));

                    vFollowUpCropDetails.setFollowUpId(followupId);
                    vFollowUpCropDetails.setUsedAreaInFollowUpReport(BigDecimal.ZERO);
                    BFCurrencyAmount expectedRevenue = new BFCurrencyAmount();
                    expectedRevenue.setCurrencyAmount(BigDecimal.ZERO);
                    expectedRevenue.setCurrencyCode(dealCurrency);
                    vFollowUpCropDetails.setExpectedRevenue(expectedRevenue);
                    dealFollowUpDetails.addFollowUpCropDetails(vFollowUpCropDetails);
                }
            }
        }
    }

}
