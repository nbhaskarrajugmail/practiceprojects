package com.ce.bankfusion.ib.util;

import static com.ce.adf.CEConstants.EMPTY;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.CommonsEventCodes;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.webservice.common.util.WebServiceInvocationHelper;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ub.lending.persistence.LoanPlanFinderMethods;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBODebitInterestFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOInterestAccruals;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_FIN_AmortizationDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOpseudonyms;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.bf.attributes.Event;
import bf.com.misys.cbs.msgs.v1r0.ReadLoanDetailsRq;
import bf.com.misys.cbs.msgs.v1r0.ReadLoanProductDetailsRq;
import bf.com.misys.cbs.msgs.v1r0.ReadLoanProductDetailsRs;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.cbs.types.ModuleConfigDetails;
import bf.com.misys.cbs.types.ReadLoanDetailsInput;
import bf.com.misys.cbs.types.ReadLoanProductDetailsInput;
import bf.com.misys.cbs.types.header.RqHeader;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRq;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRs;
import bf.com.misys.financialposting.types.PostingLeg;
import bf.com.misys.financialposting.types.TxnDetails;
import bf.com.misys.ib.schedule.payments.PaymentSchedule;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.header.EventParameters;
import bf.com.misys.ib.types.header.MessageStatus;
import bf.com.misys.ib.types.header.RsHeader;
import bf.com.misys.ib.types.header.SubCode;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class RescheduleUtils {
	public static final String CREDIT_PARAM_NAME = "2149_CR";
	public static final String DEBIT_PARAM_NAME = "2149_DR";
	public static final String LENDING_MODULE = "LENDING";
	public static final String PARAM_UPFRONTINCOMEACC = "UPFRONTINCOMEACC";
	private static final String PARAM_UNEARNEDACC = "UNEARNEDACC";
	public static final String PARAM_RESCHEDULERECEIVABLEACC = "RESCHEDULERECEIVABLEACC";
	public static final String PARAM_RESCHEDULEEARNEDACC = "RESCHEDULEEARNEDACC";
	public static final String PARAM_DEFERREDINCACCT = "DEFERREDINCACCT";
	public static final String MODULE_NAME_IB = "IB";
	public static final String PO_CREDIT_PARAM_NAME = "POCRTXNCODE";
	public static final String PO_DEBIT_PARAM_NAME = "PODRTXNCODE";
	public static final String EOD_CREDIT_PARAM_NAME = "EODCRTXNCODE";
	public static final String EOD_DEBIT_PARAM_NAME = "EODDRTXNCODE";
	
	public static final String INVGEN_DAYS_BEFORE_DUEDATE = "INVGEN_DAYS_BEFORE_DUEDATE";
	public static final String CESADADINTERFACE = "CESADADINTERFACE";
	private static final Log LOGGER = LogFactory.getLog(RescheduleUtils.class);
	public static String dealRescheduleQuery = " WHERE " + IBOCE_IB_DealReschedule.IBDEALID + " = ? ";
	public static String schHisQuery = " WHERE " + IBOCE_IB_PaymentScheduleHistory.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID + " = ? ";
	public static final String UB_READ_LOAN_API_SRVWS_WSDL = "bfweb/services/UB_R_CB_LEN_ReadLoan_SRVWS?wsdl";
    public static final String UB_READ_LOAN_API_SRV = "UB_R_CB_LEN_ReadLoan_SRV";
    public static final String ERROR = "E";
    public static final String SUCCESS = "S";
    private static final int E_GENERIC_ERROR = 35000102;
    public static final String DEFAULT_CONTEXT = "Context";
	
	public static IBOCE_IB_DealReschedule getReschReqExistingObjStatusNotCompleted(String dealId) {
		if (!IBCommonUtils.isValidString(dealId)) {
			return null;
		}
		IBOCE_IB_DealReschedule dealReschObj = null;
		ArrayList<String> dealStatusList = new ArrayList<>();
		dealStatusList.add(RescheduleConstants.STATUS_COMPLETED);
		dealStatusList.add(IBConstants.DECISION_RETURNED);
		dealStatusList.add(IBConstants.DECISION_REJECTED);
		dealStatusList.add(IBConstants.DECISION_CANCELLED);
		dealStatusList.add(IBConstants.DECISION_REVERSED);
		dealStatusList.add(CeConstants.REFUND_STATUS_REFUNDED);

		StringBuffer dealReschDetailQuery = new StringBuffer();
		dealReschDetailQuery.append(" WHERE " + IBOCE_IB_DealReschedule.IBDEALID + " = ? ");
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);

		dealReschDetailQuery.append(" AND ");
		dealReschDetailQuery.append(IBOCE_IB_DealReschedule.IBRESCHEDULESTATUS);
		dealReschDetailQuery.append(" NOT IN (");

		for (String dealStatus : dealStatusList) {
			dealReschDetailQuery.append("?,");
			params.add(dealStatus);
		}
		dealReschDetailQuery.replace(dealReschDetailQuery.lastIndexOf(","), dealReschDetailQuery.length(),
				CommonConstants.EMPTY_STRING);
		dealReschDetailQuery.append(")");

		List<IBOCE_IB_DealReschedule> dealRescheduleDetailsList = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealReschedule.BONAME, dealReschDetailQuery.toString(), params, null, false);

		if (dealRescheduleDetailsList != null && dealRescheduleDetailsList.size() > CommonConstants.INTEGER_ZERO) {
			dealReschObj = dealRescheduleDetailsList.get(CommonConstants.INTEGER_ZERO);
		}
		return dealReschObj;
	}
	public static IBOCE_IB_REFUNDRESCHDTLS getRefundReschProfitActiveReq(String dealId) {

		if (!IBCommonUtils.isValidString(dealId)) {
			return null;
		}
		IBOCE_IB_REFUNDRESCHDTLS refundReschProfitObj = null;
		ArrayList<String> dealStatusList = new ArrayList<>();
		dealStatusList.add(CeConstants.REFUND_STATUS_REFUNDED);
		dealStatusList.add(IBConstants.DECISION_RETURNED);
		dealStatusList.add(IBConstants.DECISION_REJECTED);
		dealStatusList.add(IBConstants.DECISION_CANCELLED);
		dealStatusList.add(IBConstants.DECISION_REVERSED);

		StringBuffer refundReschProfitDetailQuery = new StringBuffer();
		refundReschProfitDetailQuery.append(" WHERE " + IBOCE_IB_REFUNDRESCHDTLS.IBDEALID + " = ? ");
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);

		refundReschProfitDetailQuery.append(" AND ");
		refundReschProfitDetailQuery.append(IBOCE_IB_REFUNDRESCHDTLS.IBSYSTEMSTATUS);
		refundReschProfitDetailQuery.append(" NOT IN (");

		for (String dealStatus : dealStatusList) {
			refundReschProfitDetailQuery.append("?,");
			params.add(dealStatus);
		}
		refundReschProfitDetailQuery.replace(refundReschProfitDetailQuery.lastIndexOf(","), refundReschProfitDetailQuery.length(),
				CommonConstants.EMPTY_STRING);
		refundReschProfitDetailQuery.append(")");

		List<IBOCE_IB_REFUNDRESCHDTLS> refundReschProfitDetailsList = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_REFUNDRESCHDTLS.BONAME, refundReschProfitDetailQuery.toString(), params, null, false);

		if (refundReschProfitDetailsList != null && refundReschProfitDetailsList.size() > CommonConstants.INTEGER_ZERO) {
			refundReschProfitObj = refundReschProfitDetailsList.get(CommonConstants.INTEGER_ZERO);
		}
		return refundReschProfitObj;
	}

	public static void validateMultipleRequests(String dealNumber) {
		IBOCE_IB_DealReschedule completedRescheduleRequest = getReschReqExistingObjStatusNotCompleted(dealNumber);
		if (completedRescheduleRequest != null) {
			IBCommonUtils
					.raiseUnparameterizedEvent(CommonsEventCodes.E_ONLYONE_RESCH_REQUEST_ALLOWED_FORDEAL_ATTIME_IB);
		}
	}

	public static boolean isDisbursedAmountZero(String dealId) {
		boolean isUnDisbursedAmountNotZero = false;

		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealId);
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getLoanBasicDetails()
				.getTotalDisbursementAmount().compareTo(BigDecimal.ZERO) == 0) {
			 IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCHEDULE_DISBURSE_AMOUNT_ZERO_CEIB);
		}
		return isUnDisbursedAmountNotZero;
	}

	public static void addSameDateRepayments(Map<Date, ArrayList<CePaymentSchedule>> dateAndpaymentScheduleMap,
			CePaymentSchedule[] cePaymentSchedules, String currencyCode) {
		LOGGER.info("Adding amounts of same date repayments");
		ArrayList<CePaymentSchedule> paymentScheduleList = new ArrayList<>();
		Iterator<Entry<Date, ArrayList<CePaymentSchedule>>> iterator = dateAndpaymentScheduleMap.entrySet().iterator();
		BigDecimal totalRepaymentAmount = BigDecimal.ZERO;
		while (iterator.hasNext()) {
			Entry<Date, ArrayList<CePaymentSchedule>> entry = iterator.next();
			BigDecimal totalPrincipalRepaymentAmount = BigDecimal.ZERO;
			BigDecimal totalProfitRepaymentAmount = BigDecimal.ZERO;
			BigDecimal totalFeesRepaymentAmount = BigDecimal.ZERO;
			BigDecimal totalSubsidyRepaymentAmount = BigDecimal.ZERO;
	     String repaymentStatus=  CommonConstants.EMPTY_STRING;
			for (CePaymentSchedule paymentSchedule : entry.getValue()) {
				totalPrincipalRepaymentAmount = totalPrincipalRepaymentAmount
						.add(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
				totalProfitRepaymentAmount = totalProfitRepaymentAmount
						.add(paymentSchedule.getProfitAmount().getCurrencyAmount());
				totalFeesRepaymentAmount = totalFeesRepaymentAmount
						.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
				totalSubsidyRepaymentAmount = totalSubsidyRepaymentAmount
						.add(paymentSchedule.getSubsidyAmount().getCurrencyAmount());
				repaymentStatus=paymentSchedule.getStatus();
			}

			CePaymentSchedule paymentSchedule = new CePaymentSchedule();
			paymentSchedule.setFeesAmount(IBCommonUtils.getBFCurrencyAmount(totalFeesRepaymentAmount, currencyCode));
			paymentSchedule
					.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(totalPrincipalRepaymentAmount, currencyCode));
			paymentSchedule
					.setProfitAmount(IBCommonUtils.getBFCurrencyAmount(totalProfitRepaymentAmount, currencyCode));
			paymentSchedule.setRepaymentDate(entry.getKey());
			paymentSchedule
					.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(totalSubsidyRepaymentAmount, currencyCode));
			totalRepaymentAmount = paymentSchedule.getFeesAmount().getCurrencyAmount()
					.add(paymentSchedule.getPrincipalAmount().getCurrencyAmount())
					.add(paymentSchedule.getProfitAmount().getCurrencyAmount());
			paymentSchedule
					.setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(totalRepaymentAmount, currencyCode));
			paymentSchedule.setStatus(repaymentStatus);
			paymentScheduleList.add(paymentSchedule);
		}
		if (!paymentScheduleList.isEmpty()) {
			com.ce.bankfusion.ib.util.ScheduleUtils.sortCEPaymentSchedule(paymentScheduleList);
			for (int i = 0; i < paymentScheduleList.size(); i++) {
				if(i==0)
					paymentScheduleList.get(i).setSelect(true);
				else
					paymentScheduleList.get(i).setSelect(false);
				paymentScheduleList.get(i).setRepaymentNo(i + 1);
				cePaymentSchedules[i] = paymentScheduleList.get(i);
			}
		}
	}

	public static BigDecimal getTotalRescheduleProfit(String dealId) {
		BigDecimal totalRescheduleProfit = BigDecimal.ZERO;
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);

		List<IBOCE_IB_DealReschedule> dealRescheduleDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealReschedule.BONAME, dealRescheduleQuery, params, null, false);
		if (!dealRescheduleDtls.isEmpty()) {
			for (IBOCE_IB_DealReschedule dealReschedule : dealRescheduleDtls) {
				if (dealReschedule.getF_IBRESCHEDULESTATUS().equals("COMPLETED"))
					totalRescheduleProfit = totalRescheduleProfit.add(dealReschedule.getF_IBRESCHEDULEPROFIT());
			}
		}

		return totalRescheduleProfit;
	}

	public static CePaymentSchedule[] getNewSchedule(String dealId, String transactionId, String currencyCode) {
		Date reschedulePaymentDate = getReschedulePaymentDate(transactionId);
		CePaymentSchedule[] cePaymentSchedules = null;
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);
		params.add(transactionId);

		List<IBOCE_IB_PaymentScheduleHistory> schHistory = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentScheduleHistory.BONAME, schHisQuery, params, null, false);
		if (schHistory != null && !schHistory.isEmpty()) {
			Map<Date, ArrayList<CePaymentSchedule>> dateAndpaymentScheduleMap = new HashMap();
			for (IBOCE_IB_PaymentScheduleHistory paymentScheduleHistory : schHistory) {
				if(CalendarUtil.IsDate1GreaterThanDate2(paymentScheduleHistory.getF_IBREPAYMENTDATE(), reschedulePaymentDate)
						|| CalendarUtil.IsDate1EqualsToDate2(paymentScheduleHistory.getF_IBREPAYMENTDATE(), reschedulePaymentDate)) {
					CePaymentSchedule vCurrentSchedule = new CePaymentSchedule();
					vCurrentSchedule.setFeesAmount(IBCommonUtils
							.getBFCurrencyAmount(paymentScheduleHistory.getF_IBSCHEDULEFEESAMOUNT(), currencyCode));
					vCurrentSchedule.setPrincipalAmount(IBCommonUtils
							.getBFCurrencyAmount(paymentScheduleHistory.getF_IBPRINCIPALAMOUNT(), currencyCode));
					vCurrentSchedule.setProfitAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleHistory.getF_IBPROFITAMOUNT(), currencyCode));
					vCurrentSchedule.setRepaymentDate(paymentScheduleHistory.getF_IBREPAYMENTDATE());
					vCurrentSchedule.setSubsidyAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleHistory.getF_IBSUBSIDYAMOUNT(), currencyCode));
					vCurrentSchedule.setStatus(
	            IBCommonUtils.getGCChildDesc("IBINSTALLMENTSTATUS", paymentScheduleHistory.getF_IBREPAYMENTSTATUS()));
					if (dateAndpaymentScheduleMap.containsKey(vCurrentSchedule.getRepaymentDate())) {
						dateAndpaymentScheduleMap.get(vCurrentSchedule.getRepaymentDate()).add(vCurrentSchedule);
					} else {
						ArrayList<CePaymentSchedule> paymentSchedules = new ArrayList<>();
						paymentSchedules.add(vCurrentSchedule);
						dateAndpaymentScheduleMap.put(vCurrentSchedule.getRepaymentDate(), paymentSchedules);
					}
				}
			}
			cePaymentSchedules = new CePaymentSchedule[dateAndpaymentScheduleMap.size()];
			addSameDateRepayments(dateAndpaymentScheduleMap, cePaymentSchedules, currencyCode);
		}
		return cePaymentSchedules;
	}
	
	private static Date getReschedulePaymentDate(String transactionId) {
		IBOCE_IB_DealReschedule reschObj = (IBOCE_IB_DealReschedule) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, transactionId, true);
		if(reschObj != null)
			return reschObj.getF_IBRESCHEDULEPAYMENTDT();

		return null;
	}


	public static void validateReschedulePaymentDate(Date firstPaymentDate) {
		if (CalendarUtil.isDateNullOrDefaultDate(firstPaymentDate))
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCH_PAYMENT_DT_CANNOT_BE_BLANK_CEIB);
		Date firstPaymentDateDerived = getRescheduleMinPaymentDate();
		if (CalendarUtil.IsDate1GreaterThanDate2(firstPaymentDateDerived, firstPaymentDate))
		{
			String msgArgs[] = { firstPaymentDateDerived.toString()};
			IBCommonUtils.raiseParametrizedEvent(CeConstants.E_RESCHEDULE_PAYMENT_DATE_MIN_VALID_CEIB,msgArgs);
		}
	}

	public static Date getRescheduleMinPaymentDate() {
		Date firstPaymentDateDerived = AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(),1);
		return firstPaymentDateDerived;
	}
	public static Date getPaymentDateForInvoiceGeneration() {
		ModuleConfigDetails moduleConfigDetails = IBCommonUtils.getModuleConfigurationValue(CESADADINTERFACE,INVGEN_DAYS_BEFORE_DUEDATE);
		String invoiceDaysBeforeDaysStr = moduleConfigDetails.getValue();
        int invoiceDaysBeforeDays = Integer.parseInt(invoiceDaysBeforeDaysStr);
		Date firstPaymentDateDerived = AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(),invoiceDaysBeforeDays);
		return firstPaymentDateDerived;
	}

	public static void validateNewNoOfInstallments(Integer noOfInstallments) {
		if (noOfInstallments <= 0) {
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_SCHEDULE_NOOF_INSTALLMENTS_MIN_VALID_CEIB);
		}
	}

	public static void validateFrequency(String paymentFrequency) {
		if (IBCommonUtils.isNullOrEmpty(paymentFrequency))
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_NEW_FREQ_CANNOT_BE_EMPTY_CEIB);
	}
	public static Currency getSurplusAmount(String loanAcctNo) {
	    ReadLoanDetailsRq apiReadLoanDetailsRq = new ReadLoanDetailsRq();
        apiReadLoanDetailsRq.setRqHeader((RqHeader) CollateralUtil.intializeDefaultvalues(new RqHeader()));
        ReadLoanDetailsInput readLoanDetailsInput = (ReadLoanDetailsInput) CollateralUtil
                .intializeDefaultvalues(new ReadLoanDetailsInput());
        readLoanDetailsInput.setLoanAccountNo(loanAcctNo);
        apiReadLoanDetailsRq.setReadLoanDetailsInput(readLoanDetailsInput);
        String hostURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                CollateralUtil.IB_HOST_URL, CollateralUtil.FALSE_STRING);
        Map result = (Map) WebServiceInvocationHelper.invokeSynchronousCallGeneric(apiReadLoanDetailsRq, hostURL + UB_READ_LOAN_API_SRVWS_WSDL,
                UB_READ_LOAN_API_SRV);
        bf.com.misys.cbs.msgs.v1r0.ReadLoanDetailsRs readLoanDetailsRs = (bf.com.misys.cbs.msgs.v1r0.ReadLoanDetailsRs) result.get("ReadLoanDetailsRs");  
        if(null != readLoanDetailsRs)
        {
            return readLoanDetailsRs.getLoanDetails().getLoanBasicDetails().getSurplusAmt();
        }
        return null;
	}

	public static Object callRescheduleProfitBackOfficeRequest(String loanAcc, String loanReference,
			String transReference, BigDecimal adjustAmount) {
		LOGGER.info("callRescheduleProfitBackOfficeRequest Service is Starting...");
		BackOfficeAccountPostingRq request = new BackOfficeAccountPostingRq();
		PostingLeg[] postingLegs = new PostingLeg[2];
		PostingLeg crLeg = new PostingLeg();
		PostingLeg drLeg = new PostingLeg();
		CEUtil ceUtil = new CEUtil();
		String earnedAccount = null;
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(loanReference);
		LOGGER.info("loanAcc: " + loanAcc);
		ArrayList<String> inputParams = new ArrayList<String>();
		String whereClause = "WHERE " + IBOUB_FIN_AmortizationDetails.ACCOUNTID + " =? ";
		inputParams.add(loanAcc);
		List<IBOUB_FIN_AmortizationDetails> amortizationDetailsList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOUB_FIN_AmortizationDetails.BONAME, whereClause, inputParams, null, true);
		if (null != amortizationDetailsList && !amortizationDetailsList.isEmpty())
			earnedAccount = amortizationDetailsList.get(0).getF_EARNEDACCOUNTID();
		else
			earnedAccount = getInterestRecAccountID(loanAcc, dealDetails.getF_BranchSortCode(), dealDetails.getF_IsoCurrencyCode());
		if (null != earnedAccount && earnedAccount.trim().length() > 0) {
			String deferredIncome = getDeferredIncomeAcc(dealDetails.getF_BranchSortCode(),
					dealDetails.getF_IsoCurrencyCode());
			String drTxnCode = null;
			String crTxnCode = null;
			drTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, DEBIT_PARAM_NAME);
			LOGGER.info("Inst drTxnCode:" + drTxnCode);
			crTxnCode = ceUtil.getModuleConfigurationValue(LENDING_MODULE, CREDIT_PARAM_NAME);
			LOGGER.info("Inst crTxnCode:" + crTxnCode);
			IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
					.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
			crLeg = populatePostingLeg(deferredIncome, adjustAmount, "C", IBConstants.EMPTY_STRING, crTxnCode,
					loanAccDtl.getF_ISOCURRENCYCODE());
			LOGGER.info("crLeg:" + crLeg);
			drLeg = populatePostingLeg(earnedAccount, adjustAmount, "D", IBConstants.EMPTY_STRING, drTxnCode,
					loanAccDtl.getF_ISOCURRENCYCODE());
			LOGGER.info("drLeg:" + drLeg);
			postingLegs[0] = crLeg;
			postingLegs[1] = drLeg;
			request.setBackOfficePostingLegs(postingLegs);

			TxnDetails txnDetails = new TxnDetails();
			txnDetails.setChannelId("SADAD");
			txnDetails.setForcePost(false);
			txnDetails.setTransactionId(GUIDGen.getNewGUID());
			txnDetails.setTransactionReference(transReference);
			Date busDate = SystemInformationManager.getInstance().getBFBusinessDate();
			LOGGER.info("busDate: " + busDate);
			txnDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDateTime());
			request.setTxnDetails(txnDetails);
			Map params = new HashMap();
			params.put("backOfficeAccountPostingRq", request);
			HashMap result = MFExecuter.executeMF("UB_R_UB_TXN_BackOfficeAccountPosting_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), params);

			LOGGER.info("Before BackOfficeAccountPosting");
			BackOfficeAccountPostingRs response = (BackOfficeAccountPostingRs) result.get("backOfficeAccountPostingRs");
			LOGGER.info("response: " + response);
			ErrorResponse errorResponse = (ErrorResponse) result.get("ErrorResponse");
			LOGGER.info("errorResponse: " + errorResponse);
			LOGGER.info("callRescheduleProfitBackOfficeRequest Service is Ending...");
			if (null != response && response.getTransactionId() != null) {
				LOGGER.info("callRescheduleProfitBackOfficeRequest Service is Successful");
			} else {
				LOGGER.info("Error while executing callRescheduleProfitBackOfficeRequest Service is Ending...");
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_GENERIC_ERROR,
						new Object[] { IBConstants.EMPTY_STRING }, LOGGER,
						BankFusionThreadLocal.getBankFusionEnvironment());
			}
			return response;
		} else {
			LOGGER.info("earnedAccount is empty for the loan account -->" + loanAcc);
			return null;
		}
	}
	public static Object callBackOfficePostingRequest(String loanAcc, String loanReference,
			String transReference, BigDecimal amount, String creditAcctId, String debitAcctId,String narrative,String drTxnCode, String crTxnCode) {
		LOGGER.info("callBackOfficePostingRequest Service is Starting...");
		BackOfficeAccountPostingRq request = new BackOfficeAccountPostingRq();
		PostingLeg[] postingLegs = new PostingLeg[2];
		PostingLeg crLeg = new PostingLeg();
		PostingLeg drLeg = new PostingLeg();
		LOGGER.info("loanAcc: " + loanAcc);
		LOGGER.info("Inst drTxnCode:" + drTxnCode);
		LOGGER.info("Inst crTxnCode:" + crTxnCode);
		IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
		crLeg = populatePostingLeg(creditAcctId, amount, "C", narrative, crTxnCode,
				loanAccDtl.getF_ISOCURRENCYCODE());
		LOGGER.info("creditAcctId:" + creditAcctId);
		drLeg = populatePostingLeg(debitAcctId, amount, "D", narrative, drTxnCode,
				loanAccDtl.getF_ISOCURRENCYCODE());
		LOGGER.info("debitAcctId:" + debitAcctId);
		postingLegs[0] = crLeg;
		postingLegs[1] = drLeg;
		request.setBackOfficePostingLegs(postingLegs);

		TxnDetails txnDetails = new TxnDetails();
		txnDetails.setChannelId("SVR");
		txnDetails.setForcePost(false);
		txnDetails.setTransactionId(GUIDGen.getNewGUID());
		txnDetails.setTransactionReference(transReference);
		Date busDate = SystemInformationManager.getInstance().getBFBusinessDate();
		LOGGER.info("busDate: " + busDate);
		txnDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDateTime());
		request.setTxnDetails(txnDetails);
		Map params = new HashMap();
		params.put("backOfficeAccountPostingRq", request);
		HashMap result = MFExecuter.executeMF("UB_R_UB_TXN_BackOfficeAccountPosting_SRV",
				BankFusionThreadLocal.getBankFusionEnvironment(), params);

		LOGGER.info("Before BackOfficeAccountPosting");
		BackOfficeAccountPostingRs response = (BackOfficeAccountPostingRs) result.get("backOfficeAccountPostingRs");
		LOGGER.info("response: " + response);
		ErrorResponse errorResponse = (ErrorResponse) result.get("ErrorResponse");
		LOGGER.info("errorResponse: " + errorResponse);
		LOGGER.info("callBackOfficePostingRequest Service is Ending...");
		if (null != response && response.getTransactionId() != null) {
			LOGGER.info("callBackOfficePostingRequest Service is Successful");
		} else {
			LOGGER.info("Error while executing callBackOfficePostingRequest Service is Ending...");
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_GENERIC_ERROR,
					new Object[] { IBConstants.EMPTY_STRING }, LOGGER,
					BankFusionThreadLocal.getBankFusionEnvironment());
		}
		return response;

	}

	public static PostingLeg populatePostingLeg(String accID, BigDecimal amt, String postingAction, String narrative,
			String txnCode, String txnCur) {
		PostingLeg postingLeg = new PostingLeg();
		postingLeg.setAccountId(accID);
		postingLeg.setAmount(amt);
		postingLeg.setCreditDebitIndicator(postingAction);
		postingLeg.setNarrative(narrative);
		postingLeg.setTransactionCode(txnCode);
		postingLeg.setTransactionCurrency(txnCur);
		return postingLeg;
	}

	public static String getDeferredIncomeAcc(String branchCode, String isoCurrencyCode) {

		String chargeReceivingAccPseudonym = getDeferredIncomeAccPseudonym();
		LOGGER.info("getDeferredIncomeAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, chargeReceivingAccPseudonym);
		return bankAccID;
	}
	public static String getDeferredIncomeAccPseudonym() {
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue(MODULE_NAME_IB, PARAM_DEFERREDINCACCT);
		LOGGER.info("getDeferredIncomeAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		return chargeReceivingAccPseudonym;
	}

	public static String getRescheduleEarnedAcc(String branchCode, String isoCurrencyCode) {

		String chargeReceivingAccPseudonym = getRescheduleEarnedAccPseudonym();
		LOGGER.info("getRescheduleEarnedAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, chargeReceivingAccPseudonym);
		return bankAccID;
	}
	public static String getRescheduleEarnedAccPseudonym() {
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue(MODULE_NAME_IB, PARAM_RESCHEDULEEARNEDACC);
		LOGGER.info("getRescheduleEarnedAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		return chargeReceivingAccPseudonym;
	}

	public static String getBankAccountID(String isoCurrencyCode,String branchCode, String chargeReceivingAccPseudonym) {
		String bankAccID = EMPTY;
		IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOpseudonyms.BONAME, chargeReceivingAccPseudonym, true);
		if(null != pseudDtls)
		{
			String contextValue = isoCurrencyCode;
			LOGGER.info("getF_FINDERALTERNATIVE1: " + pseudDtls.getF_FINDERALTERNATIVE1());
			if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
				contextValue = branchCode;
				LOGGER.info("contextValue" + contextValue);
			}
			List finderResult = FinderMethods.findAccountByPseudoname(chargeReceivingAccPseudonym, isoCurrencyCode,
					pseudDtls.getF_FINDERALTERNATIVE1(), contextValue, BankFusionThreadLocal.getBankFusionEnvironment(),
					null);
			if (finderResult != null && !finderResult.isEmpty()) {
				bankAccID = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
				LOGGER.info("bankAccID:" + bankAccID);
			}
		}
		return bankAccID;
	}

	public static String getRescheduleReceivableAcc(String branchCode, String isoCurrencyCode) {
		String chargeReceivingAccPseudonym = getRescheduleReceivableAccPseudonym();
		String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, chargeReceivingAccPseudonym);
		LOGGER.info("getRescheduleReceivableAcc bankAccID : " + bankAccID);
		return bankAccID;
	}
	public static String getRescheduleReceivableAccPseudonym() {
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue(MODULE_NAME_IB, PARAM_RESCHEDULERECEIVABLEACC);
		LOGGER.info("getRescheduleReceivableAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		return chargeReceivingAccPseudonym;
	}

	public static String getUnearnedAcc(String branchCode, String isoCurrencyCode) {
		String chargeReceivingAccPseudonym = getUnearnedAccPseudonym();
		String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, chargeReceivingAccPseudonym);
		LOGGER.info("getUnearnedAcc bankAccID : " + bankAccID);
		return bankAccID;
	}
	public static String getUnearnedAccPseudonym() {
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue(MODULE_NAME_IB, PARAM_UNEARNEDACC);
		LOGGER.info("getUnearnedAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		return chargeReceivingAccPseudonym;
	}

	public static String getUpfrontIncomeAcc(String branchCode, String isoCurrencyCode) {
		String chargeReceivingAccPseudonym = getUpfrontIncomeAccPseudonym();
		String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, chargeReceivingAccPseudonym);
		LOGGER.info("getUpfrontIncomeAcc bankAccID : " + bankAccID);
		return bankAccID;
	}
	public static String getUpfrontIncomeAccPseudonym() {
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue(MODULE_NAME_IB, PARAM_UPFRONTINCOMEACC);
		LOGGER.info("getUpfrontIncomeAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		return chargeReceivingAccPseudonym;
	}

	public static String getInterestRecAccountID(String loanAccountID, String branchCode, String isoCurrencyCode) {
		ArrayList<String> params = new ArrayList<String>();
		params.add(loanAccountID);
		IBODebitInterestFeature debitInterest = (IBODebitInterestFeature) BankFusionThreadLocal.getPersistanceFactory()
				.findFirstByQuery(IBODebitInterestFeature.BONAME, " WHERE "+IBODebitInterestFeature.ACCOUNTID+"=?", params,  false);
		params.clear();
		params.add(debitInterest.getF_NOMINALCODE());
		params.add(branchCode);
		params.add(isoCurrencyCode);
		String intAccrWhereClause = " WHERE f_NOMINALCODE = ? AND f_COSTCENTRE = ? AND f_ISOCURRENCYCODE = ? ";
		List listAccruals = (ArrayList) BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOInterestAccruals.BONAME, intAccrWhereClause, params, null, false);
		if (!listAccruals.isEmpty()) {
			IBOInterestAccruals interestAccrualBO = (IBOInterestAccruals) listAccruals.get(0);
			String accountID = interestAccrualBO.getF_INTRECDACCOUNTID().toString();
			LOGGER.info("InterestRecAccountID : " + accountID);
			String bankAccID = getBankAccountID(isoCurrencyCode,branchCode, accountID);
			LOGGER.info("bankAccID : " + bankAccID);
			return EMPTY.equals(bankAccID) ? accountID : bankAccID;
		} else {
			return "";
		}
	}

	public static void handleErrorHeader(RsHeader header) {
		if (header.getStatus().getCodes().length > 0) {
			for (int i = 0; i < header.getStatus().getCodesCount(); i++) {
				if (Integer.parseInt(((SubCode) header.getStatus().getCodes(i)).getCode()) == 40000262)
					handleErrorResponse(header);
				else {
					String eventParameterValue = CommonConstants.EMPTY_STRING;
					if (header.getStatus().getCodes(i).getParametersCount() > 0) {
						eventParameterValue = ((SubCode) header.getStatus().getCodes(i)).getParameters(0)
								.getEventParameterValue();
					}
					String eventCode = ((SubCode) header.getStatus().getCodes(i)).getCode();
					BusinessEventSupport.getInstance().raiseBusinessErrorEvent(Integer.parseInt(eventCode),
							new Object[] { eventParameterValue }, LOGGER,
							BankFusionThreadLocal.getBankFusionEnvironment());
				}
			}
		}
	}

	public static void handleErrorResponse(RsHeader header) {
		StringBuilder builder = new StringBuilder(CommonConstants.EMPTY_STRING);
		if (header.getStatus().getCodes().length > 0) {
			for (int i = 0; i < header.getStatus().getCodesCount(); i++) {
				builder.append(header.getStatus().getCodes(i).getDescription());
			}
		}
		if (builder.length() > 0)
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_GENERIC_ERROR,
					new Object[] { builder.toString() }, LOGGER, BankFusionThreadLocal.getBankFusionEnvironment());
	}

	public static RsHeader getRsHeader(ErrorResponse errorResponse) {
		RsHeader ibrsHeader = new RsHeader();
		ibrsHeader.setMessageType(CommonConstants.EMPTY_STRING);
		ibrsHeader.setOrigCtxtId(CommonConstants.EMPTY_STRING);
		ibrsHeader.setStatus(getStatus(errorResponse));
		ibrsHeader.setVersion(errorResponse.getVersion());

		return ibrsHeader;
	}

	private static MessageStatus getStatus(ErrorResponse errorResponse) {
		MessageStatus messageStatus = new MessageStatus();
		if (errorResponse.getEventCollection() != null)
			messageStatus.setCodes(getCodes(errorResponse));
		if (errorResponse.getEventCollection() != null && errorResponse.getEventCollection().getEventCount() > 0) {
			errorResponse.setOVERALLSTATUS(ERROR);
		} else {
			errorResponse.setOVERALLSTATUS(SUCCESS);
		}
		messageStatus.setOverallStatus(errorResponse.getOVERALLSTATUS());
		messageStatus.setSubStatus(CommonConstants.EMPTY_STRING);

		return messageStatus;
	}

	private static SubCode[] getCodes(ErrorResponse errorResponse) {

		SubCode[] subCodes = new SubCode[errorResponse.getEventCollection().getEventCount()];
		for (int i = 0; i < errorResponse.getEventCollection().getEventCount(); i++) {
			subCodes[i] = new SubCode();
			subCodes[i].setCode(errorResponse.getEventCollection().getEvent(i).getEventNumber().toString());
			subCodes[i].setDescription(errorResponse.getEventCollection().getEvent(i).getEventMessage());
			subCodes[i].setFieldName(CommonConstants.EMPTY_STRING);
			subCodes[i].setParameters(getParamaters(errorResponse.getEventCollection().getEvent(i)));
			subCodes[i].setSeverity(errorResponse.getEventCollection().getEvent(i).getSeverity());
		}
		return subCodes;

	}

	private static EventParameters[] getParamaters(Event event) {
		EventParameters[] eventParameters = new EventParameters[0];
		event.getEventID();
		return eventParameters;
	}

	public static BigDecimal getPaidRescheduleProfit(String dealNo) {
		ArrayList<Object> inputParams = new ArrayList<Object>();
		inputParams.add(dealNo);
		String whereAllRecords = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?  ";
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereAllRecords, inputParams, null, true);
		BigDecimal paidScheduledFeeAmt = BigDecimal.ZERO;
		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			paidScheduledFeeAmt = paidScheduledFeeAmt.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
		}
		return paidScheduledFeeAmt;
	}

	public static boolean isNonFrontLoadedManual(String subProductID, String accountId,
			boolean isHostScheduleGenerator) {
		if (!isHostScheduleGenerator && IBCommonUtils.isNotEmpty(accountId))
			return !LoanPlanFinderMethods.isInterestUpfrontLoaded(accountId, IBCommonUtils.getBankFusionEnvironment());
		else if (!isHostScheduleGenerator && IBCommonUtils.isEmpty(accountId)) {
			ReadLoanProductDetailsRs apiReadLoanProductDetailsRs = getHostProductDetails(subProductID);
			return !apiReadLoanProductDetailsRs.getReadLoanProductDetailsOutput().getProductSummaryDtls()
					.getIsInterestUpFrontLoaded();
		} else
			return false;
	}
	public static ReadLoanProductDetailsRs getHostProductDetails(String subProductID) {
		String remoteHostURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,"IB_HOST_URL","false");
		ReadLoanProductDetailsRq apireadLoanProductDetailsRq=new ReadLoanProductDetailsRq();
		ReadLoanProductDetailsInput apiReadLoanProductDetailsInput=new ReadLoanProductDetailsInput();
		apiReadLoanProductDetailsInput.setProductType(subProductID);
		apiReadLoanProductDetailsInput.setLoanProductID(subProductID);
		apireadLoanProductDetailsRq.setReadLoanProductDetailsInput(apiReadLoanProductDetailsInput);
		Object response = WebServiceInvocationHelper.invokeSynchronousCallGeneric(apireadLoanProductDetailsRq,
				remoteHostURL + "bfweb/services/UB_R_CB_PRD_ReadLoanProductDetails_SRVWS?wsdl",
				"UB_R_CB_PRD_ReadLoanProductDetails_SRV");
		ReadLoanProductDetailsRs apiReadLoanProductDetailsRs = new ReadLoanProductDetailsRs();
        apiReadLoanProductDetailsRs = (ReadLoanProductDetailsRs) ((HashMap) response).get("readLoanProductDetailsRs");
		return apiReadLoanProductDetailsRs;
	}
	public static String getEventCodeLocalizedMessage(String value1, String value2, int eventcode,
			BankFusionEnvironment env) {
		HashMap<String, Object> inputs = new HashMap<String, Object>();
		inputs.put("EventCode",  String.valueOf(eventcode));
		inputs.put("Value1", value1);
		inputs.put("Value2", value2);
		HashMap scheduleOutputMap = MFExecuter.executeMF("IB_IDI_GetMessageforEventCode_SRV", env, inputs);
		String localizedMessage = (String) scheduleOutputMap.get("message");
		return localizedMessage;
	}
	public static IBOCE_IB_DealReschedule getRescheduleLatestRecord(String dealId) {
		IBOCE_IB_DealReschedule dealReschObj = null;
		String dealReschDetailQuery = " WHERE " + IBOCE_IB_DealReschedule.IBDEALID + " = ?  and "
				+ IBOCE_IB_DealReschedule.IBRESCHEDULESTATUS + "=? ORDER BY "
				+ IBOCE_IB_DealReschedule.IBRECLASTMODIFIEDDATE + " ASC ";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(RescheduleConstants.STATUS_COMPLETED);
		List<IBOCE_IB_DealReschedule> dealRescheduleDetailsList = IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_DealReschedule.BONAME,
						dealReschDetailQuery.toString(), params, null, false);
		if (dealRescheduleDetailsList != null
				&& dealRescheduleDetailsList.size() > CommonConstants.INTEGER_ZERO) {
			dealReschObj = dealRescheduleDetailsList.get(CommonConstants.INTEGER_ZERO);
		}
		return dealReschObj;
	}

	public static List<IBOCE_IB_PaymentSchBreakup> getFutureInstallmentsInBreakUpByAssetId(Date reschedulePaymentDate, String assetId,
			String dealID) {
		LOGGER.info("Entering into deleteFutureInstallmentsInBreakUp method deal Id ==>" + dealID);
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
				+ IBOCE_IB_PaymentSchBreakup.IBASSETID + " = ? AND " + IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " >= ? order by "+IBOCE_IB_PaymentSchBreakup.IBBILLDATE+" asc ";
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealID);
		params.add(assetId);
		params.add(reschedulePaymentDate);
		List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakup = IBCommonUtils.getPersistanceFactory().findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery,null,
				params,true);
		LOGGER.info(
				"Exiting from getFutureInstallmentsInBreakUpByAssetId method deal Id ==>" + dealID);
		return paymentSchBreakup;
	}
	public static IBOCE_IB_PaymentSchBreakup persistFutureInstallmentsInBreakUpByAssetId(PaymentSchedule paymentSchedule, String assetId,
			String dealID, boolean isInlcudeSubsidy, ReadAssetData readAssetData) {
		LOGGER.info("Entering into persistFutureInstallmentsInBreakUpByAssetId method deal Id ==>" + dealID);
		String assetSubsidyPercentage = CeUtils.getAssetSubsidyPercentage(readAssetData, assetId);
		if (assetSubsidyPercentage.equals(CommonConstants.EMPTY_STRING)) {
			assetSubsidyPercentage = "0.00";
		}
		List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupExisting = getExistingPaymentScheduleBreakupRecord(assetId,
				dealID, paymentSchedule.getRepaymentDate());
		IBOCE_IB_PaymentSchBreakup paymentSchBreakup = null;
		if (null != paymentSchBreakupExisting && !paymentSchBreakupExisting.isEmpty()) {

			paymentSchBreakup = updateExistingPaymentScheduleBreakupRecord(isInlcudeSubsidy, assetSubsidyPercentage,
					paymentSchedule, paymentSchBreakupExisting);
		}

		if (null == paymentSchBreakup) {
			paymentSchBreakup = createNewPaymentScheduleBreakupRecord(assetId, dealID, isInlcudeSubsidy, assetSubsidyPercentage,
					paymentSchedule);
		}
		return paymentSchBreakup;
	}
	private static IBOCE_IB_PaymentSchBreakup createNewPaymentScheduleBreakupRecord(String assetId, String dealID, boolean isInlcudeSubsidy,
			String assetSubsidyPercentage, PaymentSchedule paymentSchedule) {
		IBOCE_IB_PaymentSchBreakup paymentSchBreakup;
		paymentSchBreakup = (IBOCE_IB_PaymentSchBreakup) (BankFusionThreadLocal.getPersistanceFactory()
				.getStatelessNewInstance(IBOCE_IB_PaymentSchBreakup.BONAME));
		paymentSchBreakup.setBoID(IBCommonUtils.getNewGUID());
		paymentSchBreakup.setF_IBASSETID(assetId);
		paymentSchBreakup.setF_IBBILLDATE(paymentSchedule.getRepaymentDate());
		paymentSchBreakup.setF_IBDEALID(dealID);
		paymentSchBreakup.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMT(paymentSchedule.getPrincipleAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBPROFITAMT(paymentSchedule.getProfitAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBSCHEDULEFEEAMT(paymentSchedule.getFeeAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
		if (isInlcudeSubsidy) {
			paymentSchBreakup.setF_IBSUBSIDYAMNT((paymentSchedule.getPrincipleAmt().getCurrencyAmount()
					.multiply(new BigDecimal(assetSubsidyPercentage))).divide(new BigDecimal(100), 0,
							RoundingMode.FLOOR));
		}
		BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_PaymentSchBreakup.BONAME,
				paymentSchBreakup);
		return paymentSchBreakup;
	}
	private static IBOCE_IB_PaymentSchBreakup updateExistingPaymentScheduleBreakupRecord(boolean isInlcudeSubsidy, String assetSubsidyPercentage,
			PaymentSchedule paymentSchedule, List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupExisting) {
		IBOCE_IB_PaymentSchBreakup paymentSchBreakup;
		paymentSchBreakup = paymentSchBreakupExisting.get(0);
		paymentSchBreakup.setF_IBPRINCIPALAMT(paymentSchBreakup.getF_IBPRINCIPALAMT().add(paymentSchedule.getPrincipleAmt().getCurrencyAmount()));
		paymentSchBreakup.setF_IBPROFITAMT(paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchedule.getProfitAmt().getCurrencyAmount()));
		paymentSchBreakup.setF_IBSCHEDULEFEEAMT(paymentSchBreakup.getF_IBSCHEDULEFEEAMT().add(paymentSchedule.getFeeAmt().getCurrencyAmount()));
		if (isInlcudeSubsidy) {
			paymentSchBreakup.setF_IBSUBSIDYAMNT((paymentSchBreakup.getF_IBPRINCIPALAMT()
					.multiply(new BigDecimal(assetSubsidyPercentage))).divide(new BigDecimal(100), 0,
							RoundingMode.FLOOR));
		}
		return paymentSchBreakup;
	}
	private static List<IBOCE_IB_PaymentSchBreakup> getExistingPaymentScheduleBreakupRecord(String assetId,
			String dealID, Date repaymentDate) {
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
				+ IBOCE_IB_PaymentSchBreakup.IBASSETID + " = ? AND " + IBOCE_IB_PaymentSchBreakup.IBBILLDATE
				+ " = ? ";
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealID);
		params.add(assetId);
		params.add(repaymentDate);
		List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakupExisting = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params,null, true);
		return paymentSchBreakupExisting;
	}
	public static List<IBOCE_IB_PaymentScheduleHistory> getExistingPaymentScheduleHistoryBreakupRecord(String assetId,
			String dealID) {
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentScheduleHistory.IBDEALID + " = ? AND "
				+ IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID + " = ? AND "
				+ IBOCE_IB_PaymentScheduleHistory.IBASSETID + " = ?  order by "+IBOCE_IB_PaymentScheduleHistory.IBREPAYMENTDATE+" asc " ;
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealID);
		params.add(dealID);
		params.add(assetId);
		List<IBOCE_IB_PaymentScheduleHistory> paymentSchHistoryBreakupExisting = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentScheduleHistory.BONAME, scheduleBreakupQuery, params, null,true);
		return paymentSchHistoryBreakupExisting;
	}

	public static void peristBreakupDatatoBreakupHistory(String dealID) {
		ArrayList<String> params = new ArrayList<String>();
		String schHisQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		params.clear();
		params.add(dealID);

		List<IBOCE_IB_PaymentSchBreakup> schHistory = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, schHisQuery, params, null, false);
		if (schHistory != null && !schHistory.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : schHistory) {
				IBOCE_IB_PaymentScheduleHistory newPaymentSchedule = (IBOCE_IB_PaymentScheduleHistory) IBCommonUtils
						.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentScheduleHistory.BONAME);
				newPaymentSchedule.setF_IBASSETID(paymentSchBreakup.getF_IBASSETID());
				newPaymentSchedule.setF_IBDEALID(dealID);
				newPaymentSchedule.setF_IBPRINCIPALAMOUNT(paymentSchBreakup.getF_IBPRINCIPALAMT());
				newPaymentSchedule.setF_IBPROFITAMOUNT(paymentSchBreakup.getF_IBPROFITAMT());
				newPaymentSchedule.setF_IBREPAYMENTDATE(paymentSchBreakup.getF_IBBILLDATE());
				newPaymentSchedule.setF_IBRESCHEDULEID(dealID);
				newPaymentSchedule.setF_IBSCHEDULEFEESAMOUNT(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				newPaymentSchedule.setF_IBSUBSIDYAMOUNT(paymentSchBreakup.getF_IBSUBSIDYAMNT());
				newPaymentSchedule.setF_IBREPAYMENTSTATUS(IBConstants.REPAYMENT_STATUS_UNPAID);
				IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_PaymentScheduleHistory.BONAME,
						newPaymentSchedule);
			}
		}
	}
	public static int deleteExistingRecordsInBreakupHistoryTable(String dealID) {
		StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID
				+ "= ? AND " + IBOCE_IB_PaymentScheduleHistory.IBDEALID + "= ? ");
		ArrayList<String> params = new ArrayList<String>();
		params.add(dealID);
		params.add(dealID);
		int noOfRecordsDeleted = IBCommonUtils.getPersistanceFactory().bulkDelete(IBOCE_IB_PaymentScheduleHistory.BONAME,
				queryCondition.toString(), params);
		return noOfRecordsDeleted;
	}
	
}
