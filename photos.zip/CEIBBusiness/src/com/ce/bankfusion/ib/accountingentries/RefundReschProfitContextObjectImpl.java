package com.ce.bankfusion.ib.accountingentries;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.accountingentries.IContextObjectPreparator;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.util.IBCommonUtils;

public class RefundReschProfitContextObjectImpl implements IContextObjectPreparator {

	@Override
	public List<Object> getContextObject(String context, String objectId) {

		List<Object> returnObject = new ArrayList<>();
		IBOCE_IB_REFUNDRESCHDTLS refundReschProfitDtls = (IBOCE_IB_REFUNDRESCHDTLS) IBCommonUtils
				.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, objectId, true);

		if (refundReschProfitDtls != null
				&& refundReschProfitDtls.getF_IBSYSTEMSTATUS().equals(CeConstants.REFUND_STATUS_SCHEDULED)) {
			IBOIB_TXN_PAYRECDETAIL payRecDtlObj = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, objectId, true);
			returnObject.add(payRecDtlObj);
		}

		return returnObject;
	}

}
