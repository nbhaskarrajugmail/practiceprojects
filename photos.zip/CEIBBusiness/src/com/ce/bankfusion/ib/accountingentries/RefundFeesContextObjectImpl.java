package com.ce.bankfusion.ib.accountingentries;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDFEES;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.accountingentries.IContextObjectPreparator;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.util.IBCommonUtils;

public class RefundFeesContextObjectImpl implements IContextObjectPreparator {

	public static final String SELECT_PAYMENTRECEIVEDTLS = " WHERE " + IBOIB_TXN_PAYRECDETAIL.TRANSACTIONID + " = ?"
			+ " AND " + IBOIB_TXN_PAYRECDETAIL.DEALNO + " = ? " + " AND " + IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + " = ? ";

	public static final String AMOUNT_TYPE = "REFUNDFEES";

	@Override
	public List<Object> getContextObject(String context, String objectId) {

		List<Object> returnObject = new ArrayList<>();
		IBOCE_IB_REFUNDFEES refundFeesDtls = (IBOCE_IB_REFUNDFEES) IBCommonUtils
				.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_REFUNDFEES.BONAME, objectId, true);
		returnObject.add(refundFeesDtls);

		if (refundFeesDtls != null && CeConstants.REFUND_STATUS_SCHEDULED.equals(refundFeesDtls.getF_IBREFUNDSTATUS())) {
			IBOIB_TXN_PAYRECDETAIL payRecDtlObj = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, objectId,
							true);
			returnObject.add(payRecDtlObj);
		}

		return returnObject;
	}

}
