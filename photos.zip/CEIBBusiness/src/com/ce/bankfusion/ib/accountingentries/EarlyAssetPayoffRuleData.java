package com.ce.bankfusion.ib.accountingentries;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.misys.bankfusion.ib.accountingentries.IRuleData;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;

import bf.com.misys.ib.types.RuleInputData;
import bf.com.misys.ib.types.SystemObjectOutputDetail;

public class EarlyAssetPayoffRuleData implements IRuleData {

	@Override
	public void setSystemObjectsToRuleData(RuleInputData ruleData, List<Object> specificEntity) {
		for (Object object : specificEntity) {
			SystemObjectOutputDetail inputData = new SystemObjectOutputDetail();
			if (object instanceof IBOCE_IB_EarlyAssetPayoffDtls) {
				inputData.setSystemObjectName("CE_IB_EarlyAssetPayoffDtls");
			} else if (object instanceof IBOIB_TXN_PAYRECDETAIL) {
				inputData.setSystemObjectName("IB_TXN_PAYRECDETAIL");
			}
			List<Object> objlist = new ArrayList();
			objlist.add(object);
			inputData.setSystemObjectList(objlist);
			ruleData.addInputData(inputData);
		}
	}
}
