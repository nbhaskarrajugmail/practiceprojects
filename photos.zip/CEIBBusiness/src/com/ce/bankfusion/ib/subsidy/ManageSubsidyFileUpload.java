
package com.ce.bankfusion.ib.subsidy;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_GovtSubsidy;
import com.ce.financialgateway.BatchCollectionConstants;
import com.finastra.openapi.common.utils.CommonApiUtil;
import com.misys.bankfusion.clearing.common.ClearingUtil;
import com.misys.bankfusion.common.BankFusionMessages;
import com.misys.bankfusion.common.util.DateUtils;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;
import com.misys.cbs.config.ModuleConfiguration;
import com.misys.fbe.uploadfile.FileUploadHandler;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Party;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyContactDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

public class ManageSubsidyFileUpload extends FileUploadHandler {

	Log logger = LogFactory.getLog(ManageSubsidyFileUpload.class);
	String FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_PersonalDetails.NATIONALIDTYPEID + " = ? AND "
			+ IBOPT_PFN_PersonalDetails.NATIONALID + " = ? ";
	String FIND_CONTACT_DETAILS = " WHERE " + IBOPT_PFN_PartyContactDetails.INTERNALPARTYID + " = ? AND "
			+ IBOPT_PFN_PartyContactDetails.CONTACTMETHOD + " = ? AND "+ IBOPT_PFN_PartyContactDetails.CONTACTTYPE + " = ?";
	private final static String DUPLICATE_FILE_QUERY = " WHERE " + IBOCE_ADF_GovtSubsidy.IBPROCESSINGYEAR + " = ? ";
	ClearingUtil utils = new ClearingUtil();

	//String batchReference = "";
	String message;

	@Override
	public HashMap<String, String> uploadFileData(byte[] fileByteArray) {
		HashMap<String, String> response = new HashMap();
		HashMap<String, Object> formData = getRequestData();
		String docUpload = (String) formData.get("sname");
		if ((fileByteArray.length != 0) && (null != docUpload)) {
			copyFileInMessageGatewayFolder(fileByteArray, response, (int) formData.get("year"));
			return response;
		}
		return super.uploadFileData(fileByteArray);
	}

	private void copyFileInMessageGatewayFolder(byte[] fileByteArray, HashMap<String, String> response, int year) {
		Boolean success = false;
		String fileext = getFileExtn();
		String fileName = getFileName();
		CommonApiUtil.setBankFusionEnvironment();
		message = utils.getEventMessage(BatchCollectionConstants.EVT_UPLOAD_FAILED);
		boolean isDuplicate = isDuplicateFile(year);
		if (!isDuplicate) {
			String dateForlderName = DateUtils.dateFormatter
					.format(SystemInformationManager.getInstance().getBFBusinessDate());
			String fileLocation = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
					"BatchInfo.fileLocation");
			try {
				if (fileext.toUpperCase().equals("XLSX")) {
					String file = fileLocation + File.separator + dateForlderName + File.separator + fileName;
					File newFile = new File(file);
					FileUtils.writeByteArrayToFile(newFile, fileByteArray);
					success = importxlsFile(newFile, fileName, year);

				} else {
					message = utils.getEventMessage(BatchCollectionConstants.EVT_FORMAT_NOT_SUPORTED);
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}else {
			message = utils.getEventMessage(BatchCollectionConstants.EVT_DUPLICATE_FILE);
		}
		// response.put("batchReferenceGenerated", success ? batchReference : "");
		response.put("fileID",
				success ? getEventMessage(BatchCollectionConstants.EVT_UPLOADED_SUCCESS, new String[] { "" })
						: message);
	}

	private String getCellAsString(Row row, int idx) {
		Cell c = null;
		if (row.getCell(idx) == null) {
			c = row.createCell(idx);

		} else {
			c = row.getCell(idx);
		}
		c.setCellType(CellType.STRING);
		return c.getStringCellValue();
	}

	private boolean importxlsFile(File f, String fileName, int year) throws Exception {
		CB_CMN_PrivateSession session = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory factory = session.createSession();
		XSSFWorkbook wb = null;
		try {
			
			factory.beginTransaction();
			OPCPackage pkg = OPCPackage.open(f);
			wb = new XSSFWorkbook(pkg);
			XSSFSheet sheet = wb.getSheetAt(0);
			int columnNamesRowNo = 0;
			for (Row row : sheet) {
				if(row.getRowNum()==columnNamesRowNo)
					continue;
				
				
				
				IBOCE_ADF_GovtSubsidy subsidyDetails = (IBOCE_ADF_GovtSubsidy) factory
						.getStatelessNewInstance(IBOCE_ADF_GovtSubsidy.BONAME);
				int colIdx = 0;
				subsidyDetails.setF_IBFILENAME(fileName);
				String nationalId = getCellAsString(row, colIdx++);
				subsidyDetails.setF_IBNATIONALID(nationalId);
				
				ArrayList qParams = new ArrayList();
				qParams.add("NATIONAL_ID_001");
				qParams.add(nationalId);
				IBOPT_PFN_PersonalDetails personalDtl = (IBOPT_PFN_PersonalDetails) BankFusionThreadLocal
						.getPersistanceFactory()
						.findFirstByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_CUSTOMERID, qParams, true);
				if (personalDtl != null) {
					IBOPT_PFN_Party party = (IBOPT_PFN_Party) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOPT_PFN_Party.BONAME, personalDtl.getBoID(),true);
					if (party != null) {
						subsidyDetails.setF_IBPARTYNAME(party.getF_NAME());
						subsidyDetails.setF_IBPARTYID(party.getF_INTERNALPARTYID());
						qParams.clear();
						qParams.add(party.getF_INTERNALPARTYID());
						qParams.add("SMS");
						qParams.add("PERSONALMOBILE");
						IBOPT_PFN_PartyContactDetails contactDetails = (IBOPT_PFN_PartyContactDetails) BankFusionThreadLocal
								.getPersistanceFactory().findFirstByQuery(IBOPT_PFN_PartyContactDetails.BONAME,
										FIND_CONTACT_DETAILS, qParams, true);
						if(contactDetails!=null)
							subsidyDetails.setF_IBCONTACTNUM(contactDetails.getF_CONTACTVALUE());
					}else {
						continue;
					}
					
				}
				String amnt = getCellAsString(row, colIdx++).replace(",", "");
				subsidyDetails
						.setF_IBUPLOADAMOUNT(!StringUtils.isEmpty(amnt) ? new BigDecimal(amnt) : new BigDecimal(0));
				subsidyDetails.setF_IBUPLOADDATE(SystemInformationManager.getInstance().getBFBusinessDate());
				subsidyDetails.setF_IBUPLOADEDBY(
						BankFusionThreadLocal.getBankFusionEnvironment().getUserSession().getUserId());
				subsidyDetails.setF_IBPROCESSINGYEAR(year);
				subsidyDetails.setF_IBPROCESSEDDATE(null);
				subsidyDetails.setF_IBSTATUS("N");
				factory.create(IBOCE_ADF_GovtSubsidy.BONAME, subsidyDetails);

			}
			factory.commitTransaction();
		} catch (Exception e) {
			factory.rollbackTransaction();
			throw e;
		} finally {
			factory.closePrivateSession();
			wb.close();
		}
		return true;
	}

	public String getEventMessage(int eventNumber, String[] stringParams) {
		String params = Arrays.asList(stringParams).toString().replace("[", "").replace("]", "");
		return BankFusionMessages.getInstance().getFormattedEventMessage(eventNumber, new Object[] { params },
				BankFusionThreadLocal.getUserSession().getUserLocale());
	}
	private boolean isDuplicateFile(int year) {
		CB_CMN_PrivateSession session = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory factory = session.createSession();
		try {
			factory.beginTransaction();
			ArrayList params = new ArrayList();
			params.add(year);
			Iterator listOfFiles = factory.findByQuery(IBOCE_ADF_GovtSubsidy.BONAME, DUPLICATE_FILE_QUERY , params, 2, true);
			if(listOfFiles!=null && listOfFiles.hasNext())
			{
				return true;
			}
		}finally {
			factory.commitTransaction();
			factory.closePrivateSession();
		}
		return false;
	}
}
